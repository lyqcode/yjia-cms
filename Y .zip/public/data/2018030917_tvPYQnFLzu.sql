-- 2018-03-09 17:36:29--
-- 表的结构 `yzh_access`
-- 
DROP TABLE IF EXISTS `yzh_access`;
CREATE TABLE `yzh_access` (
  `role_id` smallint(6) unsigned NOT NULL DEFAULT '0',
  `node_id` smallint(6) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `pid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `model` varchar(50) NOT NULL DEFAULT '',
  KEY `groupId` (`role_id`),
  KEY `nodeId` (`node_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- 导出`yzh_access`表中的数据 `yzh_access`
--
INSERT INTO `yzh_access` VALUES ('2','223','3','84','');
INSERT INTO `yzh_access` VALUES ('2','222','3','84','');
INSERT INTO `yzh_access` VALUES ('2','221','3','84','');
INSERT INTO `yzh_access` VALUES ('2','220','3','84','');
INSERT INTO `yzh_access` VALUES ('2','219','3','84','');
INSERT INTO `yzh_access` VALUES ('2','218','3','47','');
INSERT INTO `yzh_access` VALUES ('2','217','3','47','');
INSERT INTO `yzh_access` VALUES ('2','216','3','209','');
INSERT INTO `yzh_access` VALUES ('2','215','3','209','');
INSERT INTO `yzh_access` VALUES ('2','214','3','209','');
INSERT INTO `yzh_access` VALUES ('2','213','3','209','');
INSERT INTO `yzh_access` VALUES ('2','212','3','209','');
INSERT INTO `yzh_access` VALUES ('2','211','3','209','');
INSERT INTO `yzh_access` VALUES ('2','210','3','209','');
INSERT INTO `yzh_access` VALUES ('2','209','2','1','');
INSERT INTO `yzh_access` VALUES ('2','208','3','71','');
INSERT INTO `yzh_access` VALUES ('2','207','3','71','');
INSERT INTO `yzh_access` VALUES ('2','206','3','71','');
INSERT INTO `yzh_access` VALUES ('2','205','3','84','');
INSERT INTO `yzh_access` VALUES ('2','204','3','143','');
INSERT INTO `yzh_access` VALUES ('2','203','3','19','');
INSERT INTO `yzh_access` VALUES ('2','202','3','172','');
INSERT INTO `yzh_access` VALUES ('2','201','3','105','');
INSERT INTO `yzh_access` VALUES ('2','200','3','199','');
INSERT INTO `yzh_access` VALUES ('2','199','2','1','');
INSERT INTO `yzh_access` VALUES ('2','198','3','157','');
INSERT INTO `yzh_access` VALUES ('2','197','3','151','');
INSERT INTO `yzh_access` VALUES ('2','195','3','66','');
INSERT INTO `yzh_access` VALUES ('2','194','3','64','');
INSERT INTO `yzh_access` VALUES ('2','193','3','63','');
INSERT INTO `yzh_access` VALUES ('2','192','3','56','');
INSERT INTO `yzh_access` VALUES ('2','191','3','49','');
INSERT INTO `yzh_access` VALUES ('2','190','3','42','');
INSERT INTO `yzh_access` VALUES ('2','189','3','31','');
INSERT INTO `yzh_access` VALUES ('2','188','3','24','');
INSERT INTO `yzh_access` VALUES ('2','187','2','1','');
INSERT INTO `yzh_access` VALUES ('2','186','3','143','');
INSERT INTO `yzh_access` VALUES ('2','185','3','187','');
INSERT INTO `yzh_access` VALUES ('2','184','3','187','');
INSERT INTO `yzh_access` VALUES ('2','183','3','121','');
INSERT INTO `yzh_access` VALUES ('2','182','3','107','');
INSERT INTO `yzh_access` VALUES ('2','181','3','173','');
INSERT INTO `yzh_access` VALUES ('2','180','3','173','');
INSERT INTO `yzh_access` VALUES ('2','179','3','123','');
INSERT INTO `yzh_access` VALUES ('2','178','3','105','');
INSERT INTO `yzh_access` VALUES ('2','177','3','78','');
INSERT INTO `yzh_access` VALUES ('2','176','3','2','');
INSERT INTO `yzh_access` VALUES ('2','175','3','187','');
INSERT INTO `yzh_access` VALUES ('2','174','3','78','');
INSERT INTO `yzh_access` VALUES ('2','173','2','1','');
INSERT INTO `yzh_access` VALUES ('2','172','2','1','');
INSERT INTO `yzh_access` VALUES ('2','171','3','64','');
INSERT INTO `yzh_access` VALUES ('2','170','3','63','');
INSERT INTO `yzh_access` VALUES ('2','169','3','56','');
INSERT INTO `yzh_access` VALUES ('2','168','3','49','');
INSERT INTO `yzh_access` VALUES ('2','167','3','42','');
INSERT INTO `yzh_access` VALUES ('2','166','3','31','');
INSERT INTO `yzh_access` VALUES ('2','165','3','21','');
INSERT INTO `yzh_access` VALUES ('2','164','3','47','');
INSERT INTO `yzh_access` VALUES ('2','163','3','107','');
INSERT INTO `yzh_access` VALUES ('2','162','3','73','');
INSERT INTO `yzh_access` VALUES ('2','161','3','157','');
INSERT INTO `yzh_access` VALUES ('2','160','3','157','');
INSERT INTO `yzh_access` VALUES ('2','159','3','157','');
INSERT INTO `yzh_access` VALUES ('2','158','3','157','');
INSERT INTO `yzh_access` VALUES ('2','157','2','1','');
INSERT INTO `yzh_access` VALUES ('2','156','3','151','');
INSERT INTO `yzh_access` VALUES ('2','155','3','151','');
INSERT INTO `yzh_access` VALUES ('2','154','3','151','');
INSERT INTO `yzh_access` VALUES ('2','153','3','151','');
INSERT INTO `yzh_access` VALUES ('2','152','3','64','');
INSERT INTO `yzh_access` VALUES ('2','151','2','1','');
INSERT INTO `yzh_access` VALUES ('2','150','3','123','');
INSERT INTO `yzh_access` VALUES ('2','149','3','142','');
INSERT INTO `yzh_access` VALUES ('2','148','3','143','');
INSERT INTO `yzh_access` VALUES ('2','147','3','143','');
INSERT INTO `yzh_access` VALUES ('2','146','3','143','');
INSERT INTO `yzh_access` VALUES ('2','145','3','143','');
INSERT INTO `yzh_access` VALUES ('2','144','3','143','');
INSERT INTO `yzh_access` VALUES ('2','143','2','1','');
INSERT INTO `yzh_access` VALUES ('2','142','2','1','');
INSERT INTO `yzh_access` VALUES ('2','141','3','5','');
INSERT INTO `yzh_access` VALUES ('2','140','3','84','');
INSERT INTO `yzh_access` VALUES ('2','139','3','84','');
INSERT INTO `yzh_access` VALUES ('2','138','3','84','');
INSERT INTO `yzh_access` VALUES ('2','136','3','74','');
INSERT INTO `yzh_access` VALUES ('2','135','3','72','');
INSERT INTO `yzh_access` VALUES ('2','133','3','199','');
INSERT INTO `yzh_access` VALUES ('2','132','3','66','');
INSERT INTO `yzh_access` VALUES ('2','131','3','70','');
INSERT INTO `yzh_access` VALUES ('2','130','3','105','');
INSERT INTO `yzh_access` VALUES ('2','129','3','65','');
INSERT INTO `yzh_access` VALUES ('2','128','3','123','');
INSERT INTO `yzh_access` VALUES ('2','127','3','82','');
INSERT INTO `yzh_access` VALUES ('2','126','3','84','');
INSERT INTO `yzh_access` VALUES ('2','125','3','76','');
INSERT INTO `yzh_access` VALUES ('2','124','3','105','');
INSERT INTO `yzh_access` VALUES ('2','123','2','1','');
INSERT INTO `yzh_access` VALUES ('2','122','3','187','');
INSERT INTO `yzh_access` VALUES ('2','121','2','1','');
INSERT INTO `yzh_access` VALUES ('2','120','3','105','');
INSERT INTO `yzh_access` VALUES ('2','119','3','82','');
INSERT INTO `yzh_access` VALUES ('2','118','3','82','');
INSERT INTO `yzh_access` VALUES ('2','117','3','121','');
INSERT INTO `yzh_access` VALUES ('2','116','3','70','');
INSERT INTO `yzh_access` VALUES ('2','115','3','66','');
INSERT INTO `yzh_access` VALUES ('2','114','3','72','');
INSERT INTO `yzh_access` VALUES ('2','113','3','63','');
INSERT INTO `yzh_access` VALUES ('2','112','3','76','');
INSERT INTO `yzh_access` VALUES ('2','111','3','64','');
INSERT INTO `yzh_access` VALUES ('2','110','3','64','');
INSERT INTO `yzh_access` VALUES ('2','109','3','63','');
INSERT INTO `yzh_access` VALUES ('2','108','3','121','');
INSERT INTO `yzh_access` VALUES ('2','107','2','1','');
INSERT INTO `yzh_access` VALUES ('2','106','3','64','');
INSERT INTO `yzh_access` VALUES ('2','105','2','1','');
INSERT INTO `yzh_access` VALUES ('2','104','3','63','');
INSERT INTO `yzh_access` VALUES ('2','103','3','70','');
INSERT INTO `yzh_access` VALUES ('2','102','3','66','');
INSERT INTO `yzh_access` VALUES ('2','101','3','65','');
INSERT INTO `yzh_access` VALUES ('2','100','3','76','');
INSERT INTO `yzh_access` VALUES ('2','98','3','64','');
INSERT INTO `yzh_access` VALUES ('2','97','3','105','');
INSERT INTO `yzh_access` VALUES ('2','96','3','63','');
INSERT INTO `yzh_access` VALUES ('2','95','3','65','');
INSERT INTO `yzh_access` VALUES ('2','93','3','80','');
INSERT INTO `yzh_access` VALUES ('2','92','3','76','');
INSERT INTO `yzh_access` VALUES ('2','91','3','73','');
INSERT INTO `yzh_access` VALUES ('2','90','3','63','');
INSERT INTO `yzh_access` VALUES ('2','89','3','66','');
INSERT INTO `yzh_access` VALUES ('2','88','3','74','');
INSERT INTO `yzh_access` VALUES ('2','87','3','72','');
INSERT INTO `yzh_access` VALUES ('2','86','3','71','');
INSERT INTO `yzh_access` VALUES ('2','85','3','70','');
INSERT INTO `yzh_access` VALUES ('2','84','2','1','');
INSERT INTO `yzh_access` VALUES ('2','83','3','65','');
INSERT INTO `yzh_access` VALUES ('2','82','2','1','');
INSERT INTO `yzh_access` VALUES ('2','80','2','1','');
INSERT INTO `yzh_access` VALUES ('2','78','2','1','');
INSERT INTO `yzh_access` VALUES ('2','77','3','78','');
INSERT INTO `yzh_access` VALUES ('2','76','2','1','');
INSERT INTO `yzh_access` VALUES ('2','75','3','47','');
INSERT INTO `yzh_access` VALUES ('2','74','2','1','');
INSERT INTO `yzh_access` VALUES ('2','73','2','1','');
INSERT INTO `yzh_access` VALUES ('2','72','2','1','');
INSERT INTO `yzh_access` VALUES ('2','71','2','1','');
INSERT INTO `yzh_access` VALUES ('2','70','2','1','');
INSERT INTO `yzh_access` VALUES ('2','69','3','19','');
INSERT INTO `yzh_access` VALUES ('2','68','3','105','');
INSERT INTO `yzh_access` VALUES ('2','67','3','5','');
INSERT INTO `yzh_access` VALUES ('2','66','2','1','');
INSERT INTO `yzh_access` VALUES ('2','65','2','1','');
INSERT INTO `yzh_access` VALUES ('2','64','2','1','');
INSERT INTO `yzh_access` VALUES ('2','63','2','1','');
INSERT INTO `yzh_access` VALUES ('2','62','3','56','');
INSERT INTO `yzh_access` VALUES ('2','61','3','199','');
INSERT INTO `yzh_access` VALUES ('2','60','3','56','');
INSERT INTO `yzh_access` VALUES ('2','59','3','56','');
INSERT INTO `yzh_access` VALUES ('2','58','3','56','');
INSERT INTO `yzh_access` VALUES ('2','57','3','56','');
INSERT INTO `yzh_access` VALUES ('2','56','2','1','');
INSERT INTO `yzh_access` VALUES ('2','55','3','49','');
INSERT INTO `yzh_access` VALUES ('2','54','3','47','');
INSERT INTO `yzh_access` VALUES ('2','53','3','49','');
INSERT INTO `yzh_access` VALUES ('2','52','3','49','');
INSERT INTO `yzh_access` VALUES ('2','51','3','49','');
INSERT INTO `yzh_access` VALUES ('2','50','3','49','');
INSERT INTO `yzh_access` VALUES ('2','49','2','1','');
INSERT INTO `yzh_access` VALUES ('2','48','3','42','');
INSERT INTO `yzh_access` VALUES ('2','47','2','1','');
INSERT INTO `yzh_access` VALUES ('2','46','3','42','');
INSERT INTO `yzh_access` VALUES ('2','45','3','42','');
INSERT INTO `yzh_access` VALUES ('2','44','3','42','');
INSERT INTO `yzh_access` VALUES ('2','43','3','42','');
INSERT INTO `yzh_access` VALUES ('2','42','2','1','');
INSERT INTO `yzh_access` VALUES ('2','41','3','38','');
INSERT INTO `yzh_access` VALUES ('2','40','3','38','');
INSERT INTO `yzh_access` VALUES ('2','39','3','38','');
INSERT INTO `yzh_access` VALUES ('2','38','2','1','');
INSERT INTO `yzh_access` VALUES ('2','37','3','31','');
INSERT INTO `yzh_access` VALUES ('2','36','3','31','');
INSERT INTO `yzh_access` VALUES ('2','35','3','31','');
INSERT INTO `yzh_access` VALUES ('2','34','3','31','');
INSERT INTO `yzh_access` VALUES ('2','33','3','31','');
INSERT INTO `yzh_access` VALUES ('2','32','3','31','');
INSERT INTO `yzh_access` VALUES ('2','31','2','1','');
INSERT INTO `yzh_access` VALUES ('2','30','3','24','');
INSERT INTO `yzh_access` VALUES ('2','29','3','24','');
INSERT INTO `yzh_access` VALUES ('2','28','3','24','');
INSERT INTO `yzh_access` VALUES ('2','27','3','24','');
INSERT INTO `yzh_access` VALUES ('2','26','3','107','');
INSERT INTO `yzh_access` VALUES ('2','25','3','24','');
INSERT INTO `yzh_access` VALUES ('2','24','2','1','');
INSERT INTO `yzh_access` VALUES ('2','23','3','21','');
INSERT INTO `yzh_access` VALUES ('2','22','3','21','');
INSERT INTO `yzh_access` VALUES ('2','21','2','1','');
INSERT INTO `yzh_access` VALUES ('2','20','3','19','');
INSERT INTO `yzh_access` VALUES ('2','19','2','1','');
INSERT INTO `yzh_access` VALUES ('2','13','3','9','');
INSERT INTO `yzh_access` VALUES ('2','12','3','9','');
INSERT INTO `yzh_access` VALUES ('2','11','3','9','');
INSERT INTO `yzh_access` VALUES ('2','10','3','9','');
INSERT INTO `yzh_access` VALUES ('2','9','2','1','');
INSERT INTO `yzh_access` VALUES ('2','8','3','76','');
INSERT INTO `yzh_access` VALUES ('2','7','3','78','');
INSERT INTO `yzh_access` VALUES ('2','6','3','5','');
INSERT INTO `yzh_access` VALUES ('2','5','2','1','');
INSERT INTO `yzh_access` VALUES ('2','4','3','2','');
INSERT INTO `yzh_access` VALUES ('2','3','3','2','');
INSERT INTO `yzh_access` VALUES ('2','2','2','1','');
INSERT INTO `yzh_access` VALUES ('2','1','1','0','');
--
-- 表的结构 `yzh_action`
-- 
DROP TABLE IF EXISTS `yzh_action`;
CREATE TABLE `yzh_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '行为唯一标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '行为说明',
  `remark` char(140) NOT NULL DEFAULT '' COMMENT '行为描述',
  `rule` text NOT NULL COMMENT '行为规则',
  `log` text NOT NULL COMMENT '日志规则',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8  COMMENT='系统行为表';

-- 
-- 导出`yzh_action`表中的数据 `yzh_action`
--
INSERT INTO `yzh_action` VALUES ('1','user_login','用户登录','积分+10，每天一次','table:member|field:score|condition:uid={$self} AND status>-1|rule:score+10|cycle:24|max:1;','[user|get_nickname]在[time|time_format]登录了后台','1','1','1387181220');
INSERT INTO `yzh_action` VALUES ('2','add_article','发布文章','积分+5，每天上限5次','table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:5','','2','0','1380173180');
INSERT INTO `yzh_action` VALUES ('6','update_config','更新配置','新增或修改或删除配置','','','1','1','1383294988');
INSERT INTO `yzh_action` VALUES ('7','update_model','更新模型','新增或修改模型','','','1','1','1383295057');
INSERT INTO `yzh_action` VALUES ('8','update_attribute','更新属性','新增或更新或删除属性','','','1','1','1383295963');
INSERT INTO `yzh_action` VALUES ('9','update_channel','更新导航','新增或修改或删除导航','','','1','1','1383296301');
INSERT INTO `yzh_action` VALUES ('10','update_menu','更新菜单','新增或修改或删除菜单','','','1','1','1383296392');
INSERT INTO `yzh_action` VALUES ('11','update_category','更新分类','新增或修改或删除分类','','','1','1','1383296765');
--
-- 表的结构 `yzh_action_log`
-- 
DROP TABLE IF EXISTS `yzh_action_log`;
CREATE TABLE `yzh_action_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `action_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '行为id',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行用户id',
  `action_ip` bigint(20) NOT NULL COMMENT '执行行为者ip',
  `model` varchar(50) NOT NULL DEFAULT '' COMMENT '触发行为的表',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '触发行为的数据id',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '日志备注',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行行为的时间',
  PRIMARY KEY (`id`),
  KEY `action_ip_ix` (`action_ip`),
  KEY `action_id_ix` (`action_id`),
  KEY `user_id_ix` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='行为日志表';

-- 
-- 导出`yzh_action_log`表中的数据 `yzh_action_log`
--
INSERT INTO `yzh_action_log` VALUES ('1','1','1','2004549706','user','1','super在2018-02-28 10:25登录了后台','1','1519784722');
INSERT INTO `yzh_action_log` VALUES ('2','1','1','2004549706','user','1','super在2018-02-28 10:33登录了后台','1','1519785209');
INSERT INTO `yzh_action_log` VALUES ('3','1','1','2004549706','user','1','super在2018-02-28 10:44登录了后台','1','1519785846');
INSERT INTO `yzh_action_log` VALUES ('4','1','1','2004549706','user','1','super在2018-02-28 16:52登录了后台','1','1519807960');
INSERT INTO `yzh_action_log` VALUES ('5','1','1','2004549848','user','1','super在2018-03-01 09:04登录了后台','1','1519866299');
INSERT INTO `yzh_action_log` VALUES ('6','1','1','1903605776','user','1','super在2018-03-03 13:41登录了后台','1','1520055667');
INSERT INTO `yzh_action_log` VALUES ('7','1','1','2004557331','user','1','super在2018-03-06 14:31登录了后台','1','1520317891');
INSERT INTO `yzh_action_log` VALUES ('8','1','1','2004557331','user','1','super在2018-03-06 14:32登录了后台','1','1520317968');
INSERT INTO `yzh_action_log` VALUES ('9','1','1','2004557331','user','1','super在2018-03-06 14:37登录了后台','1','1520318278');
INSERT INTO `yzh_action_log` VALUES ('10','1','1','2004557331','user','1','super在2018-03-06 14:39登录了后台','1','1520318361');
INSERT INTO `yzh_action_log` VALUES ('11','1','1','2004557331','user','1','super在2018-03-06 14:39登录了后台','1','1520318365');
INSERT INTO `yzh_action_log` VALUES ('12','1','1','2004557331','user','1','super在2018-03-06 15:26登录了后台','1','1520321178');
INSERT INTO `yzh_action_log` VALUES ('13','1','1','2004557331','user','1','super在2018-03-06 15:39登录了后台','1','1520321979');
INSERT INTO `yzh_action_log` VALUES ('14','1','1','2004557331','user','1','super在2018-03-07 08:47登录了后台','1','1520383675');
INSERT INTO `yzh_action_log` VALUES ('15','1','1','2004557331','user','1','super在2018-03-07 10:26登录了后台','1','1520389564');
INSERT INTO `yzh_action_log` VALUES ('16','1','1','2004557331','user','1','super在2018-03-07 14:16登录了后台','1','1520403375');
INSERT INTO `yzh_action_log` VALUES ('17','1','1','2004550123','user','1','super在2018-03-08 10:59登录了后台','1','1520477978');
INSERT INTO `yzh_action_log` VALUES ('18','1','1','2004550123','user','1','super在2018-03-08 14:39登录了后台','1','1520491180');
INSERT INTO `yzh_action_log` VALUES ('19','1','1','2004550123','user','1','super在2018-03-09 09:45登录了后台','1','1520559913');
INSERT INTO `yzh_action_log` VALUES ('20','1','1','2004550123','user','1','super在2018-03-09 09:45登录了后台','1','1520559931');
INSERT INTO `yzh_action_log` VALUES ('21','1','1','2004550123','user','1','super在2018-03-09 17:36登录了后台','1','1520588167');
--
-- 表的结构 `yzh_area`
-- 
DROP TABLE IF EXISTS `yzh_area`;
CREATE TABLE `yzh_area` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT '',
  `listorder` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3267 DEFAULT CHARSET=utf8;

-- 
-- 导出`yzh_area`表中的数据 `yzh_area`
--
INSERT INTO `yzh_area` VALUES ('1','0','﻿北京','0');
INSERT INTO `yzh_area` VALUES ('2','1','北京市','0');
INSERT INTO `yzh_area` VALUES ('3','2','东城区','0');
INSERT INTO `yzh_area` VALUES ('4','2','西城区','0');
INSERT INTO `yzh_area` VALUES ('5','2','崇文区','0');
INSERT INTO `yzh_area` VALUES ('6','2','宣武区','0');
INSERT INTO `yzh_area` VALUES ('7','2','朝阳区','0');
INSERT INTO `yzh_area` VALUES ('8','2','丰台区','0');
INSERT INTO `yzh_area` VALUES ('9','2','石景山区','0');
INSERT INTO `yzh_area` VALUES ('10','2','海淀区','0');
INSERT INTO `yzh_area` VALUES ('11','2','门头沟区','0');
INSERT INTO `yzh_area` VALUES ('12','2','房山区','0');
INSERT INTO `yzh_area` VALUES ('13','2','通州区','0');
INSERT INTO `yzh_area` VALUES ('14','2','顺义区','0');
INSERT INTO `yzh_area` VALUES ('15','2','昌平区','0');
INSERT INTO `yzh_area` VALUES ('16','2','大兴区','0');
INSERT INTO `yzh_area` VALUES ('17','2','怀柔区','0');
INSERT INTO `yzh_area` VALUES ('18','2','平谷区','0');
INSERT INTO `yzh_area` VALUES ('19','2','密云县','0');
INSERT INTO `yzh_area` VALUES ('20','2','延庆县','0');
INSERT INTO `yzh_area` VALUES ('21','0','上海','0');
INSERT INTO `yzh_area` VALUES ('22','21','上海市','0');
INSERT INTO `yzh_area` VALUES ('23','22','黄浦区','0');
INSERT INTO `yzh_area` VALUES ('24','22','卢湾区','0');
INSERT INTO `yzh_area` VALUES ('25','22','徐汇区','0');
INSERT INTO `yzh_area` VALUES ('26','22','长宁区','0');
INSERT INTO `yzh_area` VALUES ('27','22','静安区','0');
INSERT INTO `yzh_area` VALUES ('28','22','普陀区','0');
INSERT INTO `yzh_area` VALUES ('29','22','闸北区','0');
INSERT INTO `yzh_area` VALUES ('30','22','虹口区','0');
INSERT INTO `yzh_area` VALUES ('31','22','杨浦区','0');
INSERT INTO `yzh_area` VALUES ('32','22','闵行区','0');
INSERT INTO `yzh_area` VALUES ('33','22','宝山区','0');
INSERT INTO `yzh_area` VALUES ('34','22','嘉定区','0');
INSERT INTO `yzh_area` VALUES ('35','22','浦东新区','0');
INSERT INTO `yzh_area` VALUES ('36','22','金山区','0');
INSERT INTO `yzh_area` VALUES ('37','22','松江区','0');
INSERT INTO `yzh_area` VALUES ('38','22','青浦区','0');
INSERT INTO `yzh_area` VALUES ('39','22','南汇区','0');
INSERT INTO `yzh_area` VALUES ('40','22','奉贤区','0');
INSERT INTO `yzh_area` VALUES ('41','22','崇明县','0');
INSERT INTO `yzh_area` VALUES ('42','0','天津','0');
INSERT INTO `yzh_area` VALUES ('43','42','天津市','0');
INSERT INTO `yzh_area` VALUES ('44','43','和平区','0');
INSERT INTO `yzh_area` VALUES ('45','43','河东区','0');
INSERT INTO `yzh_area` VALUES ('46','43','河西区','0');
INSERT INTO `yzh_area` VALUES ('47','43','南开区','0');
INSERT INTO `yzh_area` VALUES ('48','43','河北区','0');
INSERT INTO `yzh_area` VALUES ('49','43','红桥区','0');
INSERT INTO `yzh_area` VALUES ('50','43','塘沽区','0');
INSERT INTO `yzh_area` VALUES ('51','43','汉沽区','0');
INSERT INTO `yzh_area` VALUES ('52','43','大港区','0');
INSERT INTO `yzh_area` VALUES ('53','43','东丽区','0');
INSERT INTO `yzh_area` VALUES ('54','43','西青区','0');
INSERT INTO `yzh_area` VALUES ('55','43','津南区','0');
INSERT INTO `yzh_area` VALUES ('56','43','北辰区','0');
INSERT INTO `yzh_area` VALUES ('57','43','武清区','0');
INSERT INTO `yzh_area` VALUES ('58','43','宝坻区','0');
INSERT INTO `yzh_area` VALUES ('59','43','宁河县','0');
INSERT INTO `yzh_area` VALUES ('60','43','静海县','0');
INSERT INTO `yzh_area` VALUES ('61','43','蓟县','0');
INSERT INTO `yzh_area` VALUES ('62','0','重庆','0');
INSERT INTO `yzh_area` VALUES ('63','62','重庆市','0');
INSERT INTO `yzh_area` VALUES ('64','63','万州区','0');
INSERT INTO `yzh_area` VALUES ('65','63','涪陵区','0');
INSERT INTO `yzh_area` VALUES ('66','63','渝中区','0');
INSERT INTO `yzh_area` VALUES ('67','63','大渡口区','0');
INSERT INTO `yzh_area` VALUES ('68','63','江北区','0');
INSERT INTO `yzh_area` VALUES ('69','63','沙坪坝区','0');
INSERT INTO `yzh_area` VALUES ('70','63','九龙坡区','0');
INSERT INTO `yzh_area` VALUES ('71','63','南岸区','0');
INSERT INTO `yzh_area` VALUES ('72','63','北碚区','0');
INSERT INTO `yzh_area` VALUES ('73','63','万盛区','0');
INSERT INTO `yzh_area` VALUES ('74','63','双桥区','0');
INSERT INTO `yzh_area` VALUES ('75','63','渝北区','0');
INSERT INTO `yzh_area` VALUES ('76','63','巴南区','0');
INSERT INTO `yzh_area` VALUES ('77','63','黔江区','0');
INSERT INTO `yzh_area` VALUES ('78','63','长寿区','0');
INSERT INTO `yzh_area` VALUES ('79','63','綦江县','0');
INSERT INTO `yzh_area` VALUES ('80','63','潼南县','0');
INSERT INTO `yzh_area` VALUES ('81','63','铜梁县','0');
INSERT INTO `yzh_area` VALUES ('82','63','大足县','0');
INSERT INTO `yzh_area` VALUES ('83','63','荣昌县','0');
INSERT INTO `yzh_area` VALUES ('84','63','璧山县','0');
INSERT INTO `yzh_area` VALUES ('85','63','梁平县','0');
INSERT INTO `yzh_area` VALUES ('86','63','城口县','0');
INSERT INTO `yzh_area` VALUES ('87','63','丰都县','0');
INSERT INTO `yzh_area` VALUES ('88','63','垫江县','0');
INSERT INTO `yzh_area` VALUES ('89','63','武隆县','0');
INSERT INTO `yzh_area` VALUES ('90','63','忠县','0');
INSERT INTO `yzh_area` VALUES ('91','63','开县','0');
INSERT INTO `yzh_area` VALUES ('92','63','云阳县','0');
INSERT INTO `yzh_area` VALUES ('93','63','奉节县','0');
INSERT INTO `yzh_area` VALUES ('94','63','巫山县','0');
INSERT INTO `yzh_area` VALUES ('95','63','巫溪县','0');
INSERT INTO `yzh_area` VALUES ('96','63','石柱土家族自治县','0');
INSERT INTO `yzh_area` VALUES ('97','63','秀山土家族苗族自治县','0');
INSERT INTO `yzh_area` VALUES ('98','63','酉阳土家族苗族自治县','0');
INSERT INTO `yzh_area` VALUES ('99','63','彭水苗族土家族自治县','0');
INSERT INTO `yzh_area` VALUES ('100','63','江津市','0');
INSERT INTO `yzh_area` VALUES ('101','63','合川市','0');
INSERT INTO `yzh_area` VALUES ('102','63','永川市','0');
INSERT INTO `yzh_area` VALUES ('103','63','南川市','0');
INSERT INTO `yzh_area` VALUES ('104','0','安徽','0');
INSERT INTO `yzh_area` VALUES ('105','104','合肥市','0');
INSERT INTO `yzh_area` VALUES ('106','105','瑶海区','0');
INSERT INTO `yzh_area` VALUES ('107','105','庐阳区','0');
INSERT INTO `yzh_area` VALUES ('108','105','蜀山区','0');
INSERT INTO `yzh_area` VALUES ('109','105','包河区','0');
INSERT INTO `yzh_area` VALUES ('110','105','长丰县','0');
INSERT INTO `yzh_area` VALUES ('111','105','肥东县','0');
INSERT INTO `yzh_area` VALUES ('112','105','肥西县','0');
INSERT INTO `yzh_area` VALUES ('113','104','安庆市','0');
INSERT INTO `yzh_area` VALUES ('114','113','迎江区','0');
INSERT INTO `yzh_area` VALUES ('115','113','大观区','0');
INSERT INTO `yzh_area` VALUES ('116','113','郊区','0');
INSERT INTO `yzh_area` VALUES ('117','113','怀宁县','0');
INSERT INTO `yzh_area` VALUES ('118','113','枞阳县','0');
INSERT INTO `yzh_area` VALUES ('119','113','潜山县','0');
INSERT INTO `yzh_area` VALUES ('120','113','太湖县','0');
INSERT INTO `yzh_area` VALUES ('121','113','宿松县','0');
INSERT INTO `yzh_area` VALUES ('122','113','望江县','0');
INSERT INTO `yzh_area` VALUES ('123','113','岳西县','0');
INSERT INTO `yzh_area` VALUES ('124','113','桐城市','0');
INSERT INTO `yzh_area` VALUES ('125','104','蚌埠市','0');
INSERT INTO `yzh_area` VALUES ('126','125','龙子湖区','0');
INSERT INTO `yzh_area` VALUES ('127','125','蚌山区','0');
INSERT INTO `yzh_area` VALUES ('128','125','禹会区','0');
INSERT INTO `yzh_area` VALUES ('129','125','淮上区','0');
INSERT INTO `yzh_area` VALUES ('130','125','怀远县','0');
INSERT INTO `yzh_area` VALUES ('131','125','五河县','0');
INSERT INTO `yzh_area` VALUES ('132','125','固镇县','0');
INSERT INTO `yzh_area` VALUES ('133','104','亳州市','0');
INSERT INTO `yzh_area` VALUES ('134','133','谯城区','0');
INSERT INTO `yzh_area` VALUES ('135','133','涡阳县','0');
INSERT INTO `yzh_area` VALUES ('136','133','蒙城县','0');
INSERT INTO `yzh_area` VALUES ('137','133','利辛县','0');
INSERT INTO `yzh_area` VALUES ('138','104','巢湖市','0');
INSERT INTO `yzh_area` VALUES ('139','138','居巢区','0');
INSERT INTO `yzh_area` VALUES ('140','138','庐江县','0');
INSERT INTO `yzh_area` VALUES ('141','138','无为县','0');
INSERT INTO `yzh_area` VALUES ('142','138','含山县','0');
INSERT INTO `yzh_area` VALUES ('143','138','和县','0');
INSERT INTO `yzh_area` VALUES ('144','104','池州市','0');
INSERT INTO `yzh_area` VALUES ('145','144','贵池区','0');
INSERT INTO `yzh_area` VALUES ('146','144','东至县','0');
INSERT INTO `yzh_area` VALUES ('147','144','石台县','0');
INSERT INTO `yzh_area` VALUES ('148','144','青阳县','0');
INSERT INTO `yzh_area` VALUES ('149','104','滁州市','0');
INSERT INTO `yzh_area` VALUES ('150','149','琅琊区','0');
INSERT INTO `yzh_area` VALUES ('151','149','南谯区','0');
INSERT INTO `yzh_area` VALUES ('152','149','来安县','0');
INSERT INTO `yzh_area` VALUES ('153','149','全椒县','0');
INSERT INTO `yzh_area` VALUES ('154','149','定远县','0');
INSERT INTO `yzh_area` VALUES ('155','149','凤阳县','0');
INSERT INTO `yzh_area` VALUES ('156','149','天长市','0');
INSERT INTO `yzh_area` VALUES ('157','149','明光市','0');
INSERT INTO `yzh_area` VALUES ('158','104','阜阳市','0');
INSERT INTO `yzh_area` VALUES ('159','158','颍州区','0');
INSERT INTO `yzh_area` VALUES ('160','158','颍东区','0');
INSERT INTO `yzh_area` VALUES ('161','158','颍泉区','0');
INSERT INTO `yzh_area` VALUES ('162','158','临泉县','0');
INSERT INTO `yzh_area` VALUES ('163','158','太和县','0');
INSERT INTO `yzh_area` VALUES ('164','158','阜南县','0');
INSERT INTO `yzh_area` VALUES ('165','158','颍上县','0');
INSERT INTO `yzh_area` VALUES ('166','158','界首市','0');
INSERT INTO `yzh_area` VALUES ('167','104','淮北市','0');
INSERT INTO `yzh_area` VALUES ('168','167','杜集区','0');
INSERT INTO `yzh_area` VALUES ('169','167','相山区','0');
INSERT INTO `yzh_area` VALUES ('170','167','烈山区','0');
INSERT INTO `yzh_area` VALUES ('171','167','濉溪县','0');
INSERT INTO `yzh_area` VALUES ('172','104','淮南市','0');
INSERT INTO `yzh_area` VALUES ('173','172','大通区','0');
INSERT INTO `yzh_area` VALUES ('174','172','田家庵区','0');
INSERT INTO `yzh_area` VALUES ('175','172','谢家集区','0');
INSERT INTO `yzh_area` VALUES ('176','172','八公山区','0');
INSERT INTO `yzh_area` VALUES ('177','172','潘集区','0');
INSERT INTO `yzh_area` VALUES ('178','172','凤台县','0');
INSERT INTO `yzh_area` VALUES ('179','104','黄山市','0');
INSERT INTO `yzh_area` VALUES ('180','179','屯溪区','0');
INSERT INTO `yzh_area` VALUES ('181','179','黄山区','0');
INSERT INTO `yzh_area` VALUES ('182','179','徽州区','0');
INSERT INTO `yzh_area` VALUES ('183','179','歙县','0');
INSERT INTO `yzh_area` VALUES ('184','179','休宁县','0');
INSERT INTO `yzh_area` VALUES ('185','179','黟县','0');
INSERT INTO `yzh_area` VALUES ('186','179','祁门县','0');
INSERT INTO `yzh_area` VALUES ('187','104','六安市','0');
INSERT INTO `yzh_area` VALUES ('188','187','金安区','0');
INSERT INTO `yzh_area` VALUES ('189','187','裕安区','0');
INSERT INTO `yzh_area` VALUES ('190','187','寿县','0');
INSERT INTO `yzh_area` VALUES ('191','187','霍邱县','0');
INSERT INTO `yzh_area` VALUES ('192','187','舒城县','0');
INSERT INTO `yzh_area` VALUES ('193','187','金寨县','0');
INSERT INTO `yzh_area` VALUES ('194','187','霍山县','0');
INSERT INTO `yzh_area` VALUES ('195','104','马鞍山市','0');
INSERT INTO `yzh_area` VALUES ('196','195','金家庄区','0');
INSERT INTO `yzh_area` VALUES ('197','195','花山区','0');
INSERT INTO `yzh_area` VALUES ('198','195','雨山区','0');
INSERT INTO `yzh_area` VALUES ('199','195','当涂县','0');
INSERT INTO `yzh_area` VALUES ('200','104','宿州市','0');
INSERT INTO `yzh_area` VALUES ('201','200','墉桥区','0');
INSERT INTO `yzh_area` VALUES ('202','200','砀山县','0');
INSERT INTO `yzh_area` VALUES ('203','200','萧县','0');
INSERT INTO `yzh_area` VALUES ('204','200','灵璧县','0');
INSERT INTO `yzh_area` VALUES ('205','200','泗县','0');
INSERT INTO `yzh_area` VALUES ('206','104','铜陵市','0');
INSERT INTO `yzh_area` VALUES ('207','206','铜官山区','0');
INSERT INTO `yzh_area` VALUES ('208','206','狮子山区','0');
INSERT INTO `yzh_area` VALUES ('209','206','郊区','0');
INSERT INTO `yzh_area` VALUES ('210','206','铜陵县','0');
INSERT INTO `yzh_area` VALUES ('211','104','芜湖市','0');
INSERT INTO `yzh_area` VALUES ('212','211','镜湖区','0');
INSERT INTO `yzh_area` VALUES ('213','211','马塘区','0');
INSERT INTO `yzh_area` VALUES ('214','211','新芜区','0');
INSERT INTO `yzh_area` VALUES ('215','211','鸠江区','0');
INSERT INTO `yzh_area` VALUES ('216','211','芜湖县','0');
INSERT INTO `yzh_area` VALUES ('217','211','繁昌县','0');
INSERT INTO `yzh_area` VALUES ('218','211','南陵县','0');
INSERT INTO `yzh_area` VALUES ('219','104','宣城市','0');
INSERT INTO `yzh_area` VALUES ('220','219','宣州区','0');
INSERT INTO `yzh_area` VALUES ('221','219','郎溪县','0');
INSERT INTO `yzh_area` VALUES ('222','219','广德县','0');
INSERT INTO `yzh_area` VALUES ('223','219','泾县','0');
INSERT INTO `yzh_area` VALUES ('224','219','绩溪县','0');
INSERT INTO `yzh_area` VALUES ('225','219','旌德县','0');
INSERT INTO `yzh_area` VALUES ('226','219','宁国市','0');
INSERT INTO `yzh_area` VALUES ('227','0','福建','0');
INSERT INTO `yzh_area` VALUES ('228','227','福州市','0');
INSERT INTO `yzh_area` VALUES ('229','228','鼓楼区','0');
INSERT INTO `yzh_area` VALUES ('230','228','台江区','0');
INSERT INTO `yzh_area` VALUES ('231','228','仓山区','0');
INSERT INTO `yzh_area` VALUES ('232','228','马尾区','0');
INSERT INTO `yzh_area` VALUES ('233','228','晋安区','0');
INSERT INTO `yzh_area` VALUES ('234','228','闽侯县','0');
INSERT INTO `yzh_area` VALUES ('235','228','连江县','0');
INSERT INTO `yzh_area` VALUES ('236','228','罗源县','0');
INSERT INTO `yzh_area` VALUES ('237','228','闽清县','0');
INSERT INTO `yzh_area` VALUES ('238','228','永泰县','0');
INSERT INTO `yzh_area` VALUES ('239','228','平潭县','0');
INSERT INTO `yzh_area` VALUES ('240','228','福清市','0');
INSERT INTO `yzh_area` VALUES ('241','228','长乐市','0');
INSERT INTO `yzh_area` VALUES ('242','227','龙岩市','0');
INSERT INTO `yzh_area` VALUES ('243','242','新罗区','0');
INSERT INTO `yzh_area` VALUES ('244','242','长汀县','0');
INSERT INTO `yzh_area` VALUES ('245','242','永定县','0');
INSERT INTO `yzh_area` VALUES ('246','242','上杭县','0');
INSERT INTO `yzh_area` VALUES ('247','242','武平县','0');
INSERT INTO `yzh_area` VALUES ('248','242','连城县','0');
INSERT INTO `yzh_area` VALUES ('249','242','漳平市','0');
INSERT INTO `yzh_area` VALUES ('250','227','南平市','0');
INSERT INTO `yzh_area` VALUES ('251','250','延平区','0');
INSERT INTO `yzh_area` VALUES ('252','250','顺昌县','0');
INSERT INTO `yzh_area` VALUES ('253','250','浦城县','0');
INSERT INTO `yzh_area` VALUES ('254','250','光泽县','0');
INSERT INTO `yzh_area` VALUES ('255','250','松溪县','0');
INSERT INTO `yzh_area` VALUES ('256','250','政和县','0');
INSERT INTO `yzh_area` VALUES ('257','250','邵武市','0');
INSERT INTO `yzh_area` VALUES ('258','250','武夷山市','0');
INSERT INTO `yzh_area` VALUES ('259','250','建瓯市','0');
INSERT INTO `yzh_area` VALUES ('260','250','建阳市','0');
INSERT INTO `yzh_area` VALUES ('261','227','宁德市','0');
INSERT INTO `yzh_area` VALUES ('262','261','蕉城区','0');
INSERT INTO `yzh_area` VALUES ('263','261','霞浦县','0');
INSERT INTO `yzh_area` VALUES ('264','261','古田县','0');
INSERT INTO `yzh_area` VALUES ('265','261','屏南县','0');
INSERT INTO `yzh_area` VALUES ('266','261','寿宁县','0');
INSERT INTO `yzh_area` VALUES ('267','261','周宁县','0');
INSERT INTO `yzh_area` VALUES ('268','261','柘荣县','0');
INSERT INTO `yzh_area` VALUES ('269','261','福安市','0');
INSERT INTO `yzh_area` VALUES ('270','261','福鼎市','0');
INSERT INTO `yzh_area` VALUES ('271','227','莆田市','0');
INSERT INTO `yzh_area` VALUES ('272','271','城厢区','0');
INSERT INTO `yzh_area` VALUES ('273','271','涵江区','0');
INSERT INTO `yzh_area` VALUES ('274','271','荔城区','0');
INSERT INTO `yzh_area` VALUES ('275','271','秀屿区','0');
INSERT INTO `yzh_area` VALUES ('276','271','仙游县','0');
INSERT INTO `yzh_area` VALUES ('277','227','泉州市','0');
INSERT INTO `yzh_area` VALUES ('278','277','鲤城区','0');
INSERT INTO `yzh_area` VALUES ('279','277','丰泽区','0');
INSERT INTO `yzh_area` VALUES ('280','277','洛江区','0');
INSERT INTO `yzh_area` VALUES ('281','277','泉港区','0');
INSERT INTO `yzh_area` VALUES ('282','277','惠安县','0');
INSERT INTO `yzh_area` VALUES ('283','277','安溪县','0');
INSERT INTO `yzh_area` VALUES ('284','277','永春县','0');
INSERT INTO `yzh_area` VALUES ('285','277','德化县','0');
INSERT INTO `yzh_area` VALUES ('286','277','金门县','0');
INSERT INTO `yzh_area` VALUES ('287','277','石狮市','0');
INSERT INTO `yzh_area` VALUES ('288','277','晋江市','0');
INSERT INTO `yzh_area` VALUES ('289','277','南安市','0');
INSERT INTO `yzh_area` VALUES ('290','227','三明市','0');
INSERT INTO `yzh_area` VALUES ('291','290','梅列区','0');
INSERT INTO `yzh_area` VALUES ('292','290','三元区','0');
INSERT INTO `yzh_area` VALUES ('293','290','明溪县','0');
INSERT INTO `yzh_area` VALUES ('294','290','清流县','0');
INSERT INTO `yzh_area` VALUES ('295','290','宁化县','0');
INSERT INTO `yzh_area` VALUES ('296','290','大田县','0');
INSERT INTO `yzh_area` VALUES ('297','290','尤溪县','0');
INSERT INTO `yzh_area` VALUES ('298','290','沙县','0');
INSERT INTO `yzh_area` VALUES ('299','290','将乐县','0');
INSERT INTO `yzh_area` VALUES ('300','290','泰宁县','0');
INSERT INTO `yzh_area` VALUES ('301','290','建宁县','0');
INSERT INTO `yzh_area` VALUES ('302','290','永安市','0');
INSERT INTO `yzh_area` VALUES ('303','227','厦门市','0');
INSERT INTO `yzh_area` VALUES ('304','303','思明区','0');
INSERT INTO `yzh_area` VALUES ('305','303','海沧区','0');
INSERT INTO `yzh_area` VALUES ('306','303','湖里区','0');
INSERT INTO `yzh_area` VALUES ('307','303','集美区','0');
INSERT INTO `yzh_area` VALUES ('308','303','同安区','0');
INSERT INTO `yzh_area` VALUES ('309','303','翔安区','0');
INSERT INTO `yzh_area` VALUES ('310','227','漳州市','0');
INSERT INTO `yzh_area` VALUES ('311','310','芗城区','0');
INSERT INTO `yzh_area` VALUES ('312','310','龙文区','0');
INSERT INTO `yzh_area` VALUES ('313','310','云霄县','0');
INSERT INTO `yzh_area` VALUES ('314','310','漳浦县','0');
INSERT INTO `yzh_area` VALUES ('315','310','诏安县','0');
INSERT INTO `yzh_area` VALUES ('316','310','长泰县','0');
INSERT INTO `yzh_area` VALUES ('317','310','东山县','0');
INSERT INTO `yzh_area` VALUES ('318','310','南靖县','0');
INSERT INTO `yzh_area` VALUES ('319','310','平和县','0');
INSERT INTO `yzh_area` VALUES ('320','310','华安县','0');
INSERT INTO `yzh_area` VALUES ('321','310','龙海市','0');
INSERT INTO `yzh_area` VALUES ('322','0','甘肃','0');
INSERT INTO `yzh_area` VALUES ('323','322','兰州市','0');
INSERT INTO `yzh_area` VALUES ('324','323','城关区','0');
INSERT INTO `yzh_area` VALUES ('325','323','七里河区','0');
INSERT INTO `yzh_area` VALUES ('326','323','西固区','0');
INSERT INTO `yzh_area` VALUES ('327','323','安宁区','0');
INSERT INTO `yzh_area` VALUES ('328','323','红古区','0');
INSERT INTO `yzh_area` VALUES ('329','323','永登县','0');
INSERT INTO `yzh_area` VALUES ('330','323','皋兰县','0');
INSERT INTO `yzh_area` VALUES ('331','323','榆中县','0');
INSERT INTO `yzh_area` VALUES ('332','322','白银市','0');
INSERT INTO `yzh_area` VALUES ('333','332','白银区','0');
INSERT INTO `yzh_area` VALUES ('334','332','平川区','0');
INSERT INTO `yzh_area` VALUES ('335','332','靖远县','0');
INSERT INTO `yzh_area` VALUES ('336','332','会宁县','0');
INSERT INTO `yzh_area` VALUES ('337','332','景泰县','0');
INSERT INTO `yzh_area` VALUES ('338','322','定西市','0');
INSERT INTO `yzh_area` VALUES ('339','338','安定区','0');
INSERT INTO `yzh_area` VALUES ('340','338','通渭县','0');
INSERT INTO `yzh_area` VALUES ('341','338','陇西县','0');
INSERT INTO `yzh_area` VALUES ('342','338','渭源县','0');
INSERT INTO `yzh_area` VALUES ('343','338','临洮县','0');
INSERT INTO `yzh_area` VALUES ('344','338','漳县','0');
INSERT INTO `yzh_area` VALUES ('345','338','岷县','0');
INSERT INTO `yzh_area` VALUES ('346','322','甘南藏族自治州','0');
INSERT INTO `yzh_area` VALUES ('347','346','合作市','0');
INSERT INTO `yzh_area` VALUES ('348','346','临潭县','0');
INSERT INTO `yzh_area` VALUES ('349','346','卓尼县','0');
INSERT INTO `yzh_area` VALUES ('350','346','舟曲县','0');
INSERT INTO `yzh_area` VALUES ('351','346','迭部县','0');
INSERT INTO `yzh_area` VALUES ('352','346','玛曲县','0');
INSERT INTO `yzh_area` VALUES ('353','346','碌曲县','0');
INSERT INTO `yzh_area` VALUES ('354','346','夏河县','0');
INSERT INTO `yzh_area` VALUES ('355','322','嘉峪关市','0');
INSERT INTO `yzh_area` VALUES ('356','322','金昌市','0');
INSERT INTO `yzh_area` VALUES ('357','356','金川区','0');
INSERT INTO `yzh_area` VALUES ('358','356','永昌县','0');
INSERT INTO `yzh_area` VALUES ('359','322','酒泉市','0');
INSERT INTO `yzh_area` VALUES ('360','359','肃州区','0');
INSERT INTO `yzh_area` VALUES ('361','359','金塔县','0');
INSERT INTO `yzh_area` VALUES ('362','359','安西县','0');
INSERT INTO `yzh_area` VALUES ('363','359','肃北蒙古族自治县','0');
INSERT INTO `yzh_area` VALUES ('364','359','阿克塞哈萨克族自治县','0');
INSERT INTO `yzh_area` VALUES ('365','359','玉门市','0');
INSERT INTO `yzh_area` VALUES ('366','359','敦煌市','0');
INSERT INTO `yzh_area` VALUES ('367','322','临夏回族自治州','0');
INSERT INTO `yzh_area` VALUES ('368','367','临夏市','0');
INSERT INTO `yzh_area` VALUES ('369','367','临夏县','0');
INSERT INTO `yzh_area` VALUES ('370','367','康乐县','0');
INSERT INTO `yzh_area` VALUES ('371','367','永靖县','0');
INSERT INTO `yzh_area` VALUES ('372','367','广河县','0');
INSERT INTO `yzh_area` VALUES ('373','367','和政县','0');
INSERT INTO `yzh_area` VALUES ('374','367','东乡族自治县','0');
INSERT INTO `yzh_area` VALUES ('375','367','积石山保安族东乡族撒拉族自治县','0');
INSERT INTO `yzh_area` VALUES ('376','322','陇南市','0');
INSERT INTO `yzh_area` VALUES ('377','376','武都区','0');
INSERT INTO `yzh_area` VALUES ('378','376','成县','0');
INSERT INTO `yzh_area` VALUES ('379','376','文县','0');
INSERT INTO `yzh_area` VALUES ('380','376','宕昌县','0');
INSERT INTO `yzh_area` VALUES ('381','376','康县','0');
INSERT INTO `yzh_area` VALUES ('382','376','西和县','0');
INSERT INTO `yzh_area` VALUES ('383','376','礼县','0');
INSERT INTO `yzh_area` VALUES ('384','376','徽县','0');
INSERT INTO `yzh_area` VALUES ('385','376','两当县','0');
INSERT INTO `yzh_area` VALUES ('386','322','平凉市','0');
INSERT INTO `yzh_area` VALUES ('387','386','崆峒区','0');
INSERT INTO `yzh_area` VALUES ('388','386','泾川县','0');
INSERT INTO `yzh_area` VALUES ('389','386','灵台县','0');
INSERT INTO `yzh_area` VALUES ('390','386','崇信县','0');
INSERT INTO `yzh_area` VALUES ('391','386','华亭县','0');
INSERT INTO `yzh_area` VALUES ('392','386','庄浪县','0');
INSERT INTO `yzh_area` VALUES ('393','386','静宁县','0');
INSERT INTO `yzh_area` VALUES ('394','322','庆阳市','0');
INSERT INTO `yzh_area` VALUES ('395','394','西峰区','0');
INSERT INTO `yzh_area` VALUES ('396','394','庆城县','0');
INSERT INTO `yzh_area` VALUES ('397','394','环县','0');
INSERT INTO `yzh_area` VALUES ('398','394','华池县','0');
INSERT INTO `yzh_area` VALUES ('399','394','合水县','0');
INSERT INTO `yzh_area` VALUES ('400','394','正宁县','0');
INSERT INTO `yzh_area` VALUES ('401','394','宁县','0');
INSERT INTO `yzh_area` VALUES ('402','394','镇原县','0');
INSERT INTO `yzh_area` VALUES ('403','322','天水市','0');
INSERT INTO `yzh_area` VALUES ('404','403','秦城区','0');
INSERT INTO `yzh_area` VALUES ('405','403','北道区','0');
INSERT INTO `yzh_area` VALUES ('406','403','清水县','0');
INSERT INTO `yzh_area` VALUES ('407','403','秦安县','0');
INSERT INTO `yzh_area` VALUES ('408','403','甘谷县','0');
INSERT INTO `yzh_area` VALUES ('409','403','武山县','0');
INSERT INTO `yzh_area` VALUES ('410','403','张家川回族自治县','0');
INSERT INTO `yzh_area` VALUES ('411','322','武威市','0');
INSERT INTO `yzh_area` VALUES ('412','411','凉州区','0');
INSERT INTO `yzh_area` VALUES ('413','411','民勤县','0');
INSERT INTO `yzh_area` VALUES ('414','411','古浪县','0');
INSERT INTO `yzh_area` VALUES ('415','411','天祝藏族自治县','0');
INSERT INTO `yzh_area` VALUES ('416','322','张掖市','0');
INSERT INTO `yzh_area` VALUES ('417','416','甘州区','0');
INSERT INTO `yzh_area` VALUES ('418','416','肃南裕固族自治县','0');
INSERT INTO `yzh_area` VALUES ('419','416','民乐县','0');
INSERT INTO `yzh_area` VALUES ('420','416','临泽县','0');
INSERT INTO `yzh_area` VALUES ('421','416','高台县','0');
INSERT INTO `yzh_area` VALUES ('422','416','山丹县','0');
INSERT INTO `yzh_area` VALUES ('423','0','广东','0');
INSERT INTO `yzh_area` VALUES ('424','423','广州市','0');
INSERT INTO `yzh_area` VALUES ('425','424','东山区','0');
INSERT INTO `yzh_area` VALUES ('426','424','荔湾区','0');
INSERT INTO `yzh_area` VALUES ('427','424','越秀区','0');
INSERT INTO `yzh_area` VALUES ('428','424','海珠区','0');
INSERT INTO `yzh_area` VALUES ('429','424','天河区','0');
INSERT INTO `yzh_area` VALUES ('430','424','芳村区','0');
INSERT INTO `yzh_area` VALUES ('431','424','白云区','0');
INSERT INTO `yzh_area` VALUES ('432','424','黄埔区','0');
INSERT INTO `yzh_area` VALUES ('433','424','番禺区','0');
INSERT INTO `yzh_area` VALUES ('434','424','花都区','0');
INSERT INTO `yzh_area` VALUES ('435','424','增城市','0');
INSERT INTO `yzh_area` VALUES ('436','424','从化市','0');
INSERT INTO `yzh_area` VALUES ('437','423','潮州市','0');
INSERT INTO `yzh_area` VALUES ('438','437','湘桥区','0');
INSERT INTO `yzh_area` VALUES ('439','437','潮安县','0');
INSERT INTO `yzh_area` VALUES ('440','437','饶平县','0');
INSERT INTO `yzh_area` VALUES ('441','423','东莞市','0');
INSERT INTO `yzh_area` VALUES ('442','423','佛山市','0');
INSERT INTO `yzh_area` VALUES ('443','442','禅城区','0');
INSERT INTO `yzh_area` VALUES ('444','442','南海区','0');
INSERT INTO `yzh_area` VALUES ('445','442','顺德区','0');
INSERT INTO `yzh_area` VALUES ('446','442','三水区','0');
INSERT INTO `yzh_area` VALUES ('447','442','高明区','0');
INSERT INTO `yzh_area` VALUES ('448','423','河源市','0');
INSERT INTO `yzh_area` VALUES ('449','448','源城区','0');
INSERT INTO `yzh_area` VALUES ('450','448','紫金县','0');
INSERT INTO `yzh_area` VALUES ('451','448','龙川县','0');
INSERT INTO `yzh_area` VALUES ('452','448','连平县','0');
INSERT INTO `yzh_area` VALUES ('453','448','和平县','0');
INSERT INTO `yzh_area` VALUES ('454','448','东源县','0');
INSERT INTO `yzh_area` VALUES ('455','423','惠州市','0');
INSERT INTO `yzh_area` VALUES ('456','455','惠城区','0');
INSERT INTO `yzh_area` VALUES ('457','455','惠阳区','0');
INSERT INTO `yzh_area` VALUES ('458','455','博罗县','0');
INSERT INTO `yzh_area` VALUES ('459','455','惠东县','0');
INSERT INTO `yzh_area` VALUES ('460','455','龙门县','0');
INSERT INTO `yzh_area` VALUES ('461','423','江门市','0');
INSERT INTO `yzh_area` VALUES ('462','461','蓬江区','0');
INSERT INTO `yzh_area` VALUES ('463','461','江海区','0');
INSERT INTO `yzh_area` VALUES ('464','461','新会区','0');
INSERT INTO `yzh_area` VALUES ('465','461','台山市','0');
INSERT INTO `yzh_area` VALUES ('466','461','开平市','0');
INSERT INTO `yzh_area` VALUES ('467','461','鹤山市','0');
INSERT INTO `yzh_area` VALUES ('468','461','恩平市','0');
INSERT INTO `yzh_area` VALUES ('469','423','揭阳市','0');
INSERT INTO `yzh_area` VALUES ('470','469','榕城区','0');
INSERT INTO `yzh_area` VALUES ('471','469','揭东县','0');
INSERT INTO `yzh_area` VALUES ('472','469','揭西县','0');
INSERT INTO `yzh_area` VALUES ('473','469','惠来县','0');
INSERT INTO `yzh_area` VALUES ('474','469','普宁市','0');
INSERT INTO `yzh_area` VALUES ('475','423','茂名市','0');
INSERT INTO `yzh_area` VALUES ('476','475','茂南区','0');
INSERT INTO `yzh_area` VALUES ('477','475','茂港区','0');
INSERT INTO `yzh_area` VALUES ('478','475','电白县','0');
INSERT INTO `yzh_area` VALUES ('479','475','高州市','0');
INSERT INTO `yzh_area` VALUES ('480','475','化州市','0');
INSERT INTO `yzh_area` VALUES ('481','475','信宜市','0');
INSERT INTO `yzh_area` VALUES ('482','423','梅江区','0');
INSERT INTO `yzh_area` VALUES ('483','423','梅州市','0');
INSERT INTO `yzh_area` VALUES ('484','483','梅县','0');
INSERT INTO `yzh_area` VALUES ('485','483','大埔县','0');
INSERT INTO `yzh_area` VALUES ('486','483','丰顺县','0');
INSERT INTO `yzh_area` VALUES ('487','483','五华县','0');
INSERT INTO `yzh_area` VALUES ('488','483','平远县','0');
INSERT INTO `yzh_area` VALUES ('489','483','蕉岭县','0');
INSERT INTO `yzh_area` VALUES ('490','483','兴宁市','0');
INSERT INTO `yzh_area` VALUES ('491','423','清远市','0');
INSERT INTO `yzh_area` VALUES ('492','491','清城区','0');
INSERT INTO `yzh_area` VALUES ('493','491','佛冈县','0');
INSERT INTO `yzh_area` VALUES ('494','491','阳山县','0');
INSERT INTO `yzh_area` VALUES ('495','491','连山壮族瑶族自治县','0');
INSERT INTO `yzh_area` VALUES ('496','491','连南瑶族自治县','0');
INSERT INTO `yzh_area` VALUES ('497','491','清新县','0');
INSERT INTO `yzh_area` VALUES ('498','491','英德市','0');
INSERT INTO `yzh_area` VALUES ('499','491','连州市','0');
INSERT INTO `yzh_area` VALUES ('500','423','汕头市','0');
INSERT INTO `yzh_area` VALUES ('501','500','龙湖区','0');
INSERT INTO `yzh_area` VALUES ('502','500','金平区','0');
INSERT INTO `yzh_area` VALUES ('503','500','濠江区','0');
INSERT INTO `yzh_area` VALUES ('504','500','潮阳区','0');
INSERT INTO `yzh_area` VALUES ('505','500','潮南区','0');
INSERT INTO `yzh_area` VALUES ('506','500','澄海区','0');
INSERT INTO `yzh_area` VALUES ('507','500','南澳县','0');
INSERT INTO `yzh_area` VALUES ('508','423','汕尾市','0');
INSERT INTO `yzh_area` VALUES ('509','508','城区','0');
INSERT INTO `yzh_area` VALUES ('510','508','海丰县','0');
INSERT INTO `yzh_area` VALUES ('511','508','陆河县','0');
INSERT INTO `yzh_area` VALUES ('512','508','陆丰市','0');
INSERT INTO `yzh_area` VALUES ('513','423','韶关市','0');
INSERT INTO `yzh_area` VALUES ('514','513','武江区','0');
INSERT INTO `yzh_area` VALUES ('515','513','浈江区','0');
INSERT INTO `yzh_area` VALUES ('516','513','曲江区','0');
INSERT INTO `yzh_area` VALUES ('517','513','始兴县','0');
INSERT INTO `yzh_area` VALUES ('518','513','仁化县','0');
INSERT INTO `yzh_area` VALUES ('519','513','翁源县','0');
INSERT INTO `yzh_area` VALUES ('520','513','乳源瑶族自治县','0');
INSERT INTO `yzh_area` VALUES ('521','513','新丰县','0');
INSERT INTO `yzh_area` VALUES ('522','513','乐昌市','0');
INSERT INTO `yzh_area` VALUES ('523','513','南雄市','0');
INSERT INTO `yzh_area` VALUES ('524','423','深圳市','0');
INSERT INTO `yzh_area` VALUES ('525','524','罗湖区','0');
INSERT INTO `yzh_area` VALUES ('526','524','福田区','0');
INSERT INTO `yzh_area` VALUES ('527','524','南山区','0');
INSERT INTO `yzh_area` VALUES ('528','524','宝安区','0');
INSERT INTO `yzh_area` VALUES ('529','524','龙岗区','0');
INSERT INTO `yzh_area` VALUES ('530','524','盐田区','0');
INSERT INTO `yzh_area` VALUES ('531','423','阳江市','0');
INSERT INTO `yzh_area` VALUES ('532','531','江城区','0');
INSERT INTO `yzh_area` VALUES ('533','531','阳西县','0');
INSERT INTO `yzh_area` VALUES ('534','531','阳东县','0');
INSERT INTO `yzh_area` VALUES ('535','531','阳春市','0');
INSERT INTO `yzh_area` VALUES ('536','423','云浮市','0');
INSERT INTO `yzh_area` VALUES ('537','536','云城区','0');
INSERT INTO `yzh_area` VALUES ('538','536','新兴县','0');
INSERT INTO `yzh_area` VALUES ('539','536','郁南县','0');
INSERT INTO `yzh_area` VALUES ('540','536','云安县','0');
INSERT INTO `yzh_area` VALUES ('541','536','罗定市','0');
INSERT INTO `yzh_area` VALUES ('542','423','湛江市','0');
INSERT INTO `yzh_area` VALUES ('543','542','赤坎区','0');
INSERT INTO `yzh_area` VALUES ('544','542','霞山区','0');
INSERT INTO `yzh_area` VALUES ('545','542','坡头区','0');
INSERT INTO `yzh_area` VALUES ('546','542','麻章区','0');
INSERT INTO `yzh_area` VALUES ('547','542','遂溪县','0');
INSERT INTO `yzh_area` VALUES ('548','542','徐闻县','0');
INSERT INTO `yzh_area` VALUES ('549','542','廉江市','0');
INSERT INTO `yzh_area` VALUES ('550','542','雷州市','0');
INSERT INTO `yzh_area` VALUES ('551','542','吴川市','0');
INSERT INTO `yzh_area` VALUES ('552','423','肇庆市','0');
INSERT INTO `yzh_area` VALUES ('553','552','端州区','0');
INSERT INTO `yzh_area` VALUES ('554','552','鼎湖区','0');
INSERT INTO `yzh_area` VALUES ('555','552','广宁县','0');
INSERT INTO `yzh_area` VALUES ('556','552','怀集县','0');
INSERT INTO `yzh_area` VALUES ('557','552','封开县','0');
INSERT INTO `yzh_area` VALUES ('558','552','德庆县','0');
INSERT INTO `yzh_area` VALUES ('559','552','高要市','0');
INSERT INTO `yzh_area` VALUES ('560','552','四会市','0');
INSERT INTO `yzh_area` VALUES ('561','423','中山市','0');
INSERT INTO `yzh_area` VALUES ('562','423','珠海市','0');
INSERT INTO `yzh_area` VALUES ('563','562','香洲区','0');
INSERT INTO `yzh_area` VALUES ('564','562','斗门区','0');
INSERT INTO `yzh_area` VALUES ('565','562','金湾区','0');
INSERT INTO `yzh_area` VALUES ('566','0','广西','0');
INSERT INTO `yzh_area` VALUES ('567','566','南宁市','0');
INSERT INTO `yzh_area` VALUES ('568','567','兴宁区','0');
INSERT INTO `yzh_area` VALUES ('569','567','青秀区','0');
INSERT INTO `yzh_area` VALUES ('570','567','江南区','0');
INSERT INTO `yzh_area` VALUES ('571','567','西乡塘区','0');
INSERT INTO `yzh_area` VALUES ('572','567','良庆区','0');
INSERT INTO `yzh_area` VALUES ('573','567','邕宁区','0');
INSERT INTO `yzh_area` VALUES ('574','567','武鸣县','0');
INSERT INTO `yzh_area` VALUES ('575','567','隆安县','0');
INSERT INTO `yzh_area` VALUES ('576','567','马山县','0');
INSERT INTO `yzh_area` VALUES ('577','567','上林县','0');
INSERT INTO `yzh_area` VALUES ('578','567','宾阳县','0');
INSERT INTO `yzh_area` VALUES ('579','567','横县','0');
INSERT INTO `yzh_area` VALUES ('580','566','百色市','0');
INSERT INTO `yzh_area` VALUES ('581','580','右江区','0');
INSERT INTO `yzh_area` VALUES ('582','580','田阳县','0');
INSERT INTO `yzh_area` VALUES ('583','580','田东县','0');
INSERT INTO `yzh_area` VALUES ('584','580','平果县','0');
INSERT INTO `yzh_area` VALUES ('585','580','德保县','0');
INSERT INTO `yzh_area` VALUES ('586','580','靖西县','0');
INSERT INTO `yzh_area` VALUES ('587','580','那坡县','0');
INSERT INTO `yzh_area` VALUES ('588','580','凌云县','0');
INSERT INTO `yzh_area` VALUES ('589','580','乐业县','0');
INSERT INTO `yzh_area` VALUES ('590','580','田林县','0');
INSERT INTO `yzh_area` VALUES ('591','580','西林县','0');
INSERT INTO `yzh_area` VALUES ('592','580','隆林各族自治县','0');
INSERT INTO `yzh_area` VALUES ('593','566','北海市','0');
INSERT INTO `yzh_area` VALUES ('594','593','海城区','0');
INSERT INTO `yzh_area` VALUES ('595','593','银海区','0');
INSERT INTO `yzh_area` VALUES ('596','593','铁山港区','0');
INSERT INTO `yzh_area` VALUES ('597','593','合浦县','0');
INSERT INTO `yzh_area` VALUES ('598','566','崇左市','0');
INSERT INTO `yzh_area` VALUES ('599','598','江洲区','0');
INSERT INTO `yzh_area` VALUES ('600','598','扶绥县','0');
INSERT INTO `yzh_area` VALUES ('601','598','宁明县','0');
INSERT INTO `yzh_area` VALUES ('602','598','龙州县','0');
INSERT INTO `yzh_area` VALUES ('603','598','大新县','0');
INSERT INTO `yzh_area` VALUES ('604','598','天等县','0');
INSERT INTO `yzh_area` VALUES ('605','598','凭祥市','0');
INSERT INTO `yzh_area` VALUES ('606','566','防城港市','0');
INSERT INTO `yzh_area` VALUES ('607','606','港口区','0');
INSERT INTO `yzh_area` VALUES ('608','606','防城区','0');
INSERT INTO `yzh_area` VALUES ('609','606','上思县','0');
INSERT INTO `yzh_area` VALUES ('610','606','东兴市','0');
INSERT INTO `yzh_area` VALUES ('611','566','贵港市','0');
INSERT INTO `yzh_area` VALUES ('612','611','港北区','0');
INSERT INTO `yzh_area` VALUES ('613','611','港南区','0');
INSERT INTO `yzh_area` VALUES ('614','611','覃塘区','0');
INSERT INTO `yzh_area` VALUES ('615','611','平南县','0');
INSERT INTO `yzh_area` VALUES ('616','611','桂平市','0');
INSERT INTO `yzh_area` VALUES ('617','566','桂林市','0');
INSERT INTO `yzh_area` VALUES ('618','617','秀峰区','0');
INSERT INTO `yzh_area` VALUES ('619','617','叠彩区','0');
INSERT INTO `yzh_area` VALUES ('620','617','象山区','0');
INSERT INTO `yzh_area` VALUES ('621','617','七星区','0');
INSERT INTO `yzh_area` VALUES ('622','617','雁山区','0');
INSERT INTO `yzh_area` VALUES ('623','617','阳朔县','0');
INSERT INTO `yzh_area` VALUES ('624','617','临桂县','0');
INSERT INTO `yzh_area` VALUES ('625','617','灵川县','0');
INSERT INTO `yzh_area` VALUES ('626','617','全州县','0');
INSERT INTO `yzh_area` VALUES ('627','617','兴安县','0');
INSERT INTO `yzh_area` VALUES ('628','617','永福县','0');
INSERT INTO `yzh_area` VALUES ('629','617','灌阳县','0');
INSERT INTO `yzh_area` VALUES ('630','617','龙胜各族自治县','0');
INSERT INTO `yzh_area` VALUES ('631','617','资源县','0');
INSERT INTO `yzh_area` VALUES ('632','617','平乐县','0');
INSERT INTO `yzh_area` VALUES ('633','617','荔蒲县','0');
INSERT INTO `yzh_area` VALUES ('634','617','恭城瑶族自治县','0');
INSERT INTO `yzh_area` VALUES ('635','566','河池市','0');
INSERT INTO `yzh_area` VALUES ('636','635','金城江区','0');
INSERT INTO `yzh_area` VALUES ('637','635','南丹县','0');
INSERT INTO `yzh_area` VALUES ('638','635','天峨县','0');
INSERT INTO `yzh_area` VALUES ('639','635','凤山县','0');
INSERT INTO `yzh_area` VALUES ('640','635','东兰县','0');
INSERT INTO `yzh_area` VALUES ('641','635','罗城仫佬族自治县','0');
INSERT INTO `yzh_area` VALUES ('642','635','环江毛南族自治县','0');
INSERT INTO `yzh_area` VALUES ('643','635','巴马瑶族自治县','0');
INSERT INTO `yzh_area` VALUES ('644','635','都安瑶族自治县','0');
INSERT INTO `yzh_area` VALUES ('645','635','大化瑶族自治县','0');
INSERT INTO `yzh_area` VALUES ('646','635','宜州市','0');
INSERT INTO `yzh_area` VALUES ('647','566','贺州市','0');
INSERT INTO `yzh_area` VALUES ('648','647','八步区','0');
INSERT INTO `yzh_area` VALUES ('649','647','昭平县','0');
INSERT INTO `yzh_area` VALUES ('650','647','钟山县','0');
INSERT INTO `yzh_area` VALUES ('651','647','富川瑶族自治县','0');
INSERT INTO `yzh_area` VALUES ('652','566','来宾市','0');
INSERT INTO `yzh_area` VALUES ('653','652','兴宾区','0');
INSERT INTO `yzh_area` VALUES ('654','652','忻城县','0');
INSERT INTO `yzh_area` VALUES ('655','652','象州县','0');
INSERT INTO `yzh_area` VALUES ('656','652','武宣县','0');
INSERT INTO `yzh_area` VALUES ('657','652','金秀瑶族自治县','0');
INSERT INTO `yzh_area` VALUES ('658','652','合山市','0');
INSERT INTO `yzh_area` VALUES ('659','566','柳州市','0');
INSERT INTO `yzh_area` VALUES ('660','659','城中区','0');
INSERT INTO `yzh_area` VALUES ('661','659','鱼峰区','0');
INSERT INTO `yzh_area` VALUES ('662','659','柳南区','0');
INSERT INTO `yzh_area` VALUES ('663','659','柳北区','0');
INSERT INTO `yzh_area` VALUES ('664','659','柳江县','0');
INSERT INTO `yzh_area` VALUES ('665','659','柳城县','0');
INSERT INTO `yzh_area` VALUES ('666','659','鹿寨县','0');
INSERT INTO `yzh_area` VALUES ('667','659','融安县','0');
INSERT INTO `yzh_area` VALUES ('668','659','融水苗族自治县','0');
INSERT INTO `yzh_area` VALUES ('669','659','三江侗族自治县','0');
INSERT INTO `yzh_area` VALUES ('670','566','钦州市','0');
INSERT INTO `yzh_area` VALUES ('671','670','钦南区','0');
INSERT INTO `yzh_area` VALUES ('672','670','钦北区','0');
INSERT INTO `yzh_area` VALUES ('673','670','灵山县','0');
INSERT INTO `yzh_area` VALUES ('674','670','浦北县','0');
INSERT INTO `yzh_area` VALUES ('675','566','梧州市','0');
INSERT INTO `yzh_area` VALUES ('676','675','万秀区','0');
INSERT INTO `yzh_area` VALUES ('677','675','蝶山区','0');
INSERT INTO `yzh_area` VALUES ('678','675','长洲区','0');
INSERT INTO `yzh_area` VALUES ('679','675','苍梧县','0');
INSERT INTO `yzh_area` VALUES ('680','675','藤县','0');
INSERT INTO `yzh_area` VALUES ('681','675','蒙山县','0');
INSERT INTO `yzh_area` VALUES ('682','675','岑溪市','0');
INSERT INTO `yzh_area` VALUES ('683','566','玉林市','0');
INSERT INTO `yzh_area` VALUES ('684','683','玉州区','0');
INSERT INTO `yzh_area` VALUES ('685','683','容县','0');
INSERT INTO `yzh_area` VALUES ('686','683','陆川县','0');
INSERT INTO `yzh_area` VALUES ('687','683','博白县','0');
INSERT INTO `yzh_area` VALUES ('688','683','兴业县','0');
INSERT INTO `yzh_area` VALUES ('689','683','北流市','0');
INSERT INTO `yzh_area` VALUES ('690','0','贵州','0');
INSERT INTO `yzh_area` VALUES ('691','690','贵阳市','0');
INSERT INTO `yzh_area` VALUES ('692','691','南明区','0');
INSERT INTO `yzh_area` VALUES ('693','691','云岩区','0');
INSERT INTO `yzh_area` VALUES ('694','691','花溪区','0');
INSERT INTO `yzh_area` VALUES ('695','691','乌当区','0');
INSERT INTO `yzh_area` VALUES ('696','691','白云区','0');
INSERT INTO `yzh_area` VALUES ('697','691','小河区','0');
INSERT INTO `yzh_area` VALUES ('698','691','开阳县','0');
INSERT INTO `yzh_area` VALUES ('699','691','息烽县','0');
INSERT INTO `yzh_area` VALUES ('700','691','修文县','0');
INSERT INTO `yzh_area` VALUES ('701','691','清镇市','0');
INSERT INTO `yzh_area` VALUES ('702','690','安顺市','0');
INSERT INTO `yzh_area` VALUES ('703','702','西秀区','0');
INSERT INTO `yzh_area` VALUES ('704','702','平坝县','0');
INSERT INTO `yzh_area` VALUES ('705','702','普定县','0');
INSERT INTO `yzh_area` VALUES ('706','702','镇宁布依族苗族自治县','0');
INSERT INTO `yzh_area` VALUES ('707','702','关岭布依族苗族自治县','0');
INSERT INTO `yzh_area` VALUES ('708','702','紫云苗族布依族自治县','0');
INSERT INTO `yzh_area` VALUES ('709','690','毕节地区','0');
INSERT INTO `yzh_area` VALUES ('710','709','毕节市','0');
INSERT INTO `yzh_area` VALUES ('711','709','大方县','0');
INSERT INTO `yzh_area` VALUES ('712','709','黔西县','0');
INSERT INTO `yzh_area` VALUES ('713','709','金沙县','0');
INSERT INTO `yzh_area` VALUES ('714','709','织金县','0');
INSERT INTO `yzh_area` VALUES ('715','709','纳雍县','0');
INSERT INTO `yzh_area` VALUES ('716','709','威宁彝族回族苗族自治县','0');
INSERT INTO `yzh_area` VALUES ('717','709','赫章县','0');
INSERT INTO `yzh_area` VALUES ('718','690','六盘水市','0');
INSERT INTO `yzh_area` VALUES ('719','718','钟山区','0');
INSERT INTO `yzh_area` VALUES ('720','718','六枝特区','0');
INSERT INTO `yzh_area` VALUES ('721','718','水城县','0');
INSERT INTO `yzh_area` VALUES ('722','718','盘县','0');
INSERT INTO `yzh_area` VALUES ('723','690','黔东南苗族侗族自治州','0');
INSERT INTO `yzh_area` VALUES ('724','723','凯里市','0');
INSERT INTO `yzh_area` VALUES ('725','723','黄平县','0');
INSERT INTO `yzh_area` VALUES ('726','723','施秉县','0');
INSERT INTO `yzh_area` VALUES ('727','723','三穗县','0');
INSERT INTO `yzh_area` VALUES ('728','723','镇远县','0');
INSERT INTO `yzh_area` VALUES ('729','723','岑巩县','0');
INSERT INTO `yzh_area` VALUES ('730','723','天柱县','0');
INSERT INTO `yzh_area` VALUES ('731','723','锦屏县','0');
INSERT INTO `yzh_area` VALUES ('732','723','剑河县','0');
INSERT INTO `yzh_area` VALUES ('733','723','台江县','0');
INSERT INTO `yzh_area` VALUES ('734','723','黎平县','0');
INSERT INTO `yzh_area` VALUES ('735','723','榕江县','0');
INSERT INTO `yzh_area` VALUES ('736','723','从江县','0');
INSERT INTO `yzh_area` VALUES ('737','723','雷山县','0');
INSERT INTO `yzh_area` VALUES ('738','723','麻江县','0');
INSERT INTO `yzh_area` VALUES ('739','723','丹寨县','0');
INSERT INTO `yzh_area` VALUES ('740','690','黔南布依族苗族自治州','0');
INSERT INTO `yzh_area` VALUES ('741','740','都匀市','0');
INSERT INTO `yzh_area` VALUES ('742','740','福泉市','0');
INSERT INTO `yzh_area` VALUES ('743','740','荔波县','0');
INSERT INTO `yzh_area` VALUES ('744','740','贵定县','0');
INSERT INTO `yzh_area` VALUES ('745','740','瓮安县','0');
INSERT INTO `yzh_area` VALUES ('746','740','独山县','0');
INSERT INTO `yzh_area` VALUES ('747','740','平塘县','0');
INSERT INTO `yzh_area` VALUES ('748','740','罗甸县','0');
INSERT INTO `yzh_area` VALUES ('749','740','长顺县','0');
INSERT INTO `yzh_area` VALUES ('750','740','龙里县','0');
INSERT INTO `yzh_area` VALUES ('751','740','惠水县','0');
INSERT INTO `yzh_area` VALUES ('752','740','三都水族自治县','0');
INSERT INTO `yzh_area` VALUES ('753','690','黔西南布依族苗族自治州','0');
INSERT INTO `yzh_area` VALUES ('754','753','兴义市','0');
INSERT INTO `yzh_area` VALUES ('755','753','兴仁县','0');
INSERT INTO `yzh_area` VALUES ('756','753','普安县','0');
INSERT INTO `yzh_area` VALUES ('757','753','晴隆县','0');
INSERT INTO `yzh_area` VALUES ('758','753','贞丰县','0');
INSERT INTO `yzh_area` VALUES ('759','753','望谟县','0');
INSERT INTO `yzh_area` VALUES ('760','753','册亨县','0');
INSERT INTO `yzh_area` VALUES ('761','753','安龙县','0');
INSERT INTO `yzh_area` VALUES ('762','690','铜仁地区','0');
INSERT INTO `yzh_area` VALUES ('763','762','铜仁市','0');
INSERT INTO `yzh_area` VALUES ('764','762','江口县','0');
INSERT INTO `yzh_area` VALUES ('765','762','玉屏侗族自治县','0');
INSERT INTO `yzh_area` VALUES ('766','762','石阡县','0');
INSERT INTO `yzh_area` VALUES ('767','762','思南县','0');
INSERT INTO `yzh_area` VALUES ('768','762','印江土家族苗族自治县','0');
INSERT INTO `yzh_area` VALUES ('769','762','德江县','0');
INSERT INTO `yzh_area` VALUES ('770','762','沿河土家族自治县','0');
INSERT INTO `yzh_area` VALUES ('771','762','松桃苗族自治县','0');
INSERT INTO `yzh_area` VALUES ('772','762','万山特区','0');
INSERT INTO `yzh_area` VALUES ('773','690','遵义市','0');
INSERT INTO `yzh_area` VALUES ('774','773','红花岗区','0');
INSERT INTO `yzh_area` VALUES ('775','773','汇川区','0');
INSERT INTO `yzh_area` VALUES ('776','773','遵义县','0');
INSERT INTO `yzh_area` VALUES ('777','773','桐梓县','0');
INSERT INTO `yzh_area` VALUES ('778','773','绥阳县','0');
INSERT INTO `yzh_area` VALUES ('779','773','正安县','0');
INSERT INTO `yzh_area` VALUES ('780','773','道真仡佬族苗族自治县','0');
INSERT INTO `yzh_area` VALUES ('781','773','务川仡佬族苗族自治县','0');
INSERT INTO `yzh_area` VALUES ('782','773','凤冈县','0');
INSERT INTO `yzh_area` VALUES ('783','773','湄潭县','0');
INSERT INTO `yzh_area` VALUES ('784','773','余庆县','0');
INSERT INTO `yzh_area` VALUES ('785','773','习水县','0');
INSERT INTO `yzh_area` VALUES ('786','773','赤水市','0');
INSERT INTO `yzh_area` VALUES ('787','773','仁怀市','0');
INSERT INTO `yzh_area` VALUES ('788','0','海南','0');
INSERT INTO `yzh_area` VALUES ('789','788','海口市','0');
INSERT INTO `yzh_area` VALUES ('790','789','秀英区','0');
INSERT INTO `yzh_area` VALUES ('791','789','龙华区','0');
INSERT INTO `yzh_area` VALUES ('792','789','琼山区','0');
INSERT INTO `yzh_area` VALUES ('793','789','美兰区','0');
INSERT INTO `yzh_area` VALUES ('794','788','白沙黎族自治县','0');
INSERT INTO `yzh_area` VALUES ('795','788','保亭黎族苗族自治县','0');
INSERT INTO `yzh_area` VALUES ('796','788','昌江黎族自治县','0');
INSERT INTO `yzh_area` VALUES ('797','788','澄迈县','0');
INSERT INTO `yzh_area` VALUES ('798','788','儋州市','0');
INSERT INTO `yzh_area` VALUES ('799','788','定安县','0');
INSERT INTO `yzh_area` VALUES ('800','788','东方市','0');
INSERT INTO `yzh_area` VALUES ('801','788','乐东黎族自治县','0');
INSERT INTO `yzh_area` VALUES ('802','788','临高县','0');
INSERT INTO `yzh_area` VALUES ('803','788','陵水黎族自治县','0');
INSERT INTO `yzh_area` VALUES ('804','788','南沙群岛','0');
INSERT INTO `yzh_area` VALUES ('805','788','琼海市','0');
INSERT INTO `yzh_area` VALUES ('806','788','琼中黎族苗族自治县','0');
INSERT INTO `yzh_area` VALUES ('807','788','三亚市','0');
INSERT INTO `yzh_area` VALUES ('808','788','屯昌县','0');
INSERT INTO `yzh_area` VALUES ('809','788','万宁市','0');
INSERT INTO `yzh_area` VALUES ('810','788','文昌市','0');
INSERT INTO `yzh_area` VALUES ('811','788','五指山市','0');
INSERT INTO `yzh_area` VALUES ('812','788','西沙群岛','0');
INSERT INTO `yzh_area` VALUES ('813','788','中沙群岛的岛礁及其海域','0');
INSERT INTO `yzh_area` VALUES ('814','0','河北','0');
INSERT INTO `yzh_area` VALUES ('815','814','石家庄市','0');
INSERT INTO `yzh_area` VALUES ('816','815','长安区','0');
INSERT INTO `yzh_area` VALUES ('817','815','桥东区','0');
INSERT INTO `yzh_area` VALUES ('818','815','桥西区','0');
INSERT INTO `yzh_area` VALUES ('819','815','新华区','0');
INSERT INTO `yzh_area` VALUES ('820','815','井陉矿区','0');
INSERT INTO `yzh_area` VALUES ('821','815','裕华区','0');
INSERT INTO `yzh_area` VALUES ('822','815','井陉县','0');
INSERT INTO `yzh_area` VALUES ('823','815','正定县','0');
INSERT INTO `yzh_area` VALUES ('824','815','栾城县','0');
INSERT INTO `yzh_area` VALUES ('825','815','行唐县','0');
INSERT INTO `yzh_area` VALUES ('826','815','灵寿县','0');
INSERT INTO `yzh_area` VALUES ('827','815','高邑县','0');
INSERT INTO `yzh_area` VALUES ('828','815','深泽县','0');
INSERT INTO `yzh_area` VALUES ('829','815','赞皇县','0');
INSERT INTO `yzh_area` VALUES ('830','815','无极县','0');
INSERT INTO `yzh_area` VALUES ('831','815','平山县','0');
INSERT INTO `yzh_area` VALUES ('832','815','元氏县','0');
INSERT INTO `yzh_area` VALUES ('833','815','赵县','0');
INSERT INTO `yzh_area` VALUES ('834','815','辛集市','0');
INSERT INTO `yzh_area` VALUES ('835','815','藁城市','0');
INSERT INTO `yzh_area` VALUES ('836','815','晋州市','0');
INSERT INTO `yzh_area` VALUES ('837','815','新乐市','0');
INSERT INTO `yzh_area` VALUES ('838','815','鹿泉市','0');
INSERT INTO `yzh_area` VALUES ('839','814','保定市','0');
INSERT INTO `yzh_area` VALUES ('840','839','新市区','0');
INSERT INTO `yzh_area` VALUES ('841','839','北市区','0');
INSERT INTO `yzh_area` VALUES ('842','839','南市区','0');
INSERT INTO `yzh_area` VALUES ('843','839','满城县','0');
INSERT INTO `yzh_area` VALUES ('844','839','清苑县','0');
INSERT INTO `yzh_area` VALUES ('845','839','涞水县','0');
INSERT INTO `yzh_area` VALUES ('846','839','阜平县','0');
INSERT INTO `yzh_area` VALUES ('847','839','徐水县','0');
INSERT INTO `yzh_area` VALUES ('848','839','定兴县','0');
INSERT INTO `yzh_area` VALUES ('849','839','唐县','0');
INSERT INTO `yzh_area` VALUES ('850','839','高阳县','0');
INSERT INTO `yzh_area` VALUES ('851','839','容城县','0');
INSERT INTO `yzh_area` VALUES ('852','839','涞源县','0');
INSERT INTO `yzh_area` VALUES ('853','839','望都县','0');
INSERT INTO `yzh_area` VALUES ('854','839','安新县','0');
INSERT INTO `yzh_area` VALUES ('855','839','易县','0');
INSERT INTO `yzh_area` VALUES ('856','839','曲阳县','0');
INSERT INTO `yzh_area` VALUES ('857','839','蠡县','0');
INSERT INTO `yzh_area` VALUES ('858','839','顺平县','0');
INSERT INTO `yzh_area` VALUES ('859','839','博野县','0');
INSERT INTO `yzh_area` VALUES ('860','839','雄县','0');
INSERT INTO `yzh_area` VALUES ('861','839','涿州市','0');
INSERT INTO `yzh_area` VALUES ('862','839','定州市','0');
INSERT INTO `yzh_area` VALUES ('863','839','安国市','0');
INSERT INTO `yzh_area` VALUES ('864','839','高碑店市','0');
INSERT INTO `yzh_area` VALUES ('865','814','沧州市','0');
INSERT INTO `yzh_area` VALUES ('866','865','新华区','0');
INSERT INTO `yzh_area` VALUES ('867','865','运河区','0');
INSERT INTO `yzh_area` VALUES ('868','865','沧县','0');
INSERT INTO `yzh_area` VALUES ('869','865','青县','0');
INSERT INTO `yzh_area` VALUES ('870','865','东光县','0');
INSERT INTO `yzh_area` VALUES ('871','865','海兴县','0');
INSERT INTO `yzh_area` VALUES ('872','865','盐山县','0');
INSERT INTO `yzh_area` VALUES ('873','865','肃宁县','0');
INSERT INTO `yzh_area` VALUES ('874','865','南皮县','0');
INSERT INTO `yzh_area` VALUES ('875','865','吴桥县','0');
INSERT INTO `yzh_area` VALUES ('876','865','献县','0');
INSERT INTO `yzh_area` VALUES ('877','865','孟村回族自治县','0');
INSERT INTO `yzh_area` VALUES ('878','865','泊头市','0');
INSERT INTO `yzh_area` VALUES ('879','865','任丘市','0');
INSERT INTO `yzh_area` VALUES ('880','865','黄骅市','0');
INSERT INTO `yzh_area` VALUES ('881','865','河间市','0');
INSERT INTO `yzh_area` VALUES ('882','814','承德市','0');
INSERT INTO `yzh_area` VALUES ('883','882','双桥区','0');
INSERT INTO `yzh_area` VALUES ('884','882','双滦区','0');
INSERT INTO `yzh_area` VALUES ('885','882','鹰手营子矿区','0');
INSERT INTO `yzh_area` VALUES ('886','882','承德县','0');
INSERT INTO `yzh_area` VALUES ('887','882','兴隆县','0');
INSERT INTO `yzh_area` VALUES ('888','882','平泉县','0');
INSERT INTO `yzh_area` VALUES ('889','882','滦平县','0');
INSERT INTO `yzh_area` VALUES ('890','882','隆化县','0');
INSERT INTO `yzh_area` VALUES ('891','882','丰宁满族自治县','0');
INSERT INTO `yzh_area` VALUES ('892','882','宽城满族自治县','0');
INSERT INTO `yzh_area` VALUES ('893','882','围场满族蒙古族自治县','0');
INSERT INTO `yzh_area` VALUES ('894','814','邯郸市','0');
INSERT INTO `yzh_area` VALUES ('895','894','邯山区','0');
INSERT INTO `yzh_area` VALUES ('896','894','丛台区','0');
INSERT INTO `yzh_area` VALUES ('897','894','复兴区','0');
INSERT INTO `yzh_area` VALUES ('898','894','峰峰矿区','0');
INSERT INTO `yzh_area` VALUES ('899','894','邯郸县','0');
INSERT INTO `yzh_area` VALUES ('900','894','临漳县','0');
INSERT INTO `yzh_area` VALUES ('901','894','成安县','0');
INSERT INTO `yzh_area` VALUES ('902','894','大名县','0');
INSERT INTO `yzh_area` VALUES ('903','894','涉县','0');
INSERT INTO `yzh_area` VALUES ('904','894','磁县','0');
INSERT INTO `yzh_area` VALUES ('905','894','肥乡县','0');
INSERT INTO `yzh_area` VALUES ('906','894','永年县','0');
INSERT INTO `yzh_area` VALUES ('907','894','邱县','0');
INSERT INTO `yzh_area` VALUES ('908','894','鸡泽县','0');
INSERT INTO `yzh_area` VALUES ('909','894','广平县','0');
INSERT INTO `yzh_area` VALUES ('910','894','馆陶县','0');
INSERT INTO `yzh_area` VALUES ('911','894','魏县','0');
INSERT INTO `yzh_area` VALUES ('912','894','曲周县','0');
INSERT INTO `yzh_area` VALUES ('913','894','武安市','0');
INSERT INTO `yzh_area` VALUES ('914','814','衡水市','0');
INSERT INTO `yzh_area` VALUES ('915','914','桃城区','0');
INSERT INTO `yzh_area` VALUES ('916','914','枣强县','0');
INSERT INTO `yzh_area` VALUES ('917','914','武邑县','0');
INSERT INTO `yzh_area` VALUES ('918','914','武强县','0');
INSERT INTO `yzh_area` VALUES ('919','914','饶阳县','0');
INSERT INTO `yzh_area` VALUES ('920','914','安平县','0');
INSERT INTO `yzh_area` VALUES ('921','914','故城县','0');
INSERT INTO `yzh_area` VALUES ('922','914','景县','0');
INSERT INTO `yzh_area` VALUES ('923','914','阜城县','0');
INSERT INTO `yzh_area` VALUES ('924','914','冀州市','0');
INSERT INTO `yzh_area` VALUES ('925','914','深州市','0');
INSERT INTO `yzh_area` VALUES ('926','814','廊坊市','0');
INSERT INTO `yzh_area` VALUES ('927','926','安次区','0');
INSERT INTO `yzh_area` VALUES ('928','926','广阳区','0');
INSERT INTO `yzh_area` VALUES ('929','926','固安县','0');
INSERT INTO `yzh_area` VALUES ('930','926','永清县','0');
INSERT INTO `yzh_area` VALUES ('931','926','香河县','0');
INSERT INTO `yzh_area` VALUES ('932','926','大城县','0');
INSERT INTO `yzh_area` VALUES ('933','926','文安县','0');
INSERT INTO `yzh_area` VALUES ('934','926','大厂回族自治县','0');
INSERT INTO `yzh_area` VALUES ('935','926','霸州市','0');
INSERT INTO `yzh_area` VALUES ('936','926','三河市','0');
INSERT INTO `yzh_area` VALUES ('937','814','秦皇岛市','0');
INSERT INTO `yzh_area` VALUES ('938','937','海港区','0');
INSERT INTO `yzh_area` VALUES ('939','937','山海关区','0');
INSERT INTO `yzh_area` VALUES ('940','937','北戴河区','0');
INSERT INTO `yzh_area` VALUES ('941','937','青龙满族自治县','0');
INSERT INTO `yzh_area` VALUES ('942','937','昌黎县','0');
INSERT INTO `yzh_area` VALUES ('943','937','抚宁县','0');
INSERT INTO `yzh_area` VALUES ('944','937','卢龙县','0');
INSERT INTO `yzh_area` VALUES ('945','814','唐山市','0');
INSERT INTO `yzh_area` VALUES ('946','945','路南区','0');
INSERT INTO `yzh_area` VALUES ('947','945','路北区','0');
INSERT INTO `yzh_area` VALUES ('948','945','古冶区','0');
INSERT INTO `yzh_area` VALUES ('949','945','开平区','0');
INSERT INTO `yzh_area` VALUES ('950','945','丰南区','0');
INSERT INTO `yzh_area` VALUES ('951','945','丰润区','0');
INSERT INTO `yzh_area` VALUES ('952','945','滦县','0');
INSERT INTO `yzh_area` VALUES ('953','945','滦南县','0');
INSERT INTO `yzh_area` VALUES ('954','945','乐亭县','0');
INSERT INTO `yzh_area` VALUES ('955','945','迁西县','0');
INSERT INTO `yzh_area` VALUES ('956','945','玉田县','0');
INSERT INTO `yzh_area` VALUES ('957','945','唐海县','0');
INSERT INTO `yzh_area` VALUES ('958','945','遵化市','0');
INSERT INTO `yzh_area` VALUES ('959','945','迁安市','0');
INSERT INTO `yzh_area` VALUES ('960','814','邢台市','0');
INSERT INTO `yzh_area` VALUES ('961','960','桥东区','0');
INSERT INTO `yzh_area` VALUES ('962','960','桥西区','0');
INSERT INTO `yzh_area` VALUES ('963','960','邢台县','0');
INSERT INTO `yzh_area` VALUES ('964','960','临城县','0');
INSERT INTO `yzh_area` VALUES ('965','960','内丘县','0');
INSERT INTO `yzh_area` VALUES ('966','960','柏乡县','0');
INSERT INTO `yzh_area` VALUES ('967','960','隆尧县','0');
INSERT INTO `yzh_area` VALUES ('968','960','任县','0');
INSERT INTO `yzh_area` VALUES ('969','960','南和县','0');
INSERT INTO `yzh_area` VALUES ('970','960','宁晋县','0');
INSERT INTO `yzh_area` VALUES ('971','960','巨鹿县','0');
INSERT INTO `yzh_area` VALUES ('972','960','新河县','0');
INSERT INTO `yzh_area` VALUES ('973','960','广宗县','0');
INSERT INTO `yzh_area` VALUES ('974','960','平乡县','0');
INSERT INTO `yzh_area` VALUES ('975','960','威县','0');
INSERT INTO `yzh_area` VALUES ('976','960','清河县','0');
INSERT INTO `yzh_area` VALUES ('977','960','临西县','0');
INSERT INTO `yzh_area` VALUES ('978','960','南宫市','0');
INSERT INTO `yzh_area` VALUES ('979','960','沙河市','0');
INSERT INTO `yzh_area` VALUES ('980','814','张家口市','0');
INSERT INTO `yzh_area` VALUES ('981','980','桥东区','0');
INSERT INTO `yzh_area` VALUES ('982','980','桥西区','0');
INSERT INTO `yzh_area` VALUES ('983','980','宣化区','0');
INSERT INTO `yzh_area` VALUES ('984','980','下花园区','0');
INSERT INTO `yzh_area` VALUES ('985','980','宣化县','0');
INSERT INTO `yzh_area` VALUES ('986','980','张北县','0');
INSERT INTO `yzh_area` VALUES ('987','980','康保县','0');
INSERT INTO `yzh_area` VALUES ('988','980','沽源县','0');
INSERT INTO `yzh_area` VALUES ('989','980','尚义县','0');
INSERT INTO `yzh_area` VALUES ('990','980','蔚县','0');
INSERT INTO `yzh_area` VALUES ('991','980','阳原县','0');
INSERT INTO `yzh_area` VALUES ('992','980','怀安县','0');
INSERT INTO `yzh_area` VALUES ('993','980','万全县','0');
INSERT INTO `yzh_area` VALUES ('994','980','怀来县','0');
INSERT INTO `yzh_area` VALUES ('995','980','涿鹿县','0');
INSERT INTO `yzh_area` VALUES ('996','980','赤城县','0');
INSERT INTO `yzh_area` VALUES ('997','980','崇礼县','0');
INSERT INTO `yzh_area` VALUES ('998','0','河南','0');
INSERT INTO `yzh_area` VALUES ('999','998','郑州市','0');
INSERT INTO `yzh_area` VALUES ('1000','999','中原区','0');
INSERT INTO `yzh_area` VALUES ('1001','999','二七区','0');
INSERT INTO `yzh_area` VALUES ('1002','999','管城回族区','0');
INSERT INTO `yzh_area` VALUES ('1003','999','金水区','0');
INSERT INTO `yzh_area` VALUES ('1004','999','上街区','0');
INSERT INTO `yzh_area` VALUES ('1005','999','邙山区','0');
INSERT INTO `yzh_area` VALUES ('1006','999','中牟县','0');
INSERT INTO `yzh_area` VALUES ('1007','999','巩义市','0');
INSERT INTO `yzh_area` VALUES ('1008','999','荥阳市','0');
INSERT INTO `yzh_area` VALUES ('1009','999','新密市','0');
INSERT INTO `yzh_area` VALUES ('1010','999','新郑市','0');
INSERT INTO `yzh_area` VALUES ('1011','999','登封市','0');
INSERT INTO `yzh_area` VALUES ('1012','998','安阳市','0');
INSERT INTO `yzh_area` VALUES ('1013','1012','文峰区','0');
INSERT INTO `yzh_area` VALUES ('1014','1012','北关区','0');
INSERT INTO `yzh_area` VALUES ('1015','1012','殷都区','0');
INSERT INTO `yzh_area` VALUES ('1016','1012','龙安区','0');
INSERT INTO `yzh_area` VALUES ('1017','1012','安阳县','0');
INSERT INTO `yzh_area` VALUES ('1018','1012','汤阴县','0');
INSERT INTO `yzh_area` VALUES ('1019','1012','滑县','0');
INSERT INTO `yzh_area` VALUES ('1020','1012','内黄县','0');
INSERT INTO `yzh_area` VALUES ('1021','1012','林州市','0');
INSERT INTO `yzh_area` VALUES ('1022','998','鹤壁市','0');
INSERT INTO `yzh_area` VALUES ('1023','1022','鹤山区','0');
INSERT INTO `yzh_area` VALUES ('1024','1022','山城区','0');
INSERT INTO `yzh_area` VALUES ('1025','1022','淇滨区','0');
INSERT INTO `yzh_area` VALUES ('1026','1022','浚县','0');
INSERT INTO `yzh_area` VALUES ('1027','1022','淇县','0');
INSERT INTO `yzh_area` VALUES ('1028','998','济源市','0');
INSERT INTO `yzh_area` VALUES ('1029','998','焦作市','0');
INSERT INTO `yzh_area` VALUES ('1030','1029','解放区','0');
INSERT INTO `yzh_area` VALUES ('1031','1029','中站区','0');
INSERT INTO `yzh_area` VALUES ('1032','1029','马村区','0');
INSERT INTO `yzh_area` VALUES ('1033','1029','山阳区','0');
INSERT INTO `yzh_area` VALUES ('1034','1029','修武县','0');
INSERT INTO `yzh_area` VALUES ('1035','1029','博爱县','0');
INSERT INTO `yzh_area` VALUES ('1036','1029','武陟县','0');
INSERT INTO `yzh_area` VALUES ('1037','1029','温县','0');
INSERT INTO `yzh_area` VALUES ('1038','1029','济源市','0');
INSERT INTO `yzh_area` VALUES ('1039','1029','沁阳市','0');
INSERT INTO `yzh_area` VALUES ('1040','1029','孟州市','0');
INSERT INTO `yzh_area` VALUES ('1041','998','开封市','0');
INSERT INTO `yzh_area` VALUES ('1042','1041','龙亭区','0');
INSERT INTO `yzh_area` VALUES ('1043','1041','顺河回族区','0');
INSERT INTO `yzh_area` VALUES ('1044','1041','鼓楼区','0');
INSERT INTO `yzh_area` VALUES ('1045','1041','南关区','0');
INSERT INTO `yzh_area` VALUES ('1046','1041','郊区','0');
INSERT INTO `yzh_area` VALUES ('1047','1041','杞县','0');
INSERT INTO `yzh_area` VALUES ('1048','1041','通许县','0');
INSERT INTO `yzh_area` VALUES ('1049','1041','尉氏县','0');
INSERT INTO `yzh_area` VALUES ('1050','1041','开封县','0');
INSERT INTO `yzh_area` VALUES ('1051','1041','兰考县','0');
INSERT INTO `yzh_area` VALUES ('1052','998','洛阳市','0');
INSERT INTO `yzh_area` VALUES ('1053','1052','老城区','0');
INSERT INTO `yzh_area` VALUES ('1054','1052','西工区','0');
INSERT INTO `yzh_area` VALUES ('1055','1052','廛河回族区','0');
INSERT INTO `yzh_area` VALUES ('1056','1052','涧西区','0');
INSERT INTO `yzh_area` VALUES ('1057','1052','吉利区','0');
INSERT INTO `yzh_area` VALUES ('1058','1052','洛龙区','0');
INSERT INTO `yzh_area` VALUES ('1059','1052','孟津县','0');
INSERT INTO `yzh_area` VALUES ('1060','1052','新安县','0');
INSERT INTO `yzh_area` VALUES ('1061','1052','栾川县','0');
INSERT INTO `yzh_area` VALUES ('1062','1052','嵩县','0');
INSERT INTO `yzh_area` VALUES ('1063','1052','汝阳县','0');
INSERT INTO `yzh_area` VALUES ('1064','1052','宜阳县','0');
INSERT INTO `yzh_area` VALUES ('1065','1052','洛宁县','0');
INSERT INTO `yzh_area` VALUES ('1066','1052','伊川县','0');
INSERT INTO `yzh_area` VALUES ('1067','1052','偃师市','0');
INSERT INTO `yzh_area` VALUES ('1068','998','漯河市','0');
INSERT INTO `yzh_area` VALUES ('1069','1068','源汇区','0');
INSERT INTO `yzh_area` VALUES ('1070','1068','郾城区','0');
INSERT INTO `yzh_area` VALUES ('1071','1068','召陵区','0');
INSERT INTO `yzh_area` VALUES ('1072','1068','舞阳县','0');
INSERT INTO `yzh_area` VALUES ('1073','1068','临颍县','0');
INSERT INTO `yzh_area` VALUES ('1074','998','南阳市','0');
INSERT INTO `yzh_area` VALUES ('1075','1074','宛城区','0');
INSERT INTO `yzh_area` VALUES ('1076','1074','卧龙区','0');
INSERT INTO `yzh_area` VALUES ('1077','1074','南召县','0');
INSERT INTO `yzh_area` VALUES ('1078','1074','方城县','0');
INSERT INTO `yzh_area` VALUES ('1079','1074','西峡县','0');
INSERT INTO `yzh_area` VALUES ('1080','1074','镇平县','0');
INSERT INTO `yzh_area` VALUES ('1081','1074','内乡县','0');
INSERT INTO `yzh_area` VALUES ('1082','1074','淅川县','0');
INSERT INTO `yzh_area` VALUES ('1083','1074','社旗县','0');
INSERT INTO `yzh_area` VALUES ('1084','1074','唐河县','0');
INSERT INTO `yzh_area` VALUES ('1085','1074','新野县','0');
INSERT INTO `yzh_area` VALUES ('1086','1074','桐柏县','0');
INSERT INTO `yzh_area` VALUES ('1087','1074','邓州市','0');
INSERT INTO `yzh_area` VALUES ('1088','998','平顶山市','0');
INSERT INTO `yzh_area` VALUES ('1089','1088','新华区','0');
INSERT INTO `yzh_area` VALUES ('1090','1088','卫东区','0');
INSERT INTO `yzh_area` VALUES ('1091','1088','石龙区','0');
INSERT INTO `yzh_area` VALUES ('1092','1088','湛河区','0');
INSERT INTO `yzh_area` VALUES ('1093','1088','宝丰县','0');
INSERT INTO `yzh_area` VALUES ('1094','1088','叶县','0');
INSERT INTO `yzh_area` VALUES ('1095','1088','鲁山县','0');
INSERT INTO `yzh_area` VALUES ('1096','1088','郏县','0');
INSERT INTO `yzh_area` VALUES ('1097','1088','舞钢市','0');
INSERT INTO `yzh_area` VALUES ('1098','1088','汝州市','0');
INSERT INTO `yzh_area` VALUES ('1099','998','濮阳市','0');
INSERT INTO `yzh_area` VALUES ('1100','1099','华龙区','0');
INSERT INTO `yzh_area` VALUES ('1101','1099','清丰县','0');
INSERT INTO `yzh_area` VALUES ('1102','1099','南乐县','0');
INSERT INTO `yzh_area` VALUES ('1103','1099','范县','0');
INSERT INTO `yzh_area` VALUES ('1104','1099','台前县','0');
INSERT INTO `yzh_area` VALUES ('1105','1099','濮阳县','0');
INSERT INTO `yzh_area` VALUES ('1106','998','三门峡市','0');
INSERT INTO `yzh_area` VALUES ('1107','1106','湖滨区','0');
INSERT INTO `yzh_area` VALUES ('1108','1106','渑池县','0');
INSERT INTO `yzh_area` VALUES ('1109','1106','陕县','0');
INSERT INTO `yzh_area` VALUES ('1110','1106','卢氏县','0');
INSERT INTO `yzh_area` VALUES ('1111','1106','义马市','0');
INSERT INTO `yzh_area` VALUES ('1112','1106','灵宝市','0');
INSERT INTO `yzh_area` VALUES ('1113','998','商丘市','0');
INSERT INTO `yzh_area` VALUES ('1114','1113','梁园区','0');
INSERT INTO `yzh_area` VALUES ('1115','1113','睢阳区','0');
INSERT INTO `yzh_area` VALUES ('1116','1113','民权县','0');
INSERT INTO `yzh_area` VALUES ('1117','1113','睢县','0');
INSERT INTO `yzh_area` VALUES ('1118','1113','宁陵县','0');
INSERT INTO `yzh_area` VALUES ('1119','1113','柘城县','0');
INSERT INTO `yzh_area` VALUES ('1120','1113','虞城县','0');
INSERT INTO `yzh_area` VALUES ('1121','1113','夏邑县','0');
INSERT INTO `yzh_area` VALUES ('1122','1113','永城市','0');
INSERT INTO `yzh_area` VALUES ('1123','998','新乡市','0');
INSERT INTO `yzh_area` VALUES ('1124','1123','红旗区','0');
INSERT INTO `yzh_area` VALUES ('1125','1123','卫滨区','0');
INSERT INTO `yzh_area` VALUES ('1126','1123','凤泉区','0');
INSERT INTO `yzh_area` VALUES ('1127','1123','牧野区','0');
INSERT INTO `yzh_area` VALUES ('1128','1123','新乡县','0');
INSERT INTO `yzh_area` VALUES ('1129','1123','获嘉县','0');
INSERT INTO `yzh_area` VALUES ('1130','1123','原阳县','0');
INSERT INTO `yzh_area` VALUES ('1131','1123','延津县','0');
INSERT INTO `yzh_area` VALUES ('1132','1123','封丘县','0');
INSERT INTO `yzh_area` VALUES ('1133','1123','长垣县','0');
INSERT INTO `yzh_area` VALUES ('1134','1123','卫辉市','0');
INSERT INTO `yzh_area` VALUES ('1135','1123','辉县市','0');
INSERT INTO `yzh_area` VALUES ('1136','998','信阳市','0');
INSERT INTO `yzh_area` VALUES ('1137','1136','师河区','0');
INSERT INTO `yzh_area` VALUES ('1138','1136','平桥区','0');
INSERT INTO `yzh_area` VALUES ('1139','1136','罗山县','0');
INSERT INTO `yzh_area` VALUES ('1140','1136','光山县','0');
INSERT INTO `yzh_area` VALUES ('1141','1136','新县','0');
INSERT INTO `yzh_area` VALUES ('1142','1136','商城县','0');
INSERT INTO `yzh_area` VALUES ('1143','1136','固始县','0');
INSERT INTO `yzh_area` VALUES ('1144','1136','潢川县','0');
INSERT INTO `yzh_area` VALUES ('1145','1136','淮滨县','0');
INSERT INTO `yzh_area` VALUES ('1146','1136','息县','0');
INSERT INTO `yzh_area` VALUES ('1147','998','许昌市','0');
INSERT INTO `yzh_area` VALUES ('1148','1147','魏都区','0');
INSERT INTO `yzh_area` VALUES ('1149','1147','许昌县','0');
INSERT INTO `yzh_area` VALUES ('1150','1147','鄢陵县','0');
INSERT INTO `yzh_area` VALUES ('1151','1147','襄城县','0');
INSERT INTO `yzh_area` VALUES ('1152','1147','禹州市','0');
INSERT INTO `yzh_area` VALUES ('1153','1147','长葛市','0');
INSERT INTO `yzh_area` VALUES ('1154','998','周口市','0');
INSERT INTO `yzh_area` VALUES ('1155','1154','川汇区','0');
INSERT INTO `yzh_area` VALUES ('1156','1154','扶沟县','0');
INSERT INTO `yzh_area` VALUES ('1157','1154','西华县','0');
INSERT INTO `yzh_area` VALUES ('1158','1154','商水县','0');
INSERT INTO `yzh_area` VALUES ('1159','1154','沈丘县','0');
INSERT INTO `yzh_area` VALUES ('1160','1154','郸城县','0');
INSERT INTO `yzh_area` VALUES ('1161','1154','淮阳县','0');
INSERT INTO `yzh_area` VALUES ('1162','1154','太康县','0');
INSERT INTO `yzh_area` VALUES ('1163','1154','鹿邑县','0');
INSERT INTO `yzh_area` VALUES ('1164','1154','项城市','0');
INSERT INTO `yzh_area` VALUES ('1165','998','驻马店市','0');
INSERT INTO `yzh_area` VALUES ('1166','1165','驿城区','0');
INSERT INTO `yzh_area` VALUES ('1167','1165','西平县','0');
INSERT INTO `yzh_area` VALUES ('1168','1165','上蔡县','0');
INSERT INTO `yzh_area` VALUES ('1169','1165','平舆县','0');
INSERT INTO `yzh_area` VALUES ('1170','1165','正阳县','0');
INSERT INTO `yzh_area` VALUES ('1171','1165','确山县','0');
INSERT INTO `yzh_area` VALUES ('1172','1165','泌阳县','0');
INSERT INTO `yzh_area` VALUES ('1173','1165','汝南县','0');
INSERT INTO `yzh_area` VALUES ('1174','1165','遂平县','0');
INSERT INTO `yzh_area` VALUES ('1175','1165','新蔡县','0');
INSERT INTO `yzh_area` VALUES ('1176','0','黑龙江','0');
INSERT INTO `yzh_area` VALUES ('1177','1176','哈尔滨市','0');
INSERT INTO `yzh_area` VALUES ('1178','1177','道里区','0');
INSERT INTO `yzh_area` VALUES ('1179','1177','南岗区','0');
INSERT INTO `yzh_area` VALUES ('1180','1177','道外区','0');
INSERT INTO `yzh_area` VALUES ('1181','1177','香坊区','0');
INSERT INTO `yzh_area` VALUES ('1182','1177','动力区','0');
INSERT INTO `yzh_area` VALUES ('1183','1177','平房区','0');
INSERT INTO `yzh_area` VALUES ('1184','1177','松北区','0');
INSERT INTO `yzh_area` VALUES ('1185','1177','呼兰区','0');
INSERT INTO `yzh_area` VALUES ('1186','1177','依兰县','0');
INSERT INTO `yzh_area` VALUES ('1187','1177','方正县','0');
INSERT INTO `yzh_area` VALUES ('1188','1177','宾县','0');
INSERT INTO `yzh_area` VALUES ('1189','1177','巴彦县','0');
INSERT INTO `yzh_area` VALUES ('1190','1177','木兰县','0');
INSERT INTO `yzh_area` VALUES ('1191','1177','通河县','0');
INSERT INTO `yzh_area` VALUES ('1192','1177','延寿县','0');
INSERT INTO `yzh_area` VALUES ('1193','1177','阿城市','0');
INSERT INTO `yzh_area` VALUES ('1194','1177','双城市','0');
INSERT INTO `yzh_area` VALUES ('1195','1177','尚志市','0');
INSERT INTO `yzh_area` VALUES ('1196','1177','五常市','0');
INSERT INTO `yzh_area` VALUES ('1197','1176','大庆市','0');
INSERT INTO `yzh_area` VALUES ('1198','1197','萨尔图区','0');
INSERT INTO `yzh_area` VALUES ('1199','1197','龙凤区','0');
INSERT INTO `yzh_area` VALUES ('1200','1197','让胡路区','0');
INSERT INTO `yzh_area` VALUES ('1201','1197','红岗区','0');
INSERT INTO `yzh_area` VALUES ('1202','1197','大同区','0');
INSERT INTO `yzh_area` VALUES ('1203','1197','肇州县','0');
INSERT INTO `yzh_area` VALUES ('1204','1197','肇源县','0');
INSERT INTO `yzh_area` VALUES ('1205','1197','林甸县','0');
INSERT INTO `yzh_area` VALUES ('1206','1197','杜尔伯特蒙古族自治县','0');
INSERT INTO `yzh_area` VALUES ('1207','1176','大兴安岭地区','0');
INSERT INTO `yzh_area` VALUES ('1208','1207','呼玛县','0');
INSERT INTO `yzh_area` VALUES ('1209','1207','塔河县','0');
INSERT INTO `yzh_area` VALUES ('1210','1207','漠河县','0');
INSERT INTO `yzh_area` VALUES ('1211','1176','鹤岗市','0');
INSERT INTO `yzh_area` VALUES ('1212','1211','向阳区','0');
INSERT INTO `yzh_area` VALUES ('1213','1211','工农区','0');
INSERT INTO `yzh_area` VALUES ('1214','1211','南山区','0');
INSERT INTO `yzh_area` VALUES ('1215','1211','兴安区','0');
INSERT INTO `yzh_area` VALUES ('1216','1211','东山区','0');
INSERT INTO `yzh_area` VALUES ('1217','1211','兴山区','0');
INSERT INTO `yzh_area` VALUES ('1218','1211','萝北县','0');
INSERT INTO `yzh_area` VALUES ('1219','1211','绥滨县','0');
INSERT INTO `yzh_area` VALUES ('1220','1176','黑河市','0');
INSERT INTO `yzh_area` VALUES ('1221','1220','爱辉区','0');
INSERT INTO `yzh_area` VALUES ('1222','1220','嫩江县','0');
INSERT INTO `yzh_area` VALUES ('1223','1220','逊克县','0');
INSERT INTO `yzh_area` VALUES ('1224','1220','孙吴县','0');
INSERT INTO `yzh_area` VALUES ('1225','1220','北安市','0');
INSERT INTO `yzh_area` VALUES ('1226','1220','五大连池市','0');
INSERT INTO `yzh_area` VALUES ('1227','1176','鸡西市','0');
INSERT INTO `yzh_area` VALUES ('1228','1227','鸡冠区','0');
INSERT INTO `yzh_area` VALUES ('1229','1227','恒山区','0');
INSERT INTO `yzh_area` VALUES ('1230','1227','滴道区','0');
INSERT INTO `yzh_area` VALUES ('1231','1227','梨树区','0');
INSERT INTO `yzh_area` VALUES ('1232','1227','城子河区','0');
INSERT INTO `yzh_area` VALUES ('1233','1227','麻山区','0');
INSERT INTO `yzh_area` VALUES ('1234','1227','鸡东县','0');
INSERT INTO `yzh_area` VALUES ('1235','1227','虎林市','0');
INSERT INTO `yzh_area` VALUES ('1236','1227','密山市','0');
INSERT INTO `yzh_area` VALUES ('1237','1176','佳木斯市','0');
INSERT INTO `yzh_area` VALUES ('1238','1237','永红区','0');
INSERT INTO `yzh_area` VALUES ('1239','1237','向阳区','0');
INSERT INTO `yzh_area` VALUES ('1240','1237','前进区','0');
INSERT INTO `yzh_area` VALUES ('1241','1237','东风区','0');
INSERT INTO `yzh_area` VALUES ('1242','1237','郊区','0');
INSERT INTO `yzh_area` VALUES ('1243','1237','桦南县','0');
INSERT INTO `yzh_area` VALUES ('1244','1237','桦川县','0');
INSERT INTO `yzh_area` VALUES ('1245','1237','汤原县','0');
INSERT INTO `yzh_area` VALUES ('1246','1237','抚远县','0');
INSERT INTO `yzh_area` VALUES ('1247','1237','同江市','0');
INSERT INTO `yzh_area` VALUES ('1248','1237','富锦市','0');
INSERT INTO `yzh_area` VALUES ('1249','1176','牡丹江市','0');
INSERT INTO `yzh_area` VALUES ('1250','1249','东安区','0');
INSERT INTO `yzh_area` VALUES ('1251','1249','阳明区','0');
INSERT INTO `yzh_area` VALUES ('1252','1249','爱民区','0');
INSERT INTO `yzh_area` VALUES ('1253','1249','西安区','0');
INSERT INTO `yzh_area` VALUES ('1254','1249','东宁县','0');
INSERT INTO `yzh_area` VALUES ('1255','1249','林口县','0');
INSERT INTO `yzh_area` VALUES ('1256','1249','绥芬河市','0');
INSERT INTO `yzh_area` VALUES ('1257','1249','海林市','0');
INSERT INTO `yzh_area` VALUES ('1258','1249','宁安市','0');
INSERT INTO `yzh_area` VALUES ('1259','1249','穆棱市','0');
INSERT INTO `yzh_area` VALUES ('1260','1176','七台河市','0');
INSERT INTO `yzh_area` VALUES ('1261','1260','新兴区','0');
INSERT INTO `yzh_area` VALUES ('1262','1260','桃山区','0');
INSERT INTO `yzh_area` VALUES ('1263','1260','茄子河区','0');
INSERT INTO `yzh_area` VALUES ('1264','1260','勃利县','0');
INSERT INTO `yzh_area` VALUES ('1265','1176','齐齐哈尔市','0');
INSERT INTO `yzh_area` VALUES ('1266','1265','龙沙区','0');
INSERT INTO `yzh_area` VALUES ('1267','1265','建华区','0');
INSERT INTO `yzh_area` VALUES ('1268','1265','铁锋区','0');
INSERT INTO `yzh_area` VALUES ('1269','1265','昂昂溪区','0');
INSERT INTO `yzh_area` VALUES ('1270','1265','富拉尔基区','0');
INSERT INTO `yzh_area` VALUES ('1271','1265','碾子山区','0');
INSERT INTO `yzh_area` VALUES ('1272','1265','梅里斯达斡尔族区','0');
INSERT INTO `yzh_area` VALUES ('1273','1265','龙江县','0');
INSERT INTO `yzh_area` VALUES ('1274','1265','依安县','0');
INSERT INTO `yzh_area` VALUES ('1275','1265','泰来县','0');
INSERT INTO `yzh_area` VALUES ('1276','1265','甘南县','0');
INSERT INTO `yzh_area` VALUES ('1277','1265','富裕县','0');
INSERT INTO `yzh_area` VALUES ('1278','1265','克山县','0');
INSERT INTO `yzh_area` VALUES ('1279','1265','克东县','0');
INSERT INTO `yzh_area` VALUES ('1280','1265','拜泉县','0');
INSERT INTO `yzh_area` VALUES ('1281','1265','讷河市','0');
INSERT INTO `yzh_area` VALUES ('1282','1176','双鸭山市','0');
INSERT INTO `yzh_area` VALUES ('1283','1282','尖山区','0');
INSERT INTO `yzh_area` VALUES ('1284','1282','岭东区','0');
INSERT INTO `yzh_area` VALUES ('1285','1282','四方台区','0');
INSERT INTO `yzh_area` VALUES ('1286','1282','宝山区','0');
INSERT INTO `yzh_area` VALUES ('1287','1282','集贤县','0');
INSERT INTO `yzh_area` VALUES ('1288','1282','友谊县','0');
INSERT INTO `yzh_area` VALUES ('1289','1282','宝清县','0');
INSERT INTO `yzh_area` VALUES ('1290','1282','饶河县','0');
INSERT INTO `yzh_area` VALUES ('1291','1176','绥化市','0');
INSERT INTO `yzh_area` VALUES ('1292','1291','北林区','0');
INSERT INTO `yzh_area` VALUES ('1293','1291','望奎县','0');
INSERT INTO `yzh_area` VALUES ('1294','1291','兰西县','0');
INSERT INTO `yzh_area` VALUES ('1295','1291','青冈县','0');
INSERT INTO `yzh_area` VALUES ('1296','1291','庆安县','0');
INSERT INTO `yzh_area` VALUES ('1297','1291','明水县','0');
INSERT INTO `yzh_area` VALUES ('1298','1291','绥棱县','0');
INSERT INTO `yzh_area` VALUES ('1299','1291','安达市','0');
INSERT INTO `yzh_area` VALUES ('1300','1291','肇东市','0');
INSERT INTO `yzh_area` VALUES ('1301','1291','海伦市','0');
INSERT INTO `yzh_area` VALUES ('1302','1176','伊春市','0');
INSERT INTO `yzh_area` VALUES ('1303','1302','伊春区','0');
INSERT INTO `yzh_area` VALUES ('1304','1302','南岔区','0');
INSERT INTO `yzh_area` VALUES ('1305','1302','友好区','0');
INSERT INTO `yzh_area` VALUES ('1306','1302','西林区','0');
INSERT INTO `yzh_area` VALUES ('1307','1302','翠峦区','0');
INSERT INTO `yzh_area` VALUES ('1308','1302','新青区','0');
INSERT INTO `yzh_area` VALUES ('1309','1302','美溪区','0');
INSERT INTO `yzh_area` VALUES ('1310','1302','金山屯区','0');
INSERT INTO `yzh_area` VALUES ('1311','1302','五营区','0');
INSERT INTO `yzh_area` VALUES ('1312','1302','乌马河区','0');
INSERT INTO `yzh_area` VALUES ('1313','1302','汤旺河区','0');
INSERT INTO `yzh_area` VALUES ('1314','1302','带岭区','0');
INSERT INTO `yzh_area` VALUES ('1315','1302','乌伊岭区','0');
INSERT INTO `yzh_area` VALUES ('1316','1302','红星区','0');
INSERT INTO `yzh_area` VALUES ('1317','1302','上甘岭区','0');
INSERT INTO `yzh_area` VALUES ('1318','1302','嘉荫县','0');
INSERT INTO `yzh_area` VALUES ('1319','1302','铁力市','0');
INSERT INTO `yzh_area` VALUES ('1320','0','湖北','0');
INSERT INTO `yzh_area` VALUES ('1321','1320','武汉市','0');
INSERT INTO `yzh_area` VALUES ('1322','1321','江岸区','0');
INSERT INTO `yzh_area` VALUES ('1323','1321','江汉区','0');
INSERT INTO `yzh_area` VALUES ('1324','1321','乔口区','0');
INSERT INTO `yzh_area` VALUES ('1325','1321','汉阳区','0');
INSERT INTO `yzh_area` VALUES ('1326','1321','武昌区','0');
INSERT INTO `yzh_area` VALUES ('1327','1321','青山区','0');
INSERT INTO `yzh_area` VALUES ('1328','1321','洪山区','0');
INSERT INTO `yzh_area` VALUES ('1329','1321','东西湖区','0');
INSERT INTO `yzh_area` VALUES ('1330','1321','汉南区','0');
INSERT INTO `yzh_area` VALUES ('1331','1321','蔡甸区','0');
INSERT INTO `yzh_area` VALUES ('1332','1321','江夏区','0');
INSERT INTO `yzh_area` VALUES ('1333','1321','黄陂区','0');
INSERT INTO `yzh_area` VALUES ('1334','1321','新洲区','0');
INSERT INTO `yzh_area` VALUES ('1335','1320','鄂州市','0');
INSERT INTO `yzh_area` VALUES ('1336','1335','梁子湖区','0');
INSERT INTO `yzh_area` VALUES ('1337','1335','华容区','0');
INSERT INTO `yzh_area` VALUES ('1338','1335','鄂城区','0');
INSERT INTO `yzh_area` VALUES ('1339','1320','恩施土家族苗族自治州','0');
INSERT INTO `yzh_area` VALUES ('1340','1339','恩施市','0');
INSERT INTO `yzh_area` VALUES ('1341','1339','利川市','0');
INSERT INTO `yzh_area` VALUES ('1342','1339','建始县','0');
INSERT INTO `yzh_area` VALUES ('1343','1339','巴东县','0');
INSERT INTO `yzh_area` VALUES ('1344','1339','宣恩县','0');
INSERT INTO `yzh_area` VALUES ('1345','1339','咸丰县','0');
INSERT INTO `yzh_area` VALUES ('1346','1339','来凤县','0');
INSERT INTO `yzh_area` VALUES ('1347','1339','鹤峰县','0');
INSERT INTO `yzh_area` VALUES ('1348','1320','黄冈市','0');
INSERT INTO `yzh_area` VALUES ('1349','1348','黄州区','0');
INSERT INTO `yzh_area` VALUES ('1350','1348','团风县','0');
INSERT INTO `yzh_area` VALUES ('1351','1348','红安县','0');
INSERT INTO `yzh_area` VALUES ('1352','1348','罗田县','0');
INSERT INTO `yzh_area` VALUES ('1353','1348','英山县','0');
INSERT INTO `yzh_area` VALUES ('1354','1348','浠水县','0');
INSERT INTO `yzh_area` VALUES ('1355','1348','蕲春县','0');
INSERT INTO `yzh_area` VALUES ('1356','1348','黄梅县','0');
INSERT INTO `yzh_area` VALUES ('1357','1348','麻城市','0');
INSERT INTO `yzh_area` VALUES ('1358','1348','武穴市','0');
INSERT INTO `yzh_area` VALUES ('1359','1320','黄石市','0');
INSERT INTO `yzh_area` VALUES ('1360','1359','黄石港区','0');
INSERT INTO `yzh_area` VALUES ('1361','1359','西塞山区','0');
INSERT INTO `yzh_area` VALUES ('1362','1359','下陆区','0');
INSERT INTO `yzh_area` VALUES ('1363','1359','铁山区','0');
INSERT INTO `yzh_area` VALUES ('1364','1359','阳新县','0');
INSERT INTO `yzh_area` VALUES ('1365','1359','大冶市','0');
INSERT INTO `yzh_area` VALUES ('1366','1320','荆门市','0');
INSERT INTO `yzh_area` VALUES ('1367','1366','东宝区','0');
INSERT INTO `yzh_area` VALUES ('1368','1366','掇刀区','0');
INSERT INTO `yzh_area` VALUES ('1369','1366','京山县','0');
INSERT INTO `yzh_area` VALUES ('1370','1366','沙洋县','0');
INSERT INTO `yzh_area` VALUES ('1371','1366','钟祥市','0');
INSERT INTO `yzh_area` VALUES ('1372','1320','荆州市','0');
INSERT INTO `yzh_area` VALUES ('1373','1372','沙市区','0');
INSERT INTO `yzh_area` VALUES ('1374','1372','荆州区','0');
INSERT INTO `yzh_area` VALUES ('1375','1372','公安县','0');
INSERT INTO `yzh_area` VALUES ('1376','1372','监利县','0');
INSERT INTO `yzh_area` VALUES ('1377','1372','江陵县','0');
INSERT INTO `yzh_area` VALUES ('1378','1372','石首市','0');
INSERT INTO `yzh_area` VALUES ('1379','1372','洪湖市','0');
INSERT INTO `yzh_area` VALUES ('1380','1372','松滋市','0');
INSERT INTO `yzh_area` VALUES ('1381','1320','潜江市','0');
INSERT INTO `yzh_area` VALUES ('1382','1320','神农架林区','0');
INSERT INTO `yzh_area` VALUES ('1383','1320','十堰市','0');
INSERT INTO `yzh_area` VALUES ('1384','1383','茅箭区','0');
INSERT INTO `yzh_area` VALUES ('1385','1383','张湾区','0');
INSERT INTO `yzh_area` VALUES ('1386','1383','郧县','0');
INSERT INTO `yzh_area` VALUES ('1387','1383','郧西县','0');
INSERT INTO `yzh_area` VALUES ('1388','1383','竹山县','0');
INSERT INTO `yzh_area` VALUES ('1389','1383','竹溪县','0');
INSERT INTO `yzh_area` VALUES ('1390','1383','房县','0');
INSERT INTO `yzh_area` VALUES ('1391','1383','丹江口市','0');
INSERT INTO `yzh_area` VALUES ('1392','1320','随州市','0');
INSERT INTO `yzh_area` VALUES ('1393','1392','曾都区','0');
INSERT INTO `yzh_area` VALUES ('1394','1392','广水市','0');
INSERT INTO `yzh_area` VALUES ('1395','1320','天门市','0');
INSERT INTO `yzh_area` VALUES ('1396','1320','仙桃市','0');
INSERT INTO `yzh_area` VALUES ('1397','1320','咸宁市','0');
INSERT INTO `yzh_area` VALUES ('1398','1397','咸安区','0');
INSERT INTO `yzh_area` VALUES ('1399','1397','嘉鱼县','0');
INSERT INTO `yzh_area` VALUES ('1400','1397','通城县','0');
INSERT INTO `yzh_area` VALUES ('1401','1397','崇阳县','0');
INSERT INTO `yzh_area` VALUES ('1402','1397','通山县','0');
INSERT INTO `yzh_area` VALUES ('1403','1397','赤壁市','0');
INSERT INTO `yzh_area` VALUES ('1404','1320','襄樊市','0');
INSERT INTO `yzh_area` VALUES ('1405','1404','襄城区','0');
INSERT INTO `yzh_area` VALUES ('1406','1404','樊城区','0');
INSERT INTO `yzh_area` VALUES ('1407','1404','襄阳区','0');
INSERT INTO `yzh_area` VALUES ('1408','1404','南漳县','0');
INSERT INTO `yzh_area` VALUES ('1409','1404','谷城县','0');
INSERT INTO `yzh_area` VALUES ('1410','1404','保康县','0');
INSERT INTO `yzh_area` VALUES ('1411','1404','老河口市','0');
INSERT INTO `yzh_area` VALUES ('1412','1404','枣阳市','0');
INSERT INTO `yzh_area` VALUES ('1413','1404','宜城市','0');
INSERT INTO `yzh_area` VALUES ('1414','1320','孝感市','0');
INSERT INTO `yzh_area` VALUES ('1415','1414','孝南区','0');
INSERT INTO `yzh_area` VALUES ('1416','1414','孝昌县','0');
INSERT INTO `yzh_area` VALUES ('1417','1414','大悟县','0');
INSERT INTO `yzh_area` VALUES ('1418','1414','云梦县','0');
INSERT INTO `yzh_area` VALUES ('1419','1414','应城市','0');
INSERT INTO `yzh_area` VALUES ('1420','1414','安陆市','0');
INSERT INTO `yzh_area` VALUES ('1421','1414','汉川市','0');
INSERT INTO `yzh_area` VALUES ('1422','1320','宜昌市','0');
INSERT INTO `yzh_area` VALUES ('1423','1422','西陵区','0');
INSERT INTO `yzh_area` VALUES ('1424','1422','伍家岗区','0');
INSERT INTO `yzh_area` VALUES ('1425','1422','点军区','0');
INSERT INTO `yzh_area` VALUES ('1426','1422','猇亭区','0');
INSERT INTO `yzh_area` VALUES ('1427','1422','夷陵区','0');
INSERT INTO `yzh_area` VALUES ('1428','1422','远安县','0');
INSERT INTO `yzh_area` VALUES ('1429','1422','兴山县','0');
INSERT INTO `yzh_area` VALUES ('1430','1422','秭归县','0');
INSERT INTO `yzh_area` VALUES ('1431','1422','长阳土家族自治县','0');
INSERT INTO `yzh_area` VALUES ('1432','1422','五峰土家族自治县','0');
INSERT INTO `yzh_area` VALUES ('1433','1422','宜都市','0');
INSERT INTO `yzh_area` VALUES ('1434','1422','当阳市','0');
INSERT INTO `yzh_area` VALUES ('1435','1422','枝江市','0');
INSERT INTO `yzh_area` VALUES ('1436','0','湖南','0');
INSERT INTO `yzh_area` VALUES ('1437','1436','长沙市','0');
INSERT INTO `yzh_area` VALUES ('1438','1437','芙蓉区','0');
INSERT INTO `yzh_area` VALUES ('1439','1437','天心区','0');
INSERT INTO `yzh_area` VALUES ('1440','1437','岳麓区','0');
INSERT INTO `yzh_area` VALUES ('1441','1437','开福区','0');
INSERT INTO `yzh_area` VALUES ('1442','1437','雨花区','0');
INSERT INTO `yzh_area` VALUES ('1443','1437','长沙县','0');
INSERT INTO `yzh_area` VALUES ('1444','1437','望城县','0');
INSERT INTO `yzh_area` VALUES ('1445','1437','宁乡县','0');
INSERT INTO `yzh_area` VALUES ('1446','1437','浏阳市','0');
INSERT INTO `yzh_area` VALUES ('1447','1436','常德市','0');
INSERT INTO `yzh_area` VALUES ('1448','1447','武陵区','0');
INSERT INTO `yzh_area` VALUES ('1449','1447','鼎城区','0');
INSERT INTO `yzh_area` VALUES ('1450','1447','安乡县','0');
INSERT INTO `yzh_area` VALUES ('1451','1447','汉寿县','0');
INSERT INTO `yzh_area` VALUES ('1452','1447','澧县','0');
INSERT INTO `yzh_area` VALUES ('1453','1447','临澧县','0');
INSERT INTO `yzh_area` VALUES ('1454','1447','桃源县','0');
INSERT INTO `yzh_area` VALUES ('1455','1447','石门县','0');
INSERT INTO `yzh_area` VALUES ('1456','1447','津市市','0');
INSERT INTO `yzh_area` VALUES ('1457','1436','郴州市','0');
INSERT INTO `yzh_area` VALUES ('1458','1457','北湖区','0');
INSERT INTO `yzh_area` VALUES ('1459','1457','苏仙区','0');
INSERT INTO `yzh_area` VALUES ('1460','1457','桂阳县','0');
INSERT INTO `yzh_area` VALUES ('1461','1457','宜章县','0');
INSERT INTO `yzh_area` VALUES ('1462','1457','永兴县','0');
INSERT INTO `yzh_area` VALUES ('1463','1457','嘉禾县','0');
INSERT INTO `yzh_area` VALUES ('1464','1457','临武县','0');
INSERT INTO `yzh_area` VALUES ('1465','1457','汝城县','0');
INSERT INTO `yzh_area` VALUES ('1466','1457','桂东县','0');
INSERT INTO `yzh_area` VALUES ('1467','1457','安仁县','0');
INSERT INTO `yzh_area` VALUES ('1468','1457','资兴市','0');
INSERT INTO `yzh_area` VALUES ('1469','1436','衡阳市','0');
INSERT INTO `yzh_area` VALUES ('1470','1469','珠晖区','0');
INSERT INTO `yzh_area` VALUES ('1471','1469','雁峰区','0');
INSERT INTO `yzh_area` VALUES ('1472','1469','石鼓区','0');
INSERT INTO `yzh_area` VALUES ('1473','1469','蒸湘区','0');
INSERT INTO `yzh_area` VALUES ('1474','1469','南岳区','0');
INSERT INTO `yzh_area` VALUES ('1475','1469','衡阳县','0');
INSERT INTO `yzh_area` VALUES ('1476','1469','衡南县','0');
INSERT INTO `yzh_area` VALUES ('1477','1469','衡山县','0');
INSERT INTO `yzh_area` VALUES ('1478','1469','衡东县','0');
INSERT INTO `yzh_area` VALUES ('1479','1469','祁东县','0');
INSERT INTO `yzh_area` VALUES ('1480','1469','耒阳市','0');
INSERT INTO `yzh_area` VALUES ('1481','1469','常宁市','0');
INSERT INTO `yzh_area` VALUES ('1482','1436','怀化市','0');
INSERT INTO `yzh_area` VALUES ('1483','1482','鹤城区','0');
INSERT INTO `yzh_area` VALUES ('1484','1482','中方县','0');
INSERT INTO `yzh_area` VALUES ('1485','1482','沅陵县','0');
INSERT INTO `yzh_area` VALUES ('1486','1482','辰溪县','0');
INSERT INTO `yzh_area` VALUES ('1487','1482','溆浦县','0');
INSERT INTO `yzh_area` VALUES ('1488','1482','会同县','0');
INSERT INTO `yzh_area` VALUES ('1489','1482','麻阳苗族自治县','0');
INSERT INTO `yzh_area` VALUES ('1490','1482','新晃侗族自治县','0');
INSERT INTO `yzh_area` VALUES ('1491','1482','芷江侗族自治县','0');
INSERT INTO `yzh_area` VALUES ('1492','1482','靖州苗族侗族自治县','0');
INSERT INTO `yzh_area` VALUES ('1493','1482','通道侗族自治县','0');
INSERT INTO `yzh_area` VALUES ('1494','1482','洪江市','0');
INSERT INTO `yzh_area` VALUES ('1495','1436','娄底市','0');
INSERT INTO `yzh_area` VALUES ('1496','1495','娄星区','0');
INSERT INTO `yzh_area` VALUES ('1497','1495','双峰县','0');
INSERT INTO `yzh_area` VALUES ('1498','1495','新化县','0');
INSERT INTO `yzh_area` VALUES ('1499','1495','冷水江市','0');
INSERT INTO `yzh_area` VALUES ('1500','1495','涟源市','0');
INSERT INTO `yzh_area` VALUES ('1501','1436','邵阳市','0');
INSERT INTO `yzh_area` VALUES ('1502','1501','双清区','0');
INSERT INTO `yzh_area` VALUES ('1503','1501','大祥区','0');
INSERT INTO `yzh_area` VALUES ('1504','1501','北塔区','0');
INSERT INTO `yzh_area` VALUES ('1505','1501','邵东县','0');
INSERT INTO `yzh_area` VALUES ('1506','1501','新邵县','0');
INSERT INTO `yzh_area` VALUES ('1507','1501','邵阳县','0');
INSERT INTO `yzh_area` VALUES ('1508','1501','隆回县','0');
INSERT INTO `yzh_area` VALUES ('1509','1501','洞口县','0');
INSERT INTO `yzh_area` VALUES ('1510','1501','绥宁县','0');
INSERT INTO `yzh_area` VALUES ('1511','1501','新宁县','0');
INSERT INTO `yzh_area` VALUES ('1512','1501','城步苗族自治县','0');
INSERT INTO `yzh_area` VALUES ('1513','1501','武冈市','0');
INSERT INTO `yzh_area` VALUES ('1514','1436','湘潭市','0');
INSERT INTO `yzh_area` VALUES ('1515','1514','雨湖区','0');
INSERT INTO `yzh_area` VALUES ('1516','1514','岳塘区','0');
INSERT INTO `yzh_area` VALUES ('1517','1514','湘潭县','0');
INSERT INTO `yzh_area` VALUES ('1518','1514','湘乡市','0');
INSERT INTO `yzh_area` VALUES ('1519','1514','韶山市','0');
INSERT INTO `yzh_area` VALUES ('1520','1436','湘西土家族苗族自治州','0');
INSERT INTO `yzh_area` VALUES ('1521','1520','吉首市','0');
INSERT INTO `yzh_area` VALUES ('1522','1520','泸溪县','0');
INSERT INTO `yzh_area` VALUES ('1523','1520','凤凰县','0');
INSERT INTO `yzh_area` VALUES ('1524','1520','花垣县','0');
INSERT INTO `yzh_area` VALUES ('1525','1520','保靖县','0');
INSERT INTO `yzh_area` VALUES ('1526','1520','古丈县','0');
INSERT INTO `yzh_area` VALUES ('1527','1520','永顺县','0');
INSERT INTO `yzh_area` VALUES ('1528','1520','龙山县','0');
INSERT INTO `yzh_area` VALUES ('1529','1436','益阳市','0');
INSERT INTO `yzh_area` VALUES ('1530','1529','资阳区','0');
INSERT INTO `yzh_area` VALUES ('1531','1529','赫山区','0');
INSERT INTO `yzh_area` VALUES ('1532','1529','南县','0');
INSERT INTO `yzh_area` VALUES ('1533','1529','桃江县','0');
INSERT INTO `yzh_area` VALUES ('1534','1529','安化县','0');
INSERT INTO `yzh_area` VALUES ('1535','1529','沅江市','0');
INSERT INTO `yzh_area` VALUES ('1536','1436','永州市','0');
INSERT INTO `yzh_area` VALUES ('1537','1536','芝山区','0');
INSERT INTO `yzh_area` VALUES ('1538','1536','冷水滩区','0');
INSERT INTO `yzh_area` VALUES ('1539','1536','祁阳县','0');
INSERT INTO `yzh_area` VALUES ('1540','1536','东安县','0');
INSERT INTO `yzh_area` VALUES ('1541','1536','双牌县','0');
INSERT INTO `yzh_area` VALUES ('1542','1536','道县','0');
INSERT INTO `yzh_area` VALUES ('1543','1536','江永县','0');
INSERT INTO `yzh_area` VALUES ('1544','1536','宁远县','0');
INSERT INTO `yzh_area` VALUES ('1545','1536','蓝山县','0');
INSERT INTO `yzh_area` VALUES ('1546','1536','新田县','0');
INSERT INTO `yzh_area` VALUES ('1547','1536','江华瑶族自治县','0');
INSERT INTO `yzh_area` VALUES ('1548','1436','岳阳市','0');
INSERT INTO `yzh_area` VALUES ('1549','1548','岳阳楼区','0');
INSERT INTO `yzh_area` VALUES ('1550','1548','云溪区','0');
INSERT INTO `yzh_area` VALUES ('1551','1548','君山区','0');
INSERT INTO `yzh_area` VALUES ('1552','1548','岳阳县','0');
INSERT INTO `yzh_area` VALUES ('1553','1548','华容县','0');
INSERT INTO `yzh_area` VALUES ('1554','1548','湘阴县','0');
INSERT INTO `yzh_area` VALUES ('1555','1548','平江县','0');
INSERT INTO `yzh_area` VALUES ('1556','1548','汨罗市','0');
INSERT INTO `yzh_area` VALUES ('1557','1548','临湘市','0');
INSERT INTO `yzh_area` VALUES ('1558','1436','张家界市','0');
INSERT INTO `yzh_area` VALUES ('1559','1558','永定区','0');
INSERT INTO `yzh_area` VALUES ('1560','1558','武陵源区','0');
INSERT INTO `yzh_area` VALUES ('1561','1558','慈利县','0');
INSERT INTO `yzh_area` VALUES ('1562','1558','桑植县','0');
INSERT INTO `yzh_area` VALUES ('1563','1436','株洲市','0');
INSERT INTO `yzh_area` VALUES ('1564','1563','荷塘区','0');
INSERT INTO `yzh_area` VALUES ('1565','1563','芦淞区','0');
INSERT INTO `yzh_area` VALUES ('1566','1563','石峰区','0');
INSERT INTO `yzh_area` VALUES ('1567','1563','天元区','0');
INSERT INTO `yzh_area` VALUES ('1568','1563','株洲县','0');
INSERT INTO `yzh_area` VALUES ('1569','1563','攸县','0');
INSERT INTO `yzh_area` VALUES ('1570','1563','茶陵县','0');
INSERT INTO `yzh_area` VALUES ('1571','1563','炎陵县','0');
INSERT INTO `yzh_area` VALUES ('1572','1563','醴陵市','0');
INSERT INTO `yzh_area` VALUES ('1573','0','吉林','0');
INSERT INTO `yzh_area` VALUES ('1574','1573','长春市','0');
INSERT INTO `yzh_area` VALUES ('1575','1574','南关区','0');
INSERT INTO `yzh_area` VALUES ('1576','1574','宽城区','0');
INSERT INTO `yzh_area` VALUES ('1577','1574','朝阳区','0');
INSERT INTO `yzh_area` VALUES ('1578','1574','二道区','0');
INSERT INTO `yzh_area` VALUES ('1579','1574','绿园区','0');
INSERT INTO `yzh_area` VALUES ('1580','1574','双阳区','0');
INSERT INTO `yzh_area` VALUES ('1581','1574','农安县','0');
INSERT INTO `yzh_area` VALUES ('1582','1574','九台市','0');
INSERT INTO `yzh_area` VALUES ('1583','1574','榆树市','0');
INSERT INTO `yzh_area` VALUES ('1584','1574','德惠市','0');
INSERT INTO `yzh_area` VALUES ('1585','1573','白城市','0');
INSERT INTO `yzh_area` VALUES ('1586','1585','洮北区','0');
INSERT INTO `yzh_area` VALUES ('1587','1585','镇赉县','0');
INSERT INTO `yzh_area` VALUES ('1588','1585','通榆县','0');
INSERT INTO `yzh_area` VALUES ('1589','1585','洮南市','0');
INSERT INTO `yzh_area` VALUES ('1590','1585','大安市','0');
INSERT INTO `yzh_area` VALUES ('1591','1573','白山市','0');
INSERT INTO `yzh_area` VALUES ('1592','1591','八道江区','0');
INSERT INTO `yzh_area` VALUES ('1593','1591','抚松县','0');
INSERT INTO `yzh_area` VALUES ('1594','1591','靖宇县','0');
INSERT INTO `yzh_area` VALUES ('1595','1591','长白朝鲜族自治县','0');
INSERT INTO `yzh_area` VALUES ('1596','1591','江源县','0');
INSERT INTO `yzh_area` VALUES ('1597','1591','临江市','0');
INSERT INTO `yzh_area` VALUES ('1598','1573','吉林市','0');
INSERT INTO `yzh_area` VALUES ('1599','1598','昌邑区','0');
INSERT INTO `yzh_area` VALUES ('1600','1598','龙潭区','0');
INSERT INTO `yzh_area` VALUES ('1601','1598','船营区','0');
INSERT INTO `yzh_area` VALUES ('1602','1598','丰满区','0');
INSERT INTO `yzh_area` VALUES ('1603','1598','永吉县','0');
INSERT INTO `yzh_area` VALUES ('1604','1598','蛟河市','0');
INSERT INTO `yzh_area` VALUES ('1605','1598','桦甸市','0');
INSERT INTO `yzh_area` VALUES ('1606','1598','舒兰市','0');
INSERT INTO `yzh_area` VALUES ('1607','1598','磐石市','0');
INSERT INTO `yzh_area` VALUES ('1608','1573','辽源市','0');
INSERT INTO `yzh_area` VALUES ('1609','1608','龙山区','0');
INSERT INTO `yzh_area` VALUES ('1610','1608','西安区','0');
INSERT INTO `yzh_area` VALUES ('1611','1608','东丰县','0');
INSERT INTO `yzh_area` VALUES ('1612','1608','东辽县','0');
INSERT INTO `yzh_area` VALUES ('1613','1573','四平市','0');
INSERT INTO `yzh_area` VALUES ('1614','1613','铁西区','0');
INSERT INTO `yzh_area` VALUES ('1615','1613','铁东区','0');
INSERT INTO `yzh_area` VALUES ('1616','1613','梨树县','0');
INSERT INTO `yzh_area` VALUES ('1617','1613','伊通满族自治县','0');
INSERT INTO `yzh_area` VALUES ('1618','1613','公主岭市','0');
INSERT INTO `yzh_area` VALUES ('1619','1613','双辽市','0');
INSERT INTO `yzh_area` VALUES ('1620','1573','松原市','0');
INSERT INTO `yzh_area` VALUES ('1621','1620','宁江区','0');
INSERT INTO `yzh_area` VALUES ('1622','1620','前郭尔罗斯蒙古族自治县','0');
INSERT INTO `yzh_area` VALUES ('1623','1620','长岭县','0');
INSERT INTO `yzh_area` VALUES ('1624','1620','乾安县','0');
INSERT INTO `yzh_area` VALUES ('1625','1620','扶余县','0');
INSERT INTO `yzh_area` VALUES ('1626','1573','通化市','0');
INSERT INTO `yzh_area` VALUES ('1627','1626','东昌区','0');
INSERT INTO `yzh_area` VALUES ('1628','1626','二道江区','0');
INSERT INTO `yzh_area` VALUES ('1629','1626','通化县','0');
INSERT INTO `yzh_area` VALUES ('1630','1626','辉南县','0');
INSERT INTO `yzh_area` VALUES ('1631','1626','柳河县','0');
INSERT INTO `yzh_area` VALUES ('1632','1626','梅河口市','0');
INSERT INTO `yzh_area` VALUES ('1633','1626','集安市','0');
INSERT INTO `yzh_area` VALUES ('1634','1573','延边朝鲜族自治州','0');
INSERT INTO `yzh_area` VALUES ('1635','1634','延吉市','0');
INSERT INTO `yzh_area` VALUES ('1636','1634','图们市','0');
INSERT INTO `yzh_area` VALUES ('1637','1634','敦化市','0');
INSERT INTO `yzh_area` VALUES ('1638','1634','珲春市','0');
INSERT INTO `yzh_area` VALUES ('1639','1634','龙井市','0');
INSERT INTO `yzh_area` VALUES ('1640','1634','和龙市','0');
INSERT INTO `yzh_area` VALUES ('1641','1634','汪清县','0');
INSERT INTO `yzh_area` VALUES ('1642','1634','安图县','0');
INSERT INTO `yzh_area` VALUES ('1643','0','江苏','0');
INSERT INTO `yzh_area` VALUES ('1644','1643','南京市','0');
INSERT INTO `yzh_area` VALUES ('1645','1644','玄武区','0');
INSERT INTO `yzh_area` VALUES ('1646','1644','白下区','0');
INSERT INTO `yzh_area` VALUES ('1647','1644','秦淮区','0');
INSERT INTO `yzh_area` VALUES ('1648','1644','建邺区','0');
INSERT INTO `yzh_area` VALUES ('1649','1644','鼓楼区','0');
INSERT INTO `yzh_area` VALUES ('1650','1644','下关区','0');
INSERT INTO `yzh_area` VALUES ('1651','1644','浦口区','0');
INSERT INTO `yzh_area` VALUES ('1652','1644','栖霞区','0');
INSERT INTO `yzh_area` VALUES ('1653','1644','雨花台区','0');
INSERT INTO `yzh_area` VALUES ('1654','1644','江宁区','0');
INSERT INTO `yzh_area` VALUES ('1655','1644','六合区','0');
INSERT INTO `yzh_area` VALUES ('1656','1644','溧水县','0');
INSERT INTO `yzh_area` VALUES ('1657','1644','高淳县','0');
INSERT INTO `yzh_area` VALUES ('1658','1643','常州市','0');
INSERT INTO `yzh_area` VALUES ('1659','1658','天宁区','0');
INSERT INTO `yzh_area` VALUES ('1660','1658','钟楼区','0');
INSERT INTO `yzh_area` VALUES ('1661','1658','戚墅堰区','0');
INSERT INTO `yzh_area` VALUES ('1662','1658','新北区','0');
INSERT INTO `yzh_area` VALUES ('1663','1658','武进区','0');
INSERT INTO `yzh_area` VALUES ('1664','1658','溧阳市','0');
INSERT INTO `yzh_area` VALUES ('1665','1658','金坛市','0');
INSERT INTO `yzh_area` VALUES ('1666','1643','淮安市','0');
INSERT INTO `yzh_area` VALUES ('1667','1666','清河区','0');
INSERT INTO `yzh_area` VALUES ('1668','1666','楚州区','0');
INSERT INTO `yzh_area` VALUES ('1669','1666','淮阴区','0');
INSERT INTO `yzh_area` VALUES ('1670','1666','清浦区','0');
INSERT INTO `yzh_area` VALUES ('1671','1666','涟水县','0');
INSERT INTO `yzh_area` VALUES ('1672','1666','洪泽县','0');
INSERT INTO `yzh_area` VALUES ('1673','1666','盱眙县','0');
INSERT INTO `yzh_area` VALUES ('1674','1666','金湖县','0');
INSERT INTO `yzh_area` VALUES ('1675','1643','连云港市','0');
INSERT INTO `yzh_area` VALUES ('1676','1675','连云区','0');
INSERT INTO `yzh_area` VALUES ('1677','1675','新浦区','0');
INSERT INTO `yzh_area` VALUES ('1678','1675','海州区','0');
INSERT INTO `yzh_area` VALUES ('1679','1675','赣榆县','0');
INSERT INTO `yzh_area` VALUES ('1680','1675','东海县','0');
INSERT INTO `yzh_area` VALUES ('1681','1675','灌云县','0');
INSERT INTO `yzh_area` VALUES ('1682','1675','灌南县','0');
INSERT INTO `yzh_area` VALUES ('1683','1643','南通市','0');
INSERT INTO `yzh_area` VALUES ('1684','1683','崇川区','0');
INSERT INTO `yzh_area` VALUES ('1685','1683','港闸区','0');
INSERT INTO `yzh_area` VALUES ('1686','1683','海安县','0');
INSERT INTO `yzh_area` VALUES ('1687','1683','如东县','0');
INSERT INTO `yzh_area` VALUES ('1688','1683','启东市','0');
INSERT INTO `yzh_area` VALUES ('1689','1683','如皋市','0');
INSERT INTO `yzh_area` VALUES ('1690','1683','通州市','0');
INSERT INTO `yzh_area` VALUES ('1691','1683','海门市','0');
INSERT INTO `yzh_area` VALUES ('1692','1643','苏州市','0');
INSERT INTO `yzh_area` VALUES ('1693','1692','沧浪区','0');
INSERT INTO `yzh_area` VALUES ('1694','1692','平江区','0');
INSERT INTO `yzh_area` VALUES ('1695','1692','金阊区','0');
INSERT INTO `yzh_area` VALUES ('1696','1692','虎丘区','0');
INSERT INTO `yzh_area` VALUES ('1697','1692','吴中区','0');
INSERT INTO `yzh_area` VALUES ('1698','1692','相城区','0');
INSERT INTO `yzh_area` VALUES ('1699','1692','常熟市','0');
INSERT INTO `yzh_area` VALUES ('1700','1692','张家港市','0');
INSERT INTO `yzh_area` VALUES ('1701','1692','昆山市','0');
INSERT INTO `yzh_area` VALUES ('1702','1692','吴江市','0');
INSERT INTO `yzh_area` VALUES ('1703','1692','太仓市','0');
INSERT INTO `yzh_area` VALUES ('1704','1643','宿迁市','0');
INSERT INTO `yzh_area` VALUES ('1705','1704','宿城区','0');
INSERT INTO `yzh_area` VALUES ('1706','1704','宿豫区','0');
INSERT INTO `yzh_area` VALUES ('1707','1704','沭阳县','0');
INSERT INTO `yzh_area` VALUES ('1708','1704','泗阳县','0');
INSERT INTO `yzh_area` VALUES ('1709','1704','泗洪县','0');
INSERT INTO `yzh_area` VALUES ('1710','1643','泰州市','0');
INSERT INTO `yzh_area` VALUES ('1711','1710','海陵区','0');
INSERT INTO `yzh_area` VALUES ('1712','1710','高港区','0');
INSERT INTO `yzh_area` VALUES ('1713','1710','兴化市','0');
INSERT INTO `yzh_area` VALUES ('1714','1710','靖江市','0');
INSERT INTO `yzh_area` VALUES ('1715','1710','泰兴市','0');
INSERT INTO `yzh_area` VALUES ('1716','1710','姜堰市','0');
INSERT INTO `yzh_area` VALUES ('1717','1643','无锡市','0');
INSERT INTO `yzh_area` VALUES ('1718','1717','崇安区','0');
INSERT INTO `yzh_area` VALUES ('1719','1717','南长区','0');
INSERT INTO `yzh_area` VALUES ('1720','1717','北塘区','0');
INSERT INTO `yzh_area` VALUES ('1721','1717','锡山区','0');
INSERT INTO `yzh_area` VALUES ('1722','1717','惠山区','0');
INSERT INTO `yzh_area` VALUES ('1723','1717','滨湖区','0');
INSERT INTO `yzh_area` VALUES ('1724','1717','江阴市','0');
INSERT INTO `yzh_area` VALUES ('1725','1717','宜兴市','0');
INSERT INTO `yzh_area` VALUES ('1726','1643','徐州市','0');
INSERT INTO `yzh_area` VALUES ('1727','1726','鼓楼区','0');
INSERT INTO `yzh_area` VALUES ('1728','1726','云龙区','0');
INSERT INTO `yzh_area` VALUES ('1729','1726','九里区','0');
INSERT INTO `yzh_area` VALUES ('1730','1726','贾汪区','0');
INSERT INTO `yzh_area` VALUES ('1731','1726','泉山区','0');
INSERT INTO `yzh_area` VALUES ('1732','1726','丰县','0');
INSERT INTO `yzh_area` VALUES ('1733','1726','沛县','0');
INSERT INTO `yzh_area` VALUES ('1734','1726','铜山县','0');
INSERT INTO `yzh_area` VALUES ('1735','1726','睢宁县','0');
INSERT INTO `yzh_area` VALUES ('1736','1726','新沂市','0');
INSERT INTO `yzh_area` VALUES ('1737','1726','邳州市','0');
INSERT INTO `yzh_area` VALUES ('1738','1643','盐城市','0');
INSERT INTO `yzh_area` VALUES ('1739','1738','亭湖区','0');
INSERT INTO `yzh_area` VALUES ('1740','1738','盐都区','0');
INSERT INTO `yzh_area` VALUES ('1741','1738','响水县','0');
INSERT INTO `yzh_area` VALUES ('1742','1738','滨海县','0');
INSERT INTO `yzh_area` VALUES ('1743','1738','阜宁县','0');
INSERT INTO `yzh_area` VALUES ('1744','1738','射阳县','0');
INSERT INTO `yzh_area` VALUES ('1745','1738','建湖县','0');
INSERT INTO `yzh_area` VALUES ('1746','1738','东台市','0');
INSERT INTO `yzh_area` VALUES ('1747','1738','大丰市','0');
INSERT INTO `yzh_area` VALUES ('1748','1643','扬州市','0');
INSERT INTO `yzh_area` VALUES ('1749','1748','广陵区','0');
INSERT INTO `yzh_area` VALUES ('1750','1748','邗江区','0');
INSERT INTO `yzh_area` VALUES ('1751','1748','郊区','0');
INSERT INTO `yzh_area` VALUES ('1752','1748','宝应县','0');
INSERT INTO `yzh_area` VALUES ('1753','1748','仪征市','0');
INSERT INTO `yzh_area` VALUES ('1754','1748','高邮市','0');
INSERT INTO `yzh_area` VALUES ('1755','1748','江都市','0');
INSERT INTO `yzh_area` VALUES ('1756','1643','镇江市','0');
INSERT INTO `yzh_area` VALUES ('1757','1756','京口区','0');
INSERT INTO `yzh_area` VALUES ('1758','1756','润州区','0');
INSERT INTO `yzh_area` VALUES ('1759','1756','丹徒区','0');
INSERT INTO `yzh_area` VALUES ('1760','1756','丹阳市','0');
INSERT INTO `yzh_area` VALUES ('1761','1756','扬中市','0');
INSERT INTO `yzh_area` VALUES ('1762','1756','句容市','0');
INSERT INTO `yzh_area` VALUES ('1763','0','江西','0');
INSERT INTO `yzh_area` VALUES ('1764','1763','南昌市','0');
INSERT INTO `yzh_area` VALUES ('1765','1764','东湖区','0');
INSERT INTO `yzh_area` VALUES ('1766','1764','西湖区','0');
INSERT INTO `yzh_area` VALUES ('1767','1764','青云谱区','0');
INSERT INTO `yzh_area` VALUES ('1768','1764','湾里区','0');
INSERT INTO `yzh_area` VALUES ('1769','1764','青山湖区','0');
INSERT INTO `yzh_area` VALUES ('1770','1764','南昌县','0');
INSERT INTO `yzh_area` VALUES ('1771','1764','新建县','0');
INSERT INTO `yzh_area` VALUES ('1772','1764','安义县','0');
INSERT INTO `yzh_area` VALUES ('1773','1764','进贤县','0');
INSERT INTO `yzh_area` VALUES ('1774','1763','抚州市','0');
INSERT INTO `yzh_area` VALUES ('1775','1774','临川区','0');
INSERT INTO `yzh_area` VALUES ('1776','1774','南城县','0');
INSERT INTO `yzh_area` VALUES ('1777','1774','黎川县','0');
INSERT INTO `yzh_area` VALUES ('1778','1774','南丰县','0');
INSERT INTO `yzh_area` VALUES ('1779','1774','崇仁县','0');
INSERT INTO `yzh_area` VALUES ('1780','1774','乐安县','0');
INSERT INTO `yzh_area` VALUES ('1781','1774','宜黄县','0');
INSERT INTO `yzh_area` VALUES ('1782','1774','金溪县','0');
INSERT INTO `yzh_area` VALUES ('1783','1774','资溪县','0');
INSERT INTO `yzh_area` VALUES ('1784','1774','东乡县','0');
INSERT INTO `yzh_area` VALUES ('1785','1774','广昌县','0');
INSERT INTO `yzh_area` VALUES ('1786','1763','赣州市','0');
INSERT INTO `yzh_area` VALUES ('1787','1786','章贡区','0');
INSERT INTO `yzh_area` VALUES ('1788','1786','赣县','0');
INSERT INTO `yzh_area` VALUES ('1789','1786','信丰县','0');
INSERT INTO `yzh_area` VALUES ('1790','1786','大余县','0');
INSERT INTO `yzh_area` VALUES ('1791','1786','上犹县','0');
INSERT INTO `yzh_area` VALUES ('1792','1786','崇义县','0');
INSERT INTO `yzh_area` VALUES ('1793','1786','安远县','0');
INSERT INTO `yzh_area` VALUES ('1794','1786','龙南县','0');
INSERT INTO `yzh_area` VALUES ('1795','1786','定南县','0');
INSERT INTO `yzh_area` VALUES ('1796','1786','全南县','0');
INSERT INTO `yzh_area` VALUES ('1797','1786','宁都县','0');
INSERT INTO `yzh_area` VALUES ('1798','1786','于都县','0');
INSERT INTO `yzh_area` VALUES ('1799','1786','兴国县','0');
INSERT INTO `yzh_area` VALUES ('1800','1786','会昌县','0');
INSERT INTO `yzh_area` VALUES ('1801','1786','寻乌县','0');
INSERT INTO `yzh_area` VALUES ('1802','1786','石城县','0');
INSERT INTO `yzh_area` VALUES ('1803','1786','瑞金市','0');
INSERT INTO `yzh_area` VALUES ('1804','1786','南康市','0');
INSERT INTO `yzh_area` VALUES ('1805','1763','吉安市','0');
INSERT INTO `yzh_area` VALUES ('1806','1805','吉州区','0');
INSERT INTO `yzh_area` VALUES ('1807','1805','青原区','0');
INSERT INTO `yzh_area` VALUES ('1808','1805','吉安县','0');
INSERT INTO `yzh_area` VALUES ('1809','1805','吉水县','0');
INSERT INTO `yzh_area` VALUES ('1810','1805','峡江县','0');
INSERT INTO `yzh_area` VALUES ('1811','1805','新干县','0');
INSERT INTO `yzh_area` VALUES ('1812','1805','永丰县','0');
INSERT INTO `yzh_area` VALUES ('1813','1805','泰和县','0');
INSERT INTO `yzh_area` VALUES ('1814','1805','遂川县','0');
INSERT INTO `yzh_area` VALUES ('1815','1805','万安县','0');
INSERT INTO `yzh_area` VALUES ('1816','1805','安福县','0');
INSERT INTO `yzh_area` VALUES ('1817','1805','永新县','0');
INSERT INTO `yzh_area` VALUES ('1818','1805','井冈山市','0');
INSERT INTO `yzh_area` VALUES ('1819','1763','景德镇市','0');
INSERT INTO `yzh_area` VALUES ('1820','1819','昌江区','0');
INSERT INTO `yzh_area` VALUES ('1821','1819','珠山区','0');
INSERT INTO `yzh_area` VALUES ('1822','1819','浮梁县','0');
INSERT INTO `yzh_area` VALUES ('1823','1819','乐平市','0');
INSERT INTO `yzh_area` VALUES ('1824','1763','九江市','0');
INSERT INTO `yzh_area` VALUES ('1825','1824','庐山区','0');
INSERT INTO `yzh_area` VALUES ('1826','1824','浔阳区','0');
INSERT INTO `yzh_area` VALUES ('1827','1824','九江县','0');
INSERT INTO `yzh_area` VALUES ('1828','1824','武宁县','0');
INSERT INTO `yzh_area` VALUES ('1829','1824','修水县','0');
INSERT INTO `yzh_area` VALUES ('1830','1824','永修县','0');
INSERT INTO `yzh_area` VALUES ('1831','1824','德安县','0');
INSERT INTO `yzh_area` VALUES ('1832','1824','星子县','0');
INSERT INTO `yzh_area` VALUES ('1833','1824','都昌县','0');
INSERT INTO `yzh_area` VALUES ('1834','1824','湖口县','0');
INSERT INTO `yzh_area` VALUES ('1835','1824','彭泽县','0');
INSERT INTO `yzh_area` VALUES ('1836','1824','瑞昌市','0');
INSERT INTO `yzh_area` VALUES ('1837','1763','萍乡市','0');
INSERT INTO `yzh_area` VALUES ('1838','1837','安源区','0');
INSERT INTO `yzh_area` VALUES ('1839','1837','湘东区','0');
INSERT INTO `yzh_area` VALUES ('1840','1837','莲花县','0');
INSERT INTO `yzh_area` VALUES ('1841','1837','上栗县','0');
INSERT INTO `yzh_area` VALUES ('1842','1837','芦溪县','0');
INSERT INTO `yzh_area` VALUES ('1843','1763','上饶市','0');
INSERT INTO `yzh_area` VALUES ('1844','1843','信州区','0');
INSERT INTO `yzh_area` VALUES ('1845','1843','上饶县','0');
INSERT INTO `yzh_area` VALUES ('1846','1843','广丰县','0');
INSERT INTO `yzh_area` VALUES ('1847','1843','玉山县','0');
INSERT INTO `yzh_area` VALUES ('1848','1843','铅山县','0');
INSERT INTO `yzh_area` VALUES ('1849','1843','横峰县','0');
INSERT INTO `yzh_area` VALUES ('1850','1843','弋阳县','0');
INSERT INTO `yzh_area` VALUES ('1851','1843','余干县','0');
INSERT INTO `yzh_area` VALUES ('1852','1843','鄱阳县','0');
INSERT INTO `yzh_area` VALUES ('1853','1843','万年县','0');
INSERT INTO `yzh_area` VALUES ('1854','1843','婺源县','0');
INSERT INTO `yzh_area` VALUES ('1855','1843','德兴市','0');
INSERT INTO `yzh_area` VALUES ('1856','1763','新余市','0');
INSERT INTO `yzh_area` VALUES ('1857','1856','渝水区','0');
INSERT INTO `yzh_area` VALUES ('1858','1856','分宜县','0');
INSERT INTO `yzh_area` VALUES ('1859','1763','宜春市','0');
INSERT INTO `yzh_area` VALUES ('1860','1859','袁州区','0');
INSERT INTO `yzh_area` VALUES ('1861','1859','奉新县','0');
INSERT INTO `yzh_area` VALUES ('1862','1859','万载县','0');
INSERT INTO `yzh_area` VALUES ('1863','1859','上高县','0');
INSERT INTO `yzh_area` VALUES ('1864','1859','宜丰县','0');
INSERT INTO `yzh_area` VALUES ('1865','1859','靖安县','0');
INSERT INTO `yzh_area` VALUES ('1866','1859','铜鼓县','0');
INSERT INTO `yzh_area` VALUES ('1867','1859','丰城市','0');
INSERT INTO `yzh_area` VALUES ('1868','1859','樟树市','0');
INSERT INTO `yzh_area` VALUES ('1869','1859','高安市','0');
INSERT INTO `yzh_area` VALUES ('1870','1763','鹰潭市','0');
INSERT INTO `yzh_area` VALUES ('1871','1870','月湖区','0');
INSERT INTO `yzh_area` VALUES ('1872','1870','余江县','0');
INSERT INTO `yzh_area` VALUES ('1873','1870','贵溪市','0');
INSERT INTO `yzh_area` VALUES ('1874','0','辽宁','0');
INSERT INTO `yzh_area` VALUES ('1875','1874','沈阳市','0');
INSERT INTO `yzh_area` VALUES ('1876','1875','和平区','0');
INSERT INTO `yzh_area` VALUES ('1877','1875','沈河区','0');
INSERT INTO `yzh_area` VALUES ('1878','1875','大东区','0');
INSERT INTO `yzh_area` VALUES ('1879','1875','皇姑区','0');
INSERT INTO `yzh_area` VALUES ('1880','1875','铁西区','0');
INSERT INTO `yzh_area` VALUES ('1881','1875','苏家屯区','0');
INSERT INTO `yzh_area` VALUES ('1882','1875','东陵区','0');
INSERT INTO `yzh_area` VALUES ('1883','1875','新城子区','0');
INSERT INTO `yzh_area` VALUES ('1884','1875','于洪区','0');
INSERT INTO `yzh_area` VALUES ('1885','1875','辽中县','0');
INSERT INTO `yzh_area` VALUES ('1886','1875','康平县','0');
INSERT INTO `yzh_area` VALUES ('1887','1875','法库县','0');
INSERT INTO `yzh_area` VALUES ('1888','1875','新民市','0');
INSERT INTO `yzh_area` VALUES ('1889','1874','鞍山市','0');
INSERT INTO `yzh_area` VALUES ('1890','1889','铁东区','0');
INSERT INTO `yzh_area` VALUES ('1891','1889','铁西区','0');
INSERT INTO `yzh_area` VALUES ('1892','1889','立山区','0');
INSERT INTO `yzh_area` VALUES ('1893','1889','千山区','0');
INSERT INTO `yzh_area` VALUES ('1894','1889','台安县','0');
INSERT INTO `yzh_area` VALUES ('1895','1889','岫岩满族自治县','0');
INSERT INTO `yzh_area` VALUES ('1896','1889','海城市','0');
INSERT INTO `yzh_area` VALUES ('1897','1874','本溪市','0');
INSERT INTO `yzh_area` VALUES ('1898','1897','平山区','0');
INSERT INTO `yzh_area` VALUES ('1899','1897','溪湖区','0');
INSERT INTO `yzh_area` VALUES ('1900','1897','明山区','0');
INSERT INTO `yzh_area` VALUES ('1901','1897','南芬区','0');
INSERT INTO `yzh_area` VALUES ('1902','1897','本溪满族自治县','0');
INSERT INTO `yzh_area` VALUES ('1903','1897','桓仁满族自治县','0');
INSERT INTO `yzh_area` VALUES ('1904','1874','朝阳市','0');
INSERT INTO `yzh_area` VALUES ('1905','1904','双塔区','0');
INSERT INTO `yzh_area` VALUES ('1906','1904','龙城区','0');
INSERT INTO `yzh_area` VALUES ('1907','1904','朝阳县','0');
INSERT INTO `yzh_area` VALUES ('1908','1904','建平县','0');
INSERT INTO `yzh_area` VALUES ('1909','1904','喀喇沁左翼蒙古族自治县','0');
INSERT INTO `yzh_area` VALUES ('1910','1904','北票市','0');
INSERT INTO `yzh_area` VALUES ('1911','1904','凌源市','0');
INSERT INTO `yzh_area` VALUES ('1912','1874','大连市','0');
INSERT INTO `yzh_area` VALUES ('1913','1912','中山区','0');
INSERT INTO `yzh_area` VALUES ('1914','1912','西岗区','0');
INSERT INTO `yzh_area` VALUES ('1915','1912','沙河口区','0');
INSERT INTO `yzh_area` VALUES ('1916','1912','甘井子区','0');
INSERT INTO `yzh_area` VALUES ('1917','1912','旅顺口区','0');
INSERT INTO `yzh_area` VALUES ('1918','1912','金州区','0');
INSERT INTO `yzh_area` VALUES ('1919','1912','长海县','0');
INSERT INTO `yzh_area` VALUES ('1920','1912','瓦房店市','0');
INSERT INTO `yzh_area` VALUES ('1921','1912','普兰店市','0');
INSERT INTO `yzh_area` VALUES ('1922','1912','庄河市','0');
INSERT INTO `yzh_area` VALUES ('1923','1874','丹东市','0');
INSERT INTO `yzh_area` VALUES ('1924','1923','元宝区','0');
INSERT INTO `yzh_area` VALUES ('1925','1923','振兴区','0');
INSERT INTO `yzh_area` VALUES ('1926','1923','振安区','0');
INSERT INTO `yzh_area` VALUES ('1927','1923','宽甸满族自治县','0');
INSERT INTO `yzh_area` VALUES ('1928','1923','东港市','0');
INSERT INTO `yzh_area` VALUES ('1929','1923','凤城市','0');
INSERT INTO `yzh_area` VALUES ('1930','1874','抚顺市','0');
INSERT INTO `yzh_area` VALUES ('1931','1930','新抚区','0');
INSERT INTO `yzh_area` VALUES ('1932','1930','东洲区','0');
INSERT INTO `yzh_area` VALUES ('1933','1930','望花区','0');
INSERT INTO `yzh_area` VALUES ('1934','1930','顺城区','0');
INSERT INTO `yzh_area` VALUES ('1935','1930','抚顺县','0');
INSERT INTO `yzh_area` VALUES ('1936','1930','新宾满族自治县','0');
INSERT INTO `yzh_area` VALUES ('1937','1930','清原满族自治县','0');
INSERT INTO `yzh_area` VALUES ('1938','1874','阜新市','0');
INSERT INTO `yzh_area` VALUES ('1939','1938','海州区','0');
INSERT INTO `yzh_area` VALUES ('1940','1938','新邱区','0');
INSERT INTO `yzh_area` VALUES ('1941','1938','太平区','0');
INSERT INTO `yzh_area` VALUES ('1942','1938','清河门区','0');
INSERT INTO `yzh_area` VALUES ('1943','1938','细河区','0');
INSERT INTO `yzh_area` VALUES ('1944','1938','阜新蒙古族自治县','0');
INSERT INTO `yzh_area` VALUES ('1945','1938','彰武县','0');
INSERT INTO `yzh_area` VALUES ('1946','1874','葫芦岛市','0');
INSERT INTO `yzh_area` VALUES ('1947','1946','连山区','0');
INSERT INTO `yzh_area` VALUES ('1948','1946','龙港区','0');
INSERT INTO `yzh_area` VALUES ('1949','1946','南票区','0');
INSERT INTO `yzh_area` VALUES ('1950','1946','绥中县','0');
INSERT INTO `yzh_area` VALUES ('1951','1946','建昌县','0');
INSERT INTO `yzh_area` VALUES ('1952','1946','兴城市','0');
INSERT INTO `yzh_area` VALUES ('1953','1874','锦州市','0');
INSERT INTO `yzh_area` VALUES ('1954','1953','古塔区','0');
INSERT INTO `yzh_area` VALUES ('1955','1953','凌河区','0');
INSERT INTO `yzh_area` VALUES ('1956','1953','太和区','0');
INSERT INTO `yzh_area` VALUES ('1957','1953','黑山县','0');
INSERT INTO `yzh_area` VALUES ('1958','1953','义县','0');
INSERT INTO `yzh_area` VALUES ('1959','1953','凌海市','0');
INSERT INTO `yzh_area` VALUES ('1960','1953','北宁市','0');
INSERT INTO `yzh_area` VALUES ('1961','1874','辽阳市','0');
INSERT INTO `yzh_area` VALUES ('1962','1961','白塔区','0');
INSERT INTO `yzh_area` VALUES ('1963','1961','文圣区','0');
INSERT INTO `yzh_area` VALUES ('1964','1961','宏伟区','0');
INSERT INTO `yzh_area` VALUES ('1965','1961','弓长岭区','0');
INSERT INTO `yzh_area` VALUES ('1966','1961','太子河区','0');
INSERT INTO `yzh_area` VALUES ('1967','1961','辽阳县','0');
INSERT INTO `yzh_area` VALUES ('1968','1961','灯塔市','0');
INSERT INTO `yzh_area` VALUES ('1969','1874','盘锦市','0');
INSERT INTO `yzh_area` VALUES ('1970','1969','双台子区','0');
INSERT INTO `yzh_area` VALUES ('1971','1969','兴隆台区','0');
INSERT INTO `yzh_area` VALUES ('1972','1969','大洼县','0');
INSERT INTO `yzh_area` VALUES ('1973','1969','盘山县','0');
INSERT INTO `yzh_area` VALUES ('1974','1874','铁岭市','0');
INSERT INTO `yzh_area` VALUES ('1975','1974','银州区','0');
INSERT INTO `yzh_area` VALUES ('1976','1974','清河区','0');
INSERT INTO `yzh_area` VALUES ('1977','1974','铁岭县','0');
INSERT INTO `yzh_area` VALUES ('1978','1974','西丰县','0');
INSERT INTO `yzh_area` VALUES ('1979','1974','昌图县','0');
INSERT INTO `yzh_area` VALUES ('1980','1974','调兵山市','0');
INSERT INTO `yzh_area` VALUES ('1981','1974','开原市','0');
INSERT INTO `yzh_area` VALUES ('1982','1874','营口市','0');
INSERT INTO `yzh_area` VALUES ('1983','1982','站前区','0');
INSERT INTO `yzh_area` VALUES ('1984','1982','西市区','0');
INSERT INTO `yzh_area` VALUES ('1985','1982','鲅鱼圈区','0');
INSERT INTO `yzh_area` VALUES ('1986','1982','老边区','0');
INSERT INTO `yzh_area` VALUES ('1987','1982','盖州市','0');
INSERT INTO `yzh_area` VALUES ('1988','1982','大石桥市','0');
INSERT INTO `yzh_area` VALUES ('1989','0','内蒙古','0');
INSERT INTO `yzh_area` VALUES ('1990','1989','呼和浩特市','0');
INSERT INTO `yzh_area` VALUES ('1991','1990','新城区','0');
INSERT INTO `yzh_area` VALUES ('1992','1990','回民区','0');
INSERT INTO `yzh_area` VALUES ('1993','1990','玉泉区','0');
INSERT INTO `yzh_area` VALUES ('1994','1990','赛罕区','0');
INSERT INTO `yzh_area` VALUES ('1995','1990','土默特左旗','0');
INSERT INTO `yzh_area` VALUES ('1996','1990','托克托县','0');
INSERT INTO `yzh_area` VALUES ('1997','1990','和林格尔县','0');
INSERT INTO `yzh_area` VALUES ('1998','1990','清水河县','0');
INSERT INTO `yzh_area` VALUES ('1999','1990','武川县','0');
INSERT INTO `yzh_area` VALUES ('2000','1989','阿拉善盟','0');
INSERT INTO `yzh_area` VALUES ('2001','2000','阿拉善左旗','0');
INSERT INTO `yzh_area` VALUES ('2002','2000','阿拉善右旗','0');
INSERT INTO `yzh_area` VALUES ('2003','2000','额济纳旗','0');
INSERT INTO `yzh_area` VALUES ('2004','1989','巴彦淖尔市','0');
INSERT INTO `yzh_area` VALUES ('2005','2004','临河区','0');
INSERT INTO `yzh_area` VALUES ('2006','2004','五原县','0');
INSERT INTO `yzh_area` VALUES ('2007','2004','磴口县','0');
INSERT INTO `yzh_area` VALUES ('2008','2004','乌拉特前旗','0');
INSERT INTO `yzh_area` VALUES ('2009','2004','乌拉特中旗','0');
INSERT INTO `yzh_area` VALUES ('2010','2004','乌拉特后旗','0');
INSERT INTO `yzh_area` VALUES ('2011','2004','杭锦后旗','0');
INSERT INTO `yzh_area` VALUES ('2012','1989','包头市','0');
INSERT INTO `yzh_area` VALUES ('2013','2012','东河区','0');
INSERT INTO `yzh_area` VALUES ('2014','2012','昆都仑区','0');
INSERT INTO `yzh_area` VALUES ('2015','2012','青山区','0');
INSERT INTO `yzh_area` VALUES ('2016','2012','石拐区','0');
INSERT INTO `yzh_area` VALUES ('2017','2012','白云矿区','0');
INSERT INTO `yzh_area` VALUES ('2018','2012','九原区','0');
INSERT INTO `yzh_area` VALUES ('2019','2012','土默特右旗','0');
INSERT INTO `yzh_area` VALUES ('2020','2012','固阳县','0');
INSERT INTO `yzh_area` VALUES ('2021','2012','达尔罕茂明安联合旗','0');
INSERT INTO `yzh_area` VALUES ('2022','1989','赤峰市','0');
INSERT INTO `yzh_area` VALUES ('2023','2022','红山区','0');
INSERT INTO `yzh_area` VALUES ('2024','2022','元宝山区','0');
INSERT INTO `yzh_area` VALUES ('2025','2022','松山区','0');
INSERT INTO `yzh_area` VALUES ('2026','2022','阿鲁科尔沁旗','0');
INSERT INTO `yzh_area` VALUES ('2027','2022','巴林左旗','0');
INSERT INTO `yzh_area` VALUES ('2028','2022','巴林右旗','0');
INSERT INTO `yzh_area` VALUES ('2029','2022','林西县','0');
INSERT INTO `yzh_area` VALUES ('2030','2022','克什克腾旗','0');
INSERT INTO `yzh_area` VALUES ('2031','2022','翁牛特旗','0');
INSERT INTO `yzh_area` VALUES ('2032','2022','喀喇沁旗','0');
INSERT INTO `yzh_area` VALUES ('2033','2022','宁城县','0');
INSERT INTO `yzh_area` VALUES ('2034','2022','敖汉旗','0');
INSERT INTO `yzh_area` VALUES ('2035','1989','鄂尔多斯市','0');
INSERT INTO `yzh_area` VALUES ('2036','2035','东胜区','0');
INSERT INTO `yzh_area` VALUES ('2037','2035','达拉特旗','0');
INSERT INTO `yzh_area` VALUES ('2038','2035','准格尔旗','0');
INSERT INTO `yzh_area` VALUES ('2039','2035','鄂托克前旗','0');
INSERT INTO `yzh_area` VALUES ('2040','2035','鄂托克旗','0');
INSERT INTO `yzh_area` VALUES ('2041','2035','杭锦旗','0');
INSERT INTO `yzh_area` VALUES ('2042','2035','乌审旗','0');
INSERT INTO `yzh_area` VALUES ('2043','2035','伊金霍洛旗','0');
INSERT INTO `yzh_area` VALUES ('2044','1989','呼伦贝尔市','0');
INSERT INTO `yzh_area` VALUES ('2045','2044','海拉尔区','0');
INSERT INTO `yzh_area` VALUES ('2046','2044','阿荣旗','0');
INSERT INTO `yzh_area` VALUES ('2047','2044','莫力达瓦达斡尔族自治旗','0');
INSERT INTO `yzh_area` VALUES ('2048','2044','鄂伦春自治旗','0');
INSERT INTO `yzh_area` VALUES ('2049','2044','鄂温克族自治旗','0');
INSERT INTO `yzh_area` VALUES ('2050','2044','陈巴尔虎旗','0');
INSERT INTO `yzh_area` VALUES ('2051','2044','新巴尔虎左旗','0');
INSERT INTO `yzh_area` VALUES ('2052','2044','新巴尔虎右旗','0');
INSERT INTO `yzh_area` VALUES ('2053','2044','满洲里市','0');
INSERT INTO `yzh_area` VALUES ('2054','2044','牙克石市','0');
INSERT INTO `yzh_area` VALUES ('2055','2044','扎兰屯市','0');
INSERT INTO `yzh_area` VALUES ('2056','2044','额尔古纳市','0');
INSERT INTO `yzh_area` VALUES ('2057','2044','根河市','0');
INSERT INTO `yzh_area` VALUES ('2058','1989','通辽市','0');
INSERT INTO `yzh_area` VALUES ('2059','2058','科尔沁区','0');
INSERT INTO `yzh_area` VALUES ('2060','2058','科尔沁左翼中旗','0');
INSERT INTO `yzh_area` VALUES ('2061','2058','科尔沁左翼后旗','0');
INSERT INTO `yzh_area` VALUES ('2062','2058','开鲁县','0');
INSERT INTO `yzh_area` VALUES ('2063','2058','库伦旗','0');
INSERT INTO `yzh_area` VALUES ('2064','2058','奈曼旗','0');
INSERT INTO `yzh_area` VALUES ('2065','2058','扎鲁特旗','0');
INSERT INTO `yzh_area` VALUES ('2066','2058','霍林郭勒市','0');
INSERT INTO `yzh_area` VALUES ('2067','1989','乌海市','0');
INSERT INTO `yzh_area` VALUES ('2068','2067','海勃湾区','0');
INSERT INTO `yzh_area` VALUES ('2069','2067','海南区','0');
INSERT INTO `yzh_area` VALUES ('2070','2067','乌达区','0');
INSERT INTO `yzh_area` VALUES ('2071','1989','乌兰察布市','0');
INSERT INTO `yzh_area` VALUES ('2072','2071','集宁区','0');
INSERT INTO `yzh_area` VALUES ('2073','2071','卓资县','0');
INSERT INTO `yzh_area` VALUES ('2074','2071','化德县','0');
INSERT INTO `yzh_area` VALUES ('2075','2071','商都县','0');
INSERT INTO `yzh_area` VALUES ('2076','2071','兴和县','0');
INSERT INTO `yzh_area` VALUES ('2077','2071','凉城县','0');
INSERT INTO `yzh_area` VALUES ('2078','2071','察哈尔右翼前旗','0');
INSERT INTO `yzh_area` VALUES ('2079','2071','察哈尔右翼中旗','0');
INSERT INTO `yzh_area` VALUES ('2080','2071','察哈尔右翼后旗','0');
INSERT INTO `yzh_area` VALUES ('2081','2071','四子王旗','0');
INSERT INTO `yzh_area` VALUES ('2082','2071','丰镇市','0');
INSERT INTO `yzh_area` VALUES ('2083','1989','锡林郭勒盟','0');
INSERT INTO `yzh_area` VALUES ('2084','2083','二连浩特市','0');
INSERT INTO `yzh_area` VALUES ('2085','2083','锡林浩特市','0');
INSERT INTO `yzh_area` VALUES ('2086','2083','阿巴嘎旗','0');
INSERT INTO `yzh_area` VALUES ('2087','2083','苏尼特左旗','0');
INSERT INTO `yzh_area` VALUES ('2088','2083','苏尼特右旗','0');
INSERT INTO `yzh_area` VALUES ('2089','2083','东乌珠穆沁旗','0');
INSERT INTO `yzh_area` VALUES ('2090','2083','西乌珠穆沁旗','0');
INSERT INTO `yzh_area` VALUES ('2091','2083','太仆寺旗','0');
INSERT INTO `yzh_area` VALUES ('2092','2083','镶黄旗','0');
INSERT INTO `yzh_area` VALUES ('2093','2083','正镶白旗','0');
INSERT INTO `yzh_area` VALUES ('2094','2083','正蓝旗','0');
INSERT INTO `yzh_area` VALUES ('2095','2083','多伦县','0');
INSERT INTO `yzh_area` VALUES ('2096','1989','兴安盟','0');
INSERT INTO `yzh_area` VALUES ('2097','2096','乌兰浩特市','0');
INSERT INTO `yzh_area` VALUES ('2098','2096','阿尔山市','0');
INSERT INTO `yzh_area` VALUES ('2099','2096','科尔沁右翼前旗','0');
INSERT INTO `yzh_area` VALUES ('2100','2096','科尔沁右翼中旗','0');
INSERT INTO `yzh_area` VALUES ('2101','2096','扎赉特旗','0');
INSERT INTO `yzh_area` VALUES ('2102','2096','突泉县','0');
INSERT INTO `yzh_area` VALUES ('2103','0','宁夏','0');
INSERT INTO `yzh_area` VALUES ('2104','2103','银川市','0');
INSERT INTO `yzh_area` VALUES ('2105','2104','兴庆区','0');
INSERT INTO `yzh_area` VALUES ('2106','2104','西夏区','0');
INSERT INTO `yzh_area` VALUES ('2107','2104','金凤区','0');
INSERT INTO `yzh_area` VALUES ('2108','2104','永宁县','0');
INSERT INTO `yzh_area` VALUES ('2109','2104','贺兰县','0');
INSERT INTO `yzh_area` VALUES ('2110','2104','灵武市','0');
INSERT INTO `yzh_area` VALUES ('2111','2103','固原市','0');
INSERT INTO `yzh_area` VALUES ('2112','2111','原州区','0');
INSERT INTO `yzh_area` VALUES ('2113','2111','西吉县','0');
INSERT INTO `yzh_area` VALUES ('2114','2111','隆德县','0');
INSERT INTO `yzh_area` VALUES ('2115','2111','泾源县','0');
INSERT INTO `yzh_area` VALUES ('2116','2111','彭阳县','0');
INSERT INTO `yzh_area` VALUES ('2117','2103','石嘴山市','0');
INSERT INTO `yzh_area` VALUES ('2118','2117','大武口区','0');
INSERT INTO `yzh_area` VALUES ('2119','2117','惠农区','0');
INSERT INTO `yzh_area` VALUES ('2120','2117','平罗县','0');
INSERT INTO `yzh_area` VALUES ('2121','2103','吴忠市','0');
INSERT INTO `yzh_area` VALUES ('2122','2121','利通区','0');
INSERT INTO `yzh_area` VALUES ('2123','2121','盐池县','0');
INSERT INTO `yzh_area` VALUES ('2124','2121','同心县','0');
INSERT INTO `yzh_area` VALUES ('2125','2121','青铜峡市','0');
INSERT INTO `yzh_area` VALUES ('2126','2103','中卫市','0');
INSERT INTO `yzh_area` VALUES ('2127','2126','沙坡头区','0');
INSERT INTO `yzh_area` VALUES ('2128','2126','中宁县','0');
INSERT INTO `yzh_area` VALUES ('2129','2126','海原县','0');
INSERT INTO `yzh_area` VALUES ('2130','0','青海','0');
INSERT INTO `yzh_area` VALUES ('2131','2130','西宁市','0');
INSERT INTO `yzh_area` VALUES ('2132','2131','城东区','0');
INSERT INTO `yzh_area` VALUES ('2133','2131','城中区','0');
INSERT INTO `yzh_area` VALUES ('2134','2131','城西区','0');
INSERT INTO `yzh_area` VALUES ('2135','2131','城北区','0');
INSERT INTO `yzh_area` VALUES ('2136','2131','大通回族土族自治县','0');
INSERT INTO `yzh_area` VALUES ('2137','2131','湟中县','0');
INSERT INTO `yzh_area` VALUES ('2138','2131','湟源县','0');
INSERT INTO `yzh_area` VALUES ('2139','2130','果洛藏族自治州','0');
INSERT INTO `yzh_area` VALUES ('2140','2139','玛沁县','0');
INSERT INTO `yzh_area` VALUES ('2141','2139','班玛县','0');
INSERT INTO `yzh_area` VALUES ('2142','2139','甘德县','0');
INSERT INTO `yzh_area` VALUES ('2143','2139','达日县','0');
INSERT INTO `yzh_area` VALUES ('2144','2139','久治县','0');
INSERT INTO `yzh_area` VALUES ('2145','2139','玛多县','0');
INSERT INTO `yzh_area` VALUES ('2146','2130','海北藏族自治州','0');
INSERT INTO `yzh_area` VALUES ('2147','2146','门源回族自治县','0');
INSERT INTO `yzh_area` VALUES ('2148','2146','祁连县','0');
INSERT INTO `yzh_area` VALUES ('2149','2146','海晏县','0');
INSERT INTO `yzh_area` VALUES ('2150','2146','刚察县','0');
INSERT INTO `yzh_area` VALUES ('2151','2130','海东地区','0');
INSERT INTO `yzh_area` VALUES ('2152','2151','平安县','0');
INSERT INTO `yzh_area` VALUES ('2153','2151','民和回族土族自治县','0');
INSERT INTO `yzh_area` VALUES ('2154','2151','乐都县','0');
INSERT INTO `yzh_area` VALUES ('2155','2151','互助土族自治县','0');
INSERT INTO `yzh_area` VALUES ('2156','2151','化隆回族自治县','0');
INSERT INTO `yzh_area` VALUES ('2157','2151','循化撒拉族自治县','0');
INSERT INTO `yzh_area` VALUES ('2158','2130','海南藏族自治州','0');
INSERT INTO `yzh_area` VALUES ('2159','2158','共和县','0');
INSERT INTO `yzh_area` VALUES ('2160','2158','同德县','0');
INSERT INTO `yzh_area` VALUES ('2161','2158','贵德县','0');
INSERT INTO `yzh_area` VALUES ('2162','2158','兴海县','0');
INSERT INTO `yzh_area` VALUES ('2163','2158','贵南县','0');
INSERT INTO `yzh_area` VALUES ('2164','2130','海西蒙古族藏族自治州','0');
INSERT INTO `yzh_area` VALUES ('2165','2164','格尔木市','0');
INSERT INTO `yzh_area` VALUES ('2166','2164','德令哈市','0');
INSERT INTO `yzh_area` VALUES ('2167','2164','乌兰县','0');
INSERT INTO `yzh_area` VALUES ('2168','2164','都兰县','0');
INSERT INTO `yzh_area` VALUES ('2169','2164','天峻县','0');
INSERT INTO `yzh_area` VALUES ('2170','2130','黄南藏族自治州','0');
INSERT INTO `yzh_area` VALUES ('2171','2170','同仁县','0');
INSERT INTO `yzh_area` VALUES ('2172','2170','尖扎县','0');
INSERT INTO `yzh_area` VALUES ('2173','2170','泽库县','0');
INSERT INTO `yzh_area` VALUES ('2174','2170','河南蒙古族自治县','0');
INSERT INTO `yzh_area` VALUES ('2175','2130','玉树藏族自治州','0');
INSERT INTO `yzh_area` VALUES ('2176','2175','玉树县','0');
INSERT INTO `yzh_area` VALUES ('2177','2175','杂多县','0');
INSERT INTO `yzh_area` VALUES ('2178','2175','称多县','0');
INSERT INTO `yzh_area` VALUES ('2179','2175','治多县','0');
INSERT INTO `yzh_area` VALUES ('2180','2175','囊谦县','0');
INSERT INTO `yzh_area` VALUES ('2181','2175','曲麻莱县','0');
INSERT INTO `yzh_area` VALUES ('2182','0','山东','0');
INSERT INTO `yzh_area` VALUES ('2183','2182','济南市','0');
INSERT INTO `yzh_area` VALUES ('2184','2183','历下区','0');
INSERT INTO `yzh_area` VALUES ('2185','2183','市中区','0');
INSERT INTO `yzh_area` VALUES ('2186','2183','槐荫区','0');
INSERT INTO `yzh_area` VALUES ('2187','2183','天桥区','0');
INSERT INTO `yzh_area` VALUES ('2188','2183','历城区','0');
INSERT INTO `yzh_area` VALUES ('2189','2183','长清区','0');
INSERT INTO `yzh_area` VALUES ('2190','2183','平阴县','0');
INSERT INTO `yzh_area` VALUES ('2191','2183','济阳县','0');
INSERT INTO `yzh_area` VALUES ('2192','2183','商河县','0');
INSERT INTO `yzh_area` VALUES ('2193','2183','章丘市','0');
INSERT INTO `yzh_area` VALUES ('2194','2182','滨州市','0');
INSERT INTO `yzh_area` VALUES ('2195','2194','滨城区','0');
INSERT INTO `yzh_area` VALUES ('2196','2194','惠民县','0');
INSERT INTO `yzh_area` VALUES ('2197','2194','阳信县','0');
INSERT INTO `yzh_area` VALUES ('2198','2194','无棣县','0');
INSERT INTO `yzh_area` VALUES ('2199','2194','沾化县','0');
INSERT INTO `yzh_area` VALUES ('2200','2194','博兴县','0');
INSERT INTO `yzh_area` VALUES ('2201','2194','邹平县','0');
INSERT INTO `yzh_area` VALUES ('2202','2182','德州市','0');
INSERT INTO `yzh_area` VALUES ('2203','2202','德城区','0');
INSERT INTO `yzh_area` VALUES ('2204','2202','陵县','0');
INSERT INTO `yzh_area` VALUES ('2205','2202','宁津县','0');
INSERT INTO `yzh_area` VALUES ('2206','2202','庆云县','0');
INSERT INTO `yzh_area` VALUES ('2207','2202','临邑县','0');
INSERT INTO `yzh_area` VALUES ('2208','2202','齐河县','0');
INSERT INTO `yzh_area` VALUES ('2209','2202','平原县','0');
INSERT INTO `yzh_area` VALUES ('2210','2202','夏津县','0');
INSERT INTO `yzh_area` VALUES ('2211','2202','武城县','0');
INSERT INTO `yzh_area` VALUES ('2212','2202','乐陵市','0');
INSERT INTO `yzh_area` VALUES ('2213','2202','禹城市','0');
INSERT INTO `yzh_area` VALUES ('2214','2182','东营市','0');
INSERT INTO `yzh_area` VALUES ('2215','2214','东营区','0');
INSERT INTO `yzh_area` VALUES ('2216','2214','河口区','0');
INSERT INTO `yzh_area` VALUES ('2217','2214','垦利县','0');
INSERT INTO `yzh_area` VALUES ('2218','2214','利津县','0');
INSERT INTO `yzh_area` VALUES ('2219','2214','广饶县','0');
INSERT INTO `yzh_area` VALUES ('2220','2182','菏泽市','0');
INSERT INTO `yzh_area` VALUES ('2221','2220','牡丹区','0');
INSERT INTO `yzh_area` VALUES ('2222','2220','曹县','0');
INSERT INTO `yzh_area` VALUES ('2223','2220','单县','0');
INSERT INTO `yzh_area` VALUES ('2224','2220','成武县','0');
INSERT INTO `yzh_area` VALUES ('2225','2220','巨野县','0');
INSERT INTO `yzh_area` VALUES ('2226','2220','郓城县','0');
INSERT INTO `yzh_area` VALUES ('2227','2220','鄄城县','0');
INSERT INTO `yzh_area` VALUES ('2228','2220','定陶县','0');
INSERT INTO `yzh_area` VALUES ('2229','2220','东明县','0');
INSERT INTO `yzh_area` VALUES ('2230','2182','济宁市','0');
INSERT INTO `yzh_area` VALUES ('2231','2230','市中区','0');
INSERT INTO `yzh_area` VALUES ('2232','2230','任城区','0');
INSERT INTO `yzh_area` VALUES ('2233','2230','微山县','0');
INSERT INTO `yzh_area` VALUES ('2234','2230','鱼台县','0');
INSERT INTO `yzh_area` VALUES ('2235','2230','金乡县','0');
INSERT INTO `yzh_area` VALUES ('2236','2230','嘉祥县','0');
INSERT INTO `yzh_area` VALUES ('2237','2230','汶上县','0');
INSERT INTO `yzh_area` VALUES ('2238','2230','泗水县','0');
INSERT INTO `yzh_area` VALUES ('2239','2230','梁山县','0');
INSERT INTO `yzh_area` VALUES ('2240','2230','曲阜市','0');
INSERT INTO `yzh_area` VALUES ('2241','2230','兖州市','0');
INSERT INTO `yzh_area` VALUES ('2242','2230','邹城市','0');
INSERT INTO `yzh_area` VALUES ('2243','2182','莱芜市','0');
INSERT INTO `yzh_area` VALUES ('2244','2243','莱城区','0');
INSERT INTO `yzh_area` VALUES ('2245','2243','钢城区','0');
INSERT INTO `yzh_area` VALUES ('2246','2182','聊城市','0');
INSERT INTO `yzh_area` VALUES ('2247','2246','东昌府区','0');
INSERT INTO `yzh_area` VALUES ('2248','2246','阳谷县','0');
INSERT INTO `yzh_area` VALUES ('2249','2246','莘县','0');
INSERT INTO `yzh_area` VALUES ('2250','2246','茌平县','0');
INSERT INTO `yzh_area` VALUES ('2251','2246','东阿县','0');
INSERT INTO `yzh_area` VALUES ('2252','2246','冠县','0');
INSERT INTO `yzh_area` VALUES ('2253','2246','高唐县','0');
INSERT INTO `yzh_area` VALUES ('2254','2246','临清市','0');
INSERT INTO `yzh_area` VALUES ('2255','2182','临沂市','0');
INSERT INTO `yzh_area` VALUES ('2256','2255','兰山区','0');
INSERT INTO `yzh_area` VALUES ('2257','2255','罗庄区','0');
INSERT INTO `yzh_area` VALUES ('2258','2255','河东区','0');
INSERT INTO `yzh_area` VALUES ('2259','2255','沂南县','0');
INSERT INTO `yzh_area` VALUES ('2260','2255','郯城县','0');
INSERT INTO `yzh_area` VALUES ('2261','2255','沂水县','0');
INSERT INTO `yzh_area` VALUES ('2262','2255','苍山县','0');
INSERT INTO `yzh_area` VALUES ('2263','2255','费县','0');
INSERT INTO `yzh_area` VALUES ('2264','2255','平邑县','0');
INSERT INTO `yzh_area` VALUES ('2265','2255','莒南县','0');
INSERT INTO `yzh_area` VALUES ('2266','2255','蒙阴县','0');
INSERT INTO `yzh_area` VALUES ('2267','2255','临沭县','0');
INSERT INTO `yzh_area` VALUES ('2268','2182','青岛市','0');
INSERT INTO `yzh_area` VALUES ('2269','2268','市南区','0');
INSERT INTO `yzh_area` VALUES ('2270','2268','市北区','0');
INSERT INTO `yzh_area` VALUES ('2271','2268','四方区','0');
INSERT INTO `yzh_area` VALUES ('2272','2268','黄岛区','0');
INSERT INTO `yzh_area` VALUES ('2273','2268','崂山区','0');
INSERT INTO `yzh_area` VALUES ('2274','2268','李沧区','0');
INSERT INTO `yzh_area` VALUES ('2275','2268','城阳区','0');
INSERT INTO `yzh_area` VALUES ('2276','2268','胶州市','0');
INSERT INTO `yzh_area` VALUES ('2277','2268','即墨市','0');
INSERT INTO `yzh_area` VALUES ('2278','2268','平度市','0');
INSERT INTO `yzh_area` VALUES ('2279','2268','胶南市','0');
INSERT INTO `yzh_area` VALUES ('2280','2268','莱西市','0');
INSERT INTO `yzh_area` VALUES ('2281','2182','日照市','0');
INSERT INTO `yzh_area` VALUES ('2282','2281','东港区','0');
INSERT INTO `yzh_area` VALUES ('2283','2281','岚山区','0');
INSERT INTO `yzh_area` VALUES ('2284','2281','五莲县','0');
INSERT INTO `yzh_area` VALUES ('2285','2281','莒县','0');
INSERT INTO `yzh_area` VALUES ('2286','2182','泰安市','0');
INSERT INTO `yzh_area` VALUES ('2287','2286','泰山区','0');
INSERT INTO `yzh_area` VALUES ('2288','2286','岱岳区','0');
INSERT INTO `yzh_area` VALUES ('2289','2286','宁阳县','0');
INSERT INTO `yzh_area` VALUES ('2290','2286','东平县','0');
INSERT INTO `yzh_area` VALUES ('2291','2286','新泰市','0');
INSERT INTO `yzh_area` VALUES ('2292','2286','肥城市','0');
INSERT INTO `yzh_area` VALUES ('2293','2182','威海市','0');
INSERT INTO `yzh_area` VALUES ('2294','2293','环翠区','0');
INSERT INTO `yzh_area` VALUES ('2295','2293','文登市','0');
INSERT INTO `yzh_area` VALUES ('2296','2293','荣成市','0');
INSERT INTO `yzh_area` VALUES ('2297','2293','乳山市','0');
INSERT INTO `yzh_area` VALUES ('2298','2182','潍坊市','0');
INSERT INTO `yzh_area` VALUES ('2299','2298','潍城区','0');
INSERT INTO `yzh_area` VALUES ('2300','2298','寒亭区','0');
INSERT INTO `yzh_area` VALUES ('2301','2298','坊子区','0');
INSERT INTO `yzh_area` VALUES ('2302','2298','奎文区','0');
INSERT INTO `yzh_area` VALUES ('2303','2298','临朐县','0');
INSERT INTO `yzh_area` VALUES ('2304','2298','昌乐县','0');
INSERT INTO `yzh_area` VALUES ('2305','2298','青州市','0');
INSERT INTO `yzh_area` VALUES ('2306','2298','诸城市','0');
INSERT INTO `yzh_area` VALUES ('2307','2298','寿光市','0');
INSERT INTO `yzh_area` VALUES ('2308','2298','安丘市','0');
INSERT INTO `yzh_area` VALUES ('2309','2298','高密市','0');
INSERT INTO `yzh_area` VALUES ('2310','2298','昌邑市','0');
INSERT INTO `yzh_area` VALUES ('2311','2182','烟台市','0');
INSERT INTO `yzh_area` VALUES ('2312','2311','芝罘区','0');
INSERT INTO `yzh_area` VALUES ('2313','2311','福山区','0');
INSERT INTO `yzh_area` VALUES ('2314','2311','牟平区','0');
INSERT INTO `yzh_area` VALUES ('2315','2311','莱山区','0');
INSERT INTO `yzh_area` VALUES ('2316','2311','长岛县','0');
INSERT INTO `yzh_area` VALUES ('2317','2311','龙口市','0');
INSERT INTO `yzh_area` VALUES ('2318','2311','莱阳市','0');
INSERT INTO `yzh_area` VALUES ('2319','2311','莱州市','0');
INSERT INTO `yzh_area` VALUES ('2320','2311','蓬莱市','0');
INSERT INTO `yzh_area` VALUES ('2321','2311','招远市','0');
INSERT INTO `yzh_area` VALUES ('2322','2311','栖霞市','0');
INSERT INTO `yzh_area` VALUES ('2323','2311','海阳市','0');
INSERT INTO `yzh_area` VALUES ('2324','2182','枣庄市','0');
INSERT INTO `yzh_area` VALUES ('2325','2324','市中区','0');
INSERT INTO `yzh_area` VALUES ('2326','2324','薛城区','0');
INSERT INTO `yzh_area` VALUES ('2327','2324','峄城区','0');
INSERT INTO `yzh_area` VALUES ('2328','2324','台儿庄区','0');
INSERT INTO `yzh_area` VALUES ('2329','2324','山亭区','0');
INSERT INTO `yzh_area` VALUES ('2330','2324','滕州市','0');
INSERT INTO `yzh_area` VALUES ('2331','2182','淄博市','0');
INSERT INTO `yzh_area` VALUES ('2332','2331','淄川区','0');
INSERT INTO `yzh_area` VALUES ('2333','2331','张店区','0');
INSERT INTO `yzh_area` VALUES ('2334','2331','博山区','0');
INSERT INTO `yzh_area` VALUES ('2335','2331','临淄区','0');
INSERT INTO `yzh_area` VALUES ('2336','2331','周村区','0');
INSERT INTO `yzh_area` VALUES ('2337','2331','桓台县','0');
INSERT INTO `yzh_area` VALUES ('2338','2331','高青县','0');
INSERT INTO `yzh_area` VALUES ('2339','2331','沂源县','0');
INSERT INTO `yzh_area` VALUES ('2340','0','山西','0');
INSERT INTO `yzh_area` VALUES ('2341','2340','太原市','0');
INSERT INTO `yzh_area` VALUES ('2342','2341','小店区','0');
INSERT INTO `yzh_area` VALUES ('2343','2341','迎泽区','0');
INSERT INTO `yzh_area` VALUES ('2344','2341','杏花岭区','0');
INSERT INTO `yzh_area` VALUES ('2345','2341','尖草坪区','0');
INSERT INTO `yzh_area` VALUES ('2346','2341','万柏林区','0');
INSERT INTO `yzh_area` VALUES ('2347','2341','晋源区','0');
INSERT INTO `yzh_area` VALUES ('2348','2341','清徐县','0');
INSERT INTO `yzh_area` VALUES ('2349','2341','阳曲县','0');
INSERT INTO `yzh_area` VALUES ('2350','2341','娄烦县','0');
INSERT INTO `yzh_area` VALUES ('2351','2341','古交市','0');
INSERT INTO `yzh_area` VALUES ('2352','2340','长治市','0');
INSERT INTO `yzh_area` VALUES ('2353','2352','城区','0');
INSERT INTO `yzh_area` VALUES ('2354','2352','郊区','0');
INSERT INTO `yzh_area` VALUES ('2355','2352','长治县','0');
INSERT INTO `yzh_area` VALUES ('2356','2352','襄垣县','0');
INSERT INTO `yzh_area` VALUES ('2357','2352','屯留县','0');
INSERT INTO `yzh_area` VALUES ('2358','2352','平顺县','0');
INSERT INTO `yzh_area` VALUES ('2359','2352','黎城县','0');
INSERT INTO `yzh_area` VALUES ('2360','2352','壶关县','0');
INSERT INTO `yzh_area` VALUES ('2361','2352','长子县','0');
INSERT INTO `yzh_area` VALUES ('2362','2352','武乡县','0');
INSERT INTO `yzh_area` VALUES ('2363','2352','沁县','0');
INSERT INTO `yzh_area` VALUES ('2364','2352','沁源县','0');
INSERT INTO `yzh_area` VALUES ('2365','2352','潞城市','0');
INSERT INTO `yzh_area` VALUES ('2366','2340','大同市','0');
INSERT INTO `yzh_area` VALUES ('2367','2366','城区','0');
INSERT INTO `yzh_area` VALUES ('2368','2366','矿区','0');
INSERT INTO `yzh_area` VALUES ('2369','2366','南郊区','0');
INSERT INTO `yzh_area` VALUES ('2370','2366','新荣区','0');
INSERT INTO `yzh_area` VALUES ('2371','2366','阳高县','0');
INSERT INTO `yzh_area` VALUES ('2372','2366','天镇县','0');
INSERT INTO `yzh_area` VALUES ('2373','2366','广灵县','0');
INSERT INTO `yzh_area` VALUES ('2374','2366','灵丘县','0');
INSERT INTO `yzh_area` VALUES ('2375','2366','浑源县','0');
INSERT INTO `yzh_area` VALUES ('2376','2366','左云县','0');
INSERT INTO `yzh_area` VALUES ('2377','2366','大同县','0');
INSERT INTO `yzh_area` VALUES ('2378','2340','晋城市','0');
INSERT INTO `yzh_area` VALUES ('2379','2378','城区','0');
INSERT INTO `yzh_area` VALUES ('2380','2378','沁水县','0');
INSERT INTO `yzh_area` VALUES ('2381','2378','阳城县','0');
INSERT INTO `yzh_area` VALUES ('2382','2378','陵川县','0');
INSERT INTO `yzh_area` VALUES ('2383','2378','泽州县','0');
INSERT INTO `yzh_area` VALUES ('2384','2378','高平市','0');
INSERT INTO `yzh_area` VALUES ('2385','2340','晋中市','0');
INSERT INTO `yzh_area` VALUES ('2386','2385','榆次区','0');
INSERT INTO `yzh_area` VALUES ('2387','2385','榆社县','0');
INSERT INTO `yzh_area` VALUES ('2388','2385','左权县','0');
INSERT INTO `yzh_area` VALUES ('2389','2385','和顺县','0');
INSERT INTO `yzh_area` VALUES ('2390','2385','昔阳县','0');
INSERT INTO `yzh_area` VALUES ('2391','2385','寿阳县','0');
INSERT INTO `yzh_area` VALUES ('2392','2385','太谷县','0');
INSERT INTO `yzh_area` VALUES ('2393','2385','祁县','0');
INSERT INTO `yzh_area` VALUES ('2394','2385','平遥县','0');
INSERT INTO `yzh_area` VALUES ('2395','2385','灵石县','0');
INSERT INTO `yzh_area` VALUES ('2396','2385','介休市','0');
INSERT INTO `yzh_area` VALUES ('2397','2340','临汾市','0');
INSERT INTO `yzh_area` VALUES ('2398','2397','尧都区','0');
INSERT INTO `yzh_area` VALUES ('2399','2397','曲沃县','0');
INSERT INTO `yzh_area` VALUES ('2400','2397','翼城县','0');
INSERT INTO `yzh_area` VALUES ('2401','2397','襄汾县','0');
INSERT INTO `yzh_area` VALUES ('2402','2397','洪洞县','0');
INSERT INTO `yzh_area` VALUES ('2403','2397','古县','0');
INSERT INTO `yzh_area` VALUES ('2404','2397','安泽县','0');
INSERT INTO `yzh_area` VALUES ('2405','2397','浮山县','0');
INSERT INTO `yzh_area` VALUES ('2406','2397','吉县','0');
INSERT INTO `yzh_area` VALUES ('2407','2397','乡宁县','0');
INSERT INTO `yzh_area` VALUES ('2408','2397','大宁县','0');
INSERT INTO `yzh_area` VALUES ('2409','2397','隰县','0');
INSERT INTO `yzh_area` VALUES ('2410','2397','永和县','0');
INSERT INTO `yzh_area` VALUES ('2411','2397','蒲县','0');
INSERT INTO `yzh_area` VALUES ('2412','2397','汾西县','0');
INSERT INTO `yzh_area` VALUES ('2413','2397','侯马市','0');
INSERT INTO `yzh_area` VALUES ('2414','2397','霍州市','0');
INSERT INTO `yzh_area` VALUES ('2415','2340','吕梁市','0');
INSERT INTO `yzh_area` VALUES ('2416','2415','离石区','0');
INSERT INTO `yzh_area` VALUES ('2417','2415','文水县','0');
INSERT INTO `yzh_area` VALUES ('2418','2415','交城县','0');
INSERT INTO `yzh_area` VALUES ('2419','2415','兴县','0');
INSERT INTO `yzh_area` VALUES ('2420','2415','临县','0');
INSERT INTO `yzh_area` VALUES ('2421','2415','柳林县','0');
INSERT INTO `yzh_area` VALUES ('2422','2415','石楼县','0');
INSERT INTO `yzh_area` VALUES ('2423','2415','岚县','0');
INSERT INTO `yzh_area` VALUES ('2424','2415','方山县','0');
INSERT INTO `yzh_area` VALUES ('2425','2415','中阳县','0');
INSERT INTO `yzh_area` VALUES ('2426','2415','交口县','0');
INSERT INTO `yzh_area` VALUES ('2427','2415','孝义市','0');
INSERT INTO `yzh_area` VALUES ('2428','2415','汾阳市','0');
INSERT INTO `yzh_area` VALUES ('2429','2340','朔州市','0');
INSERT INTO `yzh_area` VALUES ('2430','2429','朔城区','0');
INSERT INTO `yzh_area` VALUES ('2431','2429','平鲁区','0');
INSERT INTO `yzh_area` VALUES ('2432','2429','山阴县','0');
INSERT INTO `yzh_area` VALUES ('2433','2429','应县','0');
INSERT INTO `yzh_area` VALUES ('2434','2429','右玉县','0');
INSERT INTO `yzh_area` VALUES ('2435','2429','怀仁县','0');
INSERT INTO `yzh_area` VALUES ('2436','2340','忻州市','0');
INSERT INTO `yzh_area` VALUES ('2437','2436','忻府区','0');
INSERT INTO `yzh_area` VALUES ('2438','2436','定襄县','0');
INSERT INTO `yzh_area` VALUES ('2439','2436','五台县','0');
INSERT INTO `yzh_area` VALUES ('2440','2436','代县','0');
INSERT INTO `yzh_area` VALUES ('2441','2436','繁峙县','0');
INSERT INTO `yzh_area` VALUES ('2442','2436','宁武县','0');
INSERT INTO `yzh_area` VALUES ('2443','2436','静乐县','0');
INSERT INTO `yzh_area` VALUES ('2444','2436','神池县','0');
INSERT INTO `yzh_area` VALUES ('2445','2436','五寨县','0');
INSERT INTO `yzh_area` VALUES ('2446','2436','岢岚县','0');
INSERT INTO `yzh_area` VALUES ('2447','2436','河曲县','0');
INSERT INTO `yzh_area` VALUES ('2448','2436','保德县','0');
INSERT INTO `yzh_area` VALUES ('2449','2436','偏关县','0');
INSERT INTO `yzh_area` VALUES ('2450','2436','原平市','0');
INSERT INTO `yzh_area` VALUES ('2451','2340','阳泉市','0');
INSERT INTO `yzh_area` VALUES ('2452','2451','城区','0');
INSERT INTO `yzh_area` VALUES ('2453','2451','矿区','0');
INSERT INTO `yzh_area` VALUES ('2454','2451','郊区','0');
INSERT INTO `yzh_area` VALUES ('2455','2451','平定县','0');
INSERT INTO `yzh_area` VALUES ('2456','2451','盂县','0');
INSERT INTO `yzh_area` VALUES ('2457','2340','运城市','0');
INSERT INTO `yzh_area` VALUES ('2458','2457','盐湖区','0');
INSERT INTO `yzh_area` VALUES ('2459','2457','临猗县','0');
INSERT INTO `yzh_area` VALUES ('2460','2457','万荣县','0');
INSERT INTO `yzh_area` VALUES ('2461','2457','闻喜县','0');
INSERT INTO `yzh_area` VALUES ('2462','2457','稷山县','0');
INSERT INTO `yzh_area` VALUES ('2463','2457','新绛县','0');
INSERT INTO `yzh_area` VALUES ('2464','2457','绛县','0');
INSERT INTO `yzh_area` VALUES ('2465','2457','垣曲县','0');
INSERT INTO `yzh_area` VALUES ('2466','2457','夏县','0');
INSERT INTO `yzh_area` VALUES ('2467','2457','平陆县','0');
INSERT INTO `yzh_area` VALUES ('2468','2457','芮城县','0');
INSERT INTO `yzh_area` VALUES ('2469','2457','永济市','0');
INSERT INTO `yzh_area` VALUES ('2470','2457','河津市','0');
INSERT INTO `yzh_area` VALUES ('2471','0','陕西','0');
INSERT INTO `yzh_area` VALUES ('2472','2471','西安市','0');
INSERT INTO `yzh_area` VALUES ('2473','2472','新城区','0');
INSERT INTO `yzh_area` VALUES ('2474','2472','碑林区','0');
INSERT INTO `yzh_area` VALUES ('2475','2472','莲湖区','0');
INSERT INTO `yzh_area` VALUES ('2476','2472','灞桥区','0');
INSERT INTO `yzh_area` VALUES ('2477','2472','未央区','0');
INSERT INTO `yzh_area` VALUES ('2478','2472','雁塔区','0');
INSERT INTO `yzh_area` VALUES ('2479','2472','阎良区','0');
INSERT INTO `yzh_area` VALUES ('2480','2472','临潼区','0');
INSERT INTO `yzh_area` VALUES ('2481','2472','长安区','0');
INSERT INTO `yzh_area` VALUES ('2482','2472','蓝田县','0');
INSERT INTO `yzh_area` VALUES ('2483','2472','周至县','0');
INSERT INTO `yzh_area` VALUES ('2484','2472','户县','0');
INSERT INTO `yzh_area` VALUES ('2485','2472','高陵县','0');
INSERT INTO `yzh_area` VALUES ('2486','2471','安康市','0');
INSERT INTO `yzh_area` VALUES ('2487','2486','汉滨区','0');
INSERT INTO `yzh_area` VALUES ('2488','2486','汉阴县','0');
INSERT INTO `yzh_area` VALUES ('2489','2486','石泉县','0');
INSERT INTO `yzh_area` VALUES ('2490','2486','宁陕县','0');
INSERT INTO `yzh_area` VALUES ('2491','2486','紫阳县','0');
INSERT INTO `yzh_area` VALUES ('2492','2486','岚皋县','0');
INSERT INTO `yzh_area` VALUES ('2493','2486','平利县','0');
INSERT INTO `yzh_area` VALUES ('2494','2486','镇坪县','0');
INSERT INTO `yzh_area` VALUES ('2495','2486','旬阳县','0');
INSERT INTO `yzh_area` VALUES ('2496','2486','白河县','0');
INSERT INTO `yzh_area` VALUES ('2497','2471','宝鸡市','0');
INSERT INTO `yzh_area` VALUES ('2498','2497','渭滨区','0');
INSERT INTO `yzh_area` VALUES ('2499','2497','金台区','0');
INSERT INTO `yzh_area` VALUES ('2500','2497','陈仓区','0');
INSERT INTO `yzh_area` VALUES ('2501','2497','凤翔县','0');
INSERT INTO `yzh_area` VALUES ('2502','2497','岐山县','0');
INSERT INTO `yzh_area` VALUES ('2503','2497','扶风县','0');
INSERT INTO `yzh_area` VALUES ('2504','2497','眉县','0');
INSERT INTO `yzh_area` VALUES ('2505','2497','陇县','0');
INSERT INTO `yzh_area` VALUES ('2506','2497','千阳县','0');
INSERT INTO `yzh_area` VALUES ('2507','2497','麟游县','0');
INSERT INTO `yzh_area` VALUES ('2508','2497','凤县','0');
INSERT INTO `yzh_area` VALUES ('2509','2497','太白县','0');
INSERT INTO `yzh_area` VALUES ('2510','2471','汉中市','0');
INSERT INTO `yzh_area` VALUES ('2511','2510','汉台区','0');
INSERT INTO `yzh_area` VALUES ('2512','2510','南郑县','0');
INSERT INTO `yzh_area` VALUES ('2513','2510','城固县','0');
INSERT INTO `yzh_area` VALUES ('2514','2510','洋县','0');
INSERT INTO `yzh_area` VALUES ('2515','2510','西乡县','0');
INSERT INTO `yzh_area` VALUES ('2516','2510','勉县','0');
INSERT INTO `yzh_area` VALUES ('2517','2510','宁强县','0');
INSERT INTO `yzh_area` VALUES ('2518','2510','略阳县','0');
INSERT INTO `yzh_area` VALUES ('2519','2510','镇巴县','0');
INSERT INTO `yzh_area` VALUES ('2520','2510','留坝县','0');
INSERT INTO `yzh_area` VALUES ('2521','2510','佛坪县','0');
INSERT INTO `yzh_area` VALUES ('2522','2471','商洛市','0');
INSERT INTO `yzh_area` VALUES ('2523','2522','商州区','0');
INSERT INTO `yzh_area` VALUES ('2524','2522','洛南县','0');
INSERT INTO `yzh_area` VALUES ('2525','2522','丹凤县','0');
INSERT INTO `yzh_area` VALUES ('2526','2522','商南县','0');
INSERT INTO `yzh_area` VALUES ('2527','2522','山阳县','0');
INSERT INTO `yzh_area` VALUES ('2528','2522','镇安县','0');
INSERT INTO `yzh_area` VALUES ('2529','2522','柞水县','0');
INSERT INTO `yzh_area` VALUES ('2530','2471','铜川市','0');
INSERT INTO `yzh_area` VALUES ('2531','2530','王益区','0');
INSERT INTO `yzh_area` VALUES ('2532','2530','印台区','0');
INSERT INTO `yzh_area` VALUES ('2533','2530','耀州区','0');
INSERT INTO `yzh_area` VALUES ('2534','2530','宜君县','0');
INSERT INTO `yzh_area` VALUES ('2535','2471','渭南市','0');
INSERT INTO `yzh_area` VALUES ('2536','2535','临渭区','0');
INSERT INTO `yzh_area` VALUES ('2537','2535','华县','0');
INSERT INTO `yzh_area` VALUES ('2538','2535','潼关县','0');
INSERT INTO `yzh_area` VALUES ('2539','2535','大荔县','0');
INSERT INTO `yzh_area` VALUES ('2540','2535','合阳县','0');
INSERT INTO `yzh_area` VALUES ('2541','2535','澄城县','0');
INSERT INTO `yzh_area` VALUES ('2542','2535','蒲城县','0');
INSERT INTO `yzh_area` VALUES ('2543','2535','白水县','0');
INSERT INTO `yzh_area` VALUES ('2544','2535','富平县','0');
INSERT INTO `yzh_area` VALUES ('2545','2535','韩城市','0');
INSERT INTO `yzh_area` VALUES ('2546','2535','华阴市','0');
INSERT INTO `yzh_area` VALUES ('2547','2471','咸阳市','0');
INSERT INTO `yzh_area` VALUES ('2548','2547','秦都区','0');
INSERT INTO `yzh_area` VALUES ('2549','2547','杨凌区','0');
INSERT INTO `yzh_area` VALUES ('2550','2547','渭城区','0');
INSERT INTO `yzh_area` VALUES ('2551','2547','三原县','0');
INSERT INTO `yzh_area` VALUES ('2552','2547','泾阳县','0');
INSERT INTO `yzh_area` VALUES ('2553','2547','乾县','0');
INSERT INTO `yzh_area` VALUES ('2554','2547','礼泉县','0');
INSERT INTO `yzh_area` VALUES ('2555','2547','永寿县','0');
INSERT INTO `yzh_area` VALUES ('2556','2547','彬县','0');
INSERT INTO `yzh_area` VALUES ('2557','2547','长武县','0');
INSERT INTO `yzh_area` VALUES ('2558','2547','旬邑县','0');
INSERT INTO `yzh_area` VALUES ('2559','2547','淳化县','0');
INSERT INTO `yzh_area` VALUES ('2560','2547','武功县','0');
INSERT INTO `yzh_area` VALUES ('2561','2547','兴平市','0');
INSERT INTO `yzh_area` VALUES ('2562','2471','延安市','0');
INSERT INTO `yzh_area` VALUES ('2563','2562','宝塔区','0');
INSERT INTO `yzh_area` VALUES ('2564','2562','延长县','0');
INSERT INTO `yzh_area` VALUES ('2565','2562','延川县','0');
INSERT INTO `yzh_area` VALUES ('2566','2562','子长县','0');
INSERT INTO `yzh_area` VALUES ('2567','2562','安塞县','0');
INSERT INTO `yzh_area` VALUES ('2568','2562','志丹县','0');
INSERT INTO `yzh_area` VALUES ('2569','2562','吴旗县','0');
INSERT INTO `yzh_area` VALUES ('2570','2562','甘泉县','0');
INSERT INTO `yzh_area` VALUES ('2571','2562','富县','0');
INSERT INTO `yzh_area` VALUES ('2572','2562','洛川县','0');
INSERT INTO `yzh_area` VALUES ('2573','2562','宜川县','0');
INSERT INTO `yzh_area` VALUES ('2574','2562','黄龙县','0');
INSERT INTO `yzh_area` VALUES ('2575','2562','黄陵县','0');
INSERT INTO `yzh_area` VALUES ('2576','2471','榆林市','0');
INSERT INTO `yzh_area` VALUES ('2577','2576','榆阳区','0');
INSERT INTO `yzh_area` VALUES ('2578','2576','神木县','0');
INSERT INTO `yzh_area` VALUES ('2579','2576','府谷县','0');
INSERT INTO `yzh_area` VALUES ('2580','2576','横山县','0');
INSERT INTO `yzh_area` VALUES ('2581','2576','靖边县','0');
INSERT INTO `yzh_area` VALUES ('2582','2576','定边县','0');
INSERT INTO `yzh_area` VALUES ('2583','2576','绥德县','0');
INSERT INTO `yzh_area` VALUES ('2584','2576','米脂县','0');
INSERT INTO `yzh_area` VALUES ('2585','2576','佳县','0');
INSERT INTO `yzh_area` VALUES ('2586','2576','吴堡县','0');
INSERT INTO `yzh_area` VALUES ('2587','2576','清涧县','0');
INSERT INTO `yzh_area` VALUES ('2588','2576','子洲县','0');
INSERT INTO `yzh_area` VALUES ('2589','0','四川','0');
INSERT INTO `yzh_area` VALUES ('2590','2589','成都市','0');
INSERT INTO `yzh_area` VALUES ('2591','2590','锦江区','0');
INSERT INTO `yzh_area` VALUES ('2592','2590','青羊区','0');
INSERT INTO `yzh_area` VALUES ('2593','2590','金牛区','0');
INSERT INTO `yzh_area` VALUES ('2594','2590','武侯区','0');
INSERT INTO `yzh_area` VALUES ('2595','2590','成华区','0');
INSERT INTO `yzh_area` VALUES ('2596','2590','龙泉驿区','0');
INSERT INTO `yzh_area` VALUES ('2597','2590','青白江区','0');
INSERT INTO `yzh_area` VALUES ('2598','2590','新都区','0');
INSERT INTO `yzh_area` VALUES ('2599','2590','温江区','0');
INSERT INTO `yzh_area` VALUES ('2600','2590','金堂县','0');
INSERT INTO `yzh_area` VALUES ('2601','2590','双流县','0');
INSERT INTO `yzh_area` VALUES ('2602','2590','郫县','0');
INSERT INTO `yzh_area` VALUES ('2603','2590','大邑县','0');
INSERT INTO `yzh_area` VALUES ('2604','2590','蒲江县','0');
INSERT INTO `yzh_area` VALUES ('2605','2590','新津县','0');
INSERT INTO `yzh_area` VALUES ('2606','2590','都江堰市','0');
INSERT INTO `yzh_area` VALUES ('2607','2590','彭州市','0');
INSERT INTO `yzh_area` VALUES ('2608','2590','邛崃市','0');
INSERT INTO `yzh_area` VALUES ('2609','2590','崇州市','0');
INSERT INTO `yzh_area` VALUES ('2610','2589','阿坝藏族羌族自治州','0');
INSERT INTO `yzh_area` VALUES ('2611','2610','汶川县','0');
INSERT INTO `yzh_area` VALUES ('2612','2610','理县','0');
INSERT INTO `yzh_area` VALUES ('2613','2610','茂县','0');
INSERT INTO `yzh_area` VALUES ('2614','2610','松潘县','0');
INSERT INTO `yzh_area` VALUES ('2615','2610','九寨沟县','0');
INSERT INTO `yzh_area` VALUES ('2616','2610','金川县','0');
INSERT INTO `yzh_area` VALUES ('2617','2610','小金县','0');
INSERT INTO `yzh_area` VALUES ('2618','2610','黑水县','0');
INSERT INTO `yzh_area` VALUES ('2619','2610','马尔康县','0');
INSERT INTO `yzh_area` VALUES ('2620','2610','壤塘县','0');
INSERT INTO `yzh_area` VALUES ('2621','2610','阿坝县','0');
INSERT INTO `yzh_area` VALUES ('2622','2610','若尔盖县','0');
INSERT INTO `yzh_area` VALUES ('2623','2610','红原县','0');
INSERT INTO `yzh_area` VALUES ('2624','2589','巴中市','0');
INSERT INTO `yzh_area` VALUES ('2625','2624','巴州区','0');
INSERT INTO `yzh_area` VALUES ('2626','2624','通江县','0');
INSERT INTO `yzh_area` VALUES ('2627','2624','南江县','0');
INSERT INTO `yzh_area` VALUES ('2628','2624','平昌县','0');
INSERT INTO `yzh_area` VALUES ('2629','2589','达州市','0');
INSERT INTO `yzh_area` VALUES ('2630','2629','通川区','0');
INSERT INTO `yzh_area` VALUES ('2631','2629','达县','0');
INSERT INTO `yzh_area` VALUES ('2632','2629','宣汉县','0');
INSERT INTO `yzh_area` VALUES ('2633','2629','开江县','0');
INSERT INTO `yzh_area` VALUES ('2634','2629','大竹县','0');
INSERT INTO `yzh_area` VALUES ('2635','2629','渠县','0');
INSERT INTO `yzh_area` VALUES ('2636','2629','万源市','0');
INSERT INTO `yzh_area` VALUES ('2637','2589','德阳市','0');
INSERT INTO `yzh_area` VALUES ('2638','2637','旌阳区','0');
INSERT INTO `yzh_area` VALUES ('2639','2637','中江县','0');
INSERT INTO `yzh_area` VALUES ('2640','2637','罗江县','0');
INSERT INTO `yzh_area` VALUES ('2641','2637','广汉市','0');
INSERT INTO `yzh_area` VALUES ('2642','2637','什邡市','0');
INSERT INTO `yzh_area` VALUES ('2643','2637','绵竹市','0');
INSERT INTO `yzh_area` VALUES ('2644','2589','甘孜藏族自治州','0');
INSERT INTO `yzh_area` VALUES ('2645','2644','康定县','0');
INSERT INTO `yzh_area` VALUES ('2646','2644','泸定县','0');
INSERT INTO `yzh_area` VALUES ('2647','2644','丹巴县','0');
INSERT INTO `yzh_area` VALUES ('2648','2644','九龙县','0');
INSERT INTO `yzh_area` VALUES ('2649','2644','雅江县','0');
INSERT INTO `yzh_area` VALUES ('2650','2644','道孚县','0');
INSERT INTO `yzh_area` VALUES ('2651','2644','炉霍县','0');
INSERT INTO `yzh_area` VALUES ('2652','2644','甘孜县','0');
INSERT INTO `yzh_area` VALUES ('2653','2644','新龙县','0');
INSERT INTO `yzh_area` VALUES ('2654','2644','德格县','0');
INSERT INTO `yzh_area` VALUES ('2655','2644','白玉县','0');
INSERT INTO `yzh_area` VALUES ('2656','2644','石渠县','0');
INSERT INTO `yzh_area` VALUES ('2657','2644','色达县','0');
INSERT INTO `yzh_area` VALUES ('2658','2644','理塘县','0');
INSERT INTO `yzh_area` VALUES ('2659','2644','巴塘县','0');
INSERT INTO `yzh_area` VALUES ('2660','2644','乡城县','0');
INSERT INTO `yzh_area` VALUES ('2661','2644','稻城县','0');
INSERT INTO `yzh_area` VALUES ('2662','2644','得荣县','0');
INSERT INTO `yzh_area` VALUES ('2663','2589','广安市','0');
INSERT INTO `yzh_area` VALUES ('2664','2663','广安区','0');
INSERT INTO `yzh_area` VALUES ('2665','2663','岳池县','0');
INSERT INTO `yzh_area` VALUES ('2666','2663','武胜县','0');
INSERT INTO `yzh_area` VALUES ('2667','2663','邻水县','0');
INSERT INTO `yzh_area` VALUES ('2668','2663','华莹市','0');
INSERT INTO `yzh_area` VALUES ('2669','2589','广元市','0');
INSERT INTO `yzh_area` VALUES ('2670','2669','市中区','0');
INSERT INTO `yzh_area` VALUES ('2671','2669','元坝区','0');
INSERT INTO `yzh_area` VALUES ('2672','2669','朝天区','0');
INSERT INTO `yzh_area` VALUES ('2673','2669','旺苍县','0');
INSERT INTO `yzh_area` VALUES ('2674','2669','青川县','0');
INSERT INTO `yzh_area` VALUES ('2675','2669','剑阁县','0');
INSERT INTO `yzh_area` VALUES ('2676','2669','苍溪县','0');
INSERT INTO `yzh_area` VALUES ('2677','2589','乐山市','0');
INSERT INTO `yzh_area` VALUES ('2678','2677','市中区','0');
INSERT INTO `yzh_area` VALUES ('2679','2677','沙湾区','0');
INSERT INTO `yzh_area` VALUES ('2680','2677','五通桥区','0');
INSERT INTO `yzh_area` VALUES ('2681','2677','金口河区','0');
INSERT INTO `yzh_area` VALUES ('2682','2677','犍为县','0');
INSERT INTO `yzh_area` VALUES ('2683','2677','井研县','0');
INSERT INTO `yzh_area` VALUES ('2684','2677','夹江县','0');
INSERT INTO `yzh_area` VALUES ('2685','2677','沐川县','0');
INSERT INTO `yzh_area` VALUES ('2686','2677','峨边彝族自治县','0');
INSERT INTO `yzh_area` VALUES ('2687','2677','马边彝族自治县','0');
INSERT INTO `yzh_area` VALUES ('2688','2677','峨眉山市','0');
INSERT INTO `yzh_area` VALUES ('2689','2589','凉山彝族自治州','0');
INSERT INTO `yzh_area` VALUES ('2690','2689','西昌市','0');
INSERT INTO `yzh_area` VALUES ('2691','2689','木里藏族自治县','0');
INSERT INTO `yzh_area` VALUES ('2692','2689','盐源县','0');
INSERT INTO `yzh_area` VALUES ('2693','2689','德昌县','0');
INSERT INTO `yzh_area` VALUES ('2694','2689','会理县','0');
INSERT INTO `yzh_area` VALUES ('2695','2689','会东县','0');
INSERT INTO `yzh_area` VALUES ('2696','2689','宁南县','0');
INSERT INTO `yzh_area` VALUES ('2697','2689','普格县','0');
INSERT INTO `yzh_area` VALUES ('2698','2689','布拖县','0');
INSERT INTO `yzh_area` VALUES ('2699','2689','金阳县','0');
INSERT INTO `yzh_area` VALUES ('2700','2689','昭觉县','0');
INSERT INTO `yzh_area` VALUES ('2701','2689','喜德县','0');
INSERT INTO `yzh_area` VALUES ('2702','2689','冕宁县','0');
INSERT INTO `yzh_area` VALUES ('2703','2689','越西县','0');
INSERT INTO `yzh_area` VALUES ('2704','2689','甘洛县','0');
INSERT INTO `yzh_area` VALUES ('2705','2689','美姑县','0');
INSERT INTO `yzh_area` VALUES ('2706','2689','雷波县','0');
INSERT INTO `yzh_area` VALUES ('2707','2589','泸州市','0');
INSERT INTO `yzh_area` VALUES ('2708','2707','江阳区','0');
INSERT INTO `yzh_area` VALUES ('2709','2707','纳溪区','0');
INSERT INTO `yzh_area` VALUES ('2710','2707','龙马潭区','0');
INSERT INTO `yzh_area` VALUES ('2711','2707','泸县','0');
INSERT INTO `yzh_area` VALUES ('2712','2707','合江县','0');
INSERT INTO `yzh_area` VALUES ('2713','2707','叙永县','0');
INSERT INTO `yzh_area` VALUES ('2714','2707','古蔺县','0');
INSERT INTO `yzh_area` VALUES ('2715','2589','眉山市','0');
INSERT INTO `yzh_area` VALUES ('2716','2715','东坡区','0');
INSERT INTO `yzh_area` VALUES ('2717','2715','仁寿县','0');
INSERT INTO `yzh_area` VALUES ('2718','2715','彭山县','0');
INSERT INTO `yzh_area` VALUES ('2719','2715','洪雅县','0');
INSERT INTO `yzh_area` VALUES ('2720','2715','丹棱县','0');
INSERT INTO `yzh_area` VALUES ('2721','2715','青神县','0');
INSERT INTO `yzh_area` VALUES ('2722','2589','绵阳市','0');
INSERT INTO `yzh_area` VALUES ('2723','2722','涪城区','0');
INSERT INTO `yzh_area` VALUES ('2724','2722','游仙区','0');
INSERT INTO `yzh_area` VALUES ('2725','2722','三台县','0');
INSERT INTO `yzh_area` VALUES ('2726','2722','盐亭县','0');
INSERT INTO `yzh_area` VALUES ('2727','2722','安县','0');
INSERT INTO `yzh_area` VALUES ('2728','2722','梓潼县','0');
INSERT INTO `yzh_area` VALUES ('2729','2722','北川羌族自治县','0');
INSERT INTO `yzh_area` VALUES ('2730','2722','平武县','0');
INSERT INTO `yzh_area` VALUES ('2731','2722','江油市','0');
INSERT INTO `yzh_area` VALUES ('2732','2589','内江市','0');
INSERT INTO `yzh_area` VALUES ('2733','2732','市中区','0');
INSERT INTO `yzh_area` VALUES ('2734','2732','东兴区','0');
INSERT INTO `yzh_area` VALUES ('2735','2732','威远县','0');
INSERT INTO `yzh_area` VALUES ('2736','2732','资中县','0');
INSERT INTO `yzh_area` VALUES ('2737','2732','隆昌县','0');
INSERT INTO `yzh_area` VALUES ('2738','2589','南充市','0');
INSERT INTO `yzh_area` VALUES ('2739','2738','顺庆区','0');
INSERT INTO `yzh_area` VALUES ('2740','2738','高坪区','0');
INSERT INTO `yzh_area` VALUES ('2741','2738','嘉陵区','0');
INSERT INTO `yzh_area` VALUES ('2742','2738','南部县','0');
INSERT INTO `yzh_area` VALUES ('2743','2738','营山县','0');
INSERT INTO `yzh_area` VALUES ('2744','2738','蓬安县','0');
INSERT INTO `yzh_area` VALUES ('2745','2738','仪陇县','0');
INSERT INTO `yzh_area` VALUES ('2746','2738','西充县','0');
INSERT INTO `yzh_area` VALUES ('2747','2738','阆中市','0');
INSERT INTO `yzh_area` VALUES ('2748','2589','攀枝花市','0');
INSERT INTO `yzh_area` VALUES ('2749','2748','东区','0');
INSERT INTO `yzh_area` VALUES ('2750','2748','西区','0');
INSERT INTO `yzh_area` VALUES ('2751','2748','仁和区','0');
INSERT INTO `yzh_area` VALUES ('2752','2748','米易县','0');
INSERT INTO `yzh_area` VALUES ('2753','2748','盐边县','0');
INSERT INTO `yzh_area` VALUES ('2754','2589','遂宁市','0');
INSERT INTO `yzh_area` VALUES ('2755','2754','船山区','0');
INSERT INTO `yzh_area` VALUES ('2756','2754','安居区','0');
INSERT INTO `yzh_area` VALUES ('2757','2754','蓬溪县','0');
INSERT INTO `yzh_area` VALUES ('2758','2754','射洪县','0');
INSERT INTO `yzh_area` VALUES ('2759','2754','大英县','0');
INSERT INTO `yzh_area` VALUES ('2760','2589','雅安市','0');
INSERT INTO `yzh_area` VALUES ('2761','2760','雨城区','0');
INSERT INTO `yzh_area` VALUES ('2762','2760','名山县','0');
INSERT INTO `yzh_area` VALUES ('2763','2760','荥经县','0');
INSERT INTO `yzh_area` VALUES ('2764','2760','汉源县','0');
INSERT INTO `yzh_area` VALUES ('2765','2760','石棉县','0');
INSERT INTO `yzh_area` VALUES ('2766','2760','天全县','0');
INSERT INTO `yzh_area` VALUES ('2767','2760','芦山县','0');
INSERT INTO `yzh_area` VALUES ('2768','2760','宝兴县','0');
INSERT INTO `yzh_area` VALUES ('2769','2589','宜宾市','0');
INSERT INTO `yzh_area` VALUES ('2770','2769','翠屏区','0');
INSERT INTO `yzh_area` VALUES ('2771','2769','宜宾县','0');
INSERT INTO `yzh_area` VALUES ('2772','2769','南溪县','0');
INSERT INTO `yzh_area` VALUES ('2773','2769','江安县','0');
INSERT INTO `yzh_area` VALUES ('2774','2769','长宁县','0');
INSERT INTO `yzh_area` VALUES ('2775','2769','高县','0');
INSERT INTO `yzh_area` VALUES ('2776','2769','珙县','0');
INSERT INTO `yzh_area` VALUES ('2777','2769','筠连县','0');
INSERT INTO `yzh_area` VALUES ('2778','2769','兴文县','0');
INSERT INTO `yzh_area` VALUES ('2779','2769','屏山县','0');
INSERT INTO `yzh_area` VALUES ('2780','2589','资阳市','0');
INSERT INTO `yzh_area` VALUES ('2781','2780','雁江区','0');
INSERT INTO `yzh_area` VALUES ('2782','2780','安岳县','0');
INSERT INTO `yzh_area` VALUES ('2783','2780','乐至县','0');
INSERT INTO `yzh_area` VALUES ('2784','2780','简阳市','0');
INSERT INTO `yzh_area` VALUES ('2785','2589','自贡市','0');
INSERT INTO `yzh_area` VALUES ('2786','2785','自流井区','0');
INSERT INTO `yzh_area` VALUES ('2787','2785','贡井区','0');
INSERT INTO `yzh_area` VALUES ('2788','2785','大安区','0');
INSERT INTO `yzh_area` VALUES ('2789','2785','沿滩区','0');
INSERT INTO `yzh_area` VALUES ('2790','2785','荣县','0');
INSERT INTO `yzh_area` VALUES ('2791','2785','富顺县','0');
INSERT INTO `yzh_area` VALUES ('2792','0','西藏','0');
INSERT INTO `yzh_area` VALUES ('2793','2792','拉萨市','0');
INSERT INTO `yzh_area` VALUES ('2794','2793','城关区','0');
INSERT INTO `yzh_area` VALUES ('2795','2793','林周县','0');
INSERT INTO `yzh_area` VALUES ('2796','2793','当雄县','0');
INSERT INTO `yzh_area` VALUES ('2797','2793','尼木县','0');
INSERT INTO `yzh_area` VALUES ('2798','2793','曲水县','0');
INSERT INTO `yzh_area` VALUES ('2799','2793','堆龙德庆县','0');
INSERT INTO `yzh_area` VALUES ('2800','2793','达孜县','0');
INSERT INTO `yzh_area` VALUES ('2801','2793','墨竹工卡县','0');
INSERT INTO `yzh_area` VALUES ('2802','2792','阿里地区','0');
INSERT INTO `yzh_area` VALUES ('2803','2802','普兰县','0');
INSERT INTO `yzh_area` VALUES ('2804','2802','札达县','0');
INSERT INTO `yzh_area` VALUES ('2805','2802','噶尔县','0');
INSERT INTO `yzh_area` VALUES ('2806','2802','日土县','0');
INSERT INTO `yzh_area` VALUES ('2807','2802','革吉县','0');
INSERT INTO `yzh_area` VALUES ('2808','2802','改则县','0');
INSERT INTO `yzh_area` VALUES ('2809','2802','措勤县','0');
INSERT INTO `yzh_area` VALUES ('2810','2792','昌都地区','0');
INSERT INTO `yzh_area` VALUES ('2811','2810','昌都县','0');
INSERT INTO `yzh_area` VALUES ('2812','2810','江达县','0');
INSERT INTO `yzh_area` VALUES ('2813','2810','贡觉县','0');
INSERT INTO `yzh_area` VALUES ('2814','2810','类乌齐县','0');
INSERT INTO `yzh_area` VALUES ('2815','2810','丁青县','0');
INSERT INTO `yzh_area` VALUES ('2816','2810','察雅县','0');
INSERT INTO `yzh_area` VALUES ('2817','2810','八宿县','0');
INSERT INTO `yzh_area` VALUES ('2818','2810','左贡县','0');
INSERT INTO `yzh_area` VALUES ('2819','2810','芒康县','0');
INSERT INTO `yzh_area` VALUES ('2820','2810','洛隆县','0');
INSERT INTO `yzh_area` VALUES ('2821','2810','边坝县','0');
INSERT INTO `yzh_area` VALUES ('2822','2792','林芝地区','0');
INSERT INTO `yzh_area` VALUES ('2823','2822','林芝县','0');
INSERT INTO `yzh_area` VALUES ('2824','2822','工布江达县','0');
INSERT INTO `yzh_area` VALUES ('2825','2822','米林县','0');
INSERT INTO `yzh_area` VALUES ('2826','2822','墨脱县','0');
INSERT INTO `yzh_area` VALUES ('2827','2822','波密县','0');
INSERT INTO `yzh_area` VALUES ('2828','2822','察隅县','0');
INSERT INTO `yzh_area` VALUES ('2829','2822','朗县','0');
INSERT INTO `yzh_area` VALUES ('2830','2792','那曲地区','0');
INSERT INTO `yzh_area` VALUES ('2831','2830','那曲县','0');
INSERT INTO `yzh_area` VALUES ('2832','2830','嘉黎县','0');
INSERT INTO `yzh_area` VALUES ('2833','2830','比如县','0');
INSERT INTO `yzh_area` VALUES ('2834','2830','聂荣县','0');
INSERT INTO `yzh_area` VALUES ('2835','2830','安多县','0');
INSERT INTO `yzh_area` VALUES ('2836','2830','申扎县','0');
INSERT INTO `yzh_area` VALUES ('2837','2830','索县','0');
INSERT INTO `yzh_area` VALUES ('2838','2830','班戈县','0');
INSERT INTO `yzh_area` VALUES ('2839','2830','巴青县','0');
INSERT INTO `yzh_area` VALUES ('2840','2830','尼玛县','0');
INSERT INTO `yzh_area` VALUES ('2841','2792','日喀则地区','0');
INSERT INTO `yzh_area` VALUES ('2842','2841','日喀则市','0');
INSERT INTO `yzh_area` VALUES ('2843','2841','南木林县','0');
INSERT INTO `yzh_area` VALUES ('2844','2841','江孜县','0');
INSERT INTO `yzh_area` VALUES ('2845','2841','定日县','0');
INSERT INTO `yzh_area` VALUES ('2846','2841','萨迦县','0');
INSERT INTO `yzh_area` VALUES ('2847','2841','拉孜县','0');
INSERT INTO `yzh_area` VALUES ('2848','2841','昂仁县','0');
INSERT INTO `yzh_area` VALUES ('2849','2841','谢通门县','0');
INSERT INTO `yzh_area` VALUES ('2850','2841','白朗县','0');
INSERT INTO `yzh_area` VALUES ('2851','2841','仁布县','0');
INSERT INTO `yzh_area` VALUES ('2852','2841','康马县','0');
INSERT INTO `yzh_area` VALUES ('2853','2841','定结县','0');
INSERT INTO `yzh_area` VALUES ('2854','2841','仲巴县','0');
INSERT INTO `yzh_area` VALUES ('2855','2841','亚东县','0');
INSERT INTO `yzh_area` VALUES ('2856','2841','吉隆县','0');
INSERT INTO `yzh_area` VALUES ('2857','2841','聂拉木县','0');
INSERT INTO `yzh_area` VALUES ('2858','2841','萨嘎县','0');
INSERT INTO `yzh_area` VALUES ('2859','2841','岗巴县','0');
INSERT INTO `yzh_area` VALUES ('2860','2792','山南地区','0');
INSERT INTO `yzh_area` VALUES ('2861','2860','乃东县','0');
INSERT INTO `yzh_area` VALUES ('2862','2860','扎囊县','0');
INSERT INTO `yzh_area` VALUES ('2863','2860','贡嘎县','0');
INSERT INTO `yzh_area` VALUES ('2864','2860','桑日县','0');
INSERT INTO `yzh_area` VALUES ('2865','2860','琼结县','0');
INSERT INTO `yzh_area` VALUES ('2866','2860','曲松县','0');
INSERT INTO `yzh_area` VALUES ('2867','2860','措美县','0');
INSERT INTO `yzh_area` VALUES ('2868','2860','洛扎县','0');
INSERT INTO `yzh_area` VALUES ('2869','2860','加查县','0');
INSERT INTO `yzh_area` VALUES ('2870','2860','隆子县','0');
INSERT INTO `yzh_area` VALUES ('2871','2860','错那县','0');
INSERT INTO `yzh_area` VALUES ('2872','2860','浪卡子县','0');
INSERT INTO `yzh_area` VALUES ('2873','0','新疆','0');
INSERT INTO `yzh_area` VALUES ('2874','2873','乌鲁木齐市','0');
INSERT INTO `yzh_area` VALUES ('2875','2874','天山区','0');
INSERT INTO `yzh_area` VALUES ('2876','2874','沙依巴克区','0');
INSERT INTO `yzh_area` VALUES ('2877','2874','新市区','0');
INSERT INTO `yzh_area` VALUES ('2878','2874','水磨沟区','0');
INSERT INTO `yzh_area` VALUES ('2879','2874','头屯河区','0');
INSERT INTO `yzh_area` VALUES ('2880','2874','达坂城区','0');
INSERT INTO `yzh_area` VALUES ('2881','2874','东山区','0');
INSERT INTO `yzh_area` VALUES ('2882','2874','乌鲁木齐县','0');
INSERT INTO `yzh_area` VALUES ('2883','2873','阿克苏地区','0');
INSERT INTO `yzh_area` VALUES ('2884','2883','阿克苏市','0');
INSERT INTO `yzh_area` VALUES ('2885','2883','温宿县','0');
INSERT INTO `yzh_area` VALUES ('2886','2883','库车县','0');
INSERT INTO `yzh_area` VALUES ('2887','2883','沙雅县','0');
INSERT INTO `yzh_area` VALUES ('2888','2883','新和县','0');
INSERT INTO `yzh_area` VALUES ('2889','2883','拜城县','0');
INSERT INTO `yzh_area` VALUES ('2890','2883','乌什县','0');
INSERT INTO `yzh_area` VALUES ('2891','2883','阿瓦提县','0');
INSERT INTO `yzh_area` VALUES ('2892','2883','柯坪县','0');
INSERT INTO `yzh_area` VALUES ('2893','2873','阿拉尔市','0');
INSERT INTO `yzh_area` VALUES ('2894','2873','阿勒泰地区','0');
INSERT INTO `yzh_area` VALUES ('2895','2894','阿勒泰市','0');
INSERT INTO `yzh_area` VALUES ('2896','2894','布尔津县','0');
INSERT INTO `yzh_area` VALUES ('2897','2894','富蕴县','0');
INSERT INTO `yzh_area` VALUES ('2898','2894','福海县','0');
INSERT INTO `yzh_area` VALUES ('2899','2894','哈巴河县','0');
INSERT INTO `yzh_area` VALUES ('2900','2894','青河县','0');
INSERT INTO `yzh_area` VALUES ('2901','2894','吉木乃县','0');
INSERT INTO `yzh_area` VALUES ('2902','2873','巴音郭楞蒙古自治州','0');
INSERT INTO `yzh_area` VALUES ('2903','2902','库尔勒市','0');
INSERT INTO `yzh_area` VALUES ('2904','2902','轮台县','0');
INSERT INTO `yzh_area` VALUES ('2905','2902','尉犁县','0');
INSERT INTO `yzh_area` VALUES ('2906','2902','若羌县','0');
INSERT INTO `yzh_area` VALUES ('2907','2902','且末县','0');
INSERT INTO `yzh_area` VALUES ('2908','2902','焉耆回族自治县','0');
INSERT INTO `yzh_area` VALUES ('2909','2902','和静县','0');
INSERT INTO `yzh_area` VALUES ('2910','2902','和硕县','0');
INSERT INTO `yzh_area` VALUES ('2911','2902','博湖县','0');
INSERT INTO `yzh_area` VALUES ('2912','2873','博尔塔拉蒙古自治州','0');
INSERT INTO `yzh_area` VALUES ('2913','2912','博乐市','0');
INSERT INTO `yzh_area` VALUES ('2914','2912','精河县','0');
INSERT INTO `yzh_area` VALUES ('2915','2912','温泉县','0');
INSERT INTO `yzh_area` VALUES ('2916','2873','昌吉回族自治州','0');
INSERT INTO `yzh_area` VALUES ('2917','2916','昌吉市','0');
INSERT INTO `yzh_area` VALUES ('2918','2916','阜康市','0');
INSERT INTO `yzh_area` VALUES ('2919','2916','米泉市','0');
INSERT INTO `yzh_area` VALUES ('2920','2916','呼图壁县','0');
INSERT INTO `yzh_area` VALUES ('2921','2916','玛纳斯县','0');
INSERT INTO `yzh_area` VALUES ('2922','2916','奇台县','0');
INSERT INTO `yzh_area` VALUES ('2923','2916','吉木萨尔县','0');
INSERT INTO `yzh_area` VALUES ('2924','2916','木垒哈萨克自治县','0');
INSERT INTO `yzh_area` VALUES ('2925','2873','哈密地区','0');
INSERT INTO `yzh_area` VALUES ('2926','2925','哈密市','0');
INSERT INTO `yzh_area` VALUES ('2927','2925','巴里坤哈萨克自治县','0');
INSERT INTO `yzh_area` VALUES ('2928','2925','伊吾县','0');
INSERT INTO `yzh_area` VALUES ('2929','2873','和田地区','0');
INSERT INTO `yzh_area` VALUES ('2930','2929','和田市','0');
INSERT INTO `yzh_area` VALUES ('2931','2929','和田县','0');
INSERT INTO `yzh_area` VALUES ('2932','2929','墨玉县','0');
INSERT INTO `yzh_area` VALUES ('2933','2929','皮山县','0');
INSERT INTO `yzh_area` VALUES ('2934','2929','洛浦县','0');
INSERT INTO `yzh_area` VALUES ('2935','2929','策勒县','0');
INSERT INTO `yzh_area` VALUES ('2936','2929','于田县','0');
INSERT INTO `yzh_area` VALUES ('2937','2929','民丰县','0');
INSERT INTO `yzh_area` VALUES ('2938','2873','喀什地区','0');
INSERT INTO `yzh_area` VALUES ('2939','2938','喀什市','0');
INSERT INTO `yzh_area` VALUES ('2940','2938','疏附县','0');
INSERT INTO `yzh_area` VALUES ('2941','2938','疏勒县','0');
INSERT INTO `yzh_area` VALUES ('2942','2938','英吉沙县','0');
INSERT INTO `yzh_area` VALUES ('2943','2938','泽普县','0');
INSERT INTO `yzh_area` VALUES ('2944','2938','莎车县','0');
INSERT INTO `yzh_area` VALUES ('2945','2938','叶城县','0');
INSERT INTO `yzh_area` VALUES ('2946','2938','麦盖提县','0');
INSERT INTO `yzh_area` VALUES ('2947','2938','岳普湖县','0');
INSERT INTO `yzh_area` VALUES ('2948','2938','伽师县','0');
INSERT INTO `yzh_area` VALUES ('2949','2938','巴楚县','0');
INSERT INTO `yzh_area` VALUES ('2950','2938','塔什库尔干塔吉克自治县','0');
INSERT INTO `yzh_area` VALUES ('2951','2873','克拉玛依市','0');
INSERT INTO `yzh_area` VALUES ('2952','2951','独山子区','0');
INSERT INTO `yzh_area` VALUES ('2953','2951','克拉玛依区','0');
INSERT INTO `yzh_area` VALUES ('2954','2951','白碱滩区','0');
INSERT INTO `yzh_area` VALUES ('2955','2951','乌尔禾区','0');
INSERT INTO `yzh_area` VALUES ('2956','2873','克孜勒苏柯尔克孜自治州','0');
INSERT INTO `yzh_area` VALUES ('2957','2956','阿图什市','0');
INSERT INTO `yzh_area` VALUES ('2958','2956','阿克陶县','0');
INSERT INTO `yzh_area` VALUES ('2959','2956','阿合奇县','0');
INSERT INTO `yzh_area` VALUES ('2960','2956','乌恰县','0');
INSERT INTO `yzh_area` VALUES ('2961','2873','石河子市','0');
INSERT INTO `yzh_area` VALUES ('2962','2873','塔城地区','0');
INSERT INTO `yzh_area` VALUES ('2963','2962','塔城市','0');
INSERT INTO `yzh_area` VALUES ('2964','2962','乌苏市','0');
INSERT INTO `yzh_area` VALUES ('2965','2962','额敏县','0');
INSERT INTO `yzh_area` VALUES ('2966','2962','沙湾县','0');
INSERT INTO `yzh_area` VALUES ('2967','2962','托里县','0');
INSERT INTO `yzh_area` VALUES ('2968','2962','裕民县','0');
INSERT INTO `yzh_area` VALUES ('2969','2962','和布克赛尔蒙古自治县','0');
INSERT INTO `yzh_area` VALUES ('2970','2873','图木舒克市','0');
INSERT INTO `yzh_area` VALUES ('2971','2873','吐鲁番地区','0');
INSERT INTO `yzh_area` VALUES ('2972','2971','吐鲁番市','0');
INSERT INTO `yzh_area` VALUES ('2973','2971','鄯善县','0');
INSERT INTO `yzh_area` VALUES ('2974','2971','托克逊县','0');
INSERT INTO `yzh_area` VALUES ('2975','2873','五家渠市','0');
INSERT INTO `yzh_area` VALUES ('2976','2873','伊犁哈萨克自治州','0');
INSERT INTO `yzh_area` VALUES ('2977','2976','伊宁市','0');
INSERT INTO `yzh_area` VALUES ('2978','2976','奎屯市','0');
INSERT INTO `yzh_area` VALUES ('2979','2976','伊宁县','0');
INSERT INTO `yzh_area` VALUES ('2980','2976','察布查尔锡伯自治县','0');
INSERT INTO `yzh_area` VALUES ('2981','2976','霍城县','0');
INSERT INTO `yzh_area` VALUES ('2982','2976','巩留县','0');
INSERT INTO `yzh_area` VALUES ('2983','2976','新源县','0');
INSERT INTO `yzh_area` VALUES ('2984','2976','昭苏县','0');
INSERT INTO `yzh_area` VALUES ('2985','2976','特克斯县','0');
INSERT INTO `yzh_area` VALUES ('2986','2976','尼勒克县','0');
INSERT INTO `yzh_area` VALUES ('2987','0','云南','0');
INSERT INTO `yzh_area` VALUES ('2988','2987','昆明市','0');
INSERT INTO `yzh_area` VALUES ('2989','2988','五华区','0');
INSERT INTO `yzh_area` VALUES ('2990','2988','盘龙区','0');
INSERT INTO `yzh_area` VALUES ('2991','2988','官渡区','0');
INSERT INTO `yzh_area` VALUES ('2992','2988','西山区','0');
INSERT INTO `yzh_area` VALUES ('2993','2988','东川区','0');
INSERT INTO `yzh_area` VALUES ('2994','2988','呈贡县','0');
INSERT INTO `yzh_area` VALUES ('2995','2988','晋宁县','0');
INSERT INTO `yzh_area` VALUES ('2996','2988','富民县','0');
INSERT INTO `yzh_area` VALUES ('2997','2988','宜良县','0');
INSERT INTO `yzh_area` VALUES ('2998','2988','石林彝族自治县','0');
INSERT INTO `yzh_area` VALUES ('2999','2988','嵩明县','0');
INSERT INTO `yzh_area` VALUES ('3000','2988','禄劝彝族苗族自治县','0');
INSERT INTO `yzh_area` VALUES ('3001','2988','寻甸回族彝族自治县','0');
INSERT INTO `yzh_area` VALUES ('3002','2988','安宁市','0');
INSERT INTO `yzh_area` VALUES ('3003','2987','保山市','0');
INSERT INTO `yzh_area` VALUES ('3004','3003','隆阳区','0');
INSERT INTO `yzh_area` VALUES ('3005','3003','施甸县','0');
INSERT INTO `yzh_area` VALUES ('3006','3003','腾冲县','0');
INSERT INTO `yzh_area` VALUES ('3007','3003','龙陵县','0');
INSERT INTO `yzh_area` VALUES ('3008','3003','昌宁县','0');
INSERT INTO `yzh_area` VALUES ('3009','2987','楚雄彝族自治州','0');
INSERT INTO `yzh_area` VALUES ('3010','3009','楚雄市','0');
INSERT INTO `yzh_area` VALUES ('3011','3009','双柏县','0');
INSERT INTO `yzh_area` VALUES ('3012','3009','牟定县','0');
INSERT INTO `yzh_area` VALUES ('3013','3009','南华县','0');
INSERT INTO `yzh_area` VALUES ('3014','3009','姚安县','0');
INSERT INTO `yzh_area` VALUES ('3015','3009','大姚县','0');
INSERT INTO `yzh_area` VALUES ('3016','3009','永仁县','0');
INSERT INTO `yzh_area` VALUES ('3017','3009','元谋县','0');
INSERT INTO `yzh_area` VALUES ('3018','3009','武定县','0');
INSERT INTO `yzh_area` VALUES ('3019','3009','禄丰县','0');
INSERT INTO `yzh_area` VALUES ('3020','2987','大理白族自治州','0');
INSERT INTO `yzh_area` VALUES ('3021','3020','大理市','0');
INSERT INTO `yzh_area` VALUES ('3022','3020','漾濞彝族自治县','0');
INSERT INTO `yzh_area` VALUES ('3023','3020','祥云县','0');
INSERT INTO `yzh_area` VALUES ('3024','3020','宾川县','0');
INSERT INTO `yzh_area` VALUES ('3025','3020','弥渡县','0');
INSERT INTO `yzh_area` VALUES ('3026','3020','南涧彝族自治县','0');
INSERT INTO `yzh_area` VALUES ('3027','3020','巍山彝族回族自治县','0');
INSERT INTO `yzh_area` VALUES ('3028','3020','永平县','0');
INSERT INTO `yzh_area` VALUES ('3029','3020','云龙县','0');
INSERT INTO `yzh_area` VALUES ('3030','3020','洱源县','0');
INSERT INTO `yzh_area` VALUES ('3031','3020','剑川县','0');
INSERT INTO `yzh_area` VALUES ('3032','3020','鹤庆县','0');
INSERT INTO `yzh_area` VALUES ('3033','2987','德宏傣族景颇族自治州','0');
INSERT INTO `yzh_area` VALUES ('3034','3033','瑞丽市','0');
INSERT INTO `yzh_area` VALUES ('3035','3033','潞西市','0');
INSERT INTO `yzh_area` VALUES ('3036','3033','梁河县','0');
INSERT INTO `yzh_area` VALUES ('3037','3033','盈江县','0');
INSERT INTO `yzh_area` VALUES ('3038','3033','陇川县','0');
INSERT INTO `yzh_area` VALUES ('3039','2987','迪庆藏族自治州','0');
INSERT INTO `yzh_area` VALUES ('3040','3039','香格里拉县','0');
INSERT INTO `yzh_area` VALUES ('3041','3039','德钦县','0');
INSERT INTO `yzh_area` VALUES ('3042','3039','维西傈僳族自治县','0');
INSERT INTO `yzh_area` VALUES ('3043','2987','红河哈尼族彝族自治州','0');
INSERT INTO `yzh_area` VALUES ('3044','3043','个旧市','0');
INSERT INTO `yzh_area` VALUES ('3045','3043','开远市','0');
INSERT INTO `yzh_area` VALUES ('3046','3043','蒙自县','0');
INSERT INTO `yzh_area` VALUES ('3047','3043','屏边苗族自治县','0');
INSERT INTO `yzh_area` VALUES ('3048','3043','建水县','0');
INSERT INTO `yzh_area` VALUES ('3049','3043','石屏县','0');
INSERT INTO `yzh_area` VALUES ('3050','3043','弥勒县','0');
INSERT INTO `yzh_area` VALUES ('3051','3043','泸西县','0');
INSERT INTO `yzh_area` VALUES ('3052','3043','元阳县','0');
INSERT INTO `yzh_area` VALUES ('3053','3043','红河县','0');
INSERT INTO `yzh_area` VALUES ('3054','3043','金平苗族瑶族傣族自治县','0');
INSERT INTO `yzh_area` VALUES ('3055','3043','绿春县','0');
INSERT INTO `yzh_area` VALUES ('3056','3043','河口瑶族自治县','0');
INSERT INTO `yzh_area` VALUES ('3057','2987','丽江市','0');
INSERT INTO `yzh_area` VALUES ('3058','3057','古城区','0');
INSERT INTO `yzh_area` VALUES ('3059','3057','玉龙纳西族自治县','0');
INSERT INTO `yzh_area` VALUES ('3060','3057','永胜县','0');
INSERT INTO `yzh_area` VALUES ('3061','3057','华坪县','0');
INSERT INTO `yzh_area` VALUES ('3062','3057','宁蒗彝族自治县','0');
INSERT INTO `yzh_area` VALUES ('3063','2987','临沧市','0');
INSERT INTO `yzh_area` VALUES ('3064','3063','临翔区','0');
INSERT INTO `yzh_area` VALUES ('3065','3063','凤庆县','0');
INSERT INTO `yzh_area` VALUES ('3066','3063','云县','0');
INSERT INTO `yzh_area` VALUES ('3067','3063','永德县','0');
INSERT INTO `yzh_area` VALUES ('3068','3063','镇康县','0');
INSERT INTO `yzh_area` VALUES ('3069','3063','双江拉祜族佤族布朗族傣族自治县','0');
INSERT INTO `yzh_area` VALUES ('3070','3063','耿马傣族佤族自治县','0');
INSERT INTO `yzh_area` VALUES ('3071','3063','沧源佤族自治县','0');
INSERT INTO `yzh_area` VALUES ('3072','2987','怒江傈僳族自治州','0');
INSERT INTO `yzh_area` VALUES ('3073','3072','泸水县','0');
INSERT INTO `yzh_area` VALUES ('3074','3072','福贡县','0');
INSERT INTO `yzh_area` VALUES ('3075','3072','贡山独龙族怒族自治县','0');
INSERT INTO `yzh_area` VALUES ('3076','3072','兰坪白族普米族自治县','0');
INSERT INTO `yzh_area` VALUES ('3077','2987','曲靖市','0');
INSERT INTO `yzh_area` VALUES ('3078','3077','麒麟区','0');
INSERT INTO `yzh_area` VALUES ('3079','3077','马龙县','0');
INSERT INTO `yzh_area` VALUES ('3080','3077','陆良县','0');
INSERT INTO `yzh_area` VALUES ('3081','3077','师宗县','0');
INSERT INTO `yzh_area` VALUES ('3082','3077','罗平县','0');
INSERT INTO `yzh_area` VALUES ('3083','3077','富源县','0');
INSERT INTO `yzh_area` VALUES ('3084','3077','会泽县','0');
INSERT INTO `yzh_area` VALUES ('3085','3077','沾益县','0');
INSERT INTO `yzh_area` VALUES ('3086','3077','宣威市','0');
INSERT INTO `yzh_area` VALUES ('3087','2987','思茅市','0');
INSERT INTO `yzh_area` VALUES ('3088','3087','翠云区','0');
INSERT INTO `yzh_area` VALUES ('3089','3087','普洱哈尼族彝族自治县','0');
INSERT INTO `yzh_area` VALUES ('3090','3087','墨江哈尼族自治县','0');
INSERT INTO `yzh_area` VALUES ('3091','3087','景东彝族自治县','0');
INSERT INTO `yzh_area` VALUES ('3092','3087','景谷傣族彝族自治县','0');
INSERT INTO `yzh_area` VALUES ('3093','3087','镇沅彝族哈尼族拉祜族自治县','0');
INSERT INTO `yzh_area` VALUES ('3094','3087','江城哈尼族彝族自治县','0');
INSERT INTO `yzh_area` VALUES ('3095','3087','孟连傣族拉祜族佤族自治县','0');
INSERT INTO `yzh_area` VALUES ('3096','3087','澜沧拉祜族自治县','0');
INSERT INTO `yzh_area` VALUES ('3097','3087','西盟佤族自治县','0');
INSERT INTO `yzh_area` VALUES ('3098','2987','文山壮族苗族自治州','0');
INSERT INTO `yzh_area` VALUES ('3099','3098','文山县','0');
INSERT INTO `yzh_area` VALUES ('3100','3098','砚山县','0');
INSERT INTO `yzh_area` VALUES ('3101','3098','西畴县','0');
INSERT INTO `yzh_area` VALUES ('3102','3098','麻栗坡县','0');
INSERT INTO `yzh_area` VALUES ('3103','3098','马关县','0');
INSERT INTO `yzh_area` VALUES ('3104','3098','丘北县','0');
INSERT INTO `yzh_area` VALUES ('3105','3098','广南县','0');
INSERT INTO `yzh_area` VALUES ('3106','3098','富宁县','0');
INSERT INTO `yzh_area` VALUES ('3107','2987','西双版纳傣族自治州','0');
INSERT INTO `yzh_area` VALUES ('3108','3107','景洪市','0');
INSERT INTO `yzh_area` VALUES ('3109','3107','勐海县','0');
INSERT INTO `yzh_area` VALUES ('3110','3107','勐腊县','0');
INSERT INTO `yzh_area` VALUES ('3111','2987','玉溪市','0');
INSERT INTO `yzh_area` VALUES ('3112','3111','红塔区','0');
INSERT INTO `yzh_area` VALUES ('3113','3111','江川县','0');
INSERT INTO `yzh_area` VALUES ('3114','3111','澄江县','0');
INSERT INTO `yzh_area` VALUES ('3115','3111','通海县','0');
INSERT INTO `yzh_area` VALUES ('3116','3111','华宁县','0');
INSERT INTO `yzh_area` VALUES ('3117','3111','易门县','0');
INSERT INTO `yzh_area` VALUES ('3118','3111','峨山彝族自治县','0');
INSERT INTO `yzh_area` VALUES ('3119','3111','新平彝族傣族自治县','0');
INSERT INTO `yzh_area` VALUES ('3120','3111','元江哈尼族彝族傣族自治县','0');
INSERT INTO `yzh_area` VALUES ('3121','2987','昭通市','0');
INSERT INTO `yzh_area` VALUES ('3122','3121','昭阳区','0');
INSERT INTO `yzh_area` VALUES ('3123','3121','鲁甸县','0');
INSERT INTO `yzh_area` VALUES ('3124','3121','巧家县','0');
INSERT INTO `yzh_area` VALUES ('3125','3121','盐津县','0');
INSERT INTO `yzh_area` VALUES ('3126','3121','大关县','0');
INSERT INTO `yzh_area` VALUES ('3127','3121','永善县','0');
INSERT INTO `yzh_area` VALUES ('3128','3121','绥江县','0');
INSERT INTO `yzh_area` VALUES ('3129','3121','镇雄县','0');
INSERT INTO `yzh_area` VALUES ('3130','3121','彝良县','0');
INSERT INTO `yzh_area` VALUES ('3131','3121','威信县','0');
INSERT INTO `yzh_area` VALUES ('3132','3121','水富县','0');
INSERT INTO `yzh_area` VALUES ('3133','0','浙江','0');
INSERT INTO `yzh_area` VALUES ('3134','3133','杭州市','0');
INSERT INTO `yzh_area` VALUES ('3135','3134','上城区','0');
INSERT INTO `yzh_area` VALUES ('3136','3134','下城区','0');
INSERT INTO `yzh_area` VALUES ('3137','3134','江干区','0');
INSERT INTO `yzh_area` VALUES ('3138','3134','拱墅区','0');
INSERT INTO `yzh_area` VALUES ('3139','3134','西湖区','0');
INSERT INTO `yzh_area` VALUES ('3140','3134','滨江区','0');
INSERT INTO `yzh_area` VALUES ('3141','3134','萧山区','0');
INSERT INTO `yzh_area` VALUES ('3142','3134','余杭区','0');
INSERT INTO `yzh_area` VALUES ('3143','3134','桐庐县','0');
INSERT INTO `yzh_area` VALUES ('3144','3134','淳安县','0');
INSERT INTO `yzh_area` VALUES ('3145','3134','建德市','0');
INSERT INTO `yzh_area` VALUES ('3146','3134','富阳市','0');
INSERT INTO `yzh_area` VALUES ('3147','3134','临安市','0');
INSERT INTO `yzh_area` VALUES ('3148','3133','湖州市','0');
INSERT INTO `yzh_area` VALUES ('3149','3148','吴兴区','0');
INSERT INTO `yzh_area` VALUES ('3150','3148','南浔区','0');
INSERT INTO `yzh_area` VALUES ('3151','3148','德清县','0');
INSERT INTO `yzh_area` VALUES ('3152','3148','长兴县','0');
INSERT INTO `yzh_area` VALUES ('3153','3148','安吉县','0');
INSERT INTO `yzh_area` VALUES ('3154','3133','嘉兴市','0');
INSERT INTO `yzh_area` VALUES ('3155','3154','秀城区','0');
INSERT INTO `yzh_area` VALUES ('3156','3154','秀洲区','0');
INSERT INTO `yzh_area` VALUES ('3157','3154','嘉善县','0');
INSERT INTO `yzh_area` VALUES ('3158','3154','海盐县','0');
INSERT INTO `yzh_area` VALUES ('3159','3154','海宁市','0');
INSERT INTO `yzh_area` VALUES ('3160','3154','平湖市','0');
INSERT INTO `yzh_area` VALUES ('3161','3154','桐乡市','0');
INSERT INTO `yzh_area` VALUES ('3162','3133','金华市','0');
INSERT INTO `yzh_area` VALUES ('3163','3162','婺城区','0');
INSERT INTO `yzh_area` VALUES ('3164','3162','金东区','0');
INSERT INTO `yzh_area` VALUES ('3165','3162','武义县','0');
INSERT INTO `yzh_area` VALUES ('3166','3162','浦江县','0');
INSERT INTO `yzh_area` VALUES ('3167','3162','磐安县','0');
INSERT INTO `yzh_area` VALUES ('3168','3162','兰溪市','0');
INSERT INTO `yzh_area` VALUES ('3169','3162','义乌市','0');
INSERT INTO `yzh_area` VALUES ('3170','3162','东阳市','0');
INSERT INTO `yzh_area` VALUES ('3171','3162','永康市','0');
INSERT INTO `yzh_area` VALUES ('3172','3133','丽水市','0');
INSERT INTO `yzh_area` VALUES ('3173','3172','莲都区','0');
INSERT INTO `yzh_area` VALUES ('3174','3172','青田县','0');
INSERT INTO `yzh_area` VALUES ('3175','3172','缙云县','0');
INSERT INTO `yzh_area` VALUES ('3176','3172','遂昌县','0');
INSERT INTO `yzh_area` VALUES ('3177','3172','松阳县','0');
INSERT INTO `yzh_area` VALUES ('3178','3172','云和县','0');
INSERT INTO `yzh_area` VALUES ('3179','3172','庆元县','0');
INSERT INTO `yzh_area` VALUES ('3180','3172','景宁畲族自治县','0');
INSERT INTO `yzh_area` VALUES ('3181','3172','龙泉市','0');
INSERT INTO `yzh_area` VALUES ('3182','3133','宁波市','0');
INSERT INTO `yzh_area` VALUES ('3183','3182','海曙区','0');
INSERT INTO `yzh_area` VALUES ('3184','3182','江东区','0');
INSERT INTO `yzh_area` VALUES ('3185','3182','江北区','0');
INSERT INTO `yzh_area` VALUES ('3186','3182','北仑区','0');
INSERT INTO `yzh_area` VALUES ('3187','3182','镇海区','0');
INSERT INTO `yzh_area` VALUES ('3188','3182','鄞州区','0');
INSERT INTO `yzh_area` VALUES ('3189','3182','象山县','0');
INSERT INTO `yzh_area` VALUES ('3190','3182','宁海县','0');
INSERT INTO `yzh_area` VALUES ('3191','3182','余姚市','0');
INSERT INTO `yzh_area` VALUES ('3192','3182','慈溪市','0');
INSERT INTO `yzh_area` VALUES ('3193','3182','奉化市','0');
INSERT INTO `yzh_area` VALUES ('3194','3133','衢州市','0');
INSERT INTO `yzh_area` VALUES ('3195','3194','柯城区','0');
INSERT INTO `yzh_area` VALUES ('3196','3194','衢江区','0');
INSERT INTO `yzh_area` VALUES ('3197','3194','常山县','0');
INSERT INTO `yzh_area` VALUES ('3198','3194','开化县','0');
INSERT INTO `yzh_area` VALUES ('3199','3194','龙游县','0');
INSERT INTO `yzh_area` VALUES ('3200','3194','江山市','0');
INSERT INTO `yzh_area` VALUES ('3201','3133','绍兴市','0');
INSERT INTO `yzh_area` VALUES ('3202','3201','越城区','0');
INSERT INTO `yzh_area` VALUES ('3203','3201','绍兴县','0');
INSERT INTO `yzh_area` VALUES ('3204','3201','新昌县','0');
INSERT INTO `yzh_area` VALUES ('3205','3201','诸暨市','0');
INSERT INTO `yzh_area` VALUES ('3206','3201','上虞市','0');
INSERT INTO `yzh_area` VALUES ('3207','3201','嵊州市','0');
INSERT INTO `yzh_area` VALUES ('3208','3133','台州市','0');
INSERT INTO `yzh_area` VALUES ('3209','3208','椒江区','0');
INSERT INTO `yzh_area` VALUES ('3210','3208','黄岩区','0');
INSERT INTO `yzh_area` VALUES ('3211','3208','路桥区','0');
INSERT INTO `yzh_area` VALUES ('3212','3208','玉环县','0');
INSERT INTO `yzh_area` VALUES ('3213','3208','三门县','0');
INSERT INTO `yzh_area` VALUES ('3214','3208','天台县','0');
INSERT INTO `yzh_area` VALUES ('3215','3208','仙居县','0');
INSERT INTO `yzh_area` VALUES ('3216','3208','温岭市','0');
INSERT INTO `yzh_area` VALUES ('3217','3208','临海市','0');
INSERT INTO `yzh_area` VALUES ('3218','3133','温州市','0');
INSERT INTO `yzh_area` VALUES ('3219','3218','鹿城区','0');
INSERT INTO `yzh_area` VALUES ('3220','3218','龙湾区','0');
INSERT INTO `yzh_area` VALUES ('3221','3218','瓯海区','0');
INSERT INTO `yzh_area` VALUES ('3222','3218','洞头县','0');
INSERT INTO `yzh_area` VALUES ('3223','3218','永嘉县','0');
INSERT INTO `yzh_area` VALUES ('3224','3218','平阳县','0');
INSERT INTO `yzh_area` VALUES ('3225','3218','苍南县','0');
INSERT INTO `yzh_area` VALUES ('3226','3218','文成县','0');
INSERT INTO `yzh_area` VALUES ('3227','3218','泰顺县','0');
INSERT INTO `yzh_area` VALUES ('3228','3218','瑞安市','0');
INSERT INTO `yzh_area` VALUES ('3229','3218','乐清市','0');
INSERT INTO `yzh_area` VALUES ('3230','3133','舟山市','0');
INSERT INTO `yzh_area` VALUES ('3231','3230','定海区','0');
INSERT INTO `yzh_area` VALUES ('3232','3230','普陀区','0');
INSERT INTO `yzh_area` VALUES ('3233','3230','岱山县','0');
INSERT INTO `yzh_area` VALUES ('3234','3230','嵊泗县','0');
INSERT INTO `yzh_area` VALUES ('3235','0','香港','0');
INSERT INTO `yzh_area` VALUES ('3236','3235','九龙','0');
INSERT INTO `yzh_area` VALUES ('3237','3235','香港岛','0');
INSERT INTO `yzh_area` VALUES ('3238','3235','新界','0');
INSERT INTO `yzh_area` VALUES ('3239','0','澳门','0');
INSERT INTO `yzh_area` VALUES ('3240','3239','澳门半岛','0');
INSERT INTO `yzh_area` VALUES ('3241','3239','离岛','0');
INSERT INTO `yzh_area` VALUES ('3242','0','台湾','0');
INSERT INTO `yzh_area` VALUES ('3243','3242','台北市','0');
INSERT INTO `yzh_area` VALUES ('3244','3242','高雄市','0');
INSERT INTO `yzh_area` VALUES ('3245','3242','高雄县','0');
INSERT INTO `yzh_area` VALUES ('3246','3242','花莲县','0');
INSERT INTO `yzh_area` VALUES ('3247','3242','基隆市','0');
INSERT INTO `yzh_area` VALUES ('3248','3242','嘉义市','0');
INSERT INTO `yzh_area` VALUES ('3249','3242','嘉义县','0');
INSERT INTO `yzh_area` VALUES ('3250','3242','金门县','0');
INSERT INTO `yzh_area` VALUES ('3251','3242','苗栗县','0');
INSERT INTO `yzh_area` VALUES ('3252','3242','南投县','0');
INSERT INTO `yzh_area` VALUES ('3253','3242','澎湖县','0');
INSERT INTO `yzh_area` VALUES ('3254','3242','屏东县','0');
INSERT INTO `yzh_area` VALUES ('3255','3242','台北县','0');
INSERT INTO `yzh_area` VALUES ('3256','3242','台东县','0');
INSERT INTO `yzh_area` VALUES ('3257','3242','台南市','0');
INSERT INTO `yzh_area` VALUES ('3258','3242','台南县','0');
INSERT INTO `yzh_area` VALUES ('3259','3242','台中市','0');
INSERT INTO `yzh_area` VALUES ('3260','3242','台中县','0');
INSERT INTO `yzh_area` VALUES ('3261','3242','桃园县','0');
INSERT INTO `yzh_area` VALUES ('3262','3242','新竹市','0');
INSERT INTO `yzh_area` VALUES ('3263','3242','新竹县','0');
INSERT INTO `yzh_area` VALUES ('3264','3242','宜兰县','0');
INSERT INTO `yzh_area` VALUES ('3265','3242','云林县','0');
INSERT INTO `yzh_area` VALUES ('3266','3242','彰化县','0');
--
-- 表的结构 `yzh_article`
-- 
DROP TABLE IF EXISTS `yzh_article`;
CREATE TABLE `yzh_article` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userid` int(11) unsigned NOT NULL DEFAULT '0',
  `username` varchar(40) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `title_style` varchar(40) NOT NULL DEFAULT '',
  `keywords` varchar(120) NOT NULL DEFAULT '',
  `copyfrom` varchar(255) NOT NULL DEFAULT '',
  `fromlink` varchar(80) NOT NULL DEFAULT '0',
  `description` mediumtext NOT NULL,
  `content` text NOT NULL,
  `template` varchar(30) NOT NULL DEFAULT '',
  `thumb` varchar(100) NOT NULL DEFAULT '',
  `posid` varchar(50) NOT NULL DEFAULT '',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `recommend` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `listorder` int(10) unsigned NOT NULL DEFAULT '0',
  `url` varchar(150) NOT NULL DEFAULT '',
  `hits` int(11) unsigned NOT NULL DEFAULT '0',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `lang` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `status` (`id`,`status`,`listorder`),
  KEY `catid` (`id`,`catid`,`status`),
  KEY `listorder` (`id`,`catid`,`status`,`listorder`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- 
-- 导出`yzh_article`表中的数据 `yzh_article`
--
INSERT INTO `yzh_article` VALUES ('2','5','1','super','How to choose a smart watch?','','','','0','The question of how to choose a smartwatch may seem simple, but it\\\'s actually not easy, because there are many similar products on the market and are subdivided into many different categories, some of which look alike but in fact completely different in function, Before you choose, may wish to do homework, I hope you can quickly understand and buy smart watches. After the popularity of smart phones across the board, everyone is guessing what will be the next product to replace the smart phone, smart wearable products will undoubtedly become the next goal of intelligence. Smart watch market over the past two years, the pace of replacement faster than cutting chives, another stubble cropped up, and some want to become a reminder to summarize various notifications, and some want to be your personal fitness coach, Of course, the bigger ambition is to replace smartphones and reduce human dependence on smartphones. But no matter how smart watches update, the general public does not seem to accept it easily. The so-called intelligent product itself, more like a smart phone accessories, with and without a small gap. In particular, there are already some smartphones with built-in pedometers and heartbeat sensors. Unless the professionals need more accurate personal health data, the APP in the basic cell phone can meet the needs of the average user. Although the development of smart phones has encountered resistance, but it does not mean tasteless. When you need a smart device that\\\'s closer to your life, you\\\'ll find no product that\\\'s closer than a watch. Its more direct vibration feedback, access to more accurate body data, and more convenient use of the scene, these are difficult to match the phone. Department.','The question of how to choose a smartwatch may seem simple, but it\'s actually not easy, because there are many similar products on the market and are subdivided into many different categories, some of which look alike but in fact completely different in function, Before you choose, may wish to do homework, I hope you can quickly understand and buy smart watches. After the popularity of smart phones across the board, everyone is guessing what will be the next product to replace the smart phone, smart wearable products will undoubtedly become the next goal of intelligence. Smart watch market over the past two years, the pace of replacement faster than cutting chives, another stubble cropped up, and some want to become a reminder to summarize various notifications, and some want to be your personal fitness coach, Of course, the bigger ambition is to replace smartphones and reduce human dependence on smartphones. But no matter how smart watches update, the general public does not seem to accept it easily. The so-called intelligent product itself, more like a smart phone accessories, with and without a small gap. In particular, there are already some smartphones with built-in pedometers and heartbeat sensors. Unless the professionals need more accurate personal health data, the APP in the basic cell phone can meet the needs of the average user. Although the development of smart phones has encountered resistance, but it does not mean tasteless. When you need a smart device that\'s closer to your life, you\'ll find no product that\'s closer than a watch. Its more direct vibration feedback, access to more accurate body data, and more convenient use of the scene, these are difficult to match the phone. Department.','','/uploads/201803/5aa0b28c5f90f.jpg','-1-','1','1','0','/news/5-2.html','0','1520324419','1520480910','','1');
INSERT INTO `yzh_article` VALUES ('3','5','1','super','Traditional watches and smart watch experience','','','','0','The details of smart watch design, it can be said is unique. Eye-catching when the pointer, hollow design. When it reaches 3, 6, 9, 12, it is just a matter of including the literal cross-hatch. For the overall balance of the watch, the pointer played a big role. The whole watch work fine, while taking into account the needs of people\\\'s daily lives, and even achieved a depth of 30 meters waterproof.','The details of smart watch design, it can be said is unique. Eye-catching when the pointer, hollow design. When it reaches 3, 6, 9, 12, it is just a matter of including the literal cross-hatch. For the overall balance of the watch, the pointer played a big role. The whole watch work fine, while taking into account the needs of people\'s daily lives, and even achieved a depth of 30 meters waterproof.','','/uploads/201803/5aa0b1c461dba.png','-1-','1','1','0','/news/5-3.html','0','1520324419','1520480710','','1');
INSERT INTO `yzh_article` VALUES ('4','5','1','super','Bluetooth Low Energy Technology Features','','','','0','Data Transfers - Bluetooth low energy technology supports very short data packets (8 octet to 27 octet) with transmission speeds up to 1 Mbps. All connections use advanced sniff-subrating mode to achieve an ultra-low duty cycle. The company is located in:','Data Transfers - Bluetooth low energy technology supports very short data packets (8 octet to 27 octet) with transmission speeds up to 1 Mbps. All connections use advanced sniff-subrating mode to achieve an ultra-low duty cycle. The company is located in:<br />\nFrequency Hopping—Bluetooth low-power technology, like other Bluetooth versions, uses regulatory frequency hopping to minimize the interference of other technologies in the 2.4 GHz ISM band. This technology also allows efficient multipathing to increase link budget and increase range.<br />\nHost Control - Highly intelligent controller designed by Bluetooth low energy technology allows the host to sleep for a long period of time and is only started by the controller when the host needs to operate. Because the host consumes more energy than the controller, this design also saves the most energy. The company is located in:<br />\nLatency—Online setup of Bluetooth low-power technology takes only 3 milliseconds (ms) to complete; at the same time, the linker can be quickly started with the application, and after the approved data transmission is completed with a transmission speed of several milliseconds. Immediately close the link - Bluetooth module.<br />\nRange - An increase in Modulation Index allows low-power wireless technology to have a larger range and a range of more than 100 meters.<br />\nRobustness - Bluetooth Low Energy uses a 24-bit Cyclic Repeat Check (CRC) to ensure maximum stability of all packets when disturbed.<br />\nHigh Security - Full AES-128 encryption using CCM to provide high level of data packet encryption and authentication.<br />','','/uploads/201803/5aa0b0b9bcbe9.jpg','-1-','1','1','0','/news/5-4.html','0','1520324419','1520480444','','1');
INSERT INTO `yzh_article` VALUES ('5','5','1','super','Bluetooth 4.0 module prices have returned to civilian','','','','0','The popularity of Bluetooth 4.0 takes the industry\\\'s long-awaited IoT world a step further, and version 4.0 is helping it prove itself and bring us all the benefits of Bluetooth technology, which has been badly beaten over the past 10 years Come to more expectations.','<p>\n	The popularity of Bluetooth 4.0 takes the industry\'s long-awaited IoT world a step further, and version 4.0 is helping it prove itself and bring us all the benefits of Bluetooth technology, which has been badly beaten over the past 10 years Come to more expectations.\n</p>\n<p>\n	Most ordinary consumer impressions, \"Bluetooth\" is a familiar and unfamiliar term, familiar with it because you can always see it in mobile phones and laptops, strange, for the vast majority of users Almost never used it, making Bluetooth a chilling feature for a long time to come, but consumers should start to take a hard look at this data transfer technology after Bluetooth 4.0 It is changing our life little by little. Enter 2013, many attentive consumers should find such a phenomenon, more and more digital products began to support Bluetooth 4.0 as the main selling point in the publicity. \"Bluetooth\" This fade out of people\'s long-standing technology has suddenly been large and small hardware manufacturers pushed to the stage of the central.\n</p>\n<p>\n	Last April at the Bluetooth World Congress in Shanghai, the chief technology officer of Bluetooth Alliance Zhuo Wentai said that since the introduction of Bluetooth 4.0, the number of Bluetooth products has increased by nearly 80% in the past three years. In 2012, the global output of Bluetooth products The volume exceeds 3 billion and is expected to exceed 4 billion this year. \"There are two revolutions in Bluetooth technology, the first is the 1.0 version, the second is the 4.0 version.\" Zhuo Wentai commented. Bluetooth 4.0 version of the significance of Bluetooth technology is evident.\n</p>','','/uploads/201803/5aa0b025a110e.jpg','-1-','1','1','0','/news/5-5.html','34','1520324419','1520480296','','1');
INSERT INTO `yzh_article` VALUES ('10','7','1','super','ABOUT OVA','','','','0','All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All All What You Need To Know About Us All ','All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About UsAll What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About UsAll What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About UsAll What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About UsAll What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About UsAll What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us','','','-1-','1','1','0','/faq/7-10.html','0','1520324657','1520324657','','1');
INSERT INTO `yzh_article` VALUES ('7','7','1','super','ABOUT OVA','','','','0','All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All All What You Need To Know About Us All ','All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About UsAll What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About UsAll What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About UsAll What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About UsAll What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About UsAll What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us','','','-1-','1','1','0','/faq/7-7.html','0','1520324657','1520324657','','1');
INSERT INTO `yzh_article` VALUES ('8','7','1','super','ABOUT OVA','','','','0','All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All All What You Need To Know About Us All ','All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About UsAll What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About UsAll What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About UsAll What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About UsAll What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About UsAll What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us','','','-1-','1','1','0','/faq/7-8.html','0','1520324657','1520324657','','1');
INSERT INTO `yzh_article` VALUES ('9','7','1','super','ABOUT OVA','','','','0','All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All All What You Need To Know About Us All ','All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About UsAll What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About UsAll What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About UsAll What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About UsAll What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About UsAll What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us','','','-1-','1','1','0','/faq/7-9.html','0','1520324657','1520324657','','1');
INSERT INTO `yzh_article` VALUES ('11','7','1','super','ABOUT OVA','','','','0','All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All All What You Need To Know About Us All ','All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About UsAll What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About UsAll What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About UsAll What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About UsAll What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About UsAll What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us All What You Need To Know About Us','','','-1-','1','1','0','/faq/7-11.html','2','1520324657','1520324657','','1');
--
-- 表的结构 `yzh_attachment`
-- 
DROP TABLE IF EXISTS `yzh_attachment`;
CREATE TABLE `yzh_attachment` (
  `aid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `modelid` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `id` int(8) unsigned NOT NULL DEFAULT '0',
  `filename` varchar(50) NOT NULL DEFAULT '',
  `filepath` varchar(80) NOT NULL DEFAULT '',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0',
  `fileext` char(10) NOT NULL DEFAULT '',
  `isimage` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `isthumb` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `createtime` int(10) unsigned NOT NULL DEFAULT '0',
  `uploadip` char(15) NOT NULL DEFAULT '',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`aid`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;

-- 
-- 导出`yzh_attachment`表中的数据 `yzh_attachment`
--
INSERT INTO `yzh_attachment` VALUES ('1','1','0','0','logo.jpg','/uploads/201803/5a9e42b11c85e.jpg','8436','jpg','1','0','1','1520321201','119.123.30.19','1');
INSERT INTO `yzh_attachment` VALUES ('2','1','0','0','banner.jpg','/uploads/201803/5a9e45ca09c04.jpg','83158','jpg','1','0','1','1520321994','119.123.30.19','1');
INSERT INTO `yzh_attachment` VALUES ('8','1','0','0','q7粉色1.JPG','/uploads/201803/5a9f4a7bbe9f4.jpg','35511','jpg','1','0','1','1520388731','119.123.30.19','1');
INSERT INTO `yzh_attachment` VALUES ('4','0','0','0','about.jpg','/uploads/201803/5a9e4af48a558.jpg','17688','jpg','1','0','1','1520323316','119.123.30.19','1');
INSERT INTO `yzh_attachment` VALUES ('5','1','0','0','news.jpg','/uploads/201803/5a9e4f526ca13.jpg','59126','jpg','1','0','1','1520324434','119.123.30.19','1');
INSERT INTO `yzh_attachment` VALUES ('6','1','0','0','partner.jpg','/uploads/201803/5a9e513957de3.jpg','2219','jpg','1','0','1','1520324921','119.123.30.19','1');
INSERT INTO `yzh_attachment` VALUES ('7','0','0','0','wap_logo.jpg','/uploads/201803/5a9e6163e017e.jpg','16853','jpg','1','0','1','1520329059','119.123.30.19','1');
INSERT INTO `yzh_attachment` VALUES ('9','3','0','0','q7粉色2.JPG','/uploads/201803/5a9f4aa14c3a4.jpg','48967','jpg','1','0','1','1520388769','119.123.30.19','1');
INSERT INTO `yzh_attachment` VALUES ('10','1','0','0','q7黑色1.JPG','/uploads/201803/5a9f4aeab0921.jpg','34554','jpg','1','0','1','1520388842','119.123.30.19','1');
INSERT INTO `yzh_attachment` VALUES ('11','3','0','0','q7黑色2.JPG','/uploads/201803/5a9f4af037e0b.jpg','42086','jpg','1','0','1','1520388848','119.123.30.19','1');
INSERT INTO `yzh_attachment` VALUES ('12','1','0','0','q7金色1.JPG','/uploads/201803/5a9f4b0ac9966.jpg','41130','jpg','1','0','1','1520388874','119.123.30.19','1');
INSERT INTO `yzh_attachment` VALUES ('13','3','0','0','q7金色2.JPG','/uploads/201803/5a9f4b0fd3b77.jpg','49654','jpg','1','0','1','1520388879','119.123.30.19','1');
INSERT INTO `yzh_attachment` VALUES ('14','1','0','0','q7玫瑰金1.JPG','/uploads/201803/5a9f4b48edb72.jpg','41968','jpg','1','0','1','1520388936','119.123.30.19','1');
INSERT INTO `yzh_attachment` VALUES ('15','3','0','0','q7玫瑰金2.JPG','/uploads/201803/5a9f4b4ebc303.jpg','50275','jpg','1','0','1','1520388942','119.123.30.19','1');
INSERT INTO `yzh_attachment` VALUES ('16','1','0','0','s1黑色.JPG','/uploads/201803/5a9f4bb87b7bf.jpg','71409','jpg','1','0','1','1520389048','119.123.30.19','1');
INSERT INTO `yzh_attachment` VALUES ('17','1','0','0','s1红色.jpg','/uploads/201803/5a9f4c083737a.jpg','87020','jpg','1','0','1','1520389128','119.123.30.19','1');
INSERT INTO `yzh_attachment` VALUES ('18','1','0','0','s1金色.jpg','/uploads/201803/5a9f4c54ab592.jpg','86132','jpg','1','0','1','1520389204','119.123.30.19','1');
INSERT INTO `yzh_attachment` VALUES ('19','1','0','0','s1蓝色.JPG','/uploads/201803/5a9f4c7cb79d5.jpg','68509','jpg','1','0','1','1520389244','119.123.30.19','1');
INSERT INTO `yzh_attachment` VALUES ('20','1','0','0','s1银色.jpg','/uploads/201803/5a9f4cbb9bd51.jpg','69626','jpg','1','0','1','1520389307','119.123.30.19','1');
INSERT INTO `yzh_attachment` VALUES ('21','1','0','0','i8-6.jpg','/uploads/201803/5a9f4ce5b43ad.jpg','125582','jpg','1','0','1','1520389349','119.123.30.19','1');
INSERT INTO `yzh_attachment` VALUES ('22','1','0','0','i8-6-1.jpg','/uploads/201803/5a9f4d6cc7403.jpg','132974','jpg','1','0','1','1520389484','119.123.30.19','1');
INSERT INTO `yzh_attachment` VALUES ('23','1','0','0','i8-6-2.jpg','/uploads/201803/5a9f4d7770f5c.jpg','100638','jpg','1','0','1','1520389495','119.123.30.19','1');
INSERT INTO `yzh_attachment` VALUES ('24','1','0','0','i8-6蓝色 .jpg','/uploads/201803/5a9f4d85e0a81.jpg','130123','jpg','1','0','1','1520389509','119.123.30.19','1');
INSERT INTO `yzh_attachment` VALUES ('25','1','0','0','i8-7.jpg','/uploads/201803/5a9f4d901d1e0.jpg','129945','jpg','1','0','1','1520389520','119.123.30.19','1');
INSERT INTO `yzh_attachment` VALUES ('26','1','0','0','LG.jpg','/uploads/201803/5aa0ac49b6d5f.jpg','4167','jpg','1','0','1','1520479305','119.123.1.235','1');
INSERT INTO `yzh_attachment` VALUES ('27','1','0','0','华为.jpg','/uploads/201803/5aa0ac770ff8f.jpg','5127','jpg','1','0','1','1520479351','119.123.1.235','1');
INSERT INTO `yzh_attachment` VALUES ('28','1','0','0','三星.jpg','/uploads/201803/5aa0ac8fd77e1.jpg','7353','jpg','1','0','1','1520479375','119.123.1.235','1');
INSERT INTO `yzh_attachment` VALUES ('29','1','0','0','松下.jpg','/uploads/201803/5aa0acc32966e.jpg','6652','jpg','1','0','1','1520479427','119.123.1.235','1');
INSERT INTO `yzh_attachment` VALUES ('30','1','0','0','索尼.jpg','/uploads/201803/5aa0ad10ed091.jpg','4403','jpg','1','0','1','1520479504','119.123.1.235','1');
INSERT INTO `yzh_attachment` VALUES ('31','1','0','0','富士康.jpg','/uploads/201803/5aa0adfbe7f45.jpg','5943','jpg','1','0','1','1520479739','119.123.1.235','1');
INSERT INTO `yzh_attachment` VALUES ('32','1','0','0','1.png','/uploads/201803/5aa0ae18597fb.png','74073','png','1','0','1','1520479768','119.123.1.235','1');
INSERT INTO `yzh_attachment` VALUES ('33','1','0','0','u=2619069629,355005248&fm=27&gp=0.jpg','/uploads/201803/5aa0b025a110e.jpg','46849','jpg','1','0','1','1520480293','119.123.1.235','1');
INSERT INTO `yzh_attachment` VALUES ('34','1','0','0','u=4200980246,1738873252&fm=27&gp=0.jpg','/uploads/201803/5aa0b0b9bcbe9.jpg','22704','jpg','1','0','1','1520480441','119.123.1.235','1');
INSERT INTO `yzh_attachment` VALUES ('35','1','0','0','QQ截图20180308114432.png','/uploads/201803/5aa0b1c461dba.png','118103','png','1','0','1','1520480708','119.123.1.235','1');
INSERT INTO `yzh_attachment` VALUES ('36','1','0','0','timg (1).jpg','/uploads/201803/5aa0b28c5f90f.jpg','15835','jpg','1','0','1','1520480908','119.123.1.235','1');
INSERT INTO `yzh_attachment` VALUES ('37','1','0','0','1.png','/uploads/201803/5aa0dc8104357.png','11875','png','1','0','1','1520491649','119.123.1.235','1');
INSERT INTO `yzh_attachment` VALUES ('38','1','0','0','1.png','/uploads/201803/5aa0dd9ebc0c1.png','10866','png','1','0','1','1520491934','119.123.1.235','1');
INSERT INTO `yzh_attachment` VALUES ('39','1','0','0','1.jpg','/uploads/201803/5aa0e79eed6ca.jpg','283018','jpg','1','0','1','1520494494','119.123.1.235','1');
INSERT INTO `yzh_attachment` VALUES ('40','1','0','0','2.jpg','/uploads/201803/5aa0ead127327.jpg','209289','jpg','1','0','1','1520495313','119.123.1.235','1');
INSERT INTO `yzh_attachment` VALUES ('41','1','0','0','1.jpg','/uploads/201803/5aa0f0cd4dbc4.jpg','213148','jpg','1','0','1','1520496845','119.123.1.235','1');
--
-- 表的结构 `yzh_attachment_index`
-- 
DROP TABLE IF EXISTS `yzh_attachment_index`;
CREATE TABLE `yzh_attachment_index` (
  `keyid` char(30) NOT NULL DEFAULT '' COMMENT '关联id',
  `aid` char(10) NOT NULL DEFAULT '' COMMENT '附件ID',
  KEY `keyid` (`keyid`),
  KEY `aid` (`aid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='附件关系表';

-- 
-- 导出`yzh_attachment_index`表中的数据 `yzh_attachment_index`
--
INSERT INTO `yzh_attachment_index` VALUES ('config','1');
INSERT INTO `yzh_attachment_index` VALUES ('slide-2','2');
INSERT INTO `yzh_attachment_index` VALUES ('slide-1','2');
INSERT INTO `yzh_attachment_index` VALUES ('product-11','8');
INSERT INTO `yzh_attachment_index` VALUES ('product-11','9');
INSERT INTO `yzh_attachment_index` VALUES ('product-12','10');
INSERT INTO `yzh_attachment_index` VALUES ('product-12','11');
INSERT INTO `yzh_attachment_index` VALUES ('product-13','12');
INSERT INTO `yzh_attachment_index` VALUES ('block-2','4');
INSERT INTO `yzh_attachment_index` VALUES ('product-13','13');
INSERT INTO `yzh_attachment_index` VALUES ('product-14','14');
INSERT INTO `yzh_attachment_index` VALUES ('product-14','15');
INSERT INTO `yzh_attachment_index` VALUES ('product-15','16');
INSERT INTO `yzh_attachment_index` VALUES ('product-16','17');
INSERT INTO `yzh_attachment_index` VALUES ('config','37');
INSERT INTO `yzh_attachment_index` VALUES ('article-2','5');
INSERT INTO `yzh_attachment_index` VALUES ('article-3','5');
INSERT INTO `yzh_attachment_index` VALUES ('article-4','5');
INSERT INTO `yzh_attachment_index` VALUES ('article-5','5');
INSERT INTO `yzh_attachment_index` VALUES ('picture-1','6');
INSERT INTO `yzh_attachment_index` VALUES ('picture-2','6');
INSERT INTO `yzh_attachment_index` VALUES ('picture-3','6');
INSERT INTO `yzh_attachment_index` VALUES ('picture-4','6');
INSERT INTO `yzh_attachment_index` VALUES ('picture-5','6');
INSERT INTO `yzh_attachment_index` VALUES ('picture-6','6');
INSERT INTO `yzh_attachment_index` VALUES ('picture-7','6');
INSERT INTO `yzh_attachment_index` VALUES ('config','6');
INSERT INTO `yzh_attachment_index` VALUES ('slide-6','2');
INSERT INTO `yzh_attachment_index` VALUES ('slide-5','2');
INSERT INTO `yzh_attachment_index` VALUES ('config','7');
INSERT INTO `yzh_attachment_index` VALUES ('slide-4','2');
INSERT INTO `yzh_attachment_index` VALUES ('slide-3','2');
INSERT INTO `yzh_attachment_index` VALUES ('product-17','18');
INSERT INTO `yzh_attachment_index` VALUES ('product-18','19');
INSERT INTO `yzh_attachment_index` VALUES ('product-19','20');
INSERT INTO `yzh_attachment_index` VALUES ('product-20','21');
INSERT INTO `yzh_attachment_index` VALUES ('product-21','22');
INSERT INTO `yzh_attachment_index` VALUES ('product-22','23');
INSERT INTO `yzh_attachment_index` VALUES ('product-23','24');
INSERT INTO `yzh_attachment_index` VALUES ('product-24','25');
INSERT INTO `yzh_attachment_index` VALUES ('picture-7','26');
INSERT INTO `yzh_attachment_index` VALUES ('picture-6','27');
INSERT INTO `yzh_attachment_index` VALUES ('picture-5','28');
INSERT INTO `yzh_attachment_index` VALUES ('picture-4','29');
INSERT INTO `yzh_attachment_index` VALUES ('picture-3','30');
INSERT INTO `yzh_attachment_index` VALUES ('picture-2','31');
INSERT INTO `yzh_attachment_index` VALUES ('picture-1','32');
INSERT INTO `yzh_attachment_index` VALUES ('article-5','33');
INSERT INTO `yzh_attachment_index` VALUES ('article-4','34');
INSERT INTO `yzh_attachment_index` VALUES ('article-3','35');
INSERT INTO `yzh_attachment_index` VALUES ('article-2','36');
INSERT INTO `yzh_attachment_index` VALUES ('config','38');
INSERT INTO `yzh_attachment_index` VALUES ('slide-2','39');
INSERT INTO `yzh_attachment_index` VALUES ('slide-11','40');
INSERT INTO `yzh_attachment_index` VALUES ('slide-1','41');
--
-- 表的结构 `yzh_block`
-- 
DROP TABLE IF EXISTS `yzh_block`;
CREATE TABLE `yzh_block` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pos` char(30) NOT NULL DEFAULT '',
  `type` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL DEFAULT '',
  `remark` varchar(300) NOT NULL,
  `content` text NOT NULL,
  `groupid` tinyint(3) NOT NULL,
  `lang` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- 
-- 导出`yzh_block`表中的数据 `yzh_block`
--
INSERT INTO `yzh_block` VALUES ('1','','rtf','首页关于我们介绍','','<p>\n	is a professional company that is leading the industry in providing high-quality 3C digital, phone peripherals, speakers, smart watches and U disk devices. It integrates R & D, design, production and sales. Founded in Shenzhen in the early 2008, it provides professional services to customers in all parts of the world through its more than 30 companies and distributor network. So far, it has already had a steady operation service network composed of dozens of agents such as Shanghai, Guangzhou, Ji\'nan, Shenyang, Chengdu, Xi\'an, Wuhan and Hangzhou in China.\n</p>\n<p>\n	<br />\n</p>\n<p>\n	The business of SenXin Technology Ltd. has spread over dozens of countries in five continents. To meet the needs of all customers, and to dedicated to easy operation and to match the special requirements of the customers, it provides a full series of logo solutions. The solution is economical and practical, low in cost, simple in maintenance, excellent in performance and reliable in operation.\n</p>\n<p>\n	SenXin Technology Ltd. ensures customer satisfaction through quality policy and security measures.\n</p>\n<p>\n	Through quality certification and international CE certification, products meet all international safety standards. It widely involves many fields, like domestic and international speakers, smart watches, wireless charging, mobile power, 3C digital, mobile phone and so on.\n</p>','1','1');
INSERT INTO `yzh_block` VALUES ('2','','img','首页关于我们图片','','<img src=\"/uploads/201803/5a9e4af48a558.jpg\" width=\"360\" alt=\"\" />','1','1');
INSERT INTO `yzh_block` VALUES ('3','','text','手机端关于我们','','Actually,I like many kinds of music,I\'d like to talk about my favorite music here.Well,I like Irish folk music best,New age is Irish style,and it\'s mixes some morden melody,it sounds very nice and pure,can bring you into the never land and dream land,just relax,and forget all the problems.I like Enya,she is a very famous New age singer,her song just like the voice of heaven,her song is as nice and beautiful as herself!<br />\nI\'m not keen on American pop songs,they are terrible for me!The melody is not soft and nice at all!<br />\nSo fast and strong beat,too exciting,and can\'t hear them clearly.I can\'t stand the strong beat,that nearly make me fainted!','2','1');
--
-- 表的结构 `yzh_cache`
-- 
DROP TABLE IF EXISTS `yzh_cache`;
CREATE TABLE `yzh_cache` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '自增长ID',
  `name` varchar(255) NOT NULL COMMENT '名称',
  `module` char(30) NOT NULL COMMENT '模型名称',
  `action` char(30) NOT NULL COMMENT '方法名',
  `param` varchar(255) NOT NULL COMMENT '参数',
  `system` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否系统',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COMMENT='缓存更新列队';

-- 
-- 导出`yzh_cache`表中的数据 `yzh_cache`
--
INSERT INTO `yzh_cache` VALUES ('1','更新网站配置','Config','config_cache','','1');
INSERT INTO `yzh_cache` VALUES ('2','更新栏目缓存','Category','category_cache','','1');
INSERT INTO `yzh_cache` VALUES ('3','更新模型缓存','Model','model_cache','','1');
INSERT INTO `yzh_cache` VALUES ('4','更新后台菜单缓存','Menu','menu_cache','','1');
INSERT INTO `yzh_cache` VALUES ('5','更新模型字段缓存','Field','model_field_cache','','1');
INSERT INTO `yzh_cache` VALUES ('6','更新内容模型缓存','Urlrule','model_content_cache','','1');
INSERT INTO `yzh_cache` VALUES ('7','','Posid','','','0');
INSERT INTO `yzh_cache` VALUES ('8','','Sysconfig','','','0');
INSERT INTO `yzh_cache` VALUES ('9','','Lang','','','0');
INSERT INTO `yzh_cache` VALUES ('10','','RoleUser','','','0');
INSERT INTO `yzh_cache` VALUES ('11','','MemberGroup','','','0');
INSERT INTO `yzh_cache` VALUES ('12','','Form','','','0');
INSERT INTO `yzh_cache` VALUES ('13','','FormField','','','0');
INSERT INTO `yzh_cache` VALUES ('14','','Type','','','0');
--
-- 表的结构 `yzh_cart`
-- 
DROP TABLE IF EXISTS `yzh_cart`;
CREATE TABLE `yzh_cart` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `modelid` smallint(3) unsigned NOT NULL DEFAULT '0',
  `product_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `product_thumb` varchar(120) NOT NULL DEFAULT '',
  `product_name` varchar(120) NOT NULL DEFAULT '',
  `product_url` varchar(120) NOT NULL DEFAULT '',
  `product_price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `number` smallint(5) unsigned NOT NULL DEFAULT '0',
  `attr` text NOT NULL,
  `goods_attr_id` varchar(255) NOT NULL DEFAULT '',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `isgift` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
--
-- 表的结构 `yzh_category`
-- 
DROP TABLE IF EXISTS `yzh_category`;
CREATE TABLE `yzh_category` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `catname` varchar(30) NOT NULL DEFAULT '',
  `en_catname` varchar(30) NOT NULL,
  `catdir` varchar(30) NOT NULL DEFAULT '',
  `parentdir` varchar(50) NOT NULL DEFAULT '',
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `modelid` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `arrparentid` text NOT NULL,
  `arrchildid` text NOT NULL,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(150) NOT NULL DEFAULT '',
  `keywords` varchar(100) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ishtml` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ismenu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_wap_menu` tinyint(1) NOT NULL,
  `isblank` tinyint(1) NOT NULL,
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `image` varchar(100) NOT NULL DEFAULT '',
  `thumb` varchar(100) NOT NULL,
  `child` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `url` varchar(150) NOT NULL DEFAULT '',
  `template_list` varchar(20) NOT NULL DEFAULT '',
  `template_show` varchar(20) NOT NULL DEFAULT '',
  `pagesize` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `readgroup` varchar(100) NOT NULL DEFAULT '',
  `listtype` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `urlruleid` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `lang` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parentid` (`parentid`),
  KEY `listorder` (`listorder`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- 
-- 导出`yzh_category`表中的数据 `yzh_category`
--
INSERT INTO `yzh_category` VALUES ('1','ABOUT US','','','','0','0','0','1,11,12','2','','','','0','0','1','1','0','0','','','1','/companyprofile.html','','','0','','0','0','1');
INSERT INTO `yzh_category` VALUES ('2','Products','','products','','0','3','0','2,9,10','0','','','','0','0','1','1','0','0','','','1','/products.html','','','0','','0','0','1');
INSERT INTO `yzh_category` VALUES ('3','partner','','partner','','0','4','0','3','0','','','','0','0','1','1','0','0','','','0','/partner.html','list_partner','detail','0','','0','0','1');
INSERT INTO `yzh_category` VALUES ('4','Service','','service','','0','1','0','4','1','','','','0','0','1','1','0','0','','','0','/service.html','','','0','','0','0','1');
INSERT INTO `yzh_category` VALUES ('5','News ','','news','','0','2','0','5','0','','','','0','0','1','1','0','0','','','0','/news.html','','','0','','0','0','1');
INSERT INTO `yzh_category` VALUES ('6','Contacts','','contacts','','0','1','0','6','1','','','','0','0','1','1','0','0','','','0','/contacts.html','contact','','0','','0','0','1');
INSERT INTO `yzh_category` VALUES ('7','FAQ','','faq','','0','2','0','7','0','','','','0','0','0','0','0','0','','','0','/faq.html','list_faq','','0','','0','0','1');
INSERT INTO `yzh_category` VALUES ('9','Bluetooth audio','','bluetoothaudio','','2','3','0,2','9','0','','','','0','0','1','1','0','0','','','0','/bluetoothaudio.html','','','0','','0','0','1');
INSERT INTO `yzh_category` VALUES ('10','Smart watch','','smartwatch','','2','3','0,2','10','0','','','','0','0','1','1','0','0','','','0','/smartwatch.html','','','0','','0','0','1');
INSERT INTO `yzh_category` VALUES ('11','Company Profile','','companyprofile','','1','1','0,1','11','1','','','','0','0','1','1','0','0','','','0','/companyprofile.html','','','0','','0','0','1');
INSERT INTO `yzh_category` VALUES ('12','Company culture','','companyculture','','1','1','0,1','12','1','','','','0','0','1','1','0','0','','','0','/companyculture.html','','','0','','0','0','1');
--
-- 表的结构 `yzh_category_field`
-- 
DROP TABLE IF EXISTS `yzh_category_field`;
CREATE TABLE `yzh_category_field` (
  `fid` smallint(6) NOT NULL AUTO_INCREMENT COMMENT '自增长id',
  `catid` smallint(5) NOT NULL DEFAULT '0' COMMENT '栏目ID',
  `fieldname` varchar(30) NOT NULL DEFAULT '' COMMENT '字段名',
  `type` varchar(10) NOT NULL DEFAULT '' COMMENT '类型,input',
  `setting` mediumtext COMMENT '其他',
  `createtime` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`fid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='栏目扩展字段列表';
--
-- 表的结构 `yzh_comment`
-- 
DROP TABLE IF EXISTS `yzh_comment`;
CREATE TABLE `yzh_comment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `userid` int(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(40) NOT NULL DEFAULT '',
  `url` varchar(60) NOT NULL DEFAULT '',
  `listorder` int(10) unsigned NOT NULL DEFAULT '0',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `phone` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `content` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
--
-- 表的结构 `yzh_config`
-- 
DROP TABLE IF EXISTS `yzh_config`;
CREATE TABLE `yzh_config` (
  `id` smallint(8) unsigned NOT NULL AUTO_INCREMENT,
  `varname` varchar(25) NOT NULL DEFAULT '',
  `info` varchar(100) NOT NULL DEFAULT '',
  `groupid` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `value` text NOT NULL,
  `type` varchar(255) NOT NULL,
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0',
  `lang` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `varname` (`varname`)
) ENGINE=MyISAM AUTO_INCREMENT=71 DEFAULT CHARSET=utf8;

-- 
-- 导出`yzh_config`表中的数据 `yzh_config`
--
INSERT INTO `yzh_config` VALUES ('1','site_name','网站名称','1','Shenzhen SenXin Technology Ltd. ','0','0','1');
INSERT INTO `yzh_config` VALUES ('2','site_logo','网站logo','1','/uploads/201803/5aa0dd9ebc0c1.png','1','0','1');
INSERT INTO `yzh_config` VALUES ('3','seo_title','首页标题','1','','0','0','1');
INSERT INTO `yzh_config` VALUES ('4','seo_keywords','首页关键词','1','','0','0','1');
INSERT INTO `yzh_config` VALUES ('5','seo_description','首页描述','1','','0','0','1');
INSERT INTO `yzh_config` VALUES ('6','site_copyright','版权所有','1','2018 copyright Shenzhen SenXin Technology Ltd. ','0','0','1');
INSERT INTO `yzh_config` VALUES ('7','site_approve','ICP备案号','1','','0','0','1');
INSERT INTO `yzh_config` VALUES ('23','shortcuts','快捷操作','1','[{\"name\":\"\\u53d1\\u5e03\\u65b0\\u95fb\",\"url\":\"\\/?g=admin&m=article&a=add\"},{\"name\":\"\\u53d1\\u5e03\\u4ea7\\u54c1\",\"url\":\"\\/?g=admin&m=product&a=add\"},{\"name\":\"\\u67e5\\u770b\\u7559\\u8a00\",\"url\":\"\\/?g=admin&m=form&a=index\"},{\"name\":\"\\u7ba1\\u7406\\u94fe\\u63a5\",\"url\":\"\\/?g=admin&m=link&a=index\"},{\"name\":\"\\u7f51\\u7ad9\\u8bbe\\u7f6e\",\"url\":\"\\/?g=admin&m=config&a=index\"}]','0','0','0');
INSERT INTO `yzh_config` VALUES ('24','site_email','公司邮箱','2','563665073＠qq.com','0','0','1');
INSERT INTO `yzh_config` VALUES ('25','site_telephone','公司电话','2','+86-755-33161106','0','0','1');
INSERT INTO `yzh_config` VALUES ('26','site_lxr','联系人','2','Mr. Li','0','0','1');
INSERT INTO `yzh_config` VALUES ('27','site_fax','公司传真','2','+86-755-33161106','0','0','1');
INSERT INTO `yzh_config` VALUES ('28','site_address','公司地址','2','3F-A, 1 / F, No.1 Industrial Park, Gushu, Xixiang, Bao\'an District, Shenzhen','0','0','1');
INSERT INTO `yzh_config` VALUES ('29','site_tel400','全国服务热线','2','','0','0','1');
INSERT INTO `yzh_config` VALUES ('30','site_phone','手 机','2','+86-13554990867','0','0','1');
INSERT INTO `yzh_config` VALUES ('31','site_ywzx','阿里巴巴地址','2','','0','0','1');
INSERT INTO `yzh_config` VALUES ('33','site_txd','腾讯微博地址','2','','0','0','1');
INSERT INTO `yzh_config` VALUES ('34','site_xld','新浪微博地址','2','','0','0','1');
INSERT INTO `yzh_config` VALUES ('35','site_wxqrcode','微信二维码','2','','1','0','1');
INSERT INTO `yzh_config` VALUES ('36','site_wzqrcode','网站二维码','2','','1','0','1');
INSERT INTO `yzh_config` VALUES ('37','site_400pic','400电话','2','','0','0','1');
INSERT INTO `yzh_config` VALUES ('38','wap_company','手机公司名称','3','','0','0','1');
INSERT INTO `yzh_config` VALUES ('39','wap_bdaddress','手机公司地址','3','','0','0','1');
INSERT INTO `yzh_config` VALUES ('40','wap_qrcode','首页二维码','3','','1','0','1');
INSERT INTO `yzh_config` VALUES ('41','wap_tel400','服务电话','3','','0','0','1');
INSERT INTO `yzh_config` VALUES ('42','wap_logo','网站logo','3','/uploads/201803/5a9e6163e017e.jpg','0','0','1');
INSERT INTO `yzh_config` VALUES ('43','site_name','网站名称','1','誉字号v1测试站','0','0','2');
INSERT INTO `yzh_config` VALUES ('44','site_logo','网站logo','1','','1','0','2');
INSERT INTO `yzh_config` VALUES ('45','seo_title','首页标题','1','誉字号，竞享自豪人生！','0','0','2');
INSERT INTO `yzh_config` VALUES ('46','seo_keywords','首页关键词','1','誉字号，竞享自豪人生！','0','0','2');
INSERT INTO `yzh_config` VALUES ('47','seo_description','首页描述','1','誉字号，竞享自豪人生！业务咨询专线400-6919-602','0','0','2');
INSERT INTO `yzh_config` VALUES ('48','site_copyright','版权所有','1','© 2015 国人在线·誉字号 版权所有','0','0','2');
INSERT INTO `yzh_config` VALUES ('49','site_approve','ICP备案号','1','粤ICP备001号','0','0','2');
INSERT INTO `yzh_config` VALUES ('50','site_email','公司邮箱','2','company@qq.com','0','0','2');
INSERT INTO `yzh_config` VALUES ('51','site_telephone','公司电话','2','','0','0','2');
INSERT INTO `yzh_config` VALUES ('52','site_lxr','联系人','2','张先生','0','0','2');
INSERT INTO `yzh_config` VALUES ('53','site_fax','公司传真','2','0755-23088059','0','0','2');
INSERT INTO `yzh_config` VALUES ('54','site_address','公司地址','2','aa','0','0','2');
INSERT INTO `yzh_config` VALUES ('55','site_tel400','全国服务热线','2','16888888888','0','0','2');
INSERT INTO `yzh_config` VALUES ('56','site_phone','手 机','2','13925200705','0','0','2');
INSERT INTO `yzh_config` VALUES ('57','site_ywzx','业务咨询','2','13925200705','0','0','2');
INSERT INTO `yzh_config` VALUES ('58','site_rszp','人事招聘','2','400-8353-880','0','0','2');
INSERT INTO `yzh_config` VALUES ('59','site_txd','腾讯微博地址','2','http://t.qq.com/s','0','0','2');
INSERT INTO `yzh_config` VALUES ('60','site_xld','新浪微博地址','2','http://weibo.com','0','0','2');
INSERT INTO `yzh_config` VALUES ('61','site_wxqrcode','微信二维码','2','','1','0','2');
INSERT INTO `yzh_config` VALUES ('62','site_wzqrcode','网站二维码','2','','1','0','2');
INSERT INTO `yzh_config` VALUES ('63','site_400pic','400电话','2','400-8353-880','0','0','2');
INSERT INTO `yzh_config` VALUES ('64','wap_company','手机公司名称','3','','0','0','2');
INSERT INTO `yzh_config` VALUES ('65','wap_bdaddress','手机公司地址','3','','0','0','2');
INSERT INTO `yzh_config` VALUES ('66','wap_qrcode','首页二维码','3','','1','0','2');
INSERT INTO `yzh_config` VALUES ('67','wap_tel400','服务电话','3','1111','0','0','2');
INSERT INTO `yzh_config` VALUES ('68','wap_logo','网站logo','3','','0','0','2');
INSERT INTO `yzh_config` VALUES ('69','site_qq','QQ咨询','2','','0','0','1');
INSERT INTO `yzh_config` VALUES ('70','site_qq','QQ咨询','2','','0','0','2');
--
-- 表的结构 `yzh_download`
-- 
DROP TABLE IF EXISTS `yzh_download`;
CREATE TABLE `yzh_download` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userid` int(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(40) NOT NULL DEFAULT '',
  `title` varchar(80) NOT NULL DEFAULT '',
  `title_style` varchar(40) NOT NULL DEFAULT '',
  `thumb` varchar(100) NOT NULL DEFAULT '',
  `keywords` varchar(120) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  `posid` varchar(50) NOT NULL DEFAULT '',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `listorder` int(10) unsigned NOT NULL DEFAULT '0',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  `url` varchar(150) NOT NULL DEFAULT '',
  `filepath` varchar(80) NOT NULL DEFAULT '',
  `lang` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `status` (`id`,`status`,`listorder`),
  KEY `catid` (`id`,`catid`,`status`),
  KEY `listorder` (`id`,`catid`,`status`,`listorder`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
--
-- 表的结构 `yzh_email`
-- 
DROP TABLE IF EXISTS `yzh_email`;
CREATE TABLE `yzh_email` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `userid` int(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(40) NOT NULL DEFAULT '',
  `url` varchar(60) NOT NULL DEFAULT '',
  `listorder` int(10) unsigned NOT NULL DEFAULT '0',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  `email` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
--
-- 表的结构 `yzh_feedback`
-- 
DROP TABLE IF EXISTS `yzh_feedback`;
CREATE TABLE `yzh_feedback` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip` char(15) NOT NULL,
  `userid` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `username` varchar(20) NOT NULL DEFAULT '',
  `title` varchar(50) NOT NULL DEFAULT '',
  `tel` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(50) NOT NULL DEFAULT '',
  `content` mediumtext NOT NULL,
  `address` varchar(255) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- 
-- 导出`yzh_feedback`表中的数据 `yzh_feedback`
--
INSERT INTO `yzh_feedback` VALUES ('1','119.123.30.19','0','0','1520328350','4545','sfa','18454545454','abc@qq.com','afsaf','fasf','fa');
--
-- 表的结构 `yzh_field`
-- 
DROP TABLE IF EXISTS `yzh_field`;
CREATE TABLE `yzh_field` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `modelid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `field` varchar(20) NOT NULL DEFAULT '',
  `name` varchar(30) NOT NULL DEFAULT '',
  `tips` varchar(150) NOT NULL DEFAULT '',
  `required` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `minlength` int(10) unsigned NOT NULL DEFAULT '0',
  `maxlength` int(10) unsigned NOT NULL DEFAULT '0',
  `pattern` varchar(255) NOT NULL DEFAULT '',
  `errormsg` varchar(255) NOT NULL DEFAULT '',
  `class` varchar(20) NOT NULL DEFAULT '',
  `type` varchar(20) NOT NULL DEFAULT '',
  `setup` mediumtext NOT NULL,
  `isbase` tinyint(1) NOT NULL DEFAULT '0',
  `unpostgroup` varchar(60) NOT NULL DEFAULT '',
  `listorder` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `issystem` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=78 DEFAULT CHARSET=utf8;

-- 
-- 导出`yzh_field`表中的数据 `yzh_field`
--
INSERT INTO `yzh_field` VALUES ('1','1','title','标题','','1','3','80','0','标题必填3-80个字','','title','{\"thumb\":\"0\",\"style\":\"0\",\"size\":\"55\"}','1','','0','1','1');
INSERT INTO `yzh_field` VALUES ('2','1','keywords','关键词','','0','0','0','','','','text','array (\n  \'size\' => \'55\',\n  \'default\' => \'\',\n  \'ispassword\' => \'0\',\n)','1','','0','0','1');
INSERT INTO `yzh_field` VALUES ('3','1','description','SEO简介','','0','0','0','','','','textarea','array (\n  \'rows\' => \'4\',\n  \'cols\' => \'55\',\n  \'default\' => \'\',\n)','1','','0','0','1');
INSERT INTO `yzh_field` VALUES ('4','1','content','内容','','0','0','0','','','','editor','array (\n  \'toolbar\' => \'full\',\n  \'default\' => \'\',\n  \'height\' => \'\',\n  \'showpage\' => \'1\',\n  \'enablekeylink\' => \'0\',\n  \'replacenum\' => \'\',\n  \'enablesaveimage\' => \'0\',\n  \'flashupload\' => \'1\',\n  \'alowuploadexts\' => \'jpg,jpeg,gif,doc,rar,zip,xls\',\n)','1','','0','1','1');
INSERT INTO `yzh_field` VALUES ('5','2','catid','栏目','','1','1','6','digits','必须选择一个栏目','w-500px','catid','','1','','0','1','1');
INSERT INTO `yzh_field` VALUES ('6','2','title','标题/问题','','1','0','0','0','标题必须为1-80个字符','w-500px','title','{\"thumb\":\"1\",\"style\":\"0\",\"size\":\"55\"}','1','','0','1','1');
INSERT INTO `yzh_field` VALUES ('7','2','keywords','关键词','','0','0','0','0','','w-400','text','{\"size\":\"55\",\"default\":\"\",\"ispassword\":\"0\",\"fieldtype\":\"varchar\"}','1','','0','1','1');
INSERT INTO `yzh_field` VALUES ('8','2','description','SEO简介','','0','0','0','0','','w-500','textarea','{\"fieldtype\":\"mediumtext\",\"rows\":\"4\",\"cols\":\"55\",\"default\":\"\"}','1','','0','1','1');
INSERT INTO `yzh_field` VALUES ('9','2','content','内容/回答','','0','0','0','0','','','editor','{\"toolbar\":\"full\",\"default\":\"\",\"height\":\"\",\"show_add_description\":\"1\",\"show_auto_thumb\":\"1\",\"showpage\":\"1\",\"enablekeylink\":\"0\",\"replacenum\":\"\",\"enablesaveimage\":\"0\",\"flashupload\":\"1\",\"alowuploadexts\":\"\",\"alowuploadlimit\":\"\"}','1','','0','1','1');
INSERT INTO `yzh_field` VALUES ('10','2','createtime','发布时间','','1','0','0','0','','w-200','datetime','','0','','0','1','1');
INSERT INTO `yzh_field` VALUES ('11','2','copyfrom','来源','','0','0','0','0','','','text','{\"size\":\"20\",\"default\":\"\",\"ispassword\":\"0\",\"fieldtype\":\"varchar\"}','1','','0','1','1');
INSERT INTO `yzh_field` VALUES ('13','2','readgroup','访问权限','','0','0','0','0','','','groupid','{\"inputtype\":\"checkbox\",\"fieldtype\":\"varchar\",\"numbertype\":\"1\",\"labelwidth\":\"85\",\"default\":\"\"}','1','3,4','0','1','1');
INSERT INTO `yzh_field` VALUES ('14','2','posid','推荐位','','0','0','0','0','','','posid','','1','3,4','0','1','1');
INSERT INTO `yzh_field` VALUES ('15','2','template','模板','','0','0','0','0','','','template','','0','3,4','0','0','1');
INSERT INTO `yzh_field` VALUES ('16','2','status','状态','','0','0','0','0','','','radio','{\"options\":\"\\u5df2\\u5ba1\\u6838|1\\n\\u672a\\u5ba1\\u6838|0\",\"fieldtype\":\"tinyint\",\"numbertype\":\"1\",\"labelwidth\":\"75\",\"default\":\"1\"}','0','3,4','0','1','1');
INSERT INTO `yzh_field` VALUES ('17','2','recommend','允许评论','','0','0','1','0','','','radio','{\"options\":\"\\u5141\\u8bb8\\u8bc4\\u8bba|1\\n\\u4e0d\\u5141\\u8bb8\\u8bc4\\u8bba|0\",\"fieldtype\":\"tinyint\",\"numbertype\":\"1\",\"labelwidth\":\"\",\"default\":\"1\"}','1','3,4','0','0','0');
INSERT INTO `yzh_field` VALUES ('19','2','hits','点击次数','','0','0','8','0','','','number','{\"size\":\"5\",\"numbertype\":\"1\",\"decimaldigits\":\"0\",\"default\":\"\"}','1','','0','0','0');
INSERT INTO `yzh_field` VALUES ('20','3','catid','栏目','','1','1','6','0','必须选择一个栏目','w-500px','catid','','1','','0','1','1');
INSERT INTO `yzh_field` VALUES ('21','3','title','产品名称','','1','1','80','0','标题必须为1-80个字符','w-500px','title','{\"thumb\":\"1\",\"style\":\"0\",\"size\":\"55\"}','1','','0','1','1');
INSERT INTO `yzh_field` VALUES ('22','3','keywords','关键词','','0','0','80','0','','w-500px','text','{\"size\":\"55\",\"default\":\"\",\"ispassword\":\"0\",\"fieldtype\":\"varchar\"}','1','','0','1','1');
INSERT INTO `yzh_field` VALUES ('23','3','description','SEO简介','','0','0','0','0','','w-500','textarea','{\"fieldtype\":\"mediumtext\",\"rows\":\"4\",\"cols\":\"55\",\"default\":\"\"}','1','','0','1','1');
INSERT INTO `yzh_field` VALUES ('24','3','price','价格','','0','0','0','0','','','number','{\"size\":\"\",\"numbertype\":\"1\",\"decimaldigits\":\"2\",\"default\":\"0\"}','1','','0','1','1');
INSERT INTO `yzh_field` VALUES ('25','3','pics','图片','','0','0','0','0','','','images','{\"default\":\"\",\"upload_maxnum\":\"10\",\"upload_maxsize\":\"0.2\",\"upload_allowext\":\"jpeg,jpg,gif\",\"watermark\":\"0\",\"more\":\"1\"}','1','','90','1','0');
INSERT INTO `yzh_field` VALUES ('26','3','content','产品说明','','0','0','0','0','','','editor','{\"toolbar\":\"full\",\"default\":\"\",\"height\":\"\",\"show_add_description\":\"0\",\"show_auto_thumb\":\"0\",\"showpage\":\"1\",\"enablekeylink\":\"0\",\"replacenum\":\"\",\"enablesaveimage\":\"0\",\"flashupload\":\"1\",\"alowuploadexts\":\"\",\"alowuploadlimit\":\"\"}','1','','90','1','1');
INSERT INTO `yzh_field` VALUES ('27','3','createtime','发布时间','','1','0','0','0','','w-200','datetime','','0','','99','1','1');
INSERT INTO `yzh_field` VALUES ('28','3','readgroup','访问权限','','0','0','0','0','','','groupid','{\"inputtype\":\"checkbox\",\"fieldtype\":\"tinyint\",\"numbertype\":\"1\",\"labelwidth\":\"85\",\"default\":\"\"}','1','3,4','99','1','1');
INSERT INTO `yzh_field` VALUES ('29','3','posid','推荐位','','0','0','0','0','','','posid','','1','3,4','99','1','1');
INSERT INTO `yzh_field` VALUES ('30','3','template','模板','','0','0','0','0','','','template','','0','3,4','99','0','1');
INSERT INTO `yzh_field` VALUES ('31','3','status','状态','','0','0','0','0','','','radio','{\"options\":\"\\u5df2\\u5ba1\\u6838|1\\n\\u672a\\u5ba1\\u6838|0\",\"fieldtype\":\"tinyint\",\"numbertype\":\"1\",\"labelwidth\":\"75\",\"default\":\"1\"}','0','3,4','99','1','1');
INSERT INTO `yzh_field` VALUES ('32','3','recommend','允许评论','','0','0','1','0','','','radio','{\"options\":\"\\u5141\\u8bb8\\u8bc4\\u8bba|1\\n\\u4e0d\\u5141\\u8bb8\\u8bc4\\u8bba|0\",\"fieldtype\":\"tinyint\",\"numbertype\":\"1\",\"labelwidth\":\"\",\"default\":\"\"}','0','3,4','99','1','0');
INSERT INTO `yzh_field` VALUES ('34','3','hits','点击次数','','0','0','8','0','','','number','{\"size\":\"10\",\"numbertype\":\"1\",\"decimaldigits\":\"0\",\"default\":\"0\"}','1','','99','0','0');
INSERT INTO `yzh_field` VALUES ('35','3','relation','关联产品','','0','0','0','0','','','relation','{\"modelid\":\"3\",\"fieldtype\":\"varchar\"}','0','','99','1','0');
INSERT INTO `yzh_field` VALUES ('36','4','catid','栏目','','1','1','6','0','必须选择一个栏目','w-500px','catid','','1','','0','1','1');
INSERT INTO `yzh_field` VALUES ('37','4','title','名称','','1','1','80','0','标题必须为1-80个字符','w-500px','title','{\"thumb\":\"1\",\"style\":\"0\",\"size\":\"55\"}','1','','0','1','1');
INSERT INTO `yzh_field` VALUES ('38','4','keywords','关键词','','0','0','80','0','','w-400','text','{\"size\":\"55\",\"default\":\"\",\"ispassword\":\"0\",\"fieldtype\":\"varchar\"}','1','','0','1','1');
INSERT INTO `yzh_field` VALUES ('39','4','description','SEO简介','','0','0','0','0','','w-500','textarea','{\"fieldtype\":\"mediumtext\",\"rows\":\"4\",\"cols\":\"55\",\"default\":\"\"}','1','','0','1','1');
INSERT INTO `yzh_field` VALUES ('40','4','content','内容','','0','0','0','0','','','editor','{\"toolbar\":\"full\",\"default\":\"\",\"height\":\"\",\"show_add_description\":\"0\",\"show_auto_thumb\":\"0\",\"showpage\":\"1\",\"enablekeylink\":\"0\",\"replacenum\":\"\",\"enablesaveimage\":\"0\",\"flashupload\":\"1\",\"alowuploadexts\":\"\",\"alowuploadlimit\":\"\"}','1','','0','1','1');
INSERT INTO `yzh_field` VALUES ('41','4','createtime','发布时间','','1','0','0','0','','w-200','datetime','','0','','0','1','1');
INSERT INTO `yzh_field` VALUES ('44','4','hits','点击次数','','0','0','8','0','','','number','{\"size\":\"10\",\"numbertype\":\"1\",\"decimaldigits\":\"0\",\"default\":\"0\"}','1','','0','0','0');
INSERT INTO `yzh_field` VALUES ('45','4','posid','推荐位','','0','0','0','0','','','posid','','1','3,4','0','1','1');
INSERT INTO `yzh_field` VALUES ('46','4','template','模板','','0','0','0','0','','','template','','0','3,4','0','0','1');
INSERT INTO `yzh_field` VALUES ('47','4','status','状态','','0','0','0','0','','','radio','{\"options\":\"\\u5df2\\u5ba1\\u6838|1\\n\\u672a\\u5ba1\\u6838|0\",\"fieldtype\":\"tinyint\",\"numbertype\":\"1\",\"labelwidth\":\"75\",\"default\":\"1\"}','0','3,4','0','1','1');
INSERT INTO `yzh_field` VALUES ('48','4','pics','图组','','0','0','0','0','','','images','{\"default\":\"\",\"upload_maxnum\":\"20\",\"upload_maxsize\":\"2\",\"upload_allowext\":\"jpeg,jpg,png,gif\",\"watermark\":\"0\",\"more\":\"1\"}','1','','0','1','0');
INSERT INTO `yzh_field` VALUES ('50','5','catid','栏目','','1','1','6','0','必须选择一个栏目','w-500px','catid','','1','','0','1','1');
INSERT INTO `yzh_field` VALUES ('51','5','title','标题','','1','1','80','0','标题必须为1-80个字符','w-400px','title','{\"thumb\":\"1\",\"style\":\"0\",\"size\":\"55\"}','1','','0','1','1');
INSERT INTO `yzh_field` VALUES ('52','5','keywords','关键词','','0','0','80','0','','w-400','text','{\"size\":\"55\",\"default\":\"\",\"ispassword\":\"0\",\"fieldtype\":\"varchar\"}','1','','0','1','1');
INSERT INTO `yzh_field` VALUES ('53','5','description','SEO简介','','0','0','0','0','','w-500','textarea','{\"fieldtype\":\"mediumtext\",\"rows\":\"4\",\"cols\":\"55\",\"default\":\"\"}','1','','0','1','1');
INSERT INTO `yzh_field` VALUES ('55','5','createtime','发布时间','','1','0','0','0','','w-200','datetime','','0','','93','1','1');
INSERT INTO `yzh_field` VALUES ('56','5','filepath','文件','','0','0','0','0','','w-300','file','{\"size\":\"40\",\"default\":\"\",\"upload_maxsize\":\"\",\"upload_allowext\":\"zip,rar,doc,ppt\",\"more\":\"0\"}','1','','0','1','0');
INSERT INTO `yzh_field` VALUES ('57','5','posid','推荐位','','0','0','0','0','','','posid','','1','3,4','97','1','1');
INSERT INTO `yzh_field` VALUES ('58','5','status','状态','','0','0','0','0','','','radio','{\"options\":\"\\u5ba1\\u6838|1\\n\\u672a\\u5ba1\\u6838|0\",\"fieldtype\":\"tinyint\",\"numbertype\":\"1\",\"labelwidth\":\"75\",\"default\":\"1\"}','0','3,4','99','1','1');
INSERT INTO `yzh_field` VALUES ('60','6','status','状态','','0','0','0','0','','','radio','{\"options\":\"\\u5df2\\u5ba1\\u6838|1\\n\\u672a\\u5ba1\\u6838|0\",\"fieldtype\":\"tinyint\",\"numbertype\":\"1\",\"labelwidth\":\"75\",\"default\":\"1\"}','0','3,4','99','1','1');
INSERT INTO `yzh_field` VALUES ('61','6','title','视频标题','','0','0','0','0','','w-500px','title','{\"thumb\":\"0\",\"style\":\"0\",\"size\":\"\"}','1','','1','1','0');
INSERT INTO `yzh_field` VALUES ('62','6','content','视频地址','','0','0','0','0','','','editor','{\"toolbar\":\"full\",\"default\":\"\",\"height\":\"280\",\"show_add_description\":\"0\",\"show_auto_thumb\":\"0\",\"showpage\":\"0\",\"enablekeylink\":\"0\",\"replacenum\":\"\",\"enablesaveimage\":\"0\",\"flashupload\":\"0\",\"alowuploadexts\":\"\",\"alowuploadlimit\":\"\"}','1','','2','1','0');
INSERT INTO `yzh_field` VALUES ('63','6','catid','栏目','','1','0','0','0','','w-500px','catid','','1','','0','1','0');
INSERT INTO `yzh_field` VALUES ('64','6','createtime','发布时间','','1','0','0','0','','w-200','datetime','','0','','93','1','1');
INSERT INTO `yzh_field` VALUES ('65','7','catid','栏目','','1','1','6','0','必须选择一个栏目','w-500px','catid','','1','','0','1','1');
INSERT INTO `yzh_field` VALUES ('66','7','title','标题','','1','1','80','0','标题必须为1-80个字符','w-500px','title','{\"thumb\":\"1\",\"style\":\"0\",\"size\":\"55\"}','1','','0','1','1');
INSERT INTO `yzh_field` VALUES ('67','7','keywords','关键词','','0','0','80','0','','w-400','text','{\"size\":\"55\",\"default\":\"\",\"ispassword\":\"0\",\"fieldtype\":\"varchar\"}','1','','2','1','1');
INSERT INTO `yzh_field` VALUES ('68','7','description','SEO简介','','0','0','0','0','','w-500','textarea','{\"fieldtype\":\"mediumtext\",\"rows\":\"4\",\"cols\":\"55\",\"default\":\"\"}','1','','3','1','1');
INSERT INTO `yzh_field` VALUES ('69','7','requirements','任职要求','','0','0','0','0','','','editor','{\"toolbar\":\"full\",\"default\":\"\",\"height\":\"\",\"show_add_description\":\"0\",\"show_auto_thumb\":\"0\",\"showpage\":\"1\",\"enablekeylink\":\"0\",\"replacenum\":\"\",\"enablesaveimage\":\"0\",\"flashupload\":\"1\",\"alowuploadexts\":\"\",\"alowuploadlimit\":\"\"}','1','','12','1','1');
INSERT INTO `yzh_field` VALUES ('70','7','createtime','发布时间','','0','0','0','0','','w-200','datetime','','0','','93','1','1');
INSERT INTO `yzh_field` VALUES ('71','7','education','学历','','0','0','0','0','','w-100','text','{\"size\":\"40\",\"default\":\"\",\"ispassword\":\"0\",\"fieldtype\":\"varchar\"}','1','','6','1','0');
INSERT INTO `yzh_field` VALUES ('72','7','posid','推荐位','','0','0','0','0','','','posid','','1','','97','1','1');
INSERT INTO `yzh_field` VALUES ('73','7','status','状态','','0','0','0','0','','','radio','{\"options\":\"\\u5df2\\u5ba1\\u6838|1\\n\\u672a\\u5ba1\\u6838|0\",\"fieldtype\":\"tinyint\",\"numbertype\":\"1\",\"labelwidth\":\"75\",\"default\":\"1\"}','0','3,4','99','1','1');
INSERT INTO `yzh_field` VALUES ('74','7','num','招聘人数','','0','0','0','0','','w-100','text','{\"size\":\"\",\"default\":\"\",\"ispassword\":\"0\",\"fieldtype\":\"varchar\"}','1','','5','1','0');
INSERT INTO `yzh_field` VALUES ('75','7','jobdes','工作描述','','0','0','0','0','','','editor','{\"toolbar\":\"full\",\"default\":\"\",\"height\":\"280\",\"show_add_description\":\"0\",\"show_auto_thumb\":\"0\",\"showpage\":\"0\",\"enablekeylink\":\"0\",\"replacenum\":\"\",\"enablesaveimage\":\"0\",\"flashupload\":\"0\",\"alowuploadexts\":\"\",\"alowuploadlimit\":\"\"}','1','','11','1','0');
INSERT INTO `yzh_field` VALUES ('76','1','wap_content','手机内容','','0','0','0','0','','','editor','{\"toolbar\":\"full\",\"default\":\"\",\"height\":\"280\",\"show_add_description\":\"0\",\"show_auto_thumb\":\"0\",\"showpage\":\"0\",\"enablekeylink\":\"0\",\"replacenum\":\"\",\"enablesaveimage\":\"0\",\"flashupload\":\"0\",\"alowuploadexts\":\"\",\"alowuploadlimit\":\"\"}','1','','0','1','0');
INSERT INTO `yzh_field` VALUES ('77','3','carturl','购物车链接','','0','0','0','0','','','text','{\"size\":\"\",\"default\":\"\",\"ispassword\":\"0\",\"fieldtype\":\"varchar\"}','1','','0','1','0');
--
-- 表的结构 `yzh_fiesta`
-- 
DROP TABLE IF EXISTS `yzh_fiesta`;
CREATE TABLE `yzh_fiesta` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(20) NOT NULL DEFAULT '',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `code` mediumtext NOT NULL,
  `image` varchar(60) NOT NULL DEFAULT '0',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- 
-- 导出`yzh_fiesta`表中的数据 `yzh_fiesta`
--
INSERT INTO `yzh_fiesta` VALUES ('1','元旦节','0','','/uploads/201601/568dc7d5b22a1.png','1451577600','0');
INSERT INTO `yzh_fiesta` VALUES ('2','春节','0','','/uploads/201601/568dc77d5a966.png','1455724800','0');
INSERT INTO `yzh_fiesta` VALUES ('3','劳动节','0','','/uploads/201601/568dc78a1b2a9.png','1462032000','0');
INSERT INTO `yzh_fiesta` VALUES ('4','儿童节','0','','/uploads/201601/568dc7c58dc92.png','1464710400','0');
INSERT INTO `yzh_fiesta` VALUES ('5','建军节','0','','/uploads/201601/568dc7994e20c.png','1467302400','0');
INSERT INTO `yzh_fiesta` VALUES ('6','中秋节','0','','/uploads/201601/568dc7b645a9a.png','1473868800','0');
INSERT INTO `yzh_fiesta` VALUES ('7','国庆节','0','','/uploads/201601/568dc7a872cb3.png','1475251200','0');
INSERT INTO `yzh_fiesta` VALUES ('8','圣诞节','0','','/uploads/201601/568dc76d54666.png','1482595200','0');
--
-- 表的结构 `yzh_form`
-- 
DROP TABLE IF EXISTS `yzh_form`;
CREATE TABLE `yzh_form` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `tablename` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(200) NOT NULL DEFAULT '',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `issystem` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `issearch` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `listfields` varchar(255) NOT NULL DEFAULT '',
  `setup` mediumtext NOT NULL,
  `listorder` smallint(3) unsigned NOT NULL DEFAULT '0',
  `postgroup` varchar(100) NOT NULL DEFAULT '',
  `captcha` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `sendmail` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- 
-- 导出`yzh_form`表中的数据 `yzh_form`
--
INSERT INTO `yzh_form` VALUES ('1','在线留言','Feedback','在线留言','1','0','0','title,email,tel','','0','3','1','0');
INSERT INTO `yzh_form` VALUES ('2','产品订单','Message','产品订单','1','0','0','username','','0','','0','1');
--
-- 表的结构 `yzh_form_field`
-- 
DROP TABLE IF EXISTS `yzh_form_field`;
CREATE TABLE `yzh_form_field` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `formid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `field` varchar(20) NOT NULL DEFAULT '',
  `name` varchar(30) NOT NULL DEFAULT '',
  `tips` varchar(150) NOT NULL DEFAULT '',
  `required` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `minlength` int(10) unsigned NOT NULL DEFAULT '0',
  `maxlength` int(10) unsigned NOT NULL DEFAULT '0',
  `pattern` varchar(255) NOT NULL DEFAULT '',
  `errormsg` varchar(255) NOT NULL DEFAULT '',
  `class` varchar(20) NOT NULL DEFAULT '',
  `type` varchar(20) NOT NULL DEFAULT '',
  `setup` mediumtext NOT NULL,
  `isbase` tinyint(1) NOT NULL DEFAULT '0',
  `unpostgroup` varchar(60) NOT NULL DEFAULT '',
  `listorder` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `issystem` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- 
-- 导出`yzh_form_field`表中的数据 `yzh_form_field`
--
INSERT INTO `yzh_form_field` VALUES ('1','1','username','姓名','','1','2','20','cn_username','','','text','{\"size\":\"\",\"default\":\"\",\"ispassword\":\"0\",\"fieldtype\":\"varchar\"}','1','','2','1','0');
INSERT INTO `yzh_form_field` VALUES ('2','1','title','主题','','1','4','50','0','','','text','{\"size\":\"\",\"default\":\"\",\"ispassword\":\"0\",\"fieldtype\":\"varchar\"}','1','3,4','0','1','0');
INSERT INTO `yzh_form_field` VALUES ('3','1','tel','电话','','1','0','0','tel','','','text','{\"size\":\"\",\"default\":\"\",\"ispassword\":\"0\",\"fieldtype\":\"varchar\"}','1','','4','1','0');
INSERT INTO `yzh_form_field` VALUES ('4','1','email','邮箱','','1','0','50','email','','','text','{\"size\":\"\",\"default\":\"\",\"ispassword\":\"0\",\"fieldtype\":\"varchar\"}','1','','2','1','0');
INSERT INTO `yzh_form_field` VALUES ('5','1','content','内 容','','1','4','200','0','','','textarea','{\"fieldtype\":\"mediumtext\",\"rows\":\"\",\"cols\":\"\",\"default\":\"\"}','1','','6','1','0');
INSERT INTO `yzh_form_field` VALUES ('8','2','username','您的姓名','','1','0','0','0','','','text','{\"size\":\"\",\"default\":\"\",\"ispassword\":\"0\",\"fieldtype\":\"varchar\"}','0','','0','1','0');
INSERT INTO `yzh_form_field` VALUES ('9','2','phone','手机号码','','1','0','0','mobile','','','text','{\"size\":\"\",\"default\":\"\",\"ispassword\":\"0\",\"fieldtype\":\"varchar\"}','0','','0','1','0');
INSERT INTO `yzh_form_field` VALUES ('10','2','email','邮箱','','1','0','0','0','','','text','{\"size\":\"\",\"default\":\"\",\"ispassword\":\"0\",\"fieldtype\":\"varchar\"}','0','','0','1','0');
INSERT INTO `yzh_form_field` VALUES ('11','2','product_url','产品地址','','1','0','0','0','','','text','{\"size\":\"\",\"default\":\"\",\"ispassword\":\"0\",\"fieldtype\":\"varchar\"}','0','','0','1','0');
INSERT INTO `yzh_form_field` VALUES ('12','2','product_name','产品名称','','1','0','0','0','','','text','{\"size\":\"\",\"default\":\"\",\"ispassword\":\"0\",\"fieldtype\":\"varchar\"}','0','','0','1','0');
INSERT INTO `yzh_form_field` VALUES ('13','2','content','内容','','1','0','0','0','','','textarea','{\"fieldtype\":\"mediumtext\",\"rows\":\"\",\"cols\":\"\",\"default\":\"\"}','0','','0','1','0');
INSERT INTO `yzh_form_field` VALUES ('14','1','address','地址','','0','0','0','0','','','text','{\"size\":\"\",\"default\":\"\",\"ispassword\":\"0\",\"fieldtype\":\"varchar\"}','0','','0','1','0');
INSERT INTO `yzh_form_field` VALUES ('15','1','city','所在城市','','0','0','0','0','','','text','{\"size\":\"\",\"default\":\"\",\"ispassword\":\"0\",\"fieldtype\":\"varchar\"}','0','','0','1','0');
--
-- 表的结构 `yzh_hits`
-- 
DROP TABLE IF EXISTS `yzh_hits`;
CREATE TABLE `yzh_hits` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `views` int(10) NOT NULL COMMENT '点击总数',
  `yesterdayviews` int(10) NOT NULL COMMENT '昨天点击',
  `dayviews` int(10) NOT NULL COMMENT '今日点击',
  `weekviews` int(10) NOT NULL COMMENT '本周点击',
  `monthviews` int(10) NOT NULL COMMENT '本月点击',
  `viewsupdatetime` int(10) NOT NULL COMMENT '访问数修改时间',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1为pc(ip),2为pc(pv),3为mobile(ip),4为mobile(pv)',
  `lang` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='浏览记录';
--
-- 表的结构 `yzh_hits_info`
-- 
DROP TABLE IF EXISTS `yzh_hits_info`;
CREATE TABLE `yzh_hits_info` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `hits` int(10) NOT NULL COMMENT '点击量总数',
  `y` int(10) NOT NULL COMMENT '年',
  `m` int(10) NOT NULL COMMENT '月',
  `d` int(10) NOT NULL COMMENT '日',
  `type` tinyint(1) NOT NULL COMMENT '1为pc(ip),2为pc(pv),3为mobile(ip),4为mobile(pv)',
  `inputtime` int(10) NOT NULL COMMENT '录入时间',
  `lang` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COMMENT='当天点击量log';

-- 
-- 导出`yzh_hits_info`表中的数据 `yzh_hits_info`
--
INSERT INTO `yzh_hits_info` VALUES ('1','1','2018','201801','20180126','1','1516958412','1');
INSERT INTO `yzh_hits_info` VALUES ('2','1','2018','201801','20180126','2','1516958412','1');
INSERT INTO `yzh_hits_info` VALUES ('3','1','2018','201802','20180201','1','1517473908','1');
INSERT INTO `yzh_hits_info` VALUES ('4','1','2018','201802','20180201','2','1517473908','1');
INSERT INTO `yzh_hits_info` VALUES ('5','1','2018','201802','20180204','1','1517731492','1');
INSERT INTO `yzh_hits_info` VALUES ('6','1','2018','201802','20180204','2','1517731492','1');
INSERT INTO `yzh_hits_info` VALUES ('7','1','2018','201802','20180205','1','1517836455','1');
INSERT INTO `yzh_hits_info` VALUES ('8','1','2018','201802','20180205','2','1517836455','1');
INSERT INTO `yzh_hits_info` VALUES ('9','1','2018','201802','20180208','1','1518102386','1');
INSERT INTO `yzh_hits_info` VALUES ('10','1','2018','201802','20180208','2','1518102386','1');
INSERT INTO `yzh_hits_info` VALUES ('11','1','2018','201802','20180211','1','1518360941','1');
INSERT INTO `yzh_hits_info` VALUES ('12','1','2018','201802','20180211','2','1518360941','1');
INSERT INTO `yzh_hits_info` VALUES ('13','1','2018','201802','20180212','1','1518438236','1');
INSERT INTO `yzh_hits_info` VALUES ('14','1','2018','201802','20180212','2','1518438236','1');
INSERT INTO `yzh_hits_info` VALUES ('15','1','2018','201802','20180214','1','1518552079','1');
INSERT INTO `yzh_hits_info` VALUES ('16','1','2018','201802','20180214','2','1518552079','1');
INSERT INTO `yzh_hits_info` VALUES ('17','1','2018','201802','20180226','1','1519640688','1');
INSERT INTO `yzh_hits_info` VALUES ('18','1','2018','201802','20180226','2','1519640688','1');
INSERT INTO `yzh_hits_info` VALUES ('19','1','2018','201802','20180228','1','1519784692','1');
INSERT INTO `yzh_hits_info` VALUES ('20','5','2018','201802','20180228','2','1519784692','1');
INSERT INTO `yzh_hits_info` VALUES ('21','1','2018','201803','20180301','1','1519873110','1');
INSERT INTO `yzh_hits_info` VALUES ('22','2','2018','201803','20180301','2','1519873110','1');
INSERT INTO `yzh_hits_info` VALUES ('23','1','2018','201803','20180302','1','1519976521','1');
INSERT INTO `yzh_hits_info` VALUES ('24','2','2018','201803','20180302','2','1519976521','1');
INSERT INTO `yzh_hits_info` VALUES ('25','2','2018','201803','20180303','1','1520041469','1');
INSERT INTO `yzh_hits_info` VALUES ('26','2','2018','201803','20180303','2','1520041469','1');
INSERT INTO `yzh_hits_info` VALUES ('27','1','2018','201803','20180306','1','1520317879','1');
INSERT INTO `yzh_hits_info` VALUES ('28','4','2018','201803','20180306','2','1520317879','1');
--
-- 表的结构 `yzh_hits_iplog`
-- 
DROP TABLE IF EXISTS `yzh_hits_iplog`;
CREATE TABLE `yzh_hits_iplog` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ip` char(15) NOT NULL,
  `type` tinyint(1) NOT NULL COMMENT '1为pc ip 2 为mobile ip',
  `y` int(10) NOT NULL COMMENT '年',
  `m` int(10) NOT NULL COMMENT '月',
  `d` int(10) NOT NULL COMMENT '天',
  `address` varchar(50) NOT NULL,
  `inputtime` int(10) NOT NULL COMMENT '录入时间',
  `lang` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='当天ip记录';

-- 
-- 导出`yzh_hits_iplog`表中的数据 `yzh_hits_iplog`
--
INSERT INTO `yzh_hits_iplog` VALUES ('1','219.134.217.200','1','2018','201801','20180126','中国','1516958412','1');
INSERT INTO `yzh_hits_iplog` VALUES ('2','219.133.159.198','1','2018','201802','20180201','中国','1517473908','1');
INSERT INTO `yzh_hits_iplog` VALUES ('3','113.117.248.1','1','2018','201802','20180204','中国','1517731492','1');
INSERT INTO `yzh_hits_iplog` VALUES ('4','113.117.248.1','1','2018','201802','20180205','中国','1517836455','1');
INSERT INTO `yzh_hits_iplog` VALUES ('5','113.117.245.126','1','2018','201802','20180208','中国','1518102386','1');
INSERT INTO `yzh_hits_iplog` VALUES ('6','119.165.121.160','1','2018','201802','20180211','中国','1518360939','1');
INSERT INTO `yzh_hits_iplog` VALUES ('7','113.117.250.33','1','2018','201802','20180212','中国','1518438236','1');
INSERT INTO `yzh_hits_iplog` VALUES ('8','220.181.132.179','1','2018','201802','20180214','中国','1518552079','1');
INSERT INTO `yzh_hits_iplog` VALUES ('9','113.117.246.100','1','2018','201802','20180226','中国','1519640688','1');
INSERT INTO `yzh_hits_iplog` VALUES ('10','119.123.0.74','1','2018','201802','20180228','中国','1519784692','1');
INSERT INTO `yzh_hits_iplog` VALUES ('11','119.123.0.216','1','2018','201803','20180301','中国','1519873110','1');
INSERT INTO `yzh_hits_iplog` VALUES ('12','113.117.247.170','1','2018','201803','20180302','中国','1519976521','1');
INSERT INTO `yzh_hits_iplog` VALUES ('13','223.80.243.54','1','2018','201803','20180303','中国','1520041469','1');
INSERT INTO `yzh_hits_iplog` VALUES ('14','113.118.184.16','1','2018','201803','20180303','中国','1520055659','1');
INSERT INTO `yzh_hits_iplog` VALUES ('15','119.123.30.19','1','2018','201803','20180306','中国','1520317879','1');
--
-- 表的结构 `yzh_hotpage`
-- 
DROP TABLE IF EXISTS `yzh_hotpage`;
CREATE TABLE `yzh_hotpage` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(60) NOT NULL,
  `content` mediumtext NOT NULL,
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
--
-- 表的结构 `yzh_hotpage_message`
-- 
DROP TABLE IF EXISTS `yzh_hotpage_message`;
CREATE TABLE `yzh_hotpage_message` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `hotpage_id` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `username` varchar(255) NOT NULL DEFAULT '',
  `contact` varchar(255) NOT NULL DEFAULT '',
  `content` mediumtext NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
--
-- 表的结构 `yzh_job`
-- 
DROP TABLE IF EXISTS `yzh_job`;
CREATE TABLE `yzh_job` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userid` int(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(40) NOT NULL DEFAULT '',
  `title` varchar(120) NOT NULL DEFAULT '',
  `title_style` varchar(40) NOT NULL DEFAULT '',
  `thumb` varchar(100) NOT NULL DEFAULT '',
  `keywords` varchar(120) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  `requirements` text NOT NULL,
  `url` varchar(60) NOT NULL DEFAULT '',
  `posid` varchar(50) NOT NULL DEFAULT '',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `listorder` int(10) unsigned NOT NULL DEFAULT '0',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  `num` varchar(255) NOT NULL DEFAULT '',
  `jobdes` text NOT NULL,
  `education` varchar(255) NOT NULL DEFAULT '',
  `lang` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `status` (`id`,`status`,`listorder`),
  KEY `catid` (`id`,`catid`,`status`),
  KEY `listorder` (`id`,`catid`,`status`,`listorder`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
--
-- 表的结构 `yzh_kefu`
-- 
DROP TABLE IF EXISTS `yzh_kefu`;
CREATE TABLE `yzh_kefu` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `listorder` int(10) unsigned NOT NULL DEFAULT '0',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `name` varchar(20) NOT NULL DEFAULT '',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `code` mediumtext NOT NULL,
  `skin` varchar(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
--
-- 表的结构 `yzh_lang`
-- 
DROP TABLE IF EXISTS `yzh_lang`;
CREATE TABLE `yzh_lang` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  `mark` varchar(30) NOT NULL DEFAULT '',
  `flag` varchar(100) NOT NULL DEFAULT '',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `path` varchar(30) NOT NULL DEFAULT '',
  `domain` varchar(30) NOT NULL DEFAULT '',
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- 
-- 导出`yzh_lang`表中的数据 `yzh_lang`
--
INSERT INTO `yzh_lang` VALUES ('1','中文','cn','china.png','1','','','1');
INSERT INTO `yzh_lang` VALUES ('2','英文','en','usa.png','0','','','0');
--
-- 表的结构 `yzh_link`
-- 
DROP TABLE IF EXISTS `yzh_link`;
CREATE TABLE `yzh_link` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `listorder` int(10) unsigned NOT NULL DEFAULT '0',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT '',
  `weblogo` varchar(80) NOT NULL DEFAULT '',
  `siteurl` varchar(150) NOT NULL DEFAULT '',
  `typeid` smallint(5) unsigned NOT NULL,
  `linktype` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `siteinfo` mediumtext NOT NULL,
  `lang` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
--
-- 表的结构 `yzh_member`
-- 
DROP TABLE IF EXISTS `yzh_member`;
CREATE TABLE `yzh_member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupid` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `username` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(50) NOT NULL DEFAULT '',
  `realname` varchar(50) NOT NULL DEFAULT '',
  `question` varchar(50) NOT NULL DEFAULT '',
  `answer` varchar(50) NOT NULL DEFAULT '',
  `sex` tinyint(1) NOT NULL DEFAULT '0',
  `tel` varchar(50) NOT NULL DEFAULT '',
  `mobile` varchar(50) NOT NULL DEFAULT '',
  `address` varchar(100) NOT NULL DEFAULT '',
  `login_count` int(11) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  `reg_ip` char(15) NOT NULL DEFAULT '',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `last_ip` char(15) NOT NULL DEFAULT '',
  `last_logintime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `amount` decimal(8,2) unsigned NOT NULL DEFAULT '0.00',
  `point` smallint(5) unsigned NOT NULL DEFAULT '0',
  `avatar` varchar(120) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
--
-- 表的结构 `yzh_member_address`
-- 
DROP TABLE IF EXISTS `yzh_member_address`;
CREATE TABLE `yzh_member_address` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `consignee` varchar(60) NOT NULL DEFAULT '',
  `email` varchar(60) NOT NULL DEFAULT '',
  `country` smallint(5) unsigned NOT NULL DEFAULT '0',
  `province` smallint(5) unsigned NOT NULL DEFAULT '0',
  `city` smallint(5) unsigned NOT NULL DEFAULT '0',
  `area` smallint(5) unsigned NOT NULL DEFAULT '0',
  `address` varchar(120) NOT NULL DEFAULT '',
  `zipcode` varchar(60) NOT NULL DEFAULT '',
  `tel` varchar(60) NOT NULL DEFAULT '',
  `mobile` varchar(60) NOT NULL DEFAULT '',
  `isdefault` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
--
-- 表的结构 `yzh_member_config`
-- 
DROP TABLE IF EXISTS `yzh_member_config`;
CREATE TABLE `yzh_member_config` (
  `id` smallint(8) unsigned NOT NULL AUTO_INCREMENT,
  `varname` varchar(25) NOT NULL DEFAULT '',
  `info` varchar(100) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `varname` (`varname`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- 
-- 导出`yzh_member_config`表中的数据 `yzh_member_config`
--
INSERT INTO `yzh_member_config` VALUES ('1','register','允许新会员注册','1','0');
INSERT INTO `yzh_member_config` VALUES ('2','emailcheck','新会员注册需要邮件验证','0','0');
INSERT INTO `yzh_member_config` VALUES ('3','registecheck','新会员注册需要审核','1','0');
INSERT INTO `yzh_member_config` VALUES ('4','login_verify','注册登陆开启验证码','1','0');
INSERT INTO `yzh_member_config` VALUES ('5','emailchecktpl','邮件认证模板',' 欢迎您注册成为[国人在线]用户，您的账号需要邮箱认证，点击下面链接进行认证：{click}\r\n或者将网址复制到浏览器：{url}','0');
INSERT INTO `yzh_member_config` VALUES ('6','getpwdemaitpl','密码找回邮件内容','尊敬的用户{username}，请点击进入<a href=\\\\\\\"{url}\\\\\\\">重置密码</a>,或者将网址复制到浏览器：{url}（链接3天内有效）。<br>感谢您对本站的支持。<br>　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　{sitename}<br>此邮件为系统自动邮件，无需回复。','0');
--
-- 表的结构 `yzh_member_group`
-- 
DROP TABLE IF EXISTS `yzh_member_group`;
CREATE TABLE `yzh_member_group` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL DEFAULT '',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `remark` varchar(255) NOT NULL DEFAULT '',
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listorder` smallint(6) unsigned NOT NULL DEFAULT '0',
  `allowpost` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowpostverify` tinyint(1) unsigned NOT NULL,
  `allowsearch` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowupgrade` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `allowsendmessage` tinyint(1) unsigned NOT NULL,
  `allowattachment` tinyint(1) NOT NULL,
  `maxpostnum` smallint(5) unsigned NOT NULL DEFAULT '0',
  `maxmessagenum` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- 
-- 导出`yzh_member_group`表中的数据 `yzh_member_group`
--
INSERT INTO `yzh_member_group` VALUES ('1','普通会员','1','','0','0','0','0','0','1','0','0','0','0');
--
-- 表的结构 `yzh_menu`
-- 
DROP TABLE IF EXISTS `yzh_menu`;
CREATE TABLE `yzh_menu` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `model` char(20) NOT NULL DEFAULT '',
  `action` char(20) NOT NULL DEFAULT '',
  `data` char(50) NOT NULL DEFAULT '',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `group` varchar(30) NOT NULL DEFAULT '',
  `name` varchar(50) NOT NULL DEFAULT '',
  `icon` varchar(255) DEFAULT NULL,
  `remark` varchar(255) NOT NULL DEFAULT '',
  `listorder` smallint(6) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `parentid` (`parentid`),
  KEY `model` (`model`)
) ENGINE=MyISAM AUTO_INCREMENT=321 DEFAULT CHARSET=utf8;

-- 
-- 导出`yzh_menu`表中的数据 `yzh_menu`
--
INSERT INTO `yzh_menu` VALUES ('37','131','Theme','index','','1','Admin','模板主题','fa fa-th-large','','0');
INSERT INTO `yzh_menu` VALUES ('50','97','Menu','index','','1','Admin','后台菜单','fa fa-th-large','','0');
INSERT INTO `yzh_menu` VALUES ('51','145','Index','theme','','1','Wap','主题管理','fa fa-th-large','','0');
INSERT INTO `yzh_menu` VALUES ('58','207','Resume','view','','1','Admin','查看','fa fa-th-large','','0');
INSERT INTO `yzh_menu` VALUES ('68','208','Hotpage','add','','1','Admin','新增','','','0');
INSERT INTO `yzh_menu` VALUES ('78','208','Hotpage','edit','','1','Admin','编辑','','','0');
INSERT INTO `yzh_menu` VALUES ('101','57','','','','1','Admin','商品管理','fa fa-th-large','','0');
INSERT INTO `yzh_menu` VALUES ('172','0','Index','main','','1','Admin','首页','fa fa-home','','1');
INSERT INTO `yzh_menu` VALUES ('173','0','Config','index','','1','admin','系统','fa fa-cogs','','2');
INSERT INTO `yzh_menu` VALUES ('174','173','','','','1','','站点设置','','','0');
INSERT INTO `yzh_menu` VALUES ('175','174','Config','index','','1','admin','基础设置','fa fa-cog','','1');
INSERT INTO `yzh_menu` VALUES ('176','302','Menu','index','','1','admin','后台菜单','fa fa-list-alt','','0');
INSERT INTO `yzh_menu` VALUES ('177','176','Menu','add','','1','Admin','新增','','','0');
INSERT INTO `yzh_menu` VALUES ('178','176','Menu','edit','','1','Admin','编辑','','','0');
INSERT INTO `yzh_menu` VALUES ('179','174','User','index','','1','admin','管理员管理','fa fa-user','','3');
INSERT INTO `yzh_menu` VALUES ('180','174','Role','index','','1','admin','角色管理','fa fa-users','','4');
INSERT INTO `yzh_menu` VALUES ('181','174','Database','index','','1','Admin','数据备份','fa fa-database','','5');
INSERT INTO `yzh_menu` VALUES ('182','174','Sysconfig','mail','','1','Admin','邮箱设置','fa fa-bars','','4');
INSERT INTO `yzh_menu` VALUES ('183','302','Action','actionlog','','1','admin','登陆日志','fa fa-bars','','0');
INSERT INTO `yzh_menu` VALUES ('184','0','Category','index','','1','Admin','内容','fa fa-edit','','3');
INSERT INTO `yzh_menu` VALUES ('185','184','','','','1','','内容管理','fa fa-th-large','','0');
INSERT INTO `yzh_menu` VALUES ('186','185','Page','index','','1','Admin','单页管理','fa fa-th-large','','0');
INSERT INTO `yzh_menu` VALUES ('187','185','Article','index','','1','Admin','文章管理','fa fa-th-large','','0');
INSERT INTO `yzh_menu` VALUES ('188','185','Product','index','','1','Admin','产品管理','fa fa-file','','0');
INSERT INTO `yzh_menu` VALUES ('189','184','Category','index','','1','Admin','内容相关','','','0');
INSERT INTO `yzh_menu` VALUES ('190','185','Picture','index','','1','admin','图片管理','fa fa-file','','0');
INSERT INTO `yzh_menu` VALUES ('191','199','Selfmenu','index','','1','Admin','自定义菜单','fa fa-comment','','4');
INSERT INTO `yzh_menu` VALUES ('192','293','Tags','index','','0','admin','网站标签管理','fa fa-tags','','4');
INSERT INTO `yzh_menu` VALUES ('193','189','Category','index','','1','admin','栏目管理','fa fa-th-list','','1');
INSERT INTO `yzh_menu` VALUES ('194','0','Wap','config','','1','admin','移动','fa fa-tablet','','5');
INSERT INTO `yzh_menu` VALUES ('195','194','Wap','config','','1','Admin','全网营销','fa fa-file','','0');
INSERT INTO `yzh_menu` VALUES ('196','194','','','','0','','微应用','','','0');
INSERT INTO `yzh_menu` VALUES ('197','195','Wap','config','','1','admin','手机设置','fa fa-cogs','','0');
INSERT INTO `yzh_menu` VALUES ('198','195','Slide','picmanage','fid=2','1','admin','手机广告','fa fa-th-large','','0');
INSERT INTO `yzh_menu` VALUES ('199','195','Wechat','bind','','1','admin','微信设置','fa fa-comments','','0');
INSERT INTO `yzh_menu` VALUES ('200','284','','','','1','','网站运营','','','0');
INSERT INTO `yzh_menu` VALUES ('201','293','Link','index','','1','admin','友情链接','fa fa-file','','1');
INSERT INTO `yzh_menu` VALUES ('202','200','Kefu','index','','1','admin','客服设置','fa fa-file','','0');
INSERT INTO `yzh_menu` VALUES ('203','200','Fiesta','index','','0','Admin','节日营销','fa fa-file','','0');
INSERT INTO `yzh_menu` VALUES ('204','200','Plugin','baidumap','','1','Admin','电子地图','fa fa-map','','0');
INSERT INTO `yzh_menu` VALUES ('205','200','Form','index','','1','Admin','反馈管理','fa fa-file','','0');
INSERT INTO `yzh_menu` VALUES ('206','293','Plugin','engines','','1','Admin','搜索引擎提交','fa fa-file','','2');
INSERT INTO `yzh_menu` VALUES ('207','200','Resume','index','','0','Admin','人才管理库','fa fa-user','','0');
INSERT INTO `yzh_menu` VALUES ('208','200','Hotpage','index','','0','Admin','爆品转化页','fa fa-file','','0');
INSERT INTO `yzh_menu` VALUES ('209','293','Createhtml','sitemap','','1','admin','网站地图生成','fa fa-file','','3');
INSERT INTO `yzh_menu` VALUES ('210','0','Member','index','','0','Admin','商城','fa fa-shopping-cart','','6');
INSERT INTO `yzh_menu` VALUES ('211','210','Member','index','','1','Admin','会员管理','fa fa-user','','0');
INSERT INTO `yzh_menu` VALUES ('212','210','','','','1','','订单管理','','','0');
INSERT INTO `yzh_menu` VALUES ('213','211','Member','index','','1','admin','会员列表','fa fa-user','','0');
INSERT INTO `yzh_menu` VALUES ('214','211','Member','config','','1','admin','会员设置','fa fa-cogs','','0');
INSERT INTO `yzh_menu` VALUES ('215','212','Payment','index','','1','admin','支付管理','fa fa-file','','0');
INSERT INTO `yzh_menu` VALUES ('216','211','MemberGroup','index','','1','admin','会员组管理','fa fa-users','','0');
INSERT INTO `yzh_menu` VALUES ('217','212','Order','index','','1','admin','订单管理','fa fa-file','','0');
INSERT INTO `yzh_menu` VALUES ('218','199','Wechat','welcome','','1','admin','首次关注欢迎信息','fa fa-cogs','','0');
INSERT INTO `yzh_menu` VALUES ('219','199','Wechat','robot','','1','Admin','自动回复','fa fa-file','','0');
INSERT INTO `yzh_menu` VALUES ('220','196','Vcard','index','','1','Admin','微名片','fa fa-file','','0');
INSERT INTO `yzh_menu` VALUES ('221','196','Poster','index','','1','Admin','微海报','fa fa-file','','0');
INSERT INTO `yzh_menu` VALUES ('222','201','Link','add','','1','Admin','新增','','','0');
INSERT INTO `yzh_menu` VALUES ('223','201','Link','edit','','1','Admin','编辑','','','0');
INSERT INTO `yzh_menu` VALUES ('224','202','Kefu','add','','1','Admin','新增','','','0');
INSERT INTO `yzh_menu` VALUES ('225','186','Page','add','','1','Admin','新增','','','0');
INSERT INTO `yzh_menu` VALUES ('226','186','Page','edit','','1','Admin','编辑','','','0');
INSERT INTO `yzh_menu` VALUES ('227','179','User','add','','1','Admin','新增','fa fa-user','','0');
INSERT INTO `yzh_menu` VALUES ('228','202','Kefu','edit','','1','Admin','编辑','','','0');
INSERT INTO `yzh_menu` VALUES ('229','220','Vcard','add','','1','Admin','新增','','','0');
INSERT INTO `yzh_menu` VALUES ('230','190','Picture','add','','1','Admin','新增','','','0');
INSERT INTO `yzh_menu` VALUES ('231','179','User','edit','','1','Admin','编辑','','','0');
INSERT INTO `yzh_menu` VALUES ('232','180','Role','add','','1','Admin','新增','','','0');
INSERT INTO `yzh_menu` VALUES ('233','180','Role','edit','','1','Admin','编辑','','','0');
INSERT INTO `yzh_menu` VALUES ('234','193','Category','add','','1','Admin','新增','','','0');
INSERT INTO `yzh_menu` VALUES ('235','187','Article','add','','1','Admin','新增','','','0');
INSERT INTO `yzh_menu` VALUES ('236','187','Article','edit','','1','Admin','编辑','','','0');
INSERT INTO `yzh_menu` VALUES ('237','193','Category','edit','','1','Admin','编辑','','','0');
INSERT INTO `yzh_menu` VALUES ('238','174','Sysconfig','index','','1','Admin','系统设置','fa fa-user','','2');
INSERT INTO `yzh_menu` VALUES ('239','190','Picture','edit','','1','Admin','编辑','','','0');
INSERT INTO `yzh_menu` VALUES ('240','188','Product','add','','1','Admin','新增','','','0');
INSERT INTO `yzh_menu` VALUES ('241','220','Vcard','edit','','1','Admin','编辑','','','0');
INSERT INTO `yzh_menu` VALUES ('242','188','Product','edit','','1','Admin','编辑','','','0');
INSERT INTO `yzh_menu` VALUES ('243','213','Member','add','','1','Admin','新增','','','0');
INSERT INTO `yzh_menu` VALUES ('244','185','Download','index','','0','Admin','下载管理','fa fa-th-large','','0');
INSERT INTO `yzh_menu` VALUES ('245','185','Job','index','','0','Admin','招聘管理','fa fa-th-large','','0');
INSERT INTO `yzh_menu` VALUES ('246','244','Download','add','','1','Admin','新增','','','0');
INSERT INTO `yzh_menu` VALUES ('247','244','Download','edit','','1','Admin','编辑','','','0');
INSERT INTO `yzh_menu` VALUES ('248','245','Job','add','','1','Admin','新增','','','0');
INSERT INTO `yzh_menu` VALUES ('249','245','Job','edit','','1','Admin','编辑','','','0');
INSERT INTO `yzh_menu` VALUES ('250','181','Database','recover','','1','Admin','备份管理','','','0');
INSERT INTO `yzh_menu` VALUES ('251','192','Tag','index','','1','Admin','新增','','','0');
INSERT INTO `yzh_menu` VALUES ('252','254','Slide','editpic','','1','Admin','编辑图片','','','0');
INSERT INTO `yzh_menu` VALUES ('253','189','Createhtml','update_urls','','1','Admin','批量更新URL','fa fa-file','','5');
INSERT INTO `yzh_menu` VALUES ('254','189','Slide','index','','1','Admin','广告管理','fa fa-file','','2');
INSERT INTO `yzh_menu` VALUES ('255','203','Fiesta','add','','1','Admin','新增','','','0');
INSERT INTO `yzh_menu` VALUES ('256','203','Fiesta','edit','','1','Admin','编辑','','','0');
INSERT INTO `yzh_menu` VALUES ('258','180','Role','access','','1','Admin','权限设置','','','0');
INSERT INTO `yzh_menu` VALUES ('259','216','MemberGroup','add','','1','Admin','新增','','','0');
INSERT INTO `yzh_menu` VALUES ('260','216','MemberGroup','edit','','1','Admin','编辑','','','0');
INSERT INTO `yzh_menu` VALUES ('261','221','Poster','add','','1','Admin','新增','','','0');
INSERT INTO `yzh_menu` VALUES ('262','213','Member','edit','','1','Admin','编辑','','','0');
INSERT INTO `yzh_menu` VALUES ('263','254','Slide','add','','1','Admin','新增','','','0');
INSERT INTO `yzh_menu` VALUES ('264','254','Slide','edit','','1','Admin','编辑','','','0');
INSERT INTO `yzh_menu` VALUES ('265','254','Slide','picmanage','','1','Admin','图片管理','','','0');
INSERT INTO `yzh_menu` VALUES ('266','254','Slide','addpic','','1','Admin','新增图片','','','0');
INSERT INTO `yzh_menu` VALUES ('267','208','Hotpage','message','','1','Admin','留言管理','','','0');
INSERT INTO `yzh_menu` VALUES ('268','302','Node','index','','0','Admin','节点管理','fa fa-file','','5');
INSERT INTO `yzh_menu` VALUES ('269','268','Node','add','','1','Admin','新增','','','0');
INSERT INTO `yzh_menu` VALUES ('270','268','Node','edit','','1','Admin','编辑','','','0');
INSERT INTO `yzh_menu` VALUES ('271','174','Attachment','index','','1','Admin','附件管理器','fa fa-th-large','','7');
INSERT INTO `yzh_menu` VALUES ('272','271','Attachment','add','','1','Admin','新增','','','0');
INSERT INTO `yzh_menu` VALUES ('273','271','Attachment','edit','','1','Admin','编辑','','','0');
INSERT INTO `yzh_menu` VALUES ('274','183','Action','detail','','1','Admin','详细','','','0');
INSERT INTO `yzh_menu` VALUES ('275','198','Wap','editslide','','1','admin','编辑','','','0');
INSERT INTO `yzh_menu` VALUES ('276','302','Model','index','','1','admin','模型管理','fa fa-bars','','0');
INSERT INTO `yzh_menu` VALUES ('277','276','Model','add','','1','admin','新增','','','0');
INSERT INTO `yzh_menu` VALUES ('278','276','Model','edit','','1','admin','编辑','','','0');
INSERT INTO `yzh_menu` VALUES ('279','276','Field','index','','1','admin','字段管理','','','0');
INSERT INTO `yzh_menu` VALUES ('280','279','Field','add','','1','admin','新增','','','0');
INSERT INTO `yzh_menu` VALUES ('281','279','Field','edit','','1','admin','编辑','','','0');
INSERT INTO `yzh_menu` VALUES ('282','172','','','','1','','我的面板','','','0');
INSERT INTO `yzh_menu` VALUES ('283','172','','','','1','','快捷操作','','','0');
INSERT INTO `yzh_menu` VALUES ('284','0','Link','index','','1','Admin','运营','fa fa-bar-chart-o','','4');
INSERT INTO `yzh_menu` VALUES ('285','205','Form','add','','1','Admin','新增','','','0');
INSERT INTO `yzh_menu` VALUES ('286','283','Shortcuts','index','','1','Admin','快捷操作管理','','','0');
INSERT INTO `yzh_menu` VALUES ('287','286','Shortcuts','add','','1','Admin','新增','','','0');
INSERT INTO `yzh_menu` VALUES ('288','286','Shortcuts','edit','','1','Admin','编辑','','','0');
INSERT INTO `yzh_menu` VALUES ('289','200','Email','index','','0','Admin','邮件营销','fa fa-envelope','','0');
INSERT INTO `yzh_menu` VALUES ('290','293','Plugin','statistics','','1','Admin','流量统计','fa fa-area-chart','','5');
INSERT INTO `yzh_menu` VALUES ('291','221','Poster','edit','','1','Admin','编辑','','','0');
INSERT INTO `yzh_menu` VALUES ('292','174','Upgrade','index','','1','Admin','程序升级','fa fa-file','','7');
INSERT INTO `yzh_menu` VALUES ('293','284','','','','1','','搜索优化','','','0');
INSERT INTO `yzh_menu` VALUES ('294','189','Block','index','','1','Admin','碎片管理','fa fa-file','','1');
INSERT INTO `yzh_menu` VALUES ('295','294','Block','add','','1','Admin','新增','','','0');
INSERT INTO `yzh_menu` VALUES ('296','294','Block','edit','','1','Admin','编辑','','','0');
INSERT INTO `yzh_menu` VALUES ('297','302','Config','mylist','','1','Admin','自定义变量管理','fa fa-th-large','','10');
INSERT INTO `yzh_menu` VALUES ('298','297','Config','add','','1','Admin','新增','','','0');
INSERT INTO `yzh_menu` VALUES ('299','297','Config','edit','','1','Admin','编辑','','','0');
INSERT INTO `yzh_menu` VALUES ('300','207','Resume','detail','','1','Admin','详细','','','0');
INSERT INTO `yzh_menu` VALUES ('301','217','Order','detail','','1','admin','查看详细信息','','','0');
INSERT INTO `yzh_menu` VALUES ('302','173','','','','1','','系统维护','','','0');
INSERT INTO `yzh_menu` VALUES ('303','205','Form','edit','','1','Admin','编辑','','','0');
INSERT INTO `yzh_menu` VALUES ('304','205','Formfield','index','','1','Admin','字段','','','0');
INSERT INTO `yzh_menu` VALUES ('305','304','Formfield','add','','1','Admin','新增','','','0');
INSERT INTO `yzh_menu` VALUES ('306','304','Formfield','edit','','1','Admin','编辑','','','0');
INSERT INTO `yzh_menu` VALUES ('307','205','Form','content','','1','Admin','内容维护','','','0');
INSERT INTO `yzh_menu` VALUES ('308','307','Form','contentedit','','1','Admin','查看/修改','','','0');
INSERT INTO `yzh_menu` VALUES ('309','185','Video','index','','0','Admin','视频信息','fa fa-th-large','','0');
INSERT INTO `yzh_menu` VALUES ('310','309','Video','add','','1','Admin','新增','','','0');
INSERT INTO `yzh_menu` VALUES ('311','309','Video','edit','','1','Admin','编辑','','','0');
INSERT INTO `yzh_menu` VALUES ('312','200','Plugin','hotwords','','1','Admin','热门关键词','fa fa-th-large','','0');
INSERT INTO `yzh_menu` VALUES ('313','200','Plugin','mainpro','','1','Admin','主营产品','fa fa-th-large','','0');
INSERT INTO `yzh_menu` VALUES ('314','302','Visual','datacall','','0','Admin','可视化编辑参数','fa fa-th-large','','0');
INSERT INTO `yzh_menu` VALUES ('315','302','Lang','index','','1','Admin','语言管理','fa fa-language','','0');
INSERT INTO `yzh_menu` VALUES ('316','302','Sysconfig','advanced','','1','Admin','高级设置','fa fa-file','','5');
INSERT INTO `yzh_menu` VALUES ('317','315','Lang','add','','1','Admin','新增','','','0');
INSERT INTO `yzh_menu` VALUES ('318','315','Lang','edit','','1','Admin','编辑','','','0');
INSERT INTO `yzh_menu` VALUES ('319','195','Wap','theme','','0','Admin','主题选择','fa fa-file','','0');
INSERT INTO `yzh_menu` VALUES ('320','302','Posid','index','','1','Admin','推荐设置','fa fa-file','','5');
--
-- 表的结构 `yzh_message`
-- 
DROP TABLE IF EXISTS `yzh_message`;
CREATE TABLE `yzh_message` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip` char(15) NOT NULL,
  `userid` int(8) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  `username` varchar(40) NOT NULL DEFAULT '',
  `phone` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `content` mediumtext NOT NULL,
  `product_url` varchar(255) NOT NULL DEFAULT '',
  `product_name` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
--
-- 表的结构 `yzh_model`
-- 
DROP TABLE IF EXISTS `yzh_model`;
CREATE TABLE `yzh_model` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `tablename` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(200) NOT NULL DEFAULT '',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `issystem` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `issearch` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `listfields` varchar(255) NOT NULL DEFAULT '',
  `setup` mediumtext NOT NULL,
  `listorder` smallint(3) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `postgroup` varchar(100) NOT NULL DEFAULT '',
  `ispost` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- 
-- 导出`yzh_model`表中的数据 `yzh_model`
--
INSERT INTO `yzh_model` VALUES ('1','单页面','Page','单页信息','1','1','0','*','','0','1','','0');
INSERT INTO `yzh_model` VALUES ('2','文章模型','Article','文章信息','1','1','1','*','','0','1','','0');
INSERT INTO `yzh_model` VALUES ('3','产品模型','Product','产品信息','1','1','1','*','','0','1','','0');
INSERT INTO `yzh_model` VALUES ('4','图片模型','Picture','图片信息','1','1','1','*','','0','1','','0');
INSERT INTO `yzh_model` VALUES ('5','下载模型','Download','下载信息','1','1','1','*','','0','0','','0');
INSERT INTO `yzh_model` VALUES ('6','视频模型','Video','视频信息','1','0','0','*','','0','0','','0');
INSERT INTO `yzh_model` VALUES ('7','招聘模型','Job','招聘信息','1','0','0','*','','0','0','','0');
--
-- 表的结构 `yzh_node`
-- 
DROP TABLE IF EXISTS `yzh_node`;
CREATE TABLE `yzh_node` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL DEFAULT '',
  `title` varchar(50) NOT NULL DEFAULT '',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `remark` varchar(255) NOT NULL DEFAULT '',
  `sort` smallint(5) unsigned NOT NULL DEFAULT '0',
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `groupid` smallint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`,`status`,`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=224 DEFAULT CHARSET=utf8;

-- 
-- 导出`yzh_node`表中的数据 `yzh_node`
--
INSERT INTO `yzh_node` VALUES ('1','Admin','后台管理','1','','0','0','1','172');
INSERT INTO `yzh_node` VALUES ('2','Index','后台首页','1','','0','1','2','172');
INSERT INTO `yzh_node` VALUES ('3','index','默认','1','','0','2','3','172');
INSERT INTO `yzh_node` VALUES ('4','main','首页','1','','0','2','3','172');
INSERT INTO `yzh_node` VALUES ('5','Config','基本设置','1','','0','1','2','173');
INSERT INTO `yzh_node` VALUES ('6','index','默认','1','','0','5','3','173');
INSERT INTO `yzh_node` VALUES ('7','robots','搜索引擎抓取设置','1','','0','78','3','173');
INSERT INTO `yzh_node` VALUES ('8','config','会员设置','1','','0','76','3','210');
INSERT INTO `yzh_node` VALUES ('9','User','管理员管理','1','','0','1','2','173');
INSERT INTO `yzh_node` VALUES ('10','index','默认','1','','0','9','3','173');
INSERT INTO `yzh_node` VALUES ('11','edit','编辑','1','','0','9','3','173');
INSERT INTO `yzh_node` VALUES ('12','add','添加','1','','0','9','3','173');
INSERT INTO `yzh_node` VALUES ('13','delete','删除','1','','0','9','3','173');
INSERT INTO `yzh_node` VALUES ('14','Role','角色管理','1','','0','1','2','173');
INSERT INTO `yzh_node` VALUES ('15','index','查看','1','','0','14','3','173');
INSERT INTO `yzh_node` VALUES ('16','edit','编辑','1','','0','14','3','173');
INSERT INTO `yzh_node` VALUES ('17','add','添加','1','','0','14','3','173');
INSERT INTO `yzh_node` VALUES ('18','delete','删除','1','','0','14','3','173');
INSERT INTO `yzh_node` VALUES ('19','createhtml','更新伪静态','1','','0','1','2','184');
INSERT INTO `yzh_node` VALUES ('20','update_urls','更新伪静态','1','','0','19','3','184');
INSERT INTO `yzh_node` VALUES ('21','database','数据库','1','','0','1','2','173');
INSERT INTO `yzh_node` VALUES ('22','index','查看','1','','0','21','3','173');
INSERT INTO `yzh_node` VALUES ('23','recover','备份管理','1','','0','21','3','173');
INSERT INTO `yzh_node` VALUES ('24','Category','导航设置','1','','0','1','2','184');
INSERT INTO `yzh_node` VALUES ('25','index','查看','1','','0','24','3','184');
INSERT INTO `yzh_node` VALUES ('26','index','查看','1','','0','107','3','210');
INSERT INTO `yzh_node` VALUES ('27','edit','编辑','1','','0','24','3','184');
INSERT INTO `yzh_node` VALUES ('28','add','添加','1','','0','24','3','184');
INSERT INTO `yzh_node` VALUES ('29','insert','插入','1','','0','24','3','184');
INSERT INTO `yzh_node` VALUES ('30','delete','删除','1','','0','24','3','184');
INSERT INTO `yzh_node` VALUES ('31','slide','广告管理','1','','0','1','2','184');
INSERT INTO `yzh_node` VALUES ('32','picmanage','图片管理','1','','0','31','3','184');
INSERT INTO `yzh_node` VALUES ('33','editpic','图片修改','1','','0','31','3','184');
INSERT INTO `yzh_node` VALUES ('34','addpic','添加图片','1','','0','31','3','184');
INSERT INTO `yzh_node` VALUES ('35','index','查看','1','','0','31','3','184');
INSERT INTO `yzh_node` VALUES ('36','edit','编辑','1','','0','31','3','184');
INSERT INTO `yzh_node` VALUES ('37','delete','删除','1','','0','31','3','184');
INSERT INTO `yzh_node` VALUES ('38','page','单页管理','1','','0','1','2','184');
INSERT INTO `yzh_node` VALUES ('39','index','查看','1','','0','38','3','184');
INSERT INTO `yzh_node` VALUES ('40','edit','编辑','1','','0','38','3','184');
INSERT INTO `yzh_node` VALUES ('41','update','更新','1','','0','38','3','184');
INSERT INTO `yzh_node` VALUES ('42','product','产品管理','1','','0','1','2','184');
INSERT INTO `yzh_node` VALUES ('43','index','查看','1','','0','42','3','184');
INSERT INTO `yzh_node` VALUES ('44','edit','编辑','1','','0','42','3','184');
INSERT INTO `yzh_node` VALUES ('45','add','新增','1','','0','42','3','184');
INSERT INTO `yzh_node` VALUES ('46','delete','删除','1','','0','42','3','184');
INSERT INTO `yzh_node` VALUES ('47','plugin','插件管理','1','','0','1','2','284');
INSERT INTO `yzh_node` VALUES ('48','push','推送','1','','0','42','3','184');
INSERT INTO `yzh_node` VALUES ('49','article','新闻管理','1','','0','1','2','184');
INSERT INTO `yzh_node` VALUES ('50','index','查看','1','','0','49','3','184');
INSERT INTO `yzh_node` VALUES ('51','edit','编辑','1','','0','49','3','184');
INSERT INTO `yzh_node` VALUES ('52','add','新增','1','','0','49','3','184');
INSERT INTO `yzh_node` VALUES ('53','delete','删除','1','','0','49','3','184');
INSERT INTO `yzh_node` VALUES ('54','engines','搜索引擎提交','1','','0','47','3','284');
INSERT INTO `yzh_node` VALUES ('55','push','推送','1','','0','49','3','184');
INSERT INTO `yzh_node` VALUES ('56','picture','图片管理','1','','0','1','2','184');
INSERT INTO `yzh_node` VALUES ('57','index','查看','1','','0','56','3','184');
INSERT INTO `yzh_node` VALUES ('58','edit','编辑','1','','0','56','3','184');
INSERT INTO `yzh_node` VALUES ('59','add','新增','1','','0','56','3','184');
INSERT INTO `yzh_node` VALUES ('60','delete','删除','1','','0','56','3','184');
INSERT INTO `yzh_node` VALUES ('61','update','更新','1','','0','199','3','172');
INSERT INTO `yzh_node` VALUES ('62','push','推送','1','','0','56','3','184');
INSERT INTO `yzh_node` VALUES ('63','download','下载管理','1','','0','1','2','184');
INSERT INTO `yzh_node` VALUES ('64','job','招聘管理','1','','0','1','2','184');
INSERT INTO `yzh_node` VALUES ('65','block','碎片管理','1','','0','1','2','173');
INSERT INTO `yzh_node` VALUES ('66','link','友情链接','1','','0','1','2','284');
INSERT INTO `yzh_node` VALUES ('67','ditu','电子地图','1','','0','5','3','173');
INSERT INTO `yzh_node` VALUES ('68','index','查看','1','','0','105','3','284');
INSERT INTO `yzh_node` VALUES ('69','createsitemap','网站地图生成','1','','0','19','3','184');
INSERT INTO `yzh_node` VALUES ('70','kefu','客服设置','1','','0','1','2','284');
INSERT INTO `yzh_node` VALUES ('71','form','反馈管理','1','','0','1','2','284');
INSERT INTO `yzh_node` VALUES ('72','resume','人才管理库','1','','0','1','2','284');
INSERT INTO `yzh_node` VALUES ('73','message','产品订单','1','','0','1','2','284');
INSERT INTO `yzh_node` VALUES ('74','comment','产品评论','1','','0','1','2','284');
INSERT INTO `yzh_node` VALUES ('75','Statistics','流量统计','1','','0','47','3','284');
INSERT INTO `yzh_node` VALUES ('76','member','会员管理','1','','0','1','2','210');
INSERT INTO `yzh_node` VALUES ('77','save','保存','1','','0','78','3','173');
INSERT INTO `yzh_node` VALUES ('78','sysconfig','系统设置','1','','0','1','2','173');
INSERT INTO `yzh_node` VALUES ('79','advanced','高级设置','1','','0','78','3','173');
INSERT INTO `yzh_node` VALUES ('80','email','邮件营销','1','','0','1','2','284');
INSERT INTO `yzh_node` VALUES ('81','tags','标签管理','1','','0','1','2','184');
INSERT INTO `yzh_node` VALUES ('82','wap','移动系统','1','','0','1','2','194');
INSERT INTO `yzh_node` VALUES ('83','index','查看','1','','0','65','3','173');
INSERT INTO `yzh_node` VALUES ('84','wechat','微信平台','1','','0','1','2','194');
INSERT INTO `yzh_node` VALUES ('85','index','查看','1','','0','70','3','284');
INSERT INTO `yzh_node` VALUES ('86','index','查看','1','','0','71','3','284');
INSERT INTO `yzh_node` VALUES ('87','index','查看','1','','0','72','3','284');
INSERT INTO `yzh_node` VALUES ('88','index','查看','1','','0','74','3','284');
INSERT INTO `yzh_node` VALUES ('89','index','查看','1','','0','66','3','284');
INSERT INTO `yzh_node` VALUES ('90','index','查看','1','','0','63','3','184');
INSERT INTO `yzh_node` VALUES ('91','index','查看','1','','0','73','3','284');
INSERT INTO `yzh_node` VALUES ('92','index','查看','1','','0','76','3','210');
INSERT INTO `yzh_node` VALUES ('93','index','查看','1','','0','80','3','284');
INSERT INTO `yzh_node` VALUES ('94','index','查看','1','','0','81','3','184');
INSERT INTO `yzh_node` VALUES ('95','edit','编辑','1','','0','65','3','173');
INSERT INTO `yzh_node` VALUES ('96','edit','编辑','1','','0','63','3','184');
INSERT INTO `yzh_node` VALUES ('97','edit','编辑','1','','0','105','3','284');
INSERT INTO `yzh_node` VALUES ('98','index','查看','1','','0','64','3','184');
INSERT INTO `yzh_node` VALUES ('99','edit','编辑','1','','0','71','3','284');
INSERT INTO `yzh_node` VALUES ('100','edit','编辑','1','','0','76','3','210');
INSERT INTO `yzh_node` VALUES ('101','add','添加','1','','0','65','3','173');
INSERT INTO `yzh_node` VALUES ('102','edit','编辑','1','','0','66','3','284');
INSERT INTO `yzh_node` VALUES ('103','edit','编辑','1','','0','70','3','284');
INSERT INTO `yzh_node` VALUES ('104','add','添加','1','','0','63','3','184');
INSERT INTO `yzh_node` VALUES ('105','Hotpage','爆品转化页','1','','0','1','2','284');
INSERT INTO `yzh_node` VALUES ('106','edit','编辑','1','','0','64','3','184');
INSERT INTO `yzh_node` VALUES ('107','order','订单管理','1','','0','1','2','210');
INSERT INTO `yzh_node` VALUES ('108','edit','编辑','1','','0','121','3','210');
INSERT INTO `yzh_node` VALUES ('109','delete','删除','1','','0','63','3','184');
INSERT INTO `yzh_node` VALUES ('110','add','新增','1','','0','64','3','184');
INSERT INTO `yzh_node` VALUES ('111','delete','删除','1','','0','64','3','184');
INSERT INTO `yzh_node` VALUES ('112','add','添加','1','','0','76','3','210');
INSERT INTO `yzh_node` VALUES ('113','push','推送','1','','0','63','3','184');
INSERT INTO `yzh_node` VALUES ('114','delete','删除','1','','0','72','3','284');
INSERT INTO `yzh_node` VALUES ('115','add','添加','1','','0','66','3','284');
INSERT INTO `yzh_node` VALUES ('116','add','添加','1','','0','70','3','284');
INSERT INTO `yzh_node` VALUES ('117','index','查看','1','','0','121','3','210');
INSERT INTO `yzh_node` VALUES ('118','slide','首页广告','1','','0','82','3','194');
INSERT INTO `yzh_node` VALUES ('119','config','基本设置','1','','0','82','3','194');
INSERT INTO `yzh_node` VALUES ('120','html','生成静态页','1','','0','105','3','284');
INSERT INTO `yzh_node` VALUES ('121','MemberGroup','会员组管理','1','','0','1','2','210');
INSERT INTO `yzh_node` VALUES ('122','index','查看','1','','0','187','3','284');
INSERT INTO `yzh_node` VALUES ('123','payment','支付管理','1','','0','1','2','210');
INSERT INTO `yzh_node` VALUES ('124','add','新增','1','','0','105','3','284');
INSERT INTO `yzh_node` VALUES ('125','delete','删除','1','','0','76','3','210');
INSERT INTO `yzh_node` VALUES ('126','bind','绑定公众号','1','','0','84','3','194');
INSERT INTO `yzh_node` VALUES ('127','editslide','修改图片','1','','0','82','3','194');
INSERT INTO `yzh_node` VALUES ('128','index','查看','1','','0','123','3','210');
INSERT INTO `yzh_node` VALUES ('129','delete','删除','1','','0','65','3','173');
INSERT INTO `yzh_node` VALUES ('130','message','留言','1','','0','105','3','284');
INSERT INTO `yzh_node` VALUES ('131','delete','删除','1','','0','70','3','284');
INSERT INTO `yzh_node` VALUES ('132','delete','删除','1','','0','66','3','284');
INSERT INTO `yzh_node` VALUES ('133','edit','编辑','1','','0','199','3','172');
INSERT INTO `yzh_node` VALUES ('134','delete','删除','1','','0','71','3','284');
INSERT INTO `yzh_node` VALUES ('135','detail','查看详细','1','','0','72','3','284');
INSERT INTO `yzh_node` VALUES ('136','edit','编辑','1','','0','74','3','284');
INSERT INTO `yzh_node` VALUES ('137','edit','编辑','1','','0','81','3','184');
INSERT INTO `yzh_node` VALUES ('138','selfmenu','自定义菜单','1','','0','84','3','194');
INSERT INTO `yzh_node` VALUES ('139','sendMessage','发送新闻','1','','0','84','3','194');
INSERT INTO `yzh_node` VALUES ('140','welcome','基本设置','1','','0','84','3','194');
INSERT INTO `yzh_node` VALUES ('141','save','保存','1','','0','5','3','173');
INSERT INTO `yzh_node` VALUES ('142','Public','全局操作 ','1','','0','1','2','0');
INSERT INTO `yzh_node` VALUES ('143','attachment','附件管理 ','1','','0','1','2','173');
INSERT INTO `yzh_node` VALUES ('144','index','默认操作','1','','0','143','3','173');
INSERT INTO `yzh_node` VALUES ('145','upload','上传文件','1','','0','143','3','173');
INSERT INTO `yzh_node` VALUES ('146','filelist','浏览文件','1','','0','143','3','173');
INSERT INTO `yzh_node` VALUES ('147','delfile','删除文件','1','','0','143','3','173');
INSERT INTO `yzh_node` VALUES ('148','addwater','添加水印','1','','0','143','3','173');
INSERT INTO `yzh_node` VALUES ('149','cache','更新缓存','1','','0','142','3','0');
INSERT INTO `yzh_node` VALUES ('150','add','安装','1','','0','123','3','210');
INSERT INTO `yzh_node` VALUES ('151','vcard','微名片','1','','0','1','2','194');
INSERT INTO `yzh_node` VALUES ('152','push','推送','1','','0','64','3','184');
INSERT INTO `yzh_node` VALUES ('153','index','查看','1','','0','151','3','194');
INSERT INTO `yzh_node` VALUES ('154','add','新增','1','','0','151','3','194');
INSERT INTO `yzh_node` VALUES ('155','edit','编辑','1','','0','151','3','194');
INSERT INTO `yzh_node` VALUES ('156','html','生成','1','','0','151','3','194');
INSERT INTO `yzh_node` VALUES ('157','poster','微海报','1','','0','1','2','194');
INSERT INTO `yzh_node` VALUES ('158','index','查看','1','','0','157','3','194');
INSERT INTO `yzh_node` VALUES ('159','add','新增','1','','0','157','3','194');
INSERT INTO `yzh_node` VALUES ('160','edit','编辑','1','','0','157','3','194');
INSERT INTO `yzh_node` VALUES ('161','html','生成','1','','0','157','3','194');
INSERT INTO `yzh_node` VALUES ('162','delete','删除','1','','0','73','3','284');
INSERT INTO `yzh_node` VALUES ('163','detail','查看详情','1','','0','107','3','210');
INSERT INTO `yzh_node` VALUES ('164','baidumap','百度地图','1','','0','47','3','284');
INSERT INTO `yzh_node` VALUES ('165','backup','备份','1','','0','21','3','173');
INSERT INTO `yzh_node` VALUES ('166','deletepic','删除图片','1','','0','31','3','184');
INSERT INTO `yzh_node` VALUES ('167','remove','移动','1','','0','42','3','184');
INSERT INTO `yzh_node` VALUES ('168','remove','移动','1','','0','49','3','184');
INSERT INTO `yzh_node` VALUES ('169','remove','移动','1','','0','56','3','184');
INSERT INTO `yzh_node` VALUES ('170','remove','移动','1','','0','63','3','184');
INSERT INTO `yzh_node` VALUES ('171','remove','移动','1','','0','64','3','184');
INSERT INTO `yzh_node` VALUES ('172','upgrade','在线升级','1','','0','1','2','173');
INSERT INTO `yzh_node` VALUES ('173','action','登陆日志','1','','0','1','2','173');
INSERT INTO `yzh_node` VALUES ('174','mail','邮箱设置','1','','0','78','3','173');
INSERT INTO `yzh_node` VALUES ('175','edit','编辑','1','','0','187','3','284');
INSERT INTO `yzh_node` VALUES ('176','password','修改密码','1','','0','2','3','172');
INSERT INTO `yzh_node` VALUES ('177','Index','查看','1','','0','78','3','173');
INSERT INTO `yzh_node` VALUES ('178','delete','删除','1','','0','105','3','284');
INSERT INTO `yzh_node` VALUES ('179','edit','编辑','1','','0','123','3','210');
INSERT INTO `yzh_node` VALUES ('180','index','查看','1','','0','173','3','173');
INSERT INTO `yzh_node` VALUES ('181','edit','编辑','1','','0','173','3','173');
INSERT INTO `yzh_node` VALUES ('182','delete','删除','1','','0','107','3','210');
INSERT INTO `yzh_node` VALUES ('183','add','新增','1','','0','121','3','210');
INSERT INTO `yzh_node` VALUES ('184','delete','删除','1','','0','187','3','284');
INSERT INTO `yzh_node` VALUES ('185','add','新增','1','','0','187','3','284');
INSERT INTO `yzh_node` VALUES ('186','swfupload','文件上传','1','','0','143','3','173');
INSERT INTO `yzh_node` VALUES ('187','fiesta','节日营销','1','','0','1','2','284');
INSERT INTO `yzh_node` VALUES ('188','listorder','排序','1','','0','24','3','184');
INSERT INTO `yzh_node` VALUES ('189','listorder','排序','1','','0','31','3','184');
INSERT INTO `yzh_node` VALUES ('190','listorder','排序','1','','0','42','3','184');
INSERT INTO `yzh_node` VALUES ('191','listorder','排序','1','','0','49','3','184');
INSERT INTO `yzh_node` VALUES ('192','listorder','排序','1','','0','56','3','184');
INSERT INTO `yzh_node` VALUES ('193','listorder','排序','1','','0','63','3','184');
INSERT INTO `yzh_node` VALUES ('194','listorder','排序','1','','0','64','3','184');
INSERT INTO `yzh_node` VALUES ('195','listorder','排序','1','','0','66','3','284');
INSERT INTO `yzh_node` VALUES ('196','delete','删除','1','','0','81','3','184');
INSERT INTO `yzh_node` VALUES ('197','delete','删除','1','','0','151','3','194');
INSERT INTO `yzh_node` VALUES ('198','delete','删除','1','','0','157','3','194');
INSERT INTO `yzh_node` VALUES ('199','visual','可视化编辑','1','','0','1','2','172');
INSERT INTO `yzh_node` VALUES ('200','index','查看','1','','0','199','3','172');
INSERT INTO `yzh_node` VALUES ('201','deletemsg','删除留言','1','','0','105','3','284');
INSERT INTO `yzh_node` VALUES ('202','index','查看','1','','0','172','3','173');
INSERT INTO `yzh_node` VALUES ('203','sitemap','sitemap','1','','0','19','3','184');
INSERT INTO `yzh_node` VALUES ('204','edit','编辑附件','1','','0','143','3','173');
INSERT INTO `yzh_node` VALUES ('205','robot','自动回复','1','','0','84','3','194');
INSERT INTO `yzh_node` VALUES ('206','content','内容维护','1','','0','71','3','284');
INSERT INTO `yzh_node` VALUES ('207','contentedit','查看修改内容','1','','0','71','3','284');
INSERT INTO `yzh_node` VALUES ('208','contentdelete','删除内容','1','','0','71','3','284');
INSERT INTO `yzh_node` VALUES ('209','Video','视频模型','1','','0','1','2','184');
INSERT INTO `yzh_node` VALUES ('210','index','查看','1','','0','209','3','184');
INSERT INTO `yzh_node` VALUES ('211','add','新增','1','','0','209','3','184');
INSERT INTO `yzh_node` VALUES ('212','edit','编辑','1','','0','209','3','184');
INSERT INTO `yzh_node` VALUES ('213','delete','删除','1','','0','209','3','184');
INSERT INTO `yzh_node` VALUES ('214','push','推送','1','','0','209','3','184');
INSERT INTO `yzh_node` VALUES ('215','remove','移动','1','','0','209','3','184');
INSERT INTO `yzh_node` VALUES ('216','listorder','排序','1','','0','209','3','184');
INSERT INTO `yzh_node` VALUES ('217','hotwords','热门关键词','1','','0','47','3','284');
INSERT INTO `yzh_node` VALUES ('218','mainpro','主营产品','1','','0','47','3','284');
INSERT INTO `yzh_node` VALUES ('219','smartreply_del','smartreply_del','1','','0','84','3','194');
INSERT INTO `yzh_node` VALUES ('220','smartreply','smartreply','1','','0','84','3','194');
INSERT INTO `yzh_node` VALUES ('221','smartreply_edit','smartreply_edit','1','','0','84','3','194');
INSERT INTO `yzh_node` VALUES ('222','smartreply_add','smartreply_add','1','','0','84','3','194');
INSERT INTO `yzh_node` VALUES ('223','setMenu','setMenu','1','','0','84','3','194');
--
-- 表的结构 `yzh_order`
-- 
DROP TABLE IF EXISTS `yzh_order`;
CREATE TABLE `yzh_order` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sn` bigint(19) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `pay_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `shipping_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `consignee` varchar(60) NOT NULL DEFAULT '',
  `country` smallint(5) unsigned NOT NULL DEFAULT '0',
  `province` smallint(5) unsigned NOT NULL DEFAULT '0',
  `city` smallint(5) unsigned NOT NULL DEFAULT '0',
  `area` smallint(5) unsigned NOT NULL DEFAULT '0',
  `address` varchar(255) NOT NULL DEFAULT '',
  `zipcode` varchar(60) NOT NULL DEFAULT '',
  `tel` varchar(60) NOT NULL DEFAULT '',
  `mobile` varchar(60) NOT NULL DEFAULT '',
  `email` varchar(60) NOT NULL DEFAULT '',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `shipping_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `shipping_name` varchar(120) NOT NULL DEFAULT '',
  `shipping_sn` varchar(100) NOT NULL DEFAULT '',
  `pay_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `pay_name` varchar(120) NOT NULL DEFAULT '',
  `pay_code` varchar(120) NOT NULL DEFAULT '',
  `amount` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `pay_fee` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `shipping_fee` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `insure_fee` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `invoice_fee` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `order_amount` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `discount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `add_time` int(10) unsigned NOT NULL DEFAULT '0',
  `pay_time` int(10) unsigned NOT NULL DEFAULT '0',
  `shipping_time` int(10) unsigned NOT NULL DEFAULT '0',
  `accept_time` int(10) unsigned NOT NULL DEFAULT '0',
  `confirm_time` int(10) unsigned NOT NULL DEFAULT '0',
  `point` int(5) unsigned NOT NULL DEFAULT '0',
  `invoice` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `invoice_title` varchar(100) NOT NULL DEFAULT '',
  `postmessage` varchar(255) NOT NULL DEFAULT '',
  `note` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sn` (`sn`),
  KEY `userid` (`userid`),
  KEY `status` (`status`),
  KEY `shipping_status` (`shipping_status`),
  KEY `pay_status` (`pay_status`),
  KEY `shipping_id` (`shipping_id`),
  KEY `pay_id` (`pay_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
--
-- 表的结构 `yzh_order_data`
-- 
DROP TABLE IF EXISTS `yzh_order_data`;
CREATE TABLE `yzh_order_data` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `order_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `moduleid` smallint(3) unsigned NOT NULL DEFAULT '0',
  `product_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `product_thumb` varchar(120) NOT NULL DEFAULT '',
  `product_name` varchar(120) NOT NULL DEFAULT '',
  `product_url` varchar(120) NOT NULL DEFAULT '',
  `product_price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `number` smallint(5) unsigned NOT NULL DEFAULT '0',
  `attr` text NOT NULL,
  `goods_attr_id` varchar(255) NOT NULL DEFAULT '',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `isgift` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `userid` (`userid`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
--
-- 表的结构 `yzh_page`
-- 
DROP TABLE IF EXISTS `yzh_page`;
CREATE TABLE `yzh_page` (
  `id` smallint(5) NOT NULL,
  `title` varchar(100) NOT NULL DEFAULT '',
  `thumb` varchar(100) NOT NULL DEFAULT '',
  `keywords` varchar(250) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  `content` mediumtext NOT NULL,
  `wap_content` mediumtext NOT NULL,
  `template` varchar(30) NOT NULL DEFAULT '',
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0',
  `lang` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- 导出`yzh_page`表中的数据 `yzh_page`
--
INSERT INTO `yzh_page` VALUES ('11','Company Profile','','','','<p>\n	Shenzhen SenXin Technology Ltd. is a professional company that is leading the industry in providing high-quality 3C digital, phone peripherals, speakers, smart watches and U disk devices. It integrates R &amp; D, design, production and sales. Founded in Shenzhen in the early 2008, it provides professional services to customers in all parts of the world through its more than 30 companies and distributor network. So far, it has already had a steady operation service network composed of dozens of agents such as Shanghai, Guangzhou, Ji\'nan, Shenyang, Chengdu, Xi\'an, Wuhan and Hangzhou in China.\n</p>\n<p>\n	<br />\n</p>\n<p>\n	<br />\n</p>\n<p>\n	The business of SenXin Technology Ltd. has spread over dozens of countries in five continents. To meet the needs of all customers, and to dedicated to easy operation and to match the special requirements of the customers, it provides a full series of logo solutions. The solution is economical and practical, low in cost, simple in maintenance, excellent in performance and reliable in operation.\n</p>\n<p>\n	<br />\n</p>\n<p>\n	SenXin Technology Ltd. ensures customer satisfaction through quality policy and security measures.\n</p>\n<p>\n	<br />\n</p>\n<p>\n	Through quality certification and international CE certification, products meet all international safety standards. It widely involves many fields, like domestic and international speakers, smart watches, wireless charging, mobile power, 3C digital, mobile phone and so on.\n</p>','<p style=\"white-space:normal;\">\n	Shenzhen SenXin Technology Ltd. is a professional company that is leading the industry in providing high-quality 3C digital, phone peripherals, speakers, smart watches and U disk devices. It integrates R &amp; D, design, production and sales. Founded in Shenzhen in the early 2008, it provides professional services to customers in all parts of the world through its more than 30 companies and distributor network. So far, it has already had a steady operation service network composed of dozens of agents such as Shanghai, Guangzhou, Ji\'nan, Shenyang, Chengdu, Xi\'an, Wuhan and Hangzhou in China.\n</p>\n<p style=\"white-space:normal;\">\n	<br />\n</p>\n<p style=\"white-space:normal;\">\n	<br />\n</p>\n<p style=\"white-space:normal;\">\n	The business of SenXin Technology Ltd. has spread over dozens of countries in five continents. To meet the needs of all customers, and to dedicated to easy operation and to match the special requirements of the customers, it provides a full series of logo solutions. The solution is economical and practical, low in cost, simple in maintenance, excellent in performance and reliable in operation.\n</p>\n<p style=\"white-space:normal;\">\n	<br />\n</p>\n<p style=\"white-space:normal;\">\n	SenXin Technology Ltd. ensures customer satisfaction through quality policy and security measures.\n</p>\n<p style=\"white-space:normal;\">\n	<br />\n</p>\n<p style=\"white-space:normal;\">\n	Through quality certification and international CE certification, products meet all international safety standards. It widely involves many fields, like domestic and international speakers, smart watches, wireless charging, mobile power, 3C digital, mobile phone and so on.\n</p>','','0','0');
INSERT INTO `yzh_page` VALUES ('4','Service','','','','<p>\n	Company service\n</p>\n<p>\n	About after-sale service, we believe that every customer is most concerned about the real efficiency. We can solve the problem from the source in the shortest possible time. It is essential for us to establish a brand image. Therefore, after-sale service has a pivotal position in our sales system. Our company is willing to spend the most energy and manpower on doing this job well. We will take effective actions to let customers experience \"thinking for customers\" is not just an oral promise.\n</p>','<p>\n	Company service\n</p>\n<p>\n	About after-sale service, we believe that every customer is most concerned about the real efficiency. We can solve the problem from the source in the shortest possible time. It is essential for us to establish a brand image. Therefore, after-sale service has a pivotal position in our sales system. Our company is willing to spend the most energy and manpower on doing this job well. We will take effective actions to let customers experience \"thinking for customers\" is not just an oral promise.\n</p>','','0','0');
INSERT INTO `yzh_page` VALUES ('12','Company culture','','','','<p>\n	The product culture of SenXin\n</p>\n<p>\n	SenXin Technology Ltd. is committed to the development and production of Bluetooth speakers, microphones and wireless charger. With excelsior attitude and technology and persistent spirit of innovation, we integrate a ultimate simple and rich modern sense into products. Thus consumers can have athletic, portable, compact and outdoor experience.\n</p>\n<p>\n	Enterprise management culture of SenXin\n</p>\n<p>\n	SenXin Technology Ltd. advocates flat management. There are only four ranks---- general staff, the team leader, the supervisor and the department manager. It is an important task to motivate employees to develop and meet the challenges without too much space for promotion. As a matter of fact, one of the essences of the job promotion is to take on more new responsibilities and challenges. In addition, even in the same position, employees can still feel different challenges.\n</p>\n<p>\n	1. system of talent management:\n</p>\n<p>\n	SenXin can retain talents through the equal atmosphere, humanized management and effective incentive mechanism. SenXin advocates equality and opposes hierarchy and bureaucracy. SenXin does not encourage employees to work overtime because they think the balance of their work and life is important to the company. However, the company encourages employees to challenge their work. Even if they happen to make a mistake, they will not be punished. In such a cultural atmosphere, employees work happily and enjoy the happiness of their work. The incentive mechanism of SenXin consists of providing training opportunities, job promotion, and compensation system corresponding to ability and performance.\n</p>\n<p>\n	System of employee recruitment:\n</p>\n<p>\n	SenXin staff recruitment thinks highly of communication skills and leadership skills. Besides, it requires candidates\' personal values to be consistent with the core values of SenXin. What’s more, it focuses on employee diversity and employee training. When SenXin recruits employees, they attach great importance to people with strong communication skills. They should be straightforward, diligent, and willing to deal with the people around them. SenXin also attaches great importance to whether the applicant has leadership, network skills, negotiation skills, and so on. SenXin pays special attention to whether the individual values of the candidate are in accordance with the core values of SenXin. Those who are interested in customers, diligent, and willing to learn and progress are the candidates for SenXin.\n</p>\n<p>\n	The core value of SenXin\n</p>\n<p>\n	SenXin insists that equality, humanity, solidarity, cooperation, responsibility, willingness to help others, persistent spirit of innovation and dedication, and excelsior attitude are their core values.\n</p>','<p>\n	The product culture of SenXin\n</p>\n<p>\n	SenXin Technology Ltd. is committed to the development and production of Bluetooth speakers, microphones and wireless charger. With excelsior attitude and technology and persistent spirit of innovation, we integrate a ultimate simple and rich modern sense into products. Thus consumers can have athletic, portable, compact and outdoor experience.\n</p>\n<p>\n	Enterprise management culture of SenXin\n</p>\n<p>\n	SenXin Technology Ltd. advocates flat management. There are only four ranks---- general staff, the team leader, the supervisor and the department manager. It is an important task to motivate employees to develop and meet the challenges without too much space for promotion. As a matter of fact, one of the essences of the job promotion is to take on more new responsibilities and challenges. In addition, even in the same position, employees can still feel different challenges.\n</p>\n<p>\n	1. system of talent management:\n</p>\n<p>\n	SenXin can retain talents through the equal atmosphere, humanized management and effective incentive mechanism. SenXin advocates equality and opposes hierarchy and bureaucracy. SenXin does not encourage employees to work overtime because they think the balance of their work and life is important to the company. However, the company encourages employees to challenge their work. Even if they happen to make a mistake, they will not be punished. In such a cultural atmosphere, employees work happily and enjoy the happiness of their work. The incentive mechanism of SenXin consists of providing training opportunities, job promotion, and compensation system corresponding to ability and performance.\n</p>\n<p>\n	System of employee recruitment:\n</p>\n<p>\n	SenXin staff recruitment thinks highly of communication skills and leadership skills. Besides, it requires candidates\' personal values to be consistent with the core values of SenXin. What’s more, it focuses on employee diversity and employee training. When SenXin recruits employees, they attach great importance to people with strong communication skills. They should be straightforward, diligent, and willing to deal with the people around them. SenXin also attaches great importance to whether the applicant has leadership, network skills, negotiation skills, and so on. SenXin pays special attention to whether the individual values of the candidate are in accordance with the core values of SenXin. Those who are interested in customers, diligent, and willing to learn and progress are the candidates for SenXin.\n</p>\n<p>\n	The core value of SenXin\n</p>\n<p>\n	SenXin insists that equality, humanity, solidarity, cooperation, responsibility, willingness to help others, persistent spirit of innovation and dedication, and excelsior attitude are their core values.\n</p>','','0','0');
INSERT INTO `yzh_page` VALUES ('6','Contacts','','','','<p>\n	<p>\n		<span style=\"font-size:18px;\"><strong>Shenzhen SenXin Technology Ltd.</strong></span> \n	</p>\n	<p>\n		<br />\n	</p>\nContact: Li Shijun\n</p>\n<p>\n	Mobile: 13554990867\n</p>\n<p>\n	Tel: 0755-33161106\n</p>\n<p>\n	Fax: 0755-33161106\n</p>\n<p>\n	E-mail: 563665073@qq.com\n</p>\n<p>\n	Website: www.senxinsx.com\n</p>\n<p>\n	Address: Bao\'an District, Shenzhen Xixiang Gushu Xinyuan Industrial Zone, 3rd Floor, 3rd Floor, 3F-A\n</p>','','','0','0');
--
-- 表的结构 `yzh_payment`
-- 
DROP TABLE IF EXISTS `yzh_payment`;
CREATE TABLE `yzh_payment` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `pay_code` varchar(20) NOT NULL DEFAULT '',
  `pay_name` varchar(120) NOT NULL DEFAULT '',
  `pay_fee` varchar(10) NOT NULL DEFAULT '0',
  `pay_fee_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `pay_desc` text NOT NULL,
  `pay_config` text NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_cod` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_online` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `author` varchar(100) NOT NULL,
  `version` varchar(20) NOT NULL,
  `listorder` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `pay_code` (`pay_code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
--
-- 表的结构 `yzh_picture`
-- 
DROP TABLE IF EXISTS `yzh_picture`;
CREATE TABLE `yzh_picture` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userid` int(11) unsigned NOT NULL DEFAULT '0',
  `username` varchar(40) NOT NULL DEFAULT '',
  `title` varchar(80) NOT NULL DEFAULT '',
  `title_style` varchar(40) NOT NULL DEFAULT '',
  `thumb` varchar(100) NOT NULL DEFAULT '',
  `keywords` varchar(120) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  `content` text NOT NULL,
  `url` varchar(150) NOT NULL DEFAULT '',
  `template` varchar(40) NOT NULL DEFAULT '',
  `posid` varchar(50) NOT NULL DEFAULT '',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `listorder` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(11) unsigned NOT NULL DEFAULT '0',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  `pics` mediumtext NOT NULL,
  `lang` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `status` (`id`,`status`,`listorder`),
  KEY `catid` (`id`,`catid`,`status`),
  KEY `listorder` (`id`,`catid`,`status`,`listorder`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- 
-- 导出`yzh_picture`表中的数据 `yzh_picture`
--
INSERT INTO `yzh_picture` VALUES ('1','3','1','super','EDIFIER','','/uploads/201803/5aa0ae18597fb.png','','','','/partner/3-1.html','','-1-','1','0','0','1520324986','1520479777','[]','1');
INSERT INTO `yzh_picture` VALUES ('2','3','1','super','FOXCONN','','/uploads/201803/5aa0adfbe7f45.jpg','','','','/partner/3-2.html','','-1-','1','0','0','1520324986','1520479758','[]','1');
INSERT INTO `yzh_picture` VALUES ('3','3','1','super','SONY','','/uploads/201803/5aa0ad10ed091.jpg','','','','/partner/3-3.html','','-1-','1','0','0','1520324986','1520479513','[]','1');
INSERT INTO `yzh_picture` VALUES ('4','3','1','super','panasonic','','/uploads/201803/5aa0acc32966e.jpg','','','','/partner/3-4.html','','-1-','1','0','0','1520324986','1520479447','[]','1');
INSERT INTO `yzh_picture` VALUES ('5','3','1','super','Samsung','','/uploads/201803/5aa0ac8fd77e1.jpg','','','','/partner/3-5.html','','-1-','1','0','0','1520324986','1520479402','[]','1');
INSERT INTO `yzh_picture` VALUES ('6','3','1','super','HUAWEI','','/uploads/201803/5aa0ac770ff8f.jpg','','','','/partner/3-6.html','','-1-','1','0','0','1520324986','1520479362','[]','1');
INSERT INTO `yzh_picture` VALUES ('7','3','1','super','LG','','/uploads/201803/5aa0ac49b6d5f.jpg','','','','/partner/3-7.html','','-1-','1','0','0','1520324986','1520479312','[]','1');
--
-- 表的结构 `yzh_plugin`
-- 
DROP TABLE IF EXISTS `yzh_plugin`;
CREATE TABLE `yzh_plugin` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '',
  `title` varchar(32) NOT NULL,
  `description` text NOT NULL,
  `config` text NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `author` varchar(100) NOT NULL,
  `version` varchar(20) NOT NULL,
  `lang` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- 
-- 导出`yzh_plugin`表中的数据 `yzh_plugin`
--
INSERT INTO `yzh_plugin` VALUES ('1','Baidumap','百度地图','','{\"bdmap_x\":\"114.030794\",\"bdmap_y\":\"22.672039\",\"bdmap_name\":\"\\u56fd\\u4eba\\u4f1f\\u4e1a\",\"bdmap_address\":\"\\u9e3f\\u5b87\\u5927\\u53a6\",\"bdmap_tel\":\"11111\"}','0','','','1');
INSERT INTO `yzh_plugin` VALUES ('2','Mainpro','主营产品','','[{\"product_name\":\"\\u4ea7\\u54c11\",\"product_url\":\"http:\\/\\/www.baidu.com\"}]','0','','','1');
INSERT INTO `yzh_plugin` VALUES ('3','Hotwords','热门关键词','','[{\"name\":\"\\u5173\\u952e\\u8bcd1\",\"url\":\"http:\\/\\/www.baidu.com\"}]','0','','','1');
INSERT INTO `yzh_plugin` VALUES ('4','Baidumap','百度地图','','{\"bdmap_x\":\"114.029152\",\"bdmap_y\":\"22.658085\",\"bdmap_name\":\"\\u5927\\u5e08\\u5085\\u5927\\u5e08\\u5085\",\"bdmap_address\":\"\\u5927\\u5e08\\u5085\\u58eb\\u5927\\u592b\",\"bdmap_tel\":\"11110\"}','0','','','2');
INSERT INTO `yzh_plugin` VALUES ('5','Mainpro','主营产品','','[{\"product_name\":\"\\u4ea7\\u54c11\",\"product_url\":\"http:\\/\\/www.baidu.com\"}]','0','','','2');
INSERT INTO `yzh_plugin` VALUES ('6','Hotwords','热门关键词','','[{\"name\":\"\\u5173\\u952e\\u8bcd1\",\"url\":\"http:\\/\\/www.baidu.com\"}]','0','','','2');
INSERT INTO `yzh_plugin` VALUES ('7','Statistics','流量监控','','','0','','','0');
--
-- 表的结构 `yzh_posid`
-- 
DROP TABLE IF EXISTS `yzh_posid`;
CREATE TABLE `yzh_posid` (
  `id` tinyint(2) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL DEFAULT '',
  `listorder` tinyint(2) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- 
-- 导出`yzh_posid`表中的数据 `yzh_posid`
--
INSERT INTO `yzh_posid` VALUES ('1','首页推荐','0');
INSERT INTO `yzh_posid` VALUES ('2','首页热门','0');
INSERT INTO `yzh_posid` VALUES ('3','首页推荐2','0');
--
-- 表的结构 `yzh_poster`
-- 
DROP TABLE IF EXISTS `yzh_poster`;
CREATE TABLE `yzh_poster` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `appname` varchar(60) NOT NULL,
  `sharetitle` varchar(60) NOT NULL,
  `sharedesc` varchar(255) NOT NULL,
  `sharelogo` varchar(60) NOT NULL,
  `music` varchar(120) NOT NULL,
  `isMusic` tinyint(1) NOT NULL,
  `visit` int(11) NOT NULL,
  `data` text NOT NULL,
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
--
-- 表的结构 `yzh_poster_message`
-- 
DROP TABLE IF EXISTS `yzh_poster_message`;
CREATE TABLE `yzh_poster_message` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `poster_id` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `username` varchar(100) NOT NULL DEFAULT '',
  `qq` varchar(100) NOT NULL DEFAULT '',
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(30) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
--
-- 表的结构 `yzh_product`
-- 
DROP TABLE IF EXISTS `yzh_product`;
CREATE TABLE `yzh_product` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userid` int(11) unsigned NOT NULL DEFAULT '0',
  `username` varchar(40) NOT NULL DEFAULT '',
  `title` varchar(80) NOT NULL DEFAULT '',
  `title_style` varchar(40) NOT NULL DEFAULT '',
  `keywords` varchar(80) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  `content` text NOT NULL,
  `template` varchar(40) NOT NULL DEFAULT '',
  `thumb` varchar(100) NOT NULL DEFAULT '',
  `posid` varchar(50) NOT NULL DEFAULT '0',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `recommend` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `readgroup` varchar(100) NOT NULL DEFAULT '',
  `listorder` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(11) unsigned NOT NULL DEFAULT '0',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `url` varchar(150) NOT NULL DEFAULT '',
  `pics` mediumtext NOT NULL,
  `relation` varchar(250) NOT NULL DEFAULT '',
  `lang` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `carturl` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `status` (`id`,`status`,`listorder`),
  KEY `catid` (`id`,`catid`,`status`),
  KEY `listorder` (`id`,`catid`,`status`,`listorder`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

-- 
-- 导出`yzh_product`表中的数据 `yzh_product`
--
INSERT INTO `yzh_product` VALUES ('22','10','1','super','i8-6','','','Through quality certification and international CE certification, products meet all international safety standards. It widely involves many fields, like domestic and international speakers, smart watches, wireless charging, mobile power, 3C digital, mobile phone and so on.','','','/uploads/201803/5a9f4d7770f5c.jpg','-3-','1','0','','0','0','1520389491','1520491238','0.00','/smartwatch/10-22.html','[]','','1','');
INSERT INTO `yzh_product` VALUES ('23','10','1','super','i8-6','','','Through quality certification and international CE certification, products meet all international safety standards. It widely involves many fields, like domestic and international speakers, smart watches, wireless charging, mobile power, 3C digital, mobile phone and so on.','','','/uploads/201803/5a9f4d85e0a81.jpg','-3-','1','0','','0','0','1520389503','1520491231','0.00','/smartwatch/10-23.html','[]','','1','');
INSERT INTO `yzh_product` VALUES ('24','10','1','super','i8-6','','','Through quality certification and international CE certification, products meet all international safety standards. It widely involves many fields, like domestic and international speakers, smart watches, wireless charging, mobile power, 3C digital, mobile phone and so on.','<p>\n	Through quality certification and international CE certification, products meet all international safety standards. It widely involves many fields, like domestic and international speakers, smart watches, wireless charging, mobile power, 3C digital, mobile phone and so on.\n</p>','','/uploads/201803/5a9f4d901d1e0.jpg','-2-','1','0','','0','5','1520389516','1520491262','0.00','/smartwatch/10-24.html','[]','','1','');
INSERT INTO `yzh_product` VALUES ('12','9','1','super','q7 black','','','','','','/uploads/201803/5a9f4aeab0921.jpg','-1-','1','0','','0','0','1520388829','1520388829','0.00','/bluetoothaudio/9-12.html','[{\"filepath\":\"\\/uploads\\/201803\\/5a9f4af037e0b.jpg\",\"filename\":\"q7\\u9ed1\\u82722.JPG\"}]','','1','');
INSERT INTO `yzh_product` VALUES ('13','9','1','super','q7 Gold','','','','','','/uploads/201803/5a9f4b0ac9966.jpg','-1-','1','0','','0','0','1520388867','1520388867','0.00','/bluetoothaudio/9-13.html','[{\"filepath\":\"\\/uploads\\/201803\\/5a9f4b0fd3b77.jpg\",\"filename\":\"q7\\u91d1\\u82722.JPG\"}]','','1','');
INSERT INTO `yzh_product` VALUES ('14','9','1','super','q7 Rose gold','','','','','','/uploads/201803/5a9f4b48edb72.jpg','-1-','1','0','','0','0','1520388905','1520388905','0.00','/bluetoothaudio/9-14.html','[{\"filepath\":\"\\/uploads\\/201803\\/5a9f4b4ebc303.jpg\",\"filename\":\"q7\\u73ab\\u7470\\u91d12.JPG\"}]','','1','');
INSERT INTO `yzh_product` VALUES ('15','9','1','super','S1 black','','','','','','/uploads/201803/5a9f4bb87b7bf.jpg','-1-','1','0','','0','0','1520389032','1520389032','0.00','/bluetoothaudio/9-15.html','[]','','1','');
INSERT INTO `yzh_product` VALUES ('16','9','1','super','S1 Red','','','','','','/uploads/201803/5a9f4c083737a.jpg','','1','0','','0','0','1520389122','1520389283','0.00','/bluetoothaudio/9-16.html','[]','','1','');
INSERT INTO `yzh_product` VALUES ('17','9','1','super','S1 Gold','','','','','','/uploads/201803/5a9f4c54ab592.jpg','','1','0','','0','0','1520389188','1520389188','0.00','/bluetoothaudio/9-17.html','[]','','1','');
INSERT INTO `yzh_product` VALUES ('18','9','1','super','S1 Blue','','','','','','/uploads/201803/5a9f4c7cb79d5.jpg','-1-','1','0','','0','0','1520389235','1520389235','0.00','/bluetoothaudio/9-18.html','[]','','1','');
INSERT INTO `yzh_product` VALUES ('19','9','1','super','S1 Silver','','','','','','/uploads/201803/5a9f4cbb9bd51.jpg','','1','0','','0','0','1520389302','1520389302','0.00','/bluetoothaudio/9-19.html','[]','','1','');
INSERT INTO `yzh_product` VALUES ('20','10','1','super','i8-6','','','Through quality certification and international CE certification, products meet all international safety standards. It widely involves many fields, like domestic and international speakers, smart watches, wireless charging, mobile power, 3C digital, mobile phone and so on.','','','/uploads/201803/5a9f4ce5b43ad.jpg','-2-','1','0','','0','0','1520389329','1520491193','0.00','/smartwatch/10-20.html','[]','','1','');
INSERT INTO `yzh_product` VALUES ('21','10','1','super','i8-6','','','Through quality certification and international CE certification, products meet all international safety standards. It widely involves many fields, like domestic and international speakers, smart watches, wireless charging, mobile power, 3C digital, mobile phone and so on.','','','/uploads/201803/5a9f4d6cc7403.jpg','-3-','1','0','','0','0','1520389474','1520491247','0.00','/smartwatch/10-21.html','[]','','1','');
INSERT INTO `yzh_product` VALUES ('11','9','1','super','q7 Pink','','','','','','/uploads/201803/5a9f4a7bbe9f4.jpg','-1-','1','0','','0','0','1520388710','1520388710','0.00','/bluetoothaudio/9-11.html','[{\"filepath\":\"\\/uploads\\/201803\\/5a9f4aa14c3a4.jpg\",\"filename\":\"q7\\u7c89\\u82722.JPG\"}]','','1','');
--
-- 表的结构 `yzh_region`
-- 
DROP TABLE IF EXISTS `yzh_region`;
CREATE TABLE `yzh_region` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT '',
  `listorder` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `letter` varchar(60) NOT NULL,
  `hot` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3263 DEFAULT CHARSET=utf8;

-- 
-- 导出`yzh_region`表中的数据 `yzh_region`
--
INSERT INTO `yzh_region` VALUES ('1','0','﻿北京','0','beijing','0');
INSERT INTO `yzh_region` VALUES ('2','1','北京','0','beijing','1');
INSERT INTO `yzh_region` VALUES ('21','0','上海','0','shanghai','0');
INSERT INTO `yzh_region` VALUES ('22','21','上海','0','shanghai','1');
INSERT INTO `yzh_region` VALUES ('42','0','天津','0','tianjin','0');
INSERT INTO `yzh_region` VALUES ('43','42','天津','0','tianjin','1');
INSERT INTO `yzh_region` VALUES ('62','0','重庆','0','chongqin','0');
INSERT INTO `yzh_region` VALUES ('63','62','重庆','0','chongqin','0');
INSERT INTO `yzh_region` VALUES ('104','0','安徽','0','anhui','0');
INSERT INTO `yzh_region` VALUES ('105','104','合肥','0','hefei','0');
INSERT INTO `yzh_region` VALUES ('113','104','安庆','0','anqin','0');
INSERT INTO `yzh_region` VALUES ('124','113','桐城','0','tongcheng','0');
INSERT INTO `yzh_region` VALUES ('125','104','蚌埠','0','bengbu','0');
INSERT INTO `yzh_region` VALUES ('133','104','亳州','0','haozhou','0');
INSERT INTO `yzh_region` VALUES ('138','104','巢湖','0','chaohu','0');
INSERT INTO `yzh_region` VALUES ('144','104','池州','0','chizhou','0');
INSERT INTO `yzh_region` VALUES ('149','104','滁州','0','chuzhou','0');
INSERT INTO `yzh_region` VALUES ('156','149','天长','0','tianchang','0');
INSERT INTO `yzh_region` VALUES ('157','149','明光','0','mingguang','0');
INSERT INTO `yzh_region` VALUES ('158','104','阜阳','0','fuyang','0');
INSERT INTO `yzh_region` VALUES ('166','158','界首','0','jieshou','0');
INSERT INTO `yzh_region` VALUES ('167','104','淮北','0','huaibei','0');
INSERT INTO `yzh_region` VALUES ('172','104','淮南','0','huainan','0');
INSERT INTO `yzh_region` VALUES ('179','104','黄山','0','huangshan','0');
INSERT INTO `yzh_region` VALUES ('187','104','六安','0','liuan','0');
INSERT INTO `yzh_region` VALUES ('195','104','马鞍山','0','maanshan','0');
INSERT INTO `yzh_region` VALUES ('200','104','宿州','0','suzhou2','0');
INSERT INTO `yzh_region` VALUES ('206','104','铜陵','0','tongling','0');
INSERT INTO `yzh_region` VALUES ('211','104','芜湖','0','wuhu','0');
INSERT INTO `yzh_region` VALUES ('219','104','宣城','0','xuancheng','0');
INSERT INTO `yzh_region` VALUES ('226','219','宁国','0','ningguo','0');
INSERT INTO `yzh_region` VALUES ('227','0','福建','0','fujian','0');
INSERT INTO `yzh_region` VALUES ('228','227','福州','0','fouz','0');
INSERT INTO `yzh_region` VALUES ('240','228','福清','0','fuqing','0');
INSERT INTO `yzh_region` VALUES ('241','228','长乐','0','changle','0');
INSERT INTO `yzh_region` VALUES ('242','227','龙岩','0','longyan','0');
INSERT INTO `yzh_region` VALUES ('249','242','漳平','0','zhangping','0');
INSERT INTO `yzh_region` VALUES ('250','227','南平','0','nanping','0');
INSERT INTO `yzh_region` VALUES ('257','250','邵武','0','shaowu','0');
INSERT INTO `yzh_region` VALUES ('258','250','武夷山','0','wuyishan','0');
INSERT INTO `yzh_region` VALUES ('259','250','建瓯','0','jian','0');
INSERT INTO `yzh_region` VALUES ('260','250','建阳','0','jianyang','0');
INSERT INTO `yzh_region` VALUES ('261','227','宁德','0','ningde','0');
INSERT INTO `yzh_region` VALUES ('269','261','福安','0','fuan','0');
INSERT INTO `yzh_region` VALUES ('270','261','福鼎','0','fuding','0');
INSERT INTO `yzh_region` VALUES ('271','227','莆田','0','putian','0');
INSERT INTO `yzh_region` VALUES ('277','227','泉州','0','quanzhou','0');
INSERT INTO `yzh_region` VALUES ('287','277','石狮','0','shishi','0');
INSERT INTO `yzh_region` VALUES ('288','277','晋江','0','jinjiang','0');
INSERT INTO `yzh_region` VALUES ('289','277','南安','0','nanan','0');
INSERT INTO `yzh_region` VALUES ('290','227','三明','0','sanming','0');
INSERT INTO `yzh_region` VALUES ('302','290','永安','0','yongan','0');
INSERT INTO `yzh_region` VALUES ('303','227','厦门','0','xiamen','0');
INSERT INTO `yzh_region` VALUES ('310','227','漳州','0','zhangzhou','0');
INSERT INTO `yzh_region` VALUES ('321','310','龙海','0','longhai','0');
INSERT INTO `yzh_region` VALUES ('322','0','甘肃','0','gansu','0');
INSERT INTO `yzh_region` VALUES ('323','322','兰州','0','lanzhou','0');
INSERT INTO `yzh_region` VALUES ('332','322','白银','0','baiyin','0');
INSERT INTO `yzh_region` VALUES ('338','322','定西','0','dingxi','0');
INSERT INTO `yzh_region` VALUES ('346','322','甘南','0','gannan','0');
INSERT INTO `yzh_region` VALUES ('355','322','嘉峪关','0','jiayuguan','0');
INSERT INTO `yzh_region` VALUES ('356','322','金昌','0','jinchang','0');
INSERT INTO `yzh_region` VALUES ('359','322','酒泉','0','jiuquan','0');
INSERT INTO `yzh_region` VALUES ('365','359','玉门','0','yumen','0');
INSERT INTO `yzh_region` VALUES ('366','359','敦煌','0','dunhuang','0');
INSERT INTO `yzh_region` VALUES ('367','322','临夏','0','linxia','0');
INSERT INTO `yzh_region` VALUES ('368','367','临夏','0','linxia','0');
INSERT INTO `yzh_region` VALUES ('376','322','陇南','0','longnan','0');
INSERT INTO `yzh_region` VALUES ('386','322','平凉','0','pingliang','0');
INSERT INTO `yzh_region` VALUES ('394','322','庆阳','0','qingyang','0');
INSERT INTO `yzh_region` VALUES ('403','322','天水','0','tianshui','0');
INSERT INTO `yzh_region` VALUES ('411','322','武威','0','wuwei','0');
INSERT INTO `yzh_region` VALUES ('416','322','张掖','0','zhangye','0');
INSERT INTO `yzh_region` VALUES ('423','0','广东','0','guangdong','0');
INSERT INTO `yzh_region` VALUES ('424','423','广州','0','guanzhou','1');
INSERT INTO `yzh_region` VALUES ('435','424','增城','0','zengcheng','0');
INSERT INTO `yzh_region` VALUES ('436','424','从化','0','conghua','0');
INSERT INTO `yzh_region` VALUES ('437','423','潮州','0','chaozhou','0');
INSERT INTO `yzh_region` VALUES ('441','423','东莞','0','dong','0');
INSERT INTO `yzh_region` VALUES ('442','423','佛山','0','foshan','0');
INSERT INTO `yzh_region` VALUES ('448','423','河源','0','heyuan','0');
INSERT INTO `yzh_region` VALUES ('455','423','惠州','0','huizhou','0');
INSERT INTO `yzh_region` VALUES ('461','423','江门','0','jiangmen','0');
INSERT INTO `yzh_region` VALUES ('465','461','台山','0','taishan','0');
INSERT INTO `yzh_region` VALUES ('466','461','开平','0','kaiping','0');
INSERT INTO `yzh_region` VALUES ('467','461','鹤山','0','heshan','0');
INSERT INTO `yzh_region` VALUES ('468','461','恩平','0','enping','0');
INSERT INTO `yzh_region` VALUES ('469','423','揭阳','0','jieyang','0');
INSERT INTO `yzh_region` VALUES ('474','469','普宁','0','puning','0');
INSERT INTO `yzh_region` VALUES ('475','423','茂名','0','maoming','0');
INSERT INTO `yzh_region` VALUES ('479','475','高州','0','gaozhou','0');
INSERT INTO `yzh_region` VALUES ('480','475','化州','0','huazhou','0');
INSERT INTO `yzh_region` VALUES ('481','475','信宜','0','xinyi','0');
INSERT INTO `yzh_region` VALUES ('483','423','梅州','0','meizhou','0');
INSERT INTO `yzh_region` VALUES ('490','483','兴宁','0','xingning','0');
INSERT INTO `yzh_region` VALUES ('491','423','清远','0','qingyuan','0');
INSERT INTO `yzh_region` VALUES ('498','491','英德','0','yingde','0');
INSERT INTO `yzh_region` VALUES ('499','491','连州','0','lianzhou','0');
INSERT INTO `yzh_region` VALUES ('500','423','汕头','0','shantou','0');
INSERT INTO `yzh_region` VALUES ('508','423','汕尾','0','shanwei','0');
INSERT INTO `yzh_region` VALUES ('512','508','陆丰','0','lufeng','0');
INSERT INTO `yzh_region` VALUES ('513','423','韶关','0','shaoguan','0');
INSERT INTO `yzh_region` VALUES ('522','513','乐昌','0','lechang','0');
INSERT INTO `yzh_region` VALUES ('523','513','南雄','0','nanxiong','0');
INSERT INTO `yzh_region` VALUES ('524','423','深圳','0','shenzhen','1');
INSERT INTO `yzh_region` VALUES ('531','423','阳江','0','yangjiang','0');
INSERT INTO `yzh_region` VALUES ('535','531','阳春','0','yangchun','0');
INSERT INTO `yzh_region` VALUES ('536','423','云浮','0','yunfu','0');
INSERT INTO `yzh_region` VALUES ('541','536','罗定','0','luoding','0');
INSERT INTO `yzh_region` VALUES ('542','423','湛江','0','zhanjiang','0');
INSERT INTO `yzh_region` VALUES ('549','542','廉江','0','lianjiang','0');
INSERT INTO `yzh_region` VALUES ('550','542','雷州','0','leizhou','0');
INSERT INTO `yzh_region` VALUES ('551','542','吴川','0','wuchuan','0');
INSERT INTO `yzh_region` VALUES ('552','423','肇庆','0','zhaoqing','0');
INSERT INTO `yzh_region` VALUES ('559','552','高要','0','gaoyao','0');
INSERT INTO `yzh_region` VALUES ('560','552','四会','0','sihui','0');
INSERT INTO `yzh_region` VALUES ('561','423','中山','0','zhongshan','0');
INSERT INTO `yzh_region` VALUES ('562','423','珠海','0','zhuhai','0');
INSERT INTO `yzh_region` VALUES ('566','0','广西','0','guangxi','0');
INSERT INTO `yzh_region` VALUES ('567','566','南宁','0','nanning','0');
INSERT INTO `yzh_region` VALUES ('580','566','百色','0','baise','0');
INSERT INTO `yzh_region` VALUES ('593','566','北海','0','beihai','0');
INSERT INTO `yzh_region` VALUES ('598','566','崇左','0','chongzuo','0');
INSERT INTO `yzh_region` VALUES ('605','598','凭祥','0','pingxiang','0');
INSERT INTO `yzh_region` VALUES ('606','566','防城港','0','fangchenggang','0');
INSERT INTO `yzh_region` VALUES ('610','606','东兴','0','dongxing','0');
INSERT INTO `yzh_region` VALUES ('611','566','贵港','0','guigang','0');
INSERT INTO `yzh_region` VALUES ('616','611','桂平','0','guiping','0');
INSERT INTO `yzh_region` VALUES ('617','566','桂林','0','guilin','0');
INSERT INTO `yzh_region` VALUES ('635','566','河池','0','hechi','0');
INSERT INTO `yzh_region` VALUES ('646','635','宜州','0','yizhou','0');
INSERT INTO `yzh_region` VALUES ('647','566','贺州','0','hezhou','0');
INSERT INTO `yzh_region` VALUES ('652','566','来宾','0','laibin','0');
INSERT INTO `yzh_region` VALUES ('658','652','合山','0','heshan','0');
INSERT INTO `yzh_region` VALUES ('659','566','柳州','0','liuzhou','0');
INSERT INTO `yzh_region` VALUES ('670','566','钦州','0','qinzhou','0');
INSERT INTO `yzh_region` VALUES ('675','566','梧州','0','wuzhou','0');
INSERT INTO `yzh_region` VALUES ('682','675','岑溪','0','xi','0');
INSERT INTO `yzh_region` VALUES ('683','566','玉林','0','yulin','0');
INSERT INTO `yzh_region` VALUES ('689','683','北流','0','beiliu','0');
INSERT INTO `yzh_region` VALUES ('690','0','贵州','0','guizhou','0');
INSERT INTO `yzh_region` VALUES ('691','690','贵阳','0','guiyang','0');
INSERT INTO `yzh_region` VALUES ('701','690','清镇','0','qingzhen','0');
INSERT INTO `yzh_region` VALUES ('702','690','安顺','0','anshun','0');
INSERT INTO `yzh_region` VALUES ('710','709','毕节','0','bijie','0');
INSERT INTO `yzh_region` VALUES ('718','690','六盘水','0','liupanshui','0');
INSERT INTO `yzh_region` VALUES ('723','690','黔东南','0','qiandongnan','0');
INSERT INTO `yzh_region` VALUES ('724','723','凯里','0','kaili','0');
INSERT INTO `yzh_region` VALUES ('740','690','黔南','0','qiannan','0');
INSERT INTO `yzh_region` VALUES ('741','740','都匀','0','duyun','0');
INSERT INTO `yzh_region` VALUES ('742','740','福泉','0','fuquan','0');
INSERT INTO `yzh_region` VALUES ('753','690','黔西南','0','qianxinan','0');
INSERT INTO `yzh_region` VALUES ('754','753','兴义','0','xingyi','0');
INSERT INTO `yzh_region` VALUES ('763','762','铜仁','0','tongren','0');
INSERT INTO `yzh_region` VALUES ('773','690','遵义','0','zunyi','0');
INSERT INTO `yzh_region` VALUES ('786','773','赤水','0','chishui','0');
INSERT INTO `yzh_region` VALUES ('787','773','仁怀','0','renhuai','0');
INSERT INTO `yzh_region` VALUES ('788','0','海南','0','hainan','0');
INSERT INTO `yzh_region` VALUES ('789','788','海口','0','haikou','0');
INSERT INTO `yzh_region` VALUES ('798','788','儋州','0','zhou','0');
INSERT INTO `yzh_region` VALUES ('800','788','东方','0','dongfang','0');
INSERT INTO `yzh_region` VALUES ('804','788','南沙群岛','0','nanshaqundao','0');
INSERT INTO `yzh_region` VALUES ('805','788','琼海','0','qionghai','0');
INSERT INTO `yzh_region` VALUES ('807','788','三亚','0','sanya','0');
INSERT INTO `yzh_region` VALUES ('809','788','万宁','0','wanning','0');
INSERT INTO `yzh_region` VALUES ('810','788','文昌','0','wenchang','0');
INSERT INTO `yzh_region` VALUES ('811','788','五指山','0','wuzhishan','0');
INSERT INTO `yzh_region` VALUES ('812','788','西沙群岛','0','xishaqundao','0');
INSERT INTO `yzh_region` VALUES ('814','0','河北','0','hebei','0');
INSERT INTO `yzh_region` VALUES ('815','814','石家庄','0','shijiazhuang','0');
INSERT INTO `yzh_region` VALUES ('836','815','晋州','0','jinzhou','0');
INSERT INTO `yzh_region` VALUES ('837','815','新乐','0','xinle','0');
INSERT INTO `yzh_region` VALUES ('838','815','鹿泉','0','luquan','0');
INSERT INTO `yzh_region` VALUES ('839','814','保定','0','baoding','0');
INSERT INTO `yzh_region` VALUES ('861','839','涿州','0','zhou','0');
INSERT INTO `yzh_region` VALUES ('862','839','定州','0','dingzhou','0');
INSERT INTO `yzh_region` VALUES ('863','839','安国','0','anguo','0');
INSERT INTO `yzh_region` VALUES ('864','839','高碑店','0','gaobeidian','0');
INSERT INTO `yzh_region` VALUES ('865','814','沧州','0','cangzhou','0');
INSERT INTO `yzh_region` VALUES ('878','865','泊头','0','botou','0');
INSERT INTO `yzh_region` VALUES ('879','865','任丘','0','renqiu','0');
INSERT INTO `yzh_region` VALUES ('880','865','黄骅','0','huang','0');
INSERT INTO `yzh_region` VALUES ('881','865','河间','0','hejian','0');
INSERT INTO `yzh_region` VALUES ('882','814','承德','0','chengde','0');
INSERT INTO `yzh_region` VALUES ('894','814','邯郸','0','handan','0');
INSERT INTO `yzh_region` VALUES ('913','894','武安','0','wuan','0');
INSERT INTO `yzh_region` VALUES ('914','814','衡水','0','hengshui','0');
INSERT INTO `yzh_region` VALUES ('924','914','冀州','0','jizhou','0');
INSERT INTO `yzh_region` VALUES ('925','914','深州','0','shenzhou','0');
INSERT INTO `yzh_region` VALUES ('926','814','廊坊','0','langfang','0');
INSERT INTO `yzh_region` VALUES ('935','926','霸州','0','bazhou','0');
INSERT INTO `yzh_region` VALUES ('936','926','三河','0','sanhe','0');
INSERT INTO `yzh_region` VALUES ('937','814','秦皇岛','0','qinhuangdao','0');
INSERT INTO `yzh_region` VALUES ('945','814','唐山','0','tangshan','0');
INSERT INTO `yzh_region` VALUES ('958','945','遵化','0','zunhua','0');
INSERT INTO `yzh_region` VALUES ('959','945','迁安','0','qianan','0');
INSERT INTO `yzh_region` VALUES ('960','814','邢台','0','xingtai','0');
INSERT INTO `yzh_region` VALUES ('978','960','南宫','0','nangong','0');
INSERT INTO `yzh_region` VALUES ('979','960','沙河','0','shahe','0');
INSERT INTO `yzh_region` VALUES ('980','814','张家口','0','zhangjiakou','0');
INSERT INTO `yzh_region` VALUES ('998','0','河南','0','henan','0');
INSERT INTO `yzh_region` VALUES ('999','998','郑州','0','zhengzhou','0');
INSERT INTO `yzh_region` VALUES ('1007','999','巩义','0','gongyi','0');
INSERT INTO `yzh_region` VALUES ('1008','999','荥阳','0','yang','0');
INSERT INTO `yzh_region` VALUES ('1009','999','新密','0','xinmi','0');
INSERT INTO `yzh_region` VALUES ('1010','999','新郑','0','xinzheng','0');
INSERT INTO `yzh_region` VALUES ('1011','999','登封','0','dengfeng','0');
INSERT INTO `yzh_region` VALUES ('1012','998','安阳','0','anyang','0');
INSERT INTO `yzh_region` VALUES ('1021','1012','林州','0','linzhou','0');
INSERT INTO `yzh_region` VALUES ('1022','998','鹤壁','0','hebi','0');
INSERT INTO `yzh_region` VALUES ('1028','998','济源','0','jiyuan','0');
INSERT INTO `yzh_region` VALUES ('1029','998','焦作','0','jiaozuo','0');
INSERT INTO `yzh_region` VALUES ('1038','1029','济源','0','jiyuan','0');
INSERT INTO `yzh_region` VALUES ('1039','1029','沁阳','0','qinyang','0');
INSERT INTO `yzh_region` VALUES ('1040','1029','孟州','0','mengzhou','0');
INSERT INTO `yzh_region` VALUES ('1041','998','开封','0','kaifeng','0');
INSERT INTO `yzh_region` VALUES ('1052','998','洛阳','0','luoyang','0');
INSERT INTO `yzh_region` VALUES ('1067','1052','偃师','0','shi','0');
INSERT INTO `yzh_region` VALUES ('1068','998','漯河','0','he','0');
INSERT INTO `yzh_region` VALUES ('1074','998','南阳','0','nanyang','0');
INSERT INTO `yzh_region` VALUES ('1087','1074','邓州','0','dengzhou','0');
INSERT INTO `yzh_region` VALUES ('1088','998','平顶山','0','pingdingshan','0');
INSERT INTO `yzh_region` VALUES ('1097','1088','舞钢','0','wugang','0');
INSERT INTO `yzh_region` VALUES ('1098','1088','汝州','0','ruzhou','0');
INSERT INTO `yzh_region` VALUES ('1099','998','濮阳','0','yang','0');
INSERT INTO `yzh_region` VALUES ('1106','998','三门峡','0','sanmenxia','0');
INSERT INTO `yzh_region` VALUES ('1111','1106','义马','0','yima','0');
INSERT INTO `yzh_region` VALUES ('1112','1106','灵宝','0','lingbao','0');
INSERT INTO `yzh_region` VALUES ('1113','998','商丘','0','shangqiu','0');
INSERT INTO `yzh_region` VALUES ('1122','1113','永城','0','yongcheng','0');
INSERT INTO `yzh_region` VALUES ('1123','998','新乡','0','xinxiang','0');
INSERT INTO `yzh_region` VALUES ('1134','1123','卫辉','0','weihui','0');
INSERT INTO `yzh_region` VALUES ('1136','998','信阳','0','xinyang','0');
INSERT INTO `yzh_region` VALUES ('1147','998','许昌','0','xuchang','0');
INSERT INTO `yzh_region` VALUES ('1152','1147','禹州','0','yuzhou','0');
INSERT INTO `yzh_region` VALUES ('1153','1147','长葛','0','changge','0');
INSERT INTO `yzh_region` VALUES ('1154','998','周口','0','zhoukou','0');
INSERT INTO `yzh_region` VALUES ('1164','1154','项城','0','xiangcheng','0');
INSERT INTO `yzh_region` VALUES ('1165','998','驻马店','0','zhumadian','0');
INSERT INTO `yzh_region` VALUES ('1176','0','黑龙江','0','heilongjiang','0');
INSERT INTO `yzh_region` VALUES ('1177','1176','哈尔滨','0','haerbin','1');
INSERT INTO `yzh_region` VALUES ('1196','1177','五常','0','wuchang','0');
INSERT INTO `yzh_region` VALUES ('1197','1176','大庆','0','daqing','0');
INSERT INTO `yzh_region` VALUES ('1211','1176','鹤岗','0','hegang','0');
INSERT INTO `yzh_region` VALUES ('1220','1176','黑河','0','heihe','0');
INSERT INTO `yzh_region` VALUES ('1225','1220','北安','0','beian','0');
INSERT INTO `yzh_region` VALUES ('1226','1220','五大连池','0','wudalianchi','0');
INSERT INTO `yzh_region` VALUES ('1227','1176','鸡西','0','jixi','0');
INSERT INTO `yzh_region` VALUES ('1235','1227','虎林','0','hulin','0');
INSERT INTO `yzh_region` VALUES ('1236','1227','密山','0','mishan','0');
INSERT INTO `yzh_region` VALUES ('1237','1176','佳木斯','0','jiamusi','0');
INSERT INTO `yzh_region` VALUES ('1247','1237','同江','0','tongjiang','0');
INSERT INTO `yzh_region` VALUES ('1248','1237','富锦','0','fujin','0');
INSERT INTO `yzh_region` VALUES ('1249','1176','牡丹江','0','mudanjiang','0');
INSERT INTO `yzh_region` VALUES ('1256','1249','绥芬河','0','suifenhe','0');
INSERT INTO `yzh_region` VALUES ('1257','1249','海林','0','hailin','0');
INSERT INTO `yzh_region` VALUES ('1258','1249','宁安','0','ningan','0');
INSERT INTO `yzh_region` VALUES ('1259','1249','穆棱','0','muleng','0');
INSERT INTO `yzh_region` VALUES ('1260','1176','七台河','0','qitaihe','0');
INSERT INTO `yzh_region` VALUES ('1265','1176','齐齐哈尔','0','qiqihaer','0');
INSERT INTO `yzh_region` VALUES ('1281','1265','讷河','0','he','0');
INSERT INTO `yzh_region` VALUES ('1282','1176','双鸭山','0','shuangyashan','0');
INSERT INTO `yzh_region` VALUES ('1291','1176','绥化','0','suihua','0');
INSERT INTO `yzh_region` VALUES ('1299','1291','安达','0','anda','0');
INSERT INTO `yzh_region` VALUES ('1300','1291','肇东','0','zhaodong','0');
INSERT INTO `yzh_region` VALUES ('1301','1291','海伦','0','hailun','0');
INSERT INTO `yzh_region` VALUES ('1302','1176','伊春','0','yichun','0');
INSERT INTO `yzh_region` VALUES ('1319','1302','铁力','0','tieli','0');
INSERT INTO `yzh_region` VALUES ('1320','0','湖北','0','hubei','0');
INSERT INTO `yzh_region` VALUES ('1321','1320','武汉','0','wuhan','1');
INSERT INTO `yzh_region` VALUES ('1335','1320','鄂州','0','ezhou','0');
INSERT INTO `yzh_region` VALUES ('1339','1320','恩施','0','enshi','0');
INSERT INTO `yzh_region` VALUES ('1340','1339','恩施','0','enshi','0');
INSERT INTO `yzh_region` VALUES ('1341','1339','利川','0','lichuan','0');
INSERT INTO `yzh_region` VALUES ('1348','1320','黄冈','0','huanggang','0');
INSERT INTO `yzh_region` VALUES ('1357','1348','麻城','0','macheng','0');
INSERT INTO `yzh_region` VALUES ('1358','1348','武穴','0','wuxue','0');
INSERT INTO `yzh_region` VALUES ('1359','1320','黄石','0','huangshi','0');
INSERT INTO `yzh_region` VALUES ('1365','1359','大冶','0','daye','0');
INSERT INTO `yzh_region` VALUES ('1366','1320','荆门','0','jingmen','0');
INSERT INTO `yzh_region` VALUES ('1371','1366','钟祥','0','zhongxiang','0');
INSERT INTO `yzh_region` VALUES ('1372','1320','荆州','0','jingzhou','0');
INSERT INTO `yzh_region` VALUES ('1378','1372','石首','0','shishou','0');
INSERT INTO `yzh_region` VALUES ('1379','1372','洪湖','0','honghu','0');
INSERT INTO `yzh_region` VALUES ('1380','1372','松滋','0','songzi','0');
INSERT INTO `yzh_region` VALUES ('1381','1320','潜江','0','qianjiang','0');
INSERT INTO `yzh_region` VALUES ('1383','1320','十堰','0','shiyan','0');
INSERT INTO `yzh_region` VALUES ('1391','1383','丹江口','0','danjiangkou','0');
INSERT INTO `yzh_region` VALUES ('1392','1320','随州','0','suizhou','0');
INSERT INTO `yzh_region` VALUES ('1394','1392','广水','0','guangshui','0');
INSERT INTO `yzh_region` VALUES ('1395','1320','天门','0','tianmen','0');
INSERT INTO `yzh_region` VALUES ('1396','1320','仙桃','0','xiantao','0');
INSERT INTO `yzh_region` VALUES ('1397','1320','咸宁','0','xianning','0');
INSERT INTO `yzh_region` VALUES ('1403','1397','赤壁','0','chibi','0');
INSERT INTO `yzh_region` VALUES ('1404','1320','襄樊','0','xiangfan','0');
INSERT INTO `yzh_region` VALUES ('1411','1404','老河口','0','laohekou','0');
INSERT INTO `yzh_region` VALUES ('1412','1404','枣阳','0','zaoyang','0');
INSERT INTO `yzh_region` VALUES ('1413','1404','宜城','0','yicheng','0');
INSERT INTO `yzh_region` VALUES ('1414','1320','孝感','0','xiaogan','0');
INSERT INTO `yzh_region` VALUES ('1419','1414','应城','0','yingcheng','0');
INSERT INTO `yzh_region` VALUES ('1420','1414','安陆','0','anlu','0');
INSERT INTO `yzh_region` VALUES ('1421','1414','汉川','0','hanchuan','0');
INSERT INTO `yzh_region` VALUES ('1422','1320','宜昌','0','yichang','0');
INSERT INTO `yzh_region` VALUES ('1433','1422','宜都','0','yidu','0');
INSERT INTO `yzh_region` VALUES ('1434','1422','当阳','0','dangyang','0');
INSERT INTO `yzh_region` VALUES ('1435','1422','枝江','0','zhijiang','0');
INSERT INTO `yzh_region` VALUES ('1436','0','湖南','0','hunan','0');
INSERT INTO `yzh_region` VALUES ('1437','1436','长沙','0','changsha','1');
INSERT INTO `yzh_region` VALUES ('1446','1437','浏阳','0','yang','0');
INSERT INTO `yzh_region` VALUES ('1447','1436','常德','0','changde','0');
INSERT INTO `yzh_region` VALUES ('1456','1447','津','0','jin','0');
INSERT INTO `yzh_region` VALUES ('1457','1436','郴州','0','chenzhou','0');
INSERT INTO `yzh_region` VALUES ('1468','1457','资兴','0','zixing','0');
INSERT INTO `yzh_region` VALUES ('1469','1436','衡阳','0','hengyang','0');
INSERT INTO `yzh_region` VALUES ('1480','1469','耒阳','0','yang','0');
INSERT INTO `yzh_region` VALUES ('1481','1469','常宁','0','changning','0');
INSERT INTO `yzh_region` VALUES ('1482','1436','怀化','0','huaihua','0');
INSERT INTO `yzh_region` VALUES ('1494','1482','洪江','0','hongjiang','0');
INSERT INTO `yzh_region` VALUES ('1495','1436','娄底','0','loudi','0');
INSERT INTO `yzh_region` VALUES ('1499','1495','冷水江','0','lengshuijiang','0');
INSERT INTO `yzh_region` VALUES ('1500','1495','涟源','0','lianyuan','0');
INSERT INTO `yzh_region` VALUES ('1501','1436','邵阳','0','shaoyang','0');
INSERT INTO `yzh_region` VALUES ('1513','1501','武冈','0','wugang','0');
INSERT INTO `yzh_region` VALUES ('1514','1436','湘潭','0','xiangtan','0');
INSERT INTO `yzh_region` VALUES ('1518','1514','湘乡','0','xiangxiang','0');
INSERT INTO `yzh_region` VALUES ('1519','1514','韶山','0','shaoshan','0');
INSERT INTO `yzh_region` VALUES ('1520','1436','湘西','0','xiangxi','0');
INSERT INTO `yzh_region` VALUES ('1521','1520','吉首','0','jishou','0');
INSERT INTO `yzh_region` VALUES ('1529','1436','益阳','0','yiyang','0');
INSERT INTO `yzh_region` VALUES ('1535','1529','沅江','0','jiang','0');
INSERT INTO `yzh_region` VALUES ('1536','1436','永州','0','yongzhou','0');
INSERT INTO `yzh_region` VALUES ('1548','1436','岳阳','0','yueyang','0');
INSERT INTO `yzh_region` VALUES ('1556','1548','汨罗','0','luo','0');
INSERT INTO `yzh_region` VALUES ('1557','1548','临湘','0','linxiang','0');
INSERT INTO `yzh_region` VALUES ('1558','1436','张家界','0','zhangjiajie','0');
INSERT INTO `yzh_region` VALUES ('1563','1436','株洲','0','zhuzhou','0');
INSERT INTO `yzh_region` VALUES ('1572','1563','醴陵','0','ling','0');
INSERT INTO `yzh_region` VALUES ('1573','0','吉林','0','jilin','0');
INSERT INTO `yzh_region` VALUES ('1574','1573','长春','0','changchun','0');
INSERT INTO `yzh_region` VALUES ('1582','1574','九台','0','jiutai','0');
INSERT INTO `yzh_region` VALUES ('1583','1574','榆树','0','yushu','0');
INSERT INTO `yzh_region` VALUES ('1584','1574','德惠','0','dehui','0');
INSERT INTO `yzh_region` VALUES ('1585','1573','白城','0','baicheng','0');
INSERT INTO `yzh_region` VALUES ('1589','1585','洮南','0','nan','0');
INSERT INTO `yzh_region` VALUES ('1590','1585','大安','0','daan','0');
INSERT INTO `yzh_region` VALUES ('1591','1573','白山','0','baishan','0');
INSERT INTO `yzh_region` VALUES ('1597','1591','临江','0','linjiang','0');
INSERT INTO `yzh_region` VALUES ('1598','1573','吉林','0','jilin','0');
INSERT INTO `yzh_region` VALUES ('1604','1598','蛟河','0','he','0');
INSERT INTO `yzh_region` VALUES ('1605','1598','桦甸','0','dian','0');
INSERT INTO `yzh_region` VALUES ('1606','1598','舒兰','0','shulan','0');
INSERT INTO `yzh_region` VALUES ('1607','1598','磐石','0','panshi','0');
INSERT INTO `yzh_region` VALUES ('1608','1573','辽源','0','liaoyuan','0');
INSERT INTO `yzh_region` VALUES ('1613','1573','四平','0','siping','0');
INSERT INTO `yzh_region` VALUES ('1618','1613','公主岭','0','gongzhuling','0');
INSERT INTO `yzh_region` VALUES ('1619','1613','双辽','0','shuangliao','0');
INSERT INTO `yzh_region` VALUES ('1620','1573','松原','0','songyuan','0');
INSERT INTO `yzh_region` VALUES ('1626','1573','通化','0','tonghua','0');
INSERT INTO `yzh_region` VALUES ('1632','1626','梅河口','0','meihekou','0');
INSERT INTO `yzh_region` VALUES ('1633','1626','集安','0','jian','0');
INSERT INTO `yzh_region` VALUES ('1634','1573','延边','0','yanbian','0');
INSERT INTO `yzh_region` VALUES ('1635','1634','延吉','0','yanji','0');
INSERT INTO `yzh_region` VALUES ('1636','1634','图们','0','tumen','0');
INSERT INTO `yzh_region` VALUES ('1637','1634','敦化','0','dunhua','0');
INSERT INTO `yzh_region` VALUES ('1638','1634','珲春','0','chun','0');
INSERT INTO `yzh_region` VALUES ('1639','1634','龙井','0','longjing','0');
INSERT INTO `yzh_region` VALUES ('1640','1634','和龙','0','helong','0');
INSERT INTO `yzh_region` VALUES ('1643','0','江苏','0','jiangsu','0');
INSERT INTO `yzh_region` VALUES ('1644','1643','南京','0','nanjing','1');
INSERT INTO `yzh_region` VALUES ('1658','1643','常州','0','changzhou','0');
INSERT INTO `yzh_region` VALUES ('1664','1658','溧阳','0','yang','0');
INSERT INTO `yzh_region` VALUES ('1665','1658','金坛','0','jintan','0');
INSERT INTO `yzh_region` VALUES ('1666','1643','淮安','0','huaian','0');
INSERT INTO `yzh_region` VALUES ('1675','1643','连云港','0','lianyungang','0');
INSERT INTO `yzh_region` VALUES ('1683','1643','南通','0','nantong','0');
INSERT INTO `yzh_region` VALUES ('1688','1683','启东','0','qidong','0');
INSERT INTO `yzh_region` VALUES ('1689','1683','如皋','0','rugao','0');
INSERT INTO `yzh_region` VALUES ('1690','1683','通州','0','tongzhou','0');
INSERT INTO `yzh_region` VALUES ('1691','1683','海门','0','haimen','0');
INSERT INTO `yzh_region` VALUES ('1692','1643','苏州','0','suzhou','0');
INSERT INTO `yzh_region` VALUES ('1699','1692','常熟','0','changshu','0');
INSERT INTO `yzh_region` VALUES ('1700','1692','张家港','0','zhangjiagang','0');
INSERT INTO `yzh_region` VALUES ('1701','1692','昆山','0','kunshan','0');
INSERT INTO `yzh_region` VALUES ('1702','1692','吴江','0','wujiang','0');
INSERT INTO `yzh_region` VALUES ('1703','1692','太仓','0','taicang','0');
INSERT INTO `yzh_region` VALUES ('1704','1643','宿迁','0','suqian','0');
INSERT INTO `yzh_region` VALUES ('1710','1643','泰州','0','taizhou','0');
INSERT INTO `yzh_region` VALUES ('1713','1710','兴化','0','xinghua','0');
INSERT INTO `yzh_region` VALUES ('1714','1710','靖江','0','jingjiang','0');
INSERT INTO `yzh_region` VALUES ('1715','1710','泰兴','0','taixing','0');
INSERT INTO `yzh_region` VALUES ('1716','1710','姜堰','0','jiangyan','0');
INSERT INTO `yzh_region` VALUES ('1717','1643','无锡','0','wuxi','0');
INSERT INTO `yzh_region` VALUES ('1724','1717','江阴','0','jiangyin','0');
INSERT INTO `yzh_region` VALUES ('1725','1717','宜兴','0','yixing','0');
INSERT INTO `yzh_region` VALUES ('1726','1643','徐州','0','xuzhou','0');
INSERT INTO `yzh_region` VALUES ('1736','1726','新沂','0','xinyi','0');
INSERT INTO `yzh_region` VALUES ('1737','1726','邳州','0','zhou','0');
INSERT INTO `yzh_region` VALUES ('1738','1643','盐城','0','yancheng','0');
INSERT INTO `yzh_region` VALUES ('1746','1738','东台','0','dongtai','0');
INSERT INTO `yzh_region` VALUES ('1747','1738','大丰','0','dafeng','0');
INSERT INTO `yzh_region` VALUES ('1748','1643','扬州','0','yangzhou','0');
INSERT INTO `yzh_region` VALUES ('1753','1748','仪征','0','yizheng','0');
INSERT INTO `yzh_region` VALUES ('1754','1748','高邮','0','gaoyou','0');
INSERT INTO `yzh_region` VALUES ('1755','1748','江都','0','jiangdu','0');
INSERT INTO `yzh_region` VALUES ('1756','1643','镇江','0','zhenjiang','0');
INSERT INTO `yzh_region` VALUES ('1760','1756','丹阳','0','danyang','0');
INSERT INTO `yzh_region` VALUES ('1761','1756','扬中','0','yangzhong','0');
INSERT INTO `yzh_region` VALUES ('1762','1756','句容','0','jurong','0');
INSERT INTO `yzh_region` VALUES ('1763','0','江西','0','jiangxi','0');
INSERT INTO `yzh_region` VALUES ('1764','1763','南昌','0','nanchang','1');
INSERT INTO `yzh_region` VALUES ('1774','1763','抚州','0','fuzhou','0');
INSERT INTO `yzh_region` VALUES ('1786','1763','赣州','0','ganzhou','0');
INSERT INTO `yzh_region` VALUES ('1803','1786','瑞金','0','ruijin','0');
INSERT INTO `yzh_region` VALUES ('1804','1786','南康','0','nankang','0');
INSERT INTO `yzh_region` VALUES ('1805','1763','吉安','0','jian','0');
INSERT INTO `yzh_region` VALUES ('1818','1805','井冈山','0','jinggangshan','0');
INSERT INTO `yzh_region` VALUES ('1819','1763','景德镇','0','jingdezhen','0');
INSERT INTO `yzh_region` VALUES ('1823','1819','乐平','0','leping','0');
INSERT INTO `yzh_region` VALUES ('1824','1763','九江','0','jiujiang','0');
INSERT INTO `yzh_region` VALUES ('1836','1824','瑞昌','0','ruichang','0');
INSERT INTO `yzh_region` VALUES ('1837','1763','萍乡','0','pingxiang','0');
INSERT INTO `yzh_region` VALUES ('1843','1763','上饶','0','shangrao','0');
INSERT INTO `yzh_region` VALUES ('1855','1843','德兴','0','dexing','0');
INSERT INTO `yzh_region` VALUES ('1856','1763','新余','0','xinyu','0');
INSERT INTO `yzh_region` VALUES ('1859','1763','宜春','0','yichun','0');
INSERT INTO `yzh_region` VALUES ('1867','1859','丰城','0','fengcheng','0');
INSERT INTO `yzh_region` VALUES ('1868','1859','樟树','0','zhangshu','0');
INSERT INTO `yzh_region` VALUES ('1869','1859','高安','0','gaoan','0');
INSERT INTO `yzh_region` VALUES ('1870','1763','鹰潭','0','yingtan','0');
INSERT INTO `yzh_region` VALUES ('1873','1870','贵溪','0','guixi','0');
INSERT INTO `yzh_region` VALUES ('1874','0','辽宁','0','liaoning','0');
INSERT INTO `yzh_region` VALUES ('1875','1874','沈阳','0','shenyang','0');
INSERT INTO `yzh_region` VALUES ('1888','1875','新民','0','xinmin','0');
INSERT INTO `yzh_region` VALUES ('1889','1874','鞍山','0','anshan','0');
INSERT INTO `yzh_region` VALUES ('1896','1889','海城','0','haicheng','0');
INSERT INTO `yzh_region` VALUES ('1897','1874','本溪','0','benxi','0');
INSERT INTO `yzh_region` VALUES ('1904','1874','朝阳','0','chaoyang','0');
INSERT INTO `yzh_region` VALUES ('1910','1904','北票','0','beipiao','0');
INSERT INTO `yzh_region` VALUES ('1911','1904','凌源','0','lingyuan','0');
INSERT INTO `yzh_region` VALUES ('1912','1874','大连','0','dalian','0');
INSERT INTO `yzh_region` VALUES ('1920','1912','瓦房店','0','wafangdian','0');
INSERT INTO `yzh_region` VALUES ('1921','1912','普兰店','0','pulandian','0');
INSERT INTO `yzh_region` VALUES ('1922','1912','庄河','0','zhuanghe','0');
INSERT INTO `yzh_region` VALUES ('1923','1874','丹东','0','dandong','0');
INSERT INTO `yzh_region` VALUES ('1928','1923','东港','0','donggang','0');
INSERT INTO `yzh_region` VALUES ('1929','1923','凤城','0','fengcheng','0');
INSERT INTO `yzh_region` VALUES ('1930','1874','抚顺','0','fushun','0');
INSERT INTO `yzh_region` VALUES ('1938','1874','阜新','0','fuxin','0');
INSERT INTO `yzh_region` VALUES ('1946','1874','葫芦岛','0','huludao','0');
INSERT INTO `yzh_region` VALUES ('1952','1946','兴城','0','xingcheng','0');
INSERT INTO `yzh_region` VALUES ('1953','1874','锦州','0','jinzhou','0');
INSERT INTO `yzh_region` VALUES ('1959','1953','凌海','0','linghai','0');
INSERT INTO `yzh_region` VALUES ('1960','1953','北宁','0','beining','0');
INSERT INTO `yzh_region` VALUES ('1961','1874','辽阳','0','liaoyang','0');
INSERT INTO `yzh_region` VALUES ('1968','1961','灯塔','0','dengta','0');
INSERT INTO `yzh_region` VALUES ('1969','1874','盘锦','0','panjin','0');
INSERT INTO `yzh_region` VALUES ('1974','1874','铁岭','0','tieling','0');
INSERT INTO `yzh_region` VALUES ('1980','1974','调兵山','0','diaobingshan','0');
INSERT INTO `yzh_region` VALUES ('1981','1974','开原','0','kaiyuan','0');
INSERT INTO `yzh_region` VALUES ('1982','1874','营口','0','yingkou','0');
INSERT INTO `yzh_region` VALUES ('1987','1982','盖州','0','gaizhou','0');
INSERT INTO `yzh_region` VALUES ('1988','1982','大石桥','0','dashiqiao','0');
INSERT INTO `yzh_region` VALUES ('1989','0','内蒙古','0','neimenggu','0');
INSERT INTO `yzh_region` VALUES ('1990','1989','呼和浩特','0','huhehaote','0');
INSERT INTO `yzh_region` VALUES ('2000','1989','阿拉善盟','0','alashanmeng','0');
INSERT INTO `yzh_region` VALUES ('2003','2000','额济纳旗','0','ejinaqi','0');
INSERT INTO `yzh_region` VALUES ('2004','1989','巴彦淖尔','0','bayannaoer','0');
INSERT INTO `yzh_region` VALUES ('2008','2004','乌拉特前旗','0','wulateqianqi','0');
INSERT INTO `yzh_region` VALUES ('2009','2004','乌拉特中旗','0','wulatezhongqi','0');
INSERT INTO `yzh_region` VALUES ('2010','2004','乌拉特后旗','0','wulatehouqi','0');
INSERT INTO `yzh_region` VALUES ('2011','2004','杭锦后旗','0','hangjinhouqi','0');
INSERT INTO `yzh_region` VALUES ('2012','1989','包头','0','baotou','0');
INSERT INTO `yzh_region` VALUES ('2019','2012','土默特右旗','0','tumoteyouqi','0');
INSERT INTO `yzh_region` VALUES ('2022','1989','赤峰','0','chifeng','0');
INSERT INTO `yzh_region` VALUES ('2026','2022','阿鲁科尔沁旗','0','alukeerqinqi','0');
INSERT INTO `yzh_region` VALUES ('2027','2022','巴林左旗','0','balinzuoqi','0');
INSERT INTO `yzh_region` VALUES ('2028','2022','巴林右旗','0','balinyouqi','0');
INSERT INTO `yzh_region` VALUES ('2030','2022','克什克腾旗','0','keshiketengqi','0');
INSERT INTO `yzh_region` VALUES ('2031','2022','翁牛特旗','0','wengniuteqi','0');
INSERT INTO `yzh_region` VALUES ('2032','2022','喀喇沁旗','0','kalaqinqi','0');
INSERT INTO `yzh_region` VALUES ('2034','2022','敖汉旗','0','aohanqi','0');
INSERT INTO `yzh_region` VALUES ('2035','1989','鄂尔多斯','0','eerduosi','0');
INSERT INTO `yzh_region` VALUES ('2037','2035','达拉特旗','0','dalateqi','0');
INSERT INTO `yzh_region` VALUES ('2038','2035','准格尔旗','0','zhungeerqi','0');
INSERT INTO `yzh_region` VALUES ('2039','2035','鄂托克前旗','0','etuokeqianqi','0');
INSERT INTO `yzh_region` VALUES ('2040','2035','鄂托克旗','0','etuokeqi','0');
INSERT INTO `yzh_region` VALUES ('2044','1989','呼伦贝尔','0','hulunbeier','0');
INSERT INTO `yzh_region` VALUES ('2046','2044','阿荣旗','0','arongqi','0');
INSERT INTO `yzh_region` VALUES ('2047','2044','莫力达瓦达斡尔族自治旗','0','molidawadawoerzuzizhiqi','0');
INSERT INTO `yzh_region` VALUES ('2048','2044','鄂伦春自治旗','0','elunchunzizhiqi','0');
INSERT INTO `yzh_region` VALUES ('2049','2044','鄂温克族自治旗','0','ewenkezuzizhiqi','0');
INSERT INTO `yzh_region` VALUES ('2050','2044','陈巴尔虎旗','0','chenbaerhuqi','0');
INSERT INTO `yzh_region` VALUES ('2051','2044','新巴尔虎左旗','0','xinbaerhuzuoqi','0');
INSERT INTO `yzh_region` VALUES ('2052','2044','新巴尔虎右旗','0','xinbaerhuyouqi','0');
INSERT INTO `yzh_region` VALUES ('2053','2044','满洲里','0','manzhouli','0');
INSERT INTO `yzh_region` VALUES ('2054','2044','牙克石','0','yakeshi','0');
INSERT INTO `yzh_region` VALUES ('2055','2044','扎兰屯','0','zhalantun','0');
INSERT INTO `yzh_region` VALUES ('2056','2044','额尔古纳','0','eerguna','0');
INSERT INTO `yzh_region` VALUES ('2057','2044','根河','0','genhe','0');
INSERT INTO `yzh_region` VALUES ('2058','1989','通辽','0','tongliao','0');
INSERT INTO `yzh_region` VALUES ('2067','1989','乌海','0','wuhai','0');
INSERT INTO `yzh_region` VALUES ('2071','1989','乌兰察布','0','wulanchabu','0');
INSERT INTO `yzh_region` VALUES ('2078','2071','察哈尔右翼前旗','0','chahaeryouyiqianqi','0');
INSERT INTO `yzh_region` VALUES ('2079','2071','察哈尔右翼中旗','0','chahaeryouyizhongqi','0');
INSERT INTO `yzh_region` VALUES ('2080','2071','察哈尔右翼后旗','0','chahaeryouyihouqi','0');
INSERT INTO `yzh_region` VALUES ('2081','2071','四子王旗','0','siziwangqi','0');
INSERT INTO `yzh_region` VALUES ('2082','2071','丰镇','0','fengzhen','0');
INSERT INTO `yzh_region` VALUES ('2083','1989','锡林郭勒盟','0','xilinguolemeng','0');
INSERT INTO `yzh_region` VALUES ('2084','2083','二连浩特','0','erlianhaote','0');
INSERT INTO `yzh_region` VALUES ('2085','2083','锡林浩特','0','xilinhaote','0');
INSERT INTO `yzh_region` VALUES ('2087','2083','苏尼特左旗','0','sunitezuoqi','0');
INSERT INTO `yzh_region` VALUES ('2088','2083','苏尼特右旗','0','suniteyouqi','0');
INSERT INTO `yzh_region` VALUES ('2091','2083','太仆寺旗','0','taipusiqi','0');
INSERT INTO `yzh_region` VALUES ('2092','2083','镶黄旗','0','xianghuangqi','0');
INSERT INTO `yzh_region` VALUES ('2093','2083','正镶白旗','0','zhengxiangbaiqi','0');
INSERT INTO `yzh_region` VALUES ('2094','2083','正蓝旗','0','zhenglanqi','0');
INSERT INTO `yzh_region` VALUES ('2096','1989','兴安盟','0','xinganmeng','0');
INSERT INTO `yzh_region` VALUES ('2097','2096','乌兰浩特','0','wulanhaote','0');
INSERT INTO `yzh_region` VALUES ('2098','2096','阿尔山','0','aershan','0');
INSERT INTO `yzh_region` VALUES ('2101','2096','扎赉特旗','0','zhateqi','0');
INSERT INTO `yzh_region` VALUES ('2103','0','宁夏','0','ningxia','0');
INSERT INTO `yzh_region` VALUES ('2104','2103','银川','0','yinchuan','0');
INSERT INTO `yzh_region` VALUES ('2110','2104','灵武','0','lingwu','0');
INSERT INTO `yzh_region` VALUES ('2111','2103','固原','0','guyuan','0');
INSERT INTO `yzh_region` VALUES ('2117','2103','石嘴山','0','shizuishan','0');
INSERT INTO `yzh_region` VALUES ('2121','2103','吴忠','0','wuzhong','0');
INSERT INTO `yzh_region` VALUES ('2125','2121','青铜峡','0','qingtongxia','0');
INSERT INTO `yzh_region` VALUES ('2126','2103','中卫','0','zhongwei','0');
INSERT INTO `yzh_region` VALUES ('2130','0','青海','0','qinghai','0');
INSERT INTO `yzh_region` VALUES ('2131','2130','西宁','0','xining','0');
INSERT INTO `yzh_region` VALUES ('2139','2130','果洛','0','guoluocangzuzizhizhou','0');
INSERT INTO `yzh_region` VALUES ('2146','2130','海北','0','haibeicangzuzizhizhou','0');
INSERT INTO `yzh_region` VALUES ('2158','2130','海东','0','haidong','0');
INSERT INTO `yzh_region` VALUES ('2164','2130','海西','0','haiximengguzucangzuzizhizhou','0');
INSERT INTO `yzh_region` VALUES ('2170','2130','黄南','0','huangnancangzuzizhizhou','0');
INSERT INTO `yzh_region` VALUES ('2175','2130','玉树','0','yushucangzuzizhizhou','0');
INSERT INTO `yzh_region` VALUES ('2182','0','山东','0','shandong','0');
INSERT INTO `yzh_region` VALUES ('2183','2182','济南','0','jinan','0');
INSERT INTO `yzh_region` VALUES ('2193','2183','章丘','0','zhangqiu','0');
INSERT INTO `yzh_region` VALUES ('2194','2182','滨州','0','binzhou','0');
INSERT INTO `yzh_region` VALUES ('2202','2182','德州','0','dezhou','0');
INSERT INTO `yzh_region` VALUES ('2212','2202','乐陵','0','leling','0');
INSERT INTO `yzh_region` VALUES ('2213','2202','禹城','0','yucheng','0');
INSERT INTO `yzh_region` VALUES ('2214','2182','东营','0','dongying','0');
INSERT INTO `yzh_region` VALUES ('2220','2182','菏泽','0','heze','0');
INSERT INTO `yzh_region` VALUES ('2230','2182','济宁','0','jining','0');
INSERT INTO `yzh_region` VALUES ('2240','2230','曲阜','0','qufu','0');
INSERT INTO `yzh_region` VALUES ('2241','2230','兖州','0','zhou','0');
INSERT INTO `yzh_region` VALUES ('2242','2230','邹城','0','zoucheng','0');
INSERT INTO `yzh_region` VALUES ('2243','2182','莱芜','0','laiwu','0');
INSERT INTO `yzh_region` VALUES ('2246','2182','聊城','0','liaocheng','0');
INSERT INTO `yzh_region` VALUES ('2254','2246','临清','0','linqing','0');
INSERT INTO `yzh_region` VALUES ('2255','2182','临沂','0','linyi','0');
INSERT INTO `yzh_region` VALUES ('2268','2182','青岛','0','qingdao','0');
INSERT INTO `yzh_region` VALUES ('2276','2268','胶州','0','jiaozhou','0');
INSERT INTO `yzh_region` VALUES ('2277','2268','即墨','0','jimo','0');
INSERT INTO `yzh_region` VALUES ('2278','2268','平度','0','pingdu','0');
INSERT INTO `yzh_region` VALUES ('2279','2268','胶南','0','jiaonan','0');
INSERT INTO `yzh_region` VALUES ('2280','2268','莱西','0','laixi','0');
INSERT INTO `yzh_region` VALUES ('2281','2182','日照','0','rizhao','0');
INSERT INTO `yzh_region` VALUES ('2286','2182','泰安','0','taian','0');
INSERT INTO `yzh_region` VALUES ('2291','2286','新泰','0','xintai','0');
INSERT INTO `yzh_region` VALUES ('2292','2286','肥城','0','feicheng','0');
INSERT INTO `yzh_region` VALUES ('2293','2182','威海','0','weihai','0');
INSERT INTO `yzh_region` VALUES ('2295','2293','文登','0','wendeng','0');
INSERT INTO `yzh_region` VALUES ('2296','2293','荣成','0','rongcheng','0');
INSERT INTO `yzh_region` VALUES ('2297','2293','乳山','0','rushan','0');
INSERT INTO `yzh_region` VALUES ('2298','2182','潍坊','0','weifang','0');
INSERT INTO `yzh_region` VALUES ('2305','2298','青州','0','qingzhou','0');
INSERT INTO `yzh_region` VALUES ('2306','2298','诸城','0','zhucheng','0');
INSERT INTO `yzh_region` VALUES ('2307','2298','寿光','0','shouguang','0');
INSERT INTO `yzh_region` VALUES ('2308','2298','安丘','0','anqiu','0');
INSERT INTO `yzh_region` VALUES ('2309','2298','高密','0','gaomi','0');
INSERT INTO `yzh_region` VALUES ('2310','2298','昌邑','0','changyi','0');
INSERT INTO `yzh_region` VALUES ('2311','2182','烟台','0','yantai','0');
INSERT INTO `yzh_region` VALUES ('2317','2311','龙口','0','longkou','0');
INSERT INTO `yzh_region` VALUES ('2318','2311','莱阳','0','laiyang','0');
INSERT INTO `yzh_region` VALUES ('2319','2311','莱州','0','laizhou','0');
INSERT INTO `yzh_region` VALUES ('2320','2311','蓬莱','0','penglai','0');
INSERT INTO `yzh_region` VALUES ('2321','2311','招远','0','zhaoyuan','0');
INSERT INTO `yzh_region` VALUES ('2322','2311','栖霞','0','qixia','0');
INSERT INTO `yzh_region` VALUES ('2323','2311','海阳','0','haiyang','0');
INSERT INTO `yzh_region` VALUES ('2324','2182','枣庄','0','zaozhuang','0');
INSERT INTO `yzh_region` VALUES ('2330','2324','滕州','0','zhou','0');
INSERT INTO `yzh_region` VALUES ('2331','2182','淄博','0','zibo','0');
INSERT INTO `yzh_region` VALUES ('2340','0','山西','0','shanxi','0');
INSERT INTO `yzh_region` VALUES ('2341','2340','太原','0','taiyuan','0');
INSERT INTO `yzh_region` VALUES ('2351','2341','古交','0','gujiao','0');
INSERT INTO `yzh_region` VALUES ('2352','2340','长治','0','changzhi','0');
INSERT INTO `yzh_region` VALUES ('2365','2352','潞城','0','lucheng','0');
INSERT INTO `yzh_region` VALUES ('2366','2340','大同','0','datong','0');
INSERT INTO `yzh_region` VALUES ('2378','2340','晋城','0','jincheng','0');
INSERT INTO `yzh_region` VALUES ('2384','2378','高平','0','gaoping','0');
INSERT INTO `yzh_region` VALUES ('2385','2340','晋中','0','jinzhong','0');
INSERT INTO `yzh_region` VALUES ('2396','2385','介休','0','jiexiu','0');
INSERT INTO `yzh_region` VALUES ('2397','2340','临汾','0','linfen','0');
INSERT INTO `yzh_region` VALUES ('2413','2397','侯马','0','houma','0');
INSERT INTO `yzh_region` VALUES ('2414','2397','霍州','0','huozhou','0');
INSERT INTO `yzh_region` VALUES ('2415','2340','吕梁','0','lvliang','0');
INSERT INTO `yzh_region` VALUES ('2427','2415','孝义','0','xiaoyi','0');
INSERT INTO `yzh_region` VALUES ('2428','2415','汾阳','0','fenyang','0');
INSERT INTO `yzh_region` VALUES ('2429','2340','朔州','0','shuozhou','0');
INSERT INTO `yzh_region` VALUES ('2436','2340','忻州','0','xinzhou','0');
INSERT INTO `yzh_region` VALUES ('2450','2436','原平','0','yuanping','0');
INSERT INTO `yzh_region` VALUES ('2451','2340','阳泉','0','yangquan','0');
INSERT INTO `yzh_region` VALUES ('2457','2340','运城','0','yuncheng','0');
INSERT INTO `yzh_region` VALUES ('2469','2457','永济','0','yongji','0');
INSERT INTO `yzh_region` VALUES ('2470','2457','河津','0','hejin','0');
INSERT INTO `yzh_region` VALUES ('2471','0','陕西','0','shanxi','0');
INSERT INTO `yzh_region` VALUES ('2472','2471','西安','0','xian','0');
INSERT INTO `yzh_region` VALUES ('2486','2471','安康','0','ankang','0');
INSERT INTO `yzh_region` VALUES ('2497','2471','宝鸡','0','baoji','0');
INSERT INTO `yzh_region` VALUES ('2510','2471','汉中','0','hanzhong','0');
INSERT INTO `yzh_region` VALUES ('2522','2471','商洛','0','shangluo','0');
INSERT INTO `yzh_region` VALUES ('2530','2471','铜川','0','tongchuan','0');
INSERT INTO `yzh_region` VALUES ('2535','2471','渭南','0','weinan','0');
INSERT INTO `yzh_region` VALUES ('2545','2535','韩城','0','hancheng','0');
INSERT INTO `yzh_region` VALUES ('2546','2535','华阴','0','huayin','0');
INSERT INTO `yzh_region` VALUES ('2547','2471','咸阳','0','xianyang','0');
INSERT INTO `yzh_region` VALUES ('2561','2547','兴平','0','xingping','0');
INSERT INTO `yzh_region` VALUES ('2562','2471','延安','0','yanan','0');
INSERT INTO `yzh_region` VALUES ('2576','2471','榆林','0','yulin','0');
INSERT INTO `yzh_region` VALUES ('2589','0','四川','0','sichuan','0');
INSERT INTO `yzh_region` VALUES ('2590','2589','成都','0','chendou','0');
INSERT INTO `yzh_region` VALUES ('2606','2589','都江堰','1','dujiangyan','0');
INSERT INTO `yzh_region` VALUES ('2607','2589','彭州','1','pengzhou','0');
INSERT INTO `yzh_region` VALUES ('2608','2589','邛崃','1','','0');
INSERT INTO `yzh_region` VALUES ('2609','2589','崇州','1','chongzhou','0');
INSERT INTO `yzh_region` VALUES ('2624','2589','巴中','0','bazhong','0');
INSERT INTO `yzh_region` VALUES ('2629','2589','达州','0','dazhou','0');
INSERT INTO `yzh_region` VALUES ('2636','2589','万源','6','wanyuan','0');
INSERT INTO `yzh_region` VALUES ('2637','2589','德阳','0','deyang','0');
INSERT INTO `yzh_region` VALUES ('2641','2589','广汉','7','guanghan','0');
INSERT INTO `yzh_region` VALUES ('2642','2589','什邡','7','shi','0');
INSERT INTO `yzh_region` VALUES ('2643','2589','绵竹','7','mianzhu','0');
INSERT INTO `yzh_region` VALUES ('2644','2589','甘孜','0','ganzi','0');
INSERT INTO `yzh_region` VALUES ('2663','2589','广安','0','guangan','0');
INSERT INTO `yzh_region` VALUES ('2668','2589','华莹','8','huaying','0');
INSERT INTO `yzh_region` VALUES ('2669','2589','广元','0','guangyuan','0');
INSERT INTO `yzh_region` VALUES ('2677','2589','乐山','0','leshan','0');
INSERT INTO `yzh_region` VALUES ('2688','2589','峨眉山','10','emeishan','0');
INSERT INTO `yzh_region` VALUES ('2689','2589','凉山','0','liangshan','0');
INSERT INTO `yzh_region` VALUES ('2690','2589','西昌','12','xichang','0');
INSERT INTO `yzh_region` VALUES ('2707','2589','泸州','2','zhou','0');
INSERT INTO `yzh_region` VALUES ('2715','2589','眉山','0','meishan','0');
INSERT INTO `yzh_region` VALUES ('2722','2589','绵阳','1','mianyang','0');
INSERT INTO `yzh_region` VALUES ('2731','2589','江油','6','jiangyou','0');
INSERT INTO `yzh_region` VALUES ('2732','2589','内江','0','neijiang','0');
INSERT INTO `yzh_region` VALUES ('2738','2589','南充','3','nanchong','0');
INSERT INTO `yzh_region` VALUES ('2747','2589','阿坝州','4','abazhou ','0');
INSERT INTO `yzh_region` VALUES ('2748','2589','攀枝花','0','panzhihua','0');
INSERT INTO `yzh_region` VALUES ('2754','2589','遂宁','0','suining','0');
INSERT INTO `yzh_region` VALUES ('2760','2589','雅安','0','yaan','0');
INSERT INTO `yzh_region` VALUES ('2769','2589','宜宾','0','yibin','0');
INSERT INTO `yzh_region` VALUES ('2780','2589','资阳','0','ziyang','0');
INSERT INTO `yzh_region` VALUES ('2784','2589','简阳','19','jianyang','0');
INSERT INTO `yzh_region` VALUES ('2785','2589','自贡','0','zigong','0');
INSERT INTO `yzh_region` VALUES ('2792','0','西藏','0','xicang','0');
INSERT INTO `yzh_region` VALUES ('2793','2792','拉萨','0','lasa','0');
INSERT INTO `yzh_region` VALUES ('2842','2841','日喀则','0','rikaze','0');
INSERT INTO `yzh_region` VALUES ('2873','0','新疆','0','xinjiang','0');
INSERT INTO `yzh_region` VALUES ('2874','2873','乌鲁木齐','0','wulumuqi','0');
INSERT INTO `yzh_region` VALUES ('2884','2883','阿克苏','0','akesu','0');
INSERT INTO `yzh_region` VALUES ('2893','2873','阿拉尔','0','alaer','0');
INSERT INTO `yzh_region` VALUES ('2895','2894','阿勒泰','0','aletai','0');
INSERT INTO `yzh_region` VALUES ('2902','2873','巴州','0','bazhou','0');
INSERT INTO `yzh_region` VALUES ('2903','2873','库尔勒','3','kuerle','0');
INSERT INTO `yzh_region` VALUES ('2912','2873','博尔塔拉','0','boertala','0');
INSERT INTO `yzh_region` VALUES ('2913','2912','博乐','0','bole','0');
INSERT INTO `yzh_region` VALUES ('2917','2873','昌吉','5','changji','0');
INSERT INTO `yzh_region` VALUES ('2918','2873','阜康','5','fukang','0');
INSERT INTO `yzh_region` VALUES ('2919','2873','米泉','5','miquan','0');
INSERT INTO `yzh_region` VALUES ('2926','2925','哈密','0','hami','0');
INSERT INTO `yzh_region` VALUES ('2930','2929','和田','0','hetian','0');
INSERT INTO `yzh_region` VALUES ('2939','2938','喀什','0','kashi','0');
INSERT INTO `yzh_region` VALUES ('2951','2873','克拉玛依','0','kelamayi','0');
INSERT INTO `yzh_region` VALUES ('2956','2873','克孜勒苏','0','kezilesu','0');
INSERT INTO `yzh_region` VALUES ('2957','2956','阿图什','0','atushi','0');
INSERT INTO `yzh_region` VALUES ('2961','2873','石河子','0','shihezi','0');
INSERT INTO `yzh_region` VALUES ('2963','2962','塔城','0','tacheng','0');
INSERT INTO `yzh_region` VALUES ('2964','2962','乌苏','0','wusu','0');
INSERT INTO `yzh_region` VALUES ('2970','2873','图木舒克','0','tumushuke','0');
INSERT INTO `yzh_region` VALUES ('2972','2971','吐鲁番','0','tulufan','0');
INSERT INTO `yzh_region` VALUES ('2975','2873','五家渠','0','wujiaqu','0');
INSERT INTO `yzh_region` VALUES ('2976','2873','伊犁哈萨克自治州','0','yilihasakezizhizhou','0');
INSERT INTO `yzh_region` VALUES ('2977','2976','伊宁','0','yining','0');
INSERT INTO `yzh_region` VALUES ('2978','2976','奎屯','0','kuitun','0');
INSERT INTO `yzh_region` VALUES ('2987','0','云南','0','yunnan','0');
INSERT INTO `yzh_region` VALUES ('2988','2987','昆明','0','kunming','0');
INSERT INTO `yzh_region` VALUES ('3002','2988','安宁','0','anning','0');
INSERT INTO `yzh_region` VALUES ('3003','2987','保山','0','baoshan','0');
INSERT INTO `yzh_region` VALUES ('3010','2987','楚雄','2','chuxiong','0');
INSERT INTO `yzh_region` VALUES ('3021','2987','大理','3','dali','0');
INSERT INTO `yzh_region` VALUES ('3033','2987','德宏','0','dehong','0');
INSERT INTO `yzh_region` VALUES ('3034','3033','瑞丽','0','ruili','0');
INSERT INTO `yzh_region` VALUES ('3035','3033','潞西','0','luxi','0');
INSERT INTO `yzh_region` VALUES ('3039','2987','迪庆','0','diqing','0');
INSERT INTO `yzh_region` VALUES ('3043','2987','红河','0','honghe','0');
INSERT INTO `yzh_region` VALUES ('3044','3043','个旧','0','gejiu','0');
INSERT INTO `yzh_region` VALUES ('3045','3043','开远','0','kaiyuan','0');
INSERT INTO `yzh_region` VALUES ('3057','2987','丽江','0','lijiang','0');
INSERT INTO `yzh_region` VALUES ('3063','2987','临沧','0','lincang','0');
INSERT INTO `yzh_region` VALUES ('3072','2987','怒江','0','nujiang','0');
INSERT INTO `yzh_region` VALUES ('3077','2987','曲靖','0','qujing','0');
INSERT INTO `yzh_region` VALUES ('3086','3077','宣威','0','xuanwei','0');
INSERT INTO `yzh_region` VALUES ('3087','2987','思茅','0','simao','0');
INSERT INTO `yzh_region` VALUES ('3098','2987','文山','0','wenshan','0');
INSERT INTO `yzh_region` VALUES ('3107','2987','西双版纳','0','xishuangbanna','0');
INSERT INTO `yzh_region` VALUES ('3108','3107','景洪','0','jinghong','0');
INSERT INTO `yzh_region` VALUES ('3111','2987','玉溪','0','yuxi','0');
INSERT INTO `yzh_region` VALUES ('3121','2987','昭通','0','zhaotong','0');
INSERT INTO `yzh_region` VALUES ('3133','0','浙江','0','zhejiang','0');
INSERT INTO `yzh_region` VALUES ('3134','3133','杭州','0','hangzhou','1');
INSERT INTO `yzh_region` VALUES ('3145','3134','建德','0','jiande','0');
INSERT INTO `yzh_region` VALUES ('3146','3134','富阳','0','fuyang','0');
INSERT INTO `yzh_region` VALUES ('3147','3134','临安','0','linan','0');
INSERT INTO `yzh_region` VALUES ('3148','3133','湖州','0','huzhou','0');
INSERT INTO `yzh_region` VALUES ('3154','3133','嘉兴','0','jiaxing','0');
INSERT INTO `yzh_region` VALUES ('3159','3154','海宁','0','haining','0');
INSERT INTO `yzh_region` VALUES ('3160','3154','平湖','0','pinghu','0');
INSERT INTO `yzh_region` VALUES ('3161','3154','桐乡','0','tongxiang','0');
INSERT INTO `yzh_region` VALUES ('3162','3133','金华','0','jinhua','0');
INSERT INTO `yzh_region` VALUES ('3168','3162','兰溪','0','lanxi','0');
INSERT INTO `yzh_region` VALUES ('3169','3162','义乌','0','yiwu','0');
INSERT INTO `yzh_region` VALUES ('3170','3162','东阳','0','dongyang','0');
INSERT INTO `yzh_region` VALUES ('3171','3162','永康','0','yongkang','0');
INSERT INTO `yzh_region` VALUES ('3172','3133','丽水','0','lishui','0');
INSERT INTO `yzh_region` VALUES ('3181','3172','龙泉','0','longquan','0');
INSERT INTO `yzh_region` VALUES ('3182','3133','宁波','0','ningbo','0');
INSERT INTO `yzh_region` VALUES ('3191','3182','余姚','0','yuyao','0');
INSERT INTO `yzh_region` VALUES ('3192','3182','慈溪','0','cixi','0');
INSERT INTO `yzh_region` VALUES ('3193','3182','奉化','0','fenghua','0');
INSERT INTO `yzh_region` VALUES ('3194','3133','衢州','0','zhou','0');
INSERT INTO `yzh_region` VALUES ('3200','3194','江山','0','jiangshan','0');
INSERT INTO `yzh_region` VALUES ('3201','3133','绍兴','0','shaoxing','0');
INSERT INTO `yzh_region` VALUES ('3205','3201','诸暨','0','zhu','0');
INSERT INTO `yzh_region` VALUES ('3206','3201','上虞','0','shangyu','0');
INSERT INTO `yzh_region` VALUES ('3207','3201','嵊州','0','zhou','0');
INSERT INTO `yzh_region` VALUES ('3208','3133','台州','0','taizhou','0');
INSERT INTO `yzh_region` VALUES ('3216','3208','温岭','0','wenling','0');
INSERT INTO `yzh_region` VALUES ('3217','3208','临海','0','linhai','0');
INSERT INTO `yzh_region` VALUES ('3218','3133','温州','0','wenzhou','0');
INSERT INTO `yzh_region` VALUES ('3228','3218','瑞安','0','ruian','0');
INSERT INTO `yzh_region` VALUES ('3229','3218','乐清','0','leqing','0');
INSERT INTO `yzh_region` VALUES ('3230','3133','舟山','0','zhoushan','0');
INSERT INTO `yzh_region` VALUES ('3235','0','香港','0','xianggang','0');
INSERT INTO `yzh_region` VALUES ('3236','3235','九龙','0','jiulong','0');
INSERT INTO `yzh_region` VALUES ('3237','3235','香港岛','0','xianggangdao','0');
INSERT INTO `yzh_region` VALUES ('3238','3235','新界','0','xinjie','0');
INSERT INTO `yzh_region` VALUES ('3239','0','澳门','0','aomen','0');
INSERT INTO `yzh_region` VALUES ('3240','3239','澳门半岛','0','aomenbandao','0');
INSERT INTO `yzh_region` VALUES ('3241','3239','离岛','0','lidao','0');
INSERT INTO `yzh_region` VALUES ('3242','0','台湾','0','taiwan','0');
INSERT INTO `yzh_region` VALUES ('3243','3242','台北','0','taibei','0');
INSERT INTO `yzh_region` VALUES ('3244','3242','高雄','0','gaoxiong','0');
INSERT INTO `yzh_region` VALUES ('3247','3242','基隆','0','jilong','0');
INSERT INTO `yzh_region` VALUES ('3248','3242','嘉义','0','jiayi','0');
INSERT INTO `yzh_region` VALUES ('3257','3242','台南','0','tainan','0');
INSERT INTO `yzh_region` VALUES ('3259','3242','台中','0','taizhong','0');
INSERT INTO `yzh_region` VALUES ('3262','3242','新竹','0','xinzhu','0');
--
-- 表的结构 `yzh_resume`
-- 
DROP TABLE IF EXISTS `yzh_resume`;
CREATE TABLE `yzh_resume` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `username` varchar(40) NOT NULL DEFAULT '',
  `sex` varchar(255) NOT NULL DEFAULT '',
  `phone` varchar(255) NOT NULL DEFAULT '',
  `birthday` varchar(255) NOT NULL DEFAULT '',
  `idnum` varchar(255) NOT NULL DEFAULT '',
  `position` varchar(255) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `email` text NOT NULL,
  `experiences` mediumtext NOT NULL,
  `self_assessment` mediumtext NOT NULL,
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `jianli` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
--
-- 表的结构 `yzh_role`
-- 
DROP TABLE IF EXISTS `yzh_role`;
CREATE TABLE `yzh_role` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL DEFAULT '',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `remark` varchar(255) NOT NULL DEFAULT '',
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sort` smallint(6) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- 
-- 导出`yzh_role`表中的数据 `yzh_role`
--
INSERT INTO `yzh_role` VALUES ('1','超级管理员','1','超级管理员','0','0');
INSERT INTO `yzh_role` VALUES ('2','普通管理员','1','普通管理员','0','0');
--
-- 表的结构 `yzh_role_user`
-- 
DROP TABLE IF EXISTS `yzh_role_user`;
CREATE TABLE `yzh_role_user` (
  `role_id` mediumint(9) unsigned DEFAULT NULL,
  `user_id` char(32) DEFAULT NULL,
  KEY `group_id` (`role_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- 导出`yzh_role_user`表中的数据 `yzh_role_user`
--
INSERT INTO `yzh_role_user` VALUES ('1','1');
INSERT INTO `yzh_role_user` VALUES ('1','1');
INSERT INTO `yzh_role_user` VALUES ('2','2');
--
-- 表的结构 `yzh_shipping`
-- 
DROP TABLE IF EXISTS `yzh_shipping`;
CREATE TABLE `yzh_shipping` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(50) NOT NULL DEFAULT '',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `first_weight` int(11) unsigned NOT NULL DEFAULT '0',
  `second_weight` int(11) unsigned NOT NULL DEFAULT '0',
  `first_price` float(10,2) unsigned NOT NULL DEFAULT '0.00',
  `second_price` float(10,2) unsigned NOT NULL DEFAULT '0.00',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `listorder` mediumint(8) unsigned NOT NULL DEFAULT '99',
  `is_insure` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `insure_fee` int(11) unsigned NOT NULL DEFAULT '0',
  `insure_low_price` float(10,2) unsigned NOT NULL DEFAULT '0.00',
  `price_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
--
-- 表的结构 `yzh_slide`
-- 
DROP TABLE IF EXISTS `yzh_slide`;
CREATE TABLE `yzh_slide` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  `width` smallint(5) unsigned NOT NULL DEFAULT '0',
  `height` smallint(5) unsigned NOT NULL DEFAULT '0',
  `num` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- 
-- 导出`yzh_slide`表中的数据 `yzh_slide`
--
INSERT INTO `yzh_slide` VALUES ('1','首页幻灯','1440','539','5','1');
INSERT INTO `yzh_slide` VALUES ('2','手机幻灯','768','400','5','1');
--
-- 表的结构 `yzh_slide_data`
-- 
DROP TABLE IF EXISTS `yzh_slide_data`;
CREATE TABLE `yzh_slide_data` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `fid` tinyint(3) unsigned DEFAULT '0',
  `title` varchar(30) NOT NULL DEFAULT '',
  `small` varchar(150) NOT NULL DEFAULT '',
  `pic` varchar(150) NOT NULL DEFAULT '',
  `link` varchar(150) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `data` text,
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `lang` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fid` (`fid`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- 
-- 导出`yzh_slide_data`表中的数据 `yzh_slide_data`
--
INSERT INTO `yzh_slide_data` VALUES ('1','1','幻灯片','','/uploads/201803/5aa0f0cd4dbc4.jpg','/chanpinzhongxin.html','','','0','1','1');
INSERT INTO `yzh_slide_data` VALUES ('2','1','aaaaa','','/uploads/201803/5aa0e79eed6ca.jpg','','',NULL,'0','1','1');
INSERT INTO `yzh_slide_data` VALUES ('3','2','aaa','','/uploads/201803/5a9e45ca09c04.jpg','','',NULL,'0','1','1');
INSERT INTO `yzh_slide_data` VALUES ('4','2','bb','','/uploads/201803/5a9e45ca09c04.jpg','','',NULL,'0','1','1');
INSERT INTO `yzh_slide_data` VALUES ('5','2','cc','','/uploads/201803/5a9e45ca09c04.jpg','','',NULL,'0','1','1');
INSERT INTO `yzh_slide_data` VALUES ('6','2','dd','','/uploads/201803/5a9e45ca09c04.jpg','','',NULL,'0','1','1');
INSERT INTO `yzh_slide_data` VALUES ('7','1','幻灯片','','/uploads/201601/568dcf812ae90.jpg','/chanpinzhongxin.html','','','0','1','2');
INSERT INTO `yzh_slide_data` VALUES ('8','1','aaaaa','','/uploads/201601/568dcf48984c6.jpg','','',NULL,'0','1','2');
INSERT INTO `yzh_slide_data` VALUES ('9','2','aaa','','/uploads/201601/568dd00a74113.jpg','','',NULL,'0','1','2');
INSERT INTO `yzh_slide_data` VALUES ('10','2','bb','','/uploads/201601/568dd04cb542e.jpg','','',NULL,'0','1','2');
INSERT INTO `yzh_slide_data` VALUES ('11','1','','','/uploads/201803/5aa0ead127327.jpg','','',NULL,'0','1','1');
--
-- 表的结构 `yzh_sysconfig`
-- 
DROP TABLE IF EXISTS `yzh_sysconfig`;
CREATE TABLE `yzh_sysconfig` (
  `id` smallint(8) unsigned NOT NULL AUTO_INCREMENT,
  `varname` varchar(25) NOT NULL DEFAULT '',
  `info` varchar(100) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `varname` (`varname`)
) ENGINE=MyISAM AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;

-- 
-- 导出`yzh_sysconfig`表中的数据 `yzh_sysconfig`
--
INSERT INTO `yzh_sysconfig` VALUES ('1','mail_accept','邮件发送模式','');
INSERT INTO `yzh_sysconfig` VALUES ('2','SMTP_HOST','邮件服务器','smtp.qq.com');
INSERT INTO `yzh_sysconfig` VALUES ('3','SMTP_PORT','邮件发送端口','465');
INSERT INTO `yzh_sysconfig` VALUES ('4','mail_from','发件人地址','');
INSERT INTO `yzh_sysconfig` VALUES ('6','SMTP_USER','验证用户名','');
INSERT INTO `yzh_sysconfig` VALUES ('7','SMTP_PASS','验证密码','');
INSERT INTO `yzh_sysconfig` VALUES ('8','attach_maxsize','允许上传附件大小','5200000');
INSERT INTO `yzh_sysconfig` VALUES ('9','attach_allowext','允许上传附件类型','jpg,jpeg,gif,png,doc,docx,rar,zip,swf,pdf');
INSERT INTO `yzh_sysconfig` VALUES ('10','watermark_enable','是否开启图片水印','0');
INSERT INTO `yzh_sysconfig` VALUES ('11','watemard_text','水印文字内容','s');
INSERT INTO `yzh_sysconfig` VALUES ('12','watemard_text_size','文字大小','18');
INSERT INTO `yzh_sysconfig` VALUES ('13','watemard_text_color','watemard_text_color','#FFFFFF');
INSERT INTO `yzh_sysconfig` VALUES ('14','watemard_text_face','字体','elephant.ttf');
INSERT INTO `yzh_sysconfig` VALUES ('15','watermark_minwidth','图片最小宽度','300');
INSERT INTO `yzh_sysconfig` VALUES ('16','watermark_minheight','水印最小高度','300');
INSERT INTO `yzh_sysconfig` VALUES ('17','watermark_img','水印图片名称','');
INSERT INTO `yzh_sysconfig` VALUES ('18','watermark_pct','水印透明度','80');
INSERT INTO `yzh_sysconfig` VALUES ('19','watermark_quality','JPEG 水印质量','100');
INSERT INTO `yzh_sysconfig` VALUES ('20','watermark_pospadding','水印边距','');
INSERT INTO `yzh_sysconfig` VALUES ('21','watermark_pos','水印位置','9');
INSERT INTO `yzh_sysconfig` VALUES ('23','URL_MODEL','URL访问模式','2');
INSERT INTO `yzh_sysconfig` VALUES ('24','URL_PATHINFO_DEPR','URL参数分割符','/');
INSERT INTO `yzh_sysconfig` VALUES ('25','URL_HTML_SUFFIX','URL伪静态后缀','.html');
INSERT INTO `yzh_sysconfig` VALUES ('26','TOKEN_ON','令牌验证','0');
INSERT INTO `yzh_sysconfig` VALUES ('27','TOKEN_NAME','令牌表单字段','__hash__');
INSERT INTO `yzh_sysconfig` VALUES ('28','TMPL_CACHE_ON','模板编译缓存','0');
INSERT INTO `yzh_sysconfig` VALUES ('29','TMPL_CACHE_TIME','模板缓存有效期','-1');
INSERT INTO `yzh_sysconfig` VALUES ('30','HTML_CACHE_ON','静态缓存','0');
INSERT INTO `yzh_sysconfig` VALUES ('31','HTML_CACHE_TIME','缓存有效期','60');
INSERT INTO `yzh_sysconfig` VALUES ('32','HTML_READ_TYPE','缓存读取方式','0');
INSERT INTO `yzh_sysconfig` VALUES ('33','HTML_FILE_SUFFIX','静态文件后缀','.html');
INSERT INTO `yzh_sysconfig` VALUES ('34','DEFAULT_THEME','PC模版主题','default');
INSERT INTO `yzh_sysconfig` VALUES ('35','DEFAULT_M_THEME','手机模版主题','default');
INSERT INTO `yzh_sysconfig` VALUES ('36','DEFAULT_LANG','前台默认语言','cn');
INSERT INTO `yzh_sysconfig` VALUES ('40','SITE_DOMAIN','网站域名','v1.yuzihao.com');
INSERT INTO `yzh_sysconfig` VALUES ('41','SITE_DOMAINS','其他域名','');
INSERT INTO `yzh_sysconfig` VALUES ('42','SUB_DOMAIN','自动识别','0');
INSERT INTO `yzh_sysconfig` VALUES ('44','SITE_WAP_DOMAIN','移动端域名','m.e35.grwy.net');
INSERT INTO `yzh_sysconfig` VALUES ('49','SHOW_PAGE_TRACE','开启页面Trace显示界面','0');
INSERT INTO `yzh_sysconfig` VALUES ('50','SHOW_RUN_TIME','运行时间显示','0');
INSERT INTO `yzh_sysconfig` VALUES ('51','TMPL_EXCEPTION_FILE','404页面是否开启','0');
INSERT INTO `yzh_sysconfig` VALUES ('52','CHANGE_INDEX','关闭首页','1');
--
-- 表的结构 `yzh_tags`
-- 
DROP TABLE IF EXISTS `yzh_tags`;
CREATE TABLE `yzh_tags` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `slug` varchar(100) NOT NULL DEFAULT '',
  `modelid` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `model` varchar(30) NOT NULL DEFAULT '',
  `num` smallint(5) unsigned NOT NULL DEFAULT '0',
  `lang` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
--
-- 表的结构 `yzh_tags_data`
-- 
DROP TABLE IF EXISTS `yzh_tags_data`;
CREATE TABLE `yzh_tags_data` (
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  `tagid` int(10) unsigned NOT NULL DEFAULT '0',
  `listorder` int(10) unsigned NOT NULL DEFAULT '0',
  KEY `tagid` (`tagid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
--
-- 表的结构 `yzh_type`
-- 
DROP TABLE IF EXISTS `yzh_type`;
CREATE TABLE `yzh_type` (
  `typeid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `description` varchar(200) NOT NULL DEFAULT '',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0',
  `keyid` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`typeid`),
  KEY `parentid` (`parentid`,`listorder`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
--
-- 表的结构 `yzh_urlrule`
-- 
DROP TABLE IF EXISTS `yzh_urlrule`;
CREATE TABLE `yzh_urlrule` (
  `urlruleid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `ishtml` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `showurlrule` varchar(255) NOT NULL DEFAULT '',
  `showexample` varchar(255) NOT NULL DEFAULT '',
  `listurlrule` varchar(255) NOT NULL DEFAULT '',
  `listexample` varchar(255) NOT NULL DEFAULT '',
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`urlruleid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- 
-- 导出`yzh_urlrule`表中的数据 `yzh_urlrule`
--
INSERT INTO `yzh_urlrule` VALUES ('1','0','{$catdir}/{$catid}-{$id}.html|{$catdir}/-{$catid}-{$id}-{$page}.html','news/1.html|news/1-1.html','{$catdir}.html|{$catdir}-{$catid}-{$page}.html','news.html|news-1.html','0');
INSERT INTO `yzh_urlrule` VALUES ('2','0','show-{$catid}-{$id}.html|show-{$catid}-{$id}-{$page}.html','show-1-1.html|show-1-1-1.html','list-{$catid}.html|list-{$catid}-{$page}.html','list-1.html|list-1-1.html','0');
INSERT INTO `yzh_urlrule` VALUES ('3','0','{$model}/show/{$catid}/{$id}.html|{$model}/show/{$catid}/{$id}-{$page}.html','Article/show/1.html|Article/show/1-1.html','{$model}/list/{$catid}.html|{$model}/list/{$catid}-{$page}.html','Article/list/1.html|Article/list/1-1.html','0');
INSERT INTO `yzh_urlrule` VALUES ('4','1','{$parentdir}{$catdir}/show_{$id}.html|{$parentdir}{$catdir}/show_{$id}_{$page}.html','news/show_1.html|news/show_1_1.html','{$parentdir}{$catdir}/|{$parentdir}{$catdir}/{$page}.html','news/|news/1.html','0');
--
-- 表的结构 `yzh_user`
-- 
DROP TABLE IF EXISTS `yzh_user`;
CREATE TABLE `yzh_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `username` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(50) NOT NULL DEFAULT '',
  `question` varchar(50) NOT NULL DEFAULT '',
  `answer` varchar(50) NOT NULL DEFAULT '',
  `login_count` int(11) unsigned NOT NULL DEFAULT '0',
  `reg_time` int(11) unsigned NOT NULL DEFAULT '0',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  `last_login_time` int(11) unsigned NOT NULL DEFAULT '0',
  `reg_ip` char(15) NOT NULL DEFAULT '',
  `last_ip` char(15) NOT NULL DEFAULT '',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `avatar` varchar(120) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- 
-- 导出`yzh_user`表中的数据 `yzh_user`
--
INSERT INTO `yzh_user` VALUES ('1','1','super','e155be37562571a885f0b8710e942982e4a26a17','service@grwy.net','','','21','1516958295','0','1520588167','','119.123.1.235','1','');
INSERT INTO `yzh_user` VALUES ('2','2','admin','545a49be66808ec2d75b6a7284a4a2ecf8e81ecc','','','','5','0','0','1451350553','','127.0.0.1','1','');
--
-- 表的结构 `yzh_vcard`
-- 
DROP TABLE IF EXISTS `yzh_vcard`;
CREATE TABLE `yzh_vcard` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `position` varchar(60) NOT NULL,
  `company` varchar(60) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `companyinfo` text NOT NULL,
  `phone` varchar(30) NOT NULL,
  `wechat` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `qq` varchar(20) NOT NULL,
  `tel` varchar(20) NOT NULL,
  `fax` varchar(20) NOT NULL,
  `website` varchar(60) NOT NULL,
  `address` varchar(120) NOT NULL,
  `userinfo` text NOT NULL,
  `visit` int(11) NOT NULL,
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
--
-- 表的结构 `yzh_video`
-- 
DROP TABLE IF EXISTS `yzh_video`;
CREATE TABLE `yzh_video` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `title_style` varchar(40) NOT NULL DEFAULT '',
  `thumb` varchar(100) NOT NULL DEFAULT '',
  `content` mediumtext NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `userid` int(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(40) NOT NULL DEFAULT '',
  `url` varchar(60) NOT NULL DEFAULT '',
  `listorder` int(10) unsigned NOT NULL DEFAULT '0',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  `lang` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
--
-- 表的结构 `yzh_wx_config`
-- 
DROP TABLE IF EXISTS `yzh_wx_config`;
CREATE TABLE `yzh_wx_config` (
  `id` smallint(8) unsigned NOT NULL AUTO_INCREMENT,
  `varname` varchar(25) NOT NULL DEFAULT '',
  `info` varchar(100) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `varname` (`varname`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- 
-- 导出`yzh_wx_config`表中的数据 `yzh_wx_config`
--
INSERT INTO `yzh_wx_config` VALUES ('1','WEIXIN_NAME','公众号名称','');
INSERT INTO `yzh_wx_config` VALUES ('2','WEIXIN_SRCID','原始ID','');
INSERT INTO `yzh_wx_config` VALUES ('3','WEIXIN_ID','微信号','');
INSERT INTO `yzh_wx_config` VALUES ('4','WEIXIN_TYPE','类型','');
INSERT INTO `yzh_wx_config` VALUES ('5','WEIXIN_TOKEN','Token','');
INSERT INTO `yzh_wx_config` VALUES ('6','WEIXIN_ENCODINGAESKEY','','');
INSERT INTO `yzh_wx_config` VALUES ('7','WEIXIN_APPID','appID','');
INSERT INTO `yzh_wx_config` VALUES ('8','WEIXIN_APPSECRET','appsecret','');
INSERT INTO `yzh_wx_config` VALUES ('9','WEIXIN_SITE_URL','微信网站','');
INSERT INTO `yzh_wx_config` VALUES ('10','welcome_type','消息类型','1');
INSERT INTO `yzh_wx_config` VALUES ('11','welcome_title','消息标题','国人伟业');
INSERT INTO `yzh_wx_config` VALUES ('12','welcome_face','消息封面','');
INSERT INTO `yzh_wx_config` VALUES ('13','welcome_desc','消息内容','欢迎关注誉字号\n');
INSERT INTO `yzh_wx_config` VALUES ('14','welcome_url','微网站链接','');
INSERT INTO `yzh_wx_config` VALUES ('15','robot_content','回复内容','欢迎关注誉字号');
--
-- 表的结构 `yzh_wx_menu`
-- 
DROP TABLE IF EXISTS `yzh_wx_menu`;
CREATE TABLE `yzh_wx_menu` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `pid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT '',
  `type` varchar(50) DEFAULT NULL,
  `code` varchar(255) NOT NULL DEFAULT '',
  `listorder` smallint(6) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parentid` (`pid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
--
-- 表的结构 `yzh_wx_smartreply`
-- 
DROP TABLE IF EXISTS `yzh_wx_smartreply`;
CREATE TABLE `yzh_wx_smartreply` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `rulename` varchar(50) NOT NULL DEFAULT '',
  `key` varchar(50) DEFAULT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;