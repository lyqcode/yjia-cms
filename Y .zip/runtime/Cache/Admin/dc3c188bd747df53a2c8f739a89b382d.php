<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<!--[if IE 8 ]><html class="ie8"><![endif]-->
<!--[if IE 9 ]><html class="ie9"><![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--><html class="w3c"><!--<![endif]-->
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge,Chrome=1" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" type="text/css" href="__CSS__/elpis.min.css">
<link rel="stylesheet" href="__STATIC__/font-awesome/css/font-awesome.min.css">

<!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
<script src="__JS__/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="__JS__/bootstrap.js"></script>


<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="__STATIC__/bootstrap/js/vendor/html5shiv.js"></script>
<script src="__STATIC__/bootstrap/js/vendor/respond.min.js"></script>
<![endif]-->
<title>网站管理系统</title>

</head>

<body>

<nav>
    <!-- 面包屑导航 -->
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><i class="fa fa-map-marker"></i></li>
        <?php if(is_array($parent_menu)): $i = 0; $__LIST__ = $parent_menu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$menu_li): $mod = ($i % 2 );++$i;?><li class="breadcrumb-item"><?php echo ($menu_li["name"]); ?></li><?php endforeach; endif; else: echo "" ;endif; ?>
    </ol>
</nav>
<div class="page-container">
    
<script type="text/javascript" src="__JS__/preview.js"></script>
<style>
#preview{
    position:absolute;
    border:1px solid #ccc;
    background:#333;
    padding:5px;
    display:none;
    color:#fff;
}
#preview img{width:200px;height:200px;}
</style>

<div class="table-toolbar">
    <div class="row">
        <div class="col-md-12">
            <a href="<?php echo U($model_name.'/add');?>" class="btn btn-primary">添加</a>
            <button class="btn btn-primary" onclick="return confirm_deleteall()">删除</button>
            <button class="btn btn-primary" onclick="myform.action='<?php echo U($model_name.'/listorder');?>';$('#myform').submit();" >排序</button>
            <?php if($fields['status']): ?><button class="btn btn-primary" onclick="content_check();" >审核</button><?php endif; ?>
            <?php if($fields['status']): ?><button class="btn btn-primary" onclick="content_nocheck();">取消审核</button><?php endif; ?>
            <button class="btn btn-primary" id="push_btn">推送</button>
            <button class="btn btn-primary" id="content_move" >批量移动</button>
        </div>
    </div>
</div>

<div class="table-toolbar">
    <div class="row">
        <div class="col-md-12">
            <form class="form-inline" action="<?php echo U($model_name.'/index');?>" method="get">
                <input type="hidden" name="g" value="<?php echo (GROUP_NAME); ?>" />
                <input type="hidden" name="m" value="<?php echo (MODULE_NAME); ?>" />
                <input type="hidden" name="a" value="<?php echo (ACTION_NAME); ?>" />

                <div class="form-group">
                    <input type="text" class="form-control" name="keyword" value="<?php echo ($keyword); ?>" />
                </div>
                <div class="form-group">
                    <select class="form-control" name="searchtype">
                        <?php if($fields['title']): ?><option value="title" <?php if(($searchtype) == "title"): ?>selected="selected"<?php endif; ?>>标题</option><?php endif; ?>
                        <?php if($fields['keywords']): ?><option value="keywords" <?php if(($searchtype) == "keywords"): ?>selected="selected"<?php endif; ?>>关键词</option><?php endif; ?>
                        <option value="id" <?php if(($searchtype) == "id"): ?>selected="selected"<?php endif; ?>>ID</option>
                    </select>
                </div>

                <div class="form-group">
                    <?php if($fields['catid']): ?><select class="form-control" id="catid" name="catid">
                            <option value="0">选择栏目</option>
                            <?php echo ($select_categorys); ?>
                        </select><?php endif; ?>
                </div>

                <div class="form-group">

                    <select class="form-control" id="posid" name="posid">
                        <option value="0">选择推荐位</option>
                        <?php if(is_array($posids)): $i = 0; $__LIST__ = $posids;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$r): $mod = ($i % 2 );++$i;?><option value="<?php echo ($r["id"]); ?>" <?php if($r['id'] == $posid){ ?>selected="selected"<?php } ?>><?php echo ($r["name"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
                    </select>
                </div>
                <?php if($fields['status']): ?><div class="form-group">
                    <select class="form-control" id="status" name="map[status]">
                        <option value="">状态</option>
                        <option value="0" <?php if(isset($status) && $status ==0): ?>selected="selected"<?php endif; ?>>未审核</option>
                        <option value="1" <?php if(isset($status) && $status ==1): ?>selected="selected"<?php endif; ?>>已审核</option>
                    </select>
                </div><?php endif; ?>
                <div class="form-group">
                    <select class="form-control" id="order" name="order">
                        <option value="listorder" <?php if(($order) == "listorder"): ?>selected="selected"<?php endif; ?>>排序</option>
                        <option value="id" <?php if(($order) == "id"): ?>selected="selected"<?php endif; ?>>ID排序</option>
                        <?php if($fields['hits']): ?><option value="hits" <?php if(($order) == "hits"): ?>selected="selected"<?php endif; ?>><?php echo L('hits');?>排序</option><?php endif; ?>
                    </select>
                </div>
                <div class="form-group">
                    <select class="form-control" name="sort">
                        <option value="asc" <?php if($sort =='asc'): ?>selected="selected"<?php endif; ?>>递增</option>
                        <option value="desc" <?php if($sort =='desc'): ?>selected="selected"<?php endif; ?>>递减</option>
                    </select>
                </div>
                <div class="form-group">
                    <select class="form-control" name="listRows">
                        <option value="15" <?php if($listRows ==5): ?>selected="selected"<?php endif; ?>>15条每页</option>
                        <option value="20" <?php if($listRows ==20): ?>selected="selected"<?php endif; ?>>20条每页</option>
                        <option value="50" <?php if($listRows ==50): ?>selected="selected"<?php endif; ?>>50条每页</option>
                        <option value="100" <?php if($listRows ==100): ?>selected="selected"<?php endif; ?>>100条每页</option>
                    </select>
                </div>
                <input type="submit" value="查询"  class="btn btn-primary" />
            </form>

        </div>
    </div>
</div>

<div class="row table-container">
    <div class="col-md-12">
        <form name="myform" id="myform" action="" method="post">

            <table class="table table-hover table-bordered">
                <thead>
                <tr>
                    <th class="w-50"><input type="checkbox" value="" id="check_box" onclick="selectall('ids[]');"></th>
                    <th class="w-50">排序</th>
                    <th width="40">ID</th>
                    <th>标题</th>
                    <th>日期</th>
                    <?php if($fields['status']): ?><th width="60">状态</th><?php endif; ?>
                    <th width="60">发布人</th>
                    <th class="center table-cell-2">操作管理</th>
                </tr>
                </thead>
                <tbody>
                <?php if(empty($list)): ?><tr class="table-data-empty">
                        <td class="text-center empty-info" colspan="8">
                            <i class="fa fa-database"></i> 暂无数据<br>
                        </td>
                    </tr>
                <?php else: ?>
                <?php if(is_array($list)): $k = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($k % 2 );++$k;?><tr>
                        <td width="30" align="center">
                            <input class="inputcheckbox" name="ids[]" value="<?php echo ($vo['id']); ?>" type="checkbox">
                        </td>
                        <td width="40" align='center'>
                            <input name='listorders[<?php echo ($vo["id"]); ?>]' type='text' size='3' value='<?php echo ($vo["listorder"]); ?>' class='input-text-c'>
                        </td>
                        <td align="center"><?php echo ($vo['id']); ?></td>
                        <td>
                            <?php if($vo['catid']): ?>[<font color="green"><?php echo ($categorys[$vo['catid']]['catname']); ?></font>]<?php endif; ?>
                            <a href="<?php echo ($vo["url"]); ?>" <?php if($vo['title_style']!=''): ?>style ="<?php echo ($vo['title_style']); ?>"<?php endif; ?> target="_blank"><?php echo ($vo['title']); ?> </a>
                            <?php if($vo['thumb']!=''): ?><a href="<?php echo ($vo['thumb']); ?>" class="preview" title="<?php echo ($vo['title']); ?>"><img src="__IMG__/admin_image.gif"></a><?php endif; ?>
                            <?php if($vo['posid']!=0): ?><img src="__IMG__/admin_elite.gif"><?php endif; ?>
                        </td>
                        <td>
                            <?php echo (todate($vo['createtime'],'Y-m-d')); ?>
                            <?php if($vo['createtime'] >= time()){?>
                                定时发布
                            <?php } else { ?>
                                已发布
                            <?php }?>
                        </td>
                        <?php if($fields['status']): ?><td align="center">
                                <?php if($vo['status']==1) : ?>
                                <font color="green">已审核</font>
                                <?php else :?>
                                <a href="<?php echo U($model_name.'/status',array(id=>$vo['id'],status=>1));?>"><font color="red">未审核</font></a>
                                <?php endif;?>
                            </td><?php endif; ?>
                        <td align="center"><?php echo ($vo['username']); ?></td>
                        <td class="center table-cell-2">
                            <a class="btn btn-sm btn-primary" href="<?php echo U($model_name.'/edit',array('id'=>$vo['id']));?>">编辑</a>
                            <a class="btn btn-sm btn-danger" href="javascript:confirm_delete('<?php echo U($model_name.'/delete',array('id'=>$vo['id']));?>')">删除</a>
                        </td>
                    </tr><?php endforeach; endif; else: echo "" ;endif; endif; ?>
                </tbody>
            </table>

            <div class="row">
                <div class="col-md-12">
                    <div class="pull-left" style="margin:20px 0;">

                    </div>
                    <div class="pull-right pagination"><?php echo ($page); ?></div>
                </div>

            </div>
        </form>
    </div>
</div>

</div>

<!-- 引入js -->
<script type="text/javascript" src="__STATIC__/layer/layer.js"></script>
<script src="__STATIC__/laydate/laydate.js"></script>
<script type="text/javascript" src="__JS__/admin.js"></script>
<script type="text/javascript" src="__JS__/jquery.form.js"></script>
<script type="text/javascript" src="__JS__/jquery.colorpicker.js"></script>
<script type="text/javascript" src="__STATIC__/MyDate/WdatePicker.js"></script>

<script type="text/javascript">

    var APP = '';
    var ROOT = '';
    var PUBLIC = '/public';

    $('.dropdown-toggle').dropdown()

    laydate.skin('molv');

    //登出
    window.onload = function (){

        $('#logout').click(function(){
            var url = $('#logout').attr('href');
            $.ajax({
                url: url,
                success:function(data){
                    layer.msg(data.info);
                    window.location.href = "<?php echo U('Login/index');?>";
                }
            });
            return false;
        })
    }

    //更新缓存
    function update_cache(){
        $.ajax({
            url:"<?php echo U('Public/cache');?>",
            beforeSend:function(){
                layer.msg('正在更新缓存');
            },
            success:function(data){
                window.location.reload();
            }
        });
    }
</script>


<script>
$("#catid").val(<?php echo ($catid); ?>);

function confirm_deleteall(){
    var str = 0;
    var id = tag = '';
    $('input[name="ids[]"]:checked').each(function(){
        str = 1;
        id += tag + $(this).val();
        tag = ',';
    });
    if (str == 0) {
        layer.msg('您没有勾选信息，无法进行操作！', {
            icon: 2,
            time: 1000 //2秒关闭（如果不配置，默认是3秒）
        });
        return false;
    }
    layer.confirm("确认要删除信息吗?", function(){
        myform.action = '/?m=<?php echo ($model_name); ?>&g=admin&a=delete&id='+id;
        $('#myform').submit();
    });
}

function content_check(){
    var str = 0;
    var id = tag = '';
    $('input[name="ids[]"]:checked').each(function(){
        str = 1;
        id += tag + $(this).val();
        tag = ',';
    });
    if (str == 0) {
        layer.msg('您没有勾选信息，无法进行操作！', {
            icon: 2,
            time: 1000 //2秒关闭（如果不配置，默认是3秒）
        });
        return false;
    }
    $.ajax({
        url:'/?m=<?php echo ($model_name); ?>&g=admin&a=public_check&id='+id,
        beforeSend:function(){
            layer.msg('审核中');
        },
        success:function(data){
            window.location.reload();
        }
    });
}
function content_nocheck(){
    var str = 0;
    var id = tag = '';
    $('input[name="ids[]"]:checked').each(function(){
        str = 1;
        id += tag + $(this).val();
        tag = ',';
    });
    if (str == 0) {
        layer.msg('您没有勾选信息，无法进行操作！', {
            icon: 2,
            time: 1000 //2秒关闭（如果不配置，默认是3秒）
        });
        return false;
    }
    $.ajax({
        url:'/?m=<?php echo ($model_name); ?>&g=admin&a=public_nocheck&id='+id,
        beforeSend:function(){
            layer.msg('取消审核中');
        },
        success:function(data){
            window.location.reload();
        }
    });
}

$('#push_btn').click(function(){
    var str = 0;
    var id = tag = '';
    $('input[name="ids[]"]:checked').each(function(){
            str = 1;
            id += tag + $(this).val();
            tag = '|';
    });
    if (str == 0) {
        layer.msg('您没有勾选信息，无法进行操作！', {
            icon: 2,
            time: 1000 //2秒关闭（如果不配置，默认是3秒）
        });
        return false;
    }
    openwin('/?m=<?php echo ($model_name); ?>&g=admin&a=push&action=position_list&modelid=<?php echo ($modelid); ?>&id=' + id,'信息推送','800px','400px');
});

$('#content_move').click(function(){
    var str = 0;
    var id = tag = '';
    $('input[name="ids[]"]:checked').each(function(){
            str = 1;
            id += tag + $(this).val();
            tag = '|';
    });
    if (str == 0) {
        layer.msg('您没有勾选信息，无法进行操作！', {
            icon: 2,
            time: 1000 //2秒关闭（如果不配置，默认是3秒）
        });
        return false;
    }
    openwin('/?m=<?php echo ($model_name); ?>&g=admin&a=remove&modelid=<?php echo ($modelid); ?>&id=' + id,'批量移动','800px','400px');
});

</script>

</body>
</html>