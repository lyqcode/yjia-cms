<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<!--[if IE 8 ]><html class="ie8"><![endif]-->
<!--[if IE 9 ]><html class="ie9"><![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--><html class="w3c"><!--<![endif]-->
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge,Chrome=1" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" type="text/css" href="__CSS__/elpis.min.css">
<link rel="stylesheet" href="__STATIC__/font-awesome/css/font-awesome.min.css">

<!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
<script src="__JS__/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="__JS__/bootstrap.js"></script>


<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="__STATIC__/bootstrap/js/vendor/html5shiv.js"></script>
<script src="__STATIC__/bootstrap/js/vendor/respond.min.js"></script>
<![endif]-->
<title>网站管理系统</title>

</head>

<body>

<nav>
    <!-- 面包屑导航 -->
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><i class="fa fa-map-marker"></i></li>
        <?php if(is_array($parent_menu)): $i = 0; $__LIST__ = $parent_menu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$menu_li): $mod = ($i % 2 );++$i;?><li class="breadcrumb-item"><?php echo ($menu_li["name"]); ?></li><?php endforeach; endif; else: echo "" ;endif; ?>
    </ol>
</nav>
<div class="page-container">
    

    <div class="row">
        <div class="col-md-12">
            <form action="<?php echo U('Page/in');?>" method="post">
                <table class="table table-striped table-bordered">
                    <thead>
                    <tr>
                        <th width="60">栏目ID</th>
                        <th>单页名称</th>
                        <th class="w-200px">操作</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if(is_array($list)): $k = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($k % 2 );++$k;?><tr>
                            <td width="60"><?php echo ($vo['id']); ?></td>
                            <td><?php echo ($vo['catname']); ?></td>
                            <td>
                                <a class="btn btn-sm btn-info" target="_blank" href="<?php echo $categorys[$vo['id']]['url'] ?>">访问</a>
                                <a class="btn btn-sm btn-primary" href="<?php echo U('Page/edit','id='.$vo['id']);?>">修改</a>
                             </td>
                        </tr><?php endforeach; endif; else: echo "" ;endif; ?>
                    </tbody>
                </table>
            </form>

            <div class="pagination"><?php echo ($page); ?></div>
        </div>

    </div>



</div>

<!-- 引入js -->
<script type="text/javascript" src="__STATIC__/layer/layer.js"></script>
<script src="__STATIC__/laydate/laydate.js"></script>
<script type="text/javascript" src="__JS__/admin.js"></script>
<script type="text/javascript" src="__JS__/jquery.form.js"></script>
<script type="text/javascript" src="__JS__/jquery.colorpicker.js"></script>
<script type="text/javascript" src="__STATIC__/MyDate/WdatePicker.js"></script>

<script type="text/javascript">

    var APP = '';
    var ROOT = '';
    var PUBLIC = '/public';

    $('.dropdown-toggle').dropdown()

    laydate.skin('molv');

    //登出
    window.onload = function (){

        $('#logout').click(function(){
            var url = $('#logout').attr('href');
            $.ajax({
                url: url,
                success:function(data){
                    layer.msg(data.info);
                    window.location.href = "<?php echo U('Login/index');?>";
                }
            });
            return false;
        })
    }

    //更新缓存
    function update_cache(){
        $.ajax({
            url:"<?php echo U('Public/cache');?>",
            beforeSend:function(){
                layer.msg('正在更新缓存');
            },
            success:function(data){
                window.location.reload();
            }
        });
    }
</script>


</body>
</html>