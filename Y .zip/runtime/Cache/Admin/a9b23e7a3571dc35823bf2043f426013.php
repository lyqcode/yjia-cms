<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<!--[if IE 8 ]><html class="ie8"><![endif]-->
<!--[if IE 9 ]><html class="ie9"><![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--><html class="w3c"><!--<![endif]-->
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,Chrome=1" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- 最新 Bootstrap 核心 CSS 文件 -->
    <link rel="stylesheet" href="__CSS__/elpis.min.css">
    <link rel="stylesheet" href="__STATIC__/font-awesome/css/font-awesome.min.css">

    <link rel="stylesheet" type="text/css" href="__PUBLIC__/admin/css/layout.min.css">
    <!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
    <script src="__JS__/jquery-1.10.2.min.js"></script>
    <script type="text/javascript" src="__STATIC__/bootstrap/js/bootstrap.min.js"></script>

    <!-- custom scrollbar stylesheet -->
    <link rel="stylesheet" href="__PUBLIC__/admin/css/jquery.mCustomScrollbar.min.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="__STATIC__/bootstrap/js/vendor/html5shiv.js"></script>
    <script src="__STATIC__/bootstrap/js/vendor/respond.min.js"></script>
    <![endif]-->
    <title>网站管理系统</title>
    
    <script>
        var APP = '';
        var ROOT = '';
        var PUBLIC = '/public';
        var COOKIE_PREFIX = '<?php echo (C("COOKIE_PREFIX")); ?>';
    </script>
</head>
<body>

<div id="header">
    <div class="navbar-fixed-top">
        <div class="container-fluid">
            <div id="brand"></div>

            <ul class="nav navbar-nav main-nav">
                <?php if(is_array($topmenu)): $i = 0; $__LIST__ = $topmenu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$menu): $mod = ($i % 2 );++$i;?><li id="top_<?php echo ($i); ?>">
                    <a href="<?php echo U($menu['group'].'/'.$menu['model'].'/'.$menu['action'],$menu['data']);?>">
                        <i class="<?php echo ($menu['icon']); ?>"></i>
                        <span><?php echo ($menu['name']); ?></span>
                    </a>
                </li><?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>

            <div class="navbar-content clearfix">
                <ul class="nav navbar-top-links pull-sm-right">
                    <?php if(count($Lang)>1){ ?>
                    <li class="dropdown">
                        <a id="lang_flag"  href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <img style="margin:0 5px;height: 20px;" src="__PUBLIC__/images/flag/<?php echo ($_SESSION['lang']['flag']); ?>"/>
							<span><?php echo ($_SESSION['lang']['name']); ?></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right">
                            <?php if(is_array($Lang)): $i = 0; $__LIST__ = $Lang;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$r): $mod = ($i % 2 );++$i;?><a class="dropdown-item" href="javascript:;" onclick="change_lang(this,'<?php echo ($r['mark']); ?>')">
                                <img style="margin:0 5px;height: 20px;" src="__PUBLIC__/images/flag/<?php echo ($r['flag']); ?>"/>
                                <span><?php echo ($r['name']); ?></span>
                            </a><?php endforeach; endif; else: echo "" ;endif; ?>
                        </div>
                    </li>
                    <?php } ?>
                    <li><a href="javascript:update_cache();" title="更新缓存"><i class="fa fa-lg fa-refresh"></i>更新缓存</a></li>
                    <li><a href="/" target="_blank" title="浏览站点"><i class="fa fa-lg fa-globe"></i>浏览站点</a></li>
                    <li><a href="http://e.grwy.net/ejiahelp" target="_blank" title="帮助说明"><i class="fa fa-lg fa-question-circle"></i>操作说明</a></li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <img src="<?php if(empty($_SESSION['admin']['avatar'])): ?>__PUBLIC__/images/admin_avtar.png<?php else: echo (thumb($_SESSION['admin']['avatar'],'30,30')); endif; ?>" alt="avatar" class="mw30 br64">
                            <?php echo ($_SESSION['admin']['username']); ?>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right">
                            <a class="dropdown-item" href="javascript:;" onclick="set_url('<?php echo U('User/index');?>')"><i class="fa fa-edit"></i>帐号设置</a>
                            <a class="dropdown-item" id="logout" href="<?php echo U('Login/logout');?>"><i class="fa fa-sign-out"></i>安全退出</a>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<!--侧边导航-->
<div id="aside" class="scrollerbar">
    <div class="navbar">
        <?php if(is_array($all_menu_list)): $ii = 0; $__LIST__ = $all_menu_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$side_menu_list): $mod = ($ii % 2 );++$ii;?><ul class="asidenav" id="aside_<?php echo ($ii); ?>">
            <?php if($ii == 1) { ?>

            <li><a><i class="fa fa-folder-open-o"></i><span>快捷操作</span></a>
                <ul>
                    <?php if(is_array($shortcuts)): $i = 0; $__LIST__ = $shortcuts;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$r): $mod = ($i % 2 );++$i;?><li>
                            <a href="javascript:;" onclick="set_url('<?php echo ($r["url"]); ?>');">
                                <i class="fa fa-mail-forward"></i><span><?php echo ($r["name"]); ?></span>
                            </a>
                        </li><?php endforeach; endif; else: echo "" ;endif; ?>
                    <!--<li>
                        <a href="<?php echo U('Visual/index');?>" target="_blank">
                            <i class="fa fa-eye"></i>
                            <span>可视化编辑</span>
                        </a>
                    </li>-->
                    <?php if($_SESSION['admin']['id']== 1): ?><li>
                            <a href="javascript:;" onclick="set_url('<?php echo U('Index/shortcuts');?>');">
                                <i class="fa fa-eye"></i>
                                <span>快捷操作管理</span>
                            </a>
                        </li><?php endif; ?>

                </ul>
            </li>

            <?php }else{ ?>
            <?php if(is_array($side_menu_list['_child'])): $i = 0; $__LIST__ = $side_menu_list['_child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$r): $mod = ($i % 2 );++$i; if($r['status'] != 0) : ?>
                <li><a><i class="fa fa-folder-open-o"></i><span><?php echo ($r['name']); ?></span></a>
                    <ul>
                        <?php if(is_array($r["_child"])): $i = 0; $__LIST__ = $r["_child"];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$rr): $mod = ($i % 2 );++$i;?><li>
                                <a href="javascript:;" onclick="set_url('<?php echo U($rr['group'].'/'.$rr['model'].'/'.$rr['action'],$rr['data']);?>')">
                                    <i class="<?php echo ($rr['icon']); ?>"></i><span><?php echo ($rr['name']); ?></span>
                                </a>
                            </li><?php endforeach; endif; else: echo "" ;endif; ?>
                    </ul>
                </li>
            <?php endif; endforeach; endif; else: echo "" ;endif; ?>
            <?php } ?>
        </ul><?php endforeach; endif; else: echo "" ;endif; ?>
    </div>
</div>

<div id="main">
    <iframe name="main-content" id="iframe_box" src="<?php echo U('index/main');?>" frameborder="false" scrolling="auto" allowTransparency="true" style="border:none;height:100%;" width="100%" height="100%">
    </iframe>
</div>

<!-- 引入js -->
<script type="text/javascript" src="__STATIC__/layer/layer.js"></script>
<script type="text/javascript" src="__JS__/admin.js"></script>
<!-- custom scrollbar plugin -->
<script src="__JS__/jquery.mCustomScrollbar.concat.min.js"></script>

<script type="text/javascript">
    $(function() {
        var id = getcookie('id');
        var location = getcookie('location');
        if (id && location) {
            $('.main-nav li').removeClass('active');
            $('#top_' + id).addClass('active');
            $('.asidenav').hide();
            $('#aside_' + id).show();
            $('#iframe_box').attr('src', location);
        } else {
            $('.main-nav li').removeClass('active');
            $('#top_1').addClass('active');
            $('.asidenav').hide();
            $('#aside_1').show();
            $("#iframe_box").attr("src", '/index.php?g=admin&m=index&a=main');
        }
    });
    window.onload = function (){
        if(!+"\v1" && !document.querySelector) { // for IE6 IE7
            document.body.onresize = init;
        } else {
            window.onresize = init;
        }
    };

    //返回浏览器可见区高度
    function getWindowHeight(){
        return window['innerHeight']|| document.compatMode === "CSS1Compat" && document.documentElement['clientHeight'] || document.body['clientHeight'];
    }
    //打开浏览器就执行自定义初始函数
    function init(){
        var heights = getWindowHeight()-54;
        if($('#aside').height()>heights){
            var width = $('#aside').width();
            $('#aside').width(width);
        }
        //设置右主体内容高度
    }
    init();

    $('.dropdown-toggle').dropdown();

    function set_url(url){
        $('#iframe_box').attr('src',url);
        setcookie('location', url);
        return false;
    }

    function change_lang(obj,lang){
        var url = getcookie('location') + '&l='+lang;
        var flag = $(obj).find('img').attr('src');
        var text = $(obj).find('span').text();
        $('#lang_flag img').attr('src', flag);
        $('#lang_flag span').text(text);
        $('#iframe_box').attr('src',url);
        return false;
    }

    $('.main-nav a').click(function(){
        var id = $(this).parent().attr('id').split('_');
        $('.main-nav li').removeClass('active');
        $(this).parent().addClass('active');
        $('.asidenav').hide();
        $('#aside_'+id[1]).show();
        var url = '/'+$(this).attr('href');
        $('#iframe_box').attr('src',url);
        setcookie("id", id[1]);
        setcookie('location', url);
        return false;
    });

    $(".scrollerbar").mCustomScrollbar({theme:"minimal"});

    //登出
    window.onload = function (){

        $('#logout').click(function(){
            setcookie("id", '');
            setcookie('location', '');
            var url = $('#logout').attr('href');
            $.ajax({
                url: url,
                success:function(data){
                    layer.msg(data.info);
                    window.location.href = "<?php echo U('Login/index');?>";
                }
            });
            return false;
        })
    }

    //更新缓存
    function update_cache(){
        $.ajax({
            url:"<?php echo U('Public/cache');?>",
            beforeSend:function(){
                layer.msg('正在更新缓存');
            },
            success:function(data){
                window.location.reload();
            }
        });
    }

    $("#top_1").addClass('active');
    $("#aside_1").show();
</script>
</body>
</html>