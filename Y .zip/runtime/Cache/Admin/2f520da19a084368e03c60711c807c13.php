<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
<html>
<head>
<title><?php echo L('message_title');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo C('DEFAULT_CHARSET');?>">
<link rel="stylesheet" href="__STATIC__/bootstrap/css/bootstrap.min.css">

<!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
<script src="__STATIC__/jquery-1.10.2.min.js"></script>

<script type="text/javascript" src="__STATIC__/bootstrap/js/bootstrap.min.js"></script>

<style type="text/css">
.showMsg {
    left: 50%;
    font-size: 14px;
    margin: -87px 0 0 -225px;
    position: absolute;
    top: 50%;
    width: 450px;
}
#sec {
    color:blue;
    font-weight:bold
}
</style>
</head>
<body>
<?php if (empty($jumpUrl)){ $jumpUrl = U('Index/index'); } ?>
<!--<?php echo ($msgTitle); ?> -->
<div class="showMsg panel panel-default">
    <div class="panel-heading">提示信息</div>
    <div class="panel-body"><?php echo ($message); ?> <?php echo ($error); ?></div>

    <div class="panel-footer">
    <?php if(isset($closeWin)): ?>系统将在<span id="sec"><?php echo ($waitSecond); ?></span> 秒后自动跳转，如果不想等待,直接<a href="<?php echo ($jumpUrl); ?>">关闭</a> 点击这里<?php endif; ?>
    <?php if(!isset($closeWin)): ?>系统将在 <span id="sec"><?php echo ($waitSecond); ?></span>秒后自动跳转，如果不想等待,直接 <a href="<?php echo ($jumpUrl); ?>">点击这里</a> 跳转<?php endif; ?>
    </div>

</div>

 <script>
    var seco=document.getElementById("sec");
    var time=<?php echo ($waitSecond); ?>;
    var tt = setInterval(function(){
            time--;
            seco.innerHTML=time;
            if(time<=0){
                <?php if(isset($jumpUrl)): ?>location.href = '<?php echo ($jumpUrl); ?>';
                <?php else: ?>
                window.history.go(-1);<?php endif; ?>
                return;
            }
        }, 1000);

    function stop(obj){
        clearInterval(tt);
        obj.style.display="none";
    }
</script>
</body>
</html>