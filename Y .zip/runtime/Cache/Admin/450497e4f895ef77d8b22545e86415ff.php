<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<!--[if IE 8 ]><html class="ie8"><![endif]-->
<!--[if IE 9 ]><html class="ie9"><![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--><html class="w3c"><!--<![endif]-->
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge,Chrome=1" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" type="text/css" href="__CSS__/elpis.min.css">
<link rel="stylesheet" href="__STATIC__/font-awesome/css/font-awesome.min.css">

<!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
<script src="__JS__/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="__JS__/bootstrap.js"></script>


<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="__STATIC__/bootstrap/js/vendor/html5shiv.js"></script>
<script src="__STATIC__/bootstrap/js/vendor/respond.min.js"></script>
<![endif]-->
<title>网站管理系统</title>

</head>

<body>

<nav>
    <!-- 面包屑导航 -->
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><i class="fa fa-map-marker"></i></li>
        <?php if(is_array($parent_menu)): $i = 0; $__LIST__ = $parent_menu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$menu_li): $mod = ($i % 2 );++$i;?><li class="breadcrumb-item"><?php echo ($menu_li["name"]); ?></li><?php endforeach; endif; else: echo "" ;endif; ?>
    </ol>
</nav>
<div class="page-container">
    

    <?php if(!empty($message)): ?><div class="col-2 col-auto alert-info">
		<h6>提示建议</h6>
		<div class="content">
			<div class="bk20 hr"><hr /></div>
			<?php if(is_array($message)): $i = 0; $__LIST__ = $message;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($i % 2 );++$i;?><div class="on<?php echo ($val["type"]); ?>">&nbsp;<?php echo ($val["content"]); ?></div><br /><?php endforeach; endif; else: echo "" ;endif; ?>
		</div>
	</div><?php endif; ?>

    <?php if(APP_DEBUG){?>
    <div class="alert alert-danger">
        <h6>提示建议</h6>
        <div class="content">
            <div class="bk20 hr"><hr /></div>
            上线之后请将APP_DEBUG参数设为false
        </div>
    </div>
    <?php } ?>

    <?php if(is_dir('./install')){?>
    <div class="alert alert-danger">
        <h6>提示建议</h6>
        <div class="content">
            <div class="bk20 hr"><hr /></div>
            上线之后请将install文件夹删除
        </div>
    </div>
    <?php } ?>

    <div class="page-header">

        <div class="pull-left">
            <h1>欢迎使用网站后台管理系统</h1>
        </div>

    </div>

    <div class="row">
        <div class="col-md-12 chartshow">
            <div class="card" style="border-color:#27b6c7;">
                <div class="card-header bg-primary">
                    <tr>
                        <th style="text-align:left;"><b class="ico"></b>
                            <span id="type">PC端统计图表</span>
                            <a class="red" style="background: rgb(29, 156, 171);" href="javascript:;" onclick="refresh_chart(this)">手机端统计图表</a>
                            <a class="green" href="javascript:;" onclick="tab_charts_w(this)">7天</a>
                            <a class="blue" href="javascript:;" onclick="tab_charts_m(this)">30天</a>
                            <img src="__IMG__/loading.gif" alt="">
                        </th>
                    </tr>
                </div>
                <div>
                    <tr>
                        <td style="border-bottom-width:0">
                            <div id="chart" style="height:300px;"></div>
                        </td>
                    </tr>
                </div>
            </div>
        </div>

    </div>

    <div class="row">
        <div class="content col-md-6">
            <div class="card" style="border-color:#27b6c7;">
                <div class="card-header bg-primary"><i class="fa fa-bar-chart-o"></i>数据统计</div>
                <table class="table table-hover">
                    <tr>
                        <th>信息类型</>
                        <th>总数据</th>
                        <th>操作</th>
                    </tr>
                    <?php if(is_array($models)): $i = 0; $__LIST__ = $models;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$r): $mod = ($i % 2 );++$i;?><tr>
                            <td><?php echo ($r["description"]); ?></td>
                            <td><?php echo ($mdata[$r['tablename']]); ?></td>
                            <td><a class="btn btn-primary btn-sm" href="<?php echo U($r['tablename'].'/index');?>">查看</a></td>
                        </tr><?php endforeach; endif; else: echo "" ;endif; ?>
                </table>

            </div>
        </div>

        <div class="col-md-6">
            <div class="card" style="border-color:#27b6c7;">
                <div class="card-header bg-primary">系统信息</div>
                <table class="table table-hover">
                    <?php if(is_array($server_info)): $i = 0; $__LIST__ = $server_info;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><tr>
                            <td><?php echo L($key);?>:</td>
                            <td><?php echo ($v); ?></td>
                        </tr><?php endforeach; endif; else: echo "" ;endif; ?>
                    <tr>
                        <td>版本号：</td>
                        <td><?php echo (C("cms_version")); ?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>


</div>

<!-- 引入js -->
<script type="text/javascript" src="__STATIC__/layer/layer.js"></script>
<script src="__STATIC__/laydate/laydate.js"></script>
<script type="text/javascript" src="__JS__/admin.js"></script>
<script type="text/javascript" src="__JS__/jquery.form.js"></script>
<script type="text/javascript" src="__JS__/jquery.colorpicker.js"></script>
<script type="text/javascript" src="__STATIC__/MyDate/WdatePicker.js"></script>

<script type="text/javascript">

    var APP = '';
    var ROOT = '';
    var PUBLIC = '/public';

    $('.dropdown-toggle').dropdown()

    laydate.skin('molv');

    //登出
    window.onload = function (){

        $('#logout').click(function(){
            var url = $('#logout').attr('href');
            $.ajax({
                url: url,
                success:function(data){
                    layer.msg(data.info);
                    window.location.href = "<?php echo U('Login/index');?>";
                }
            });
            return false;
        })
    }

    //更新缓存
    function update_cache(){
        $.ajax({
            url:"<?php echo U('Public/cache');?>",
            beforeSend:function(){
                layer.msg('正在更新缓存');
            },
            success:function(data){
                window.location.reload();
            }
        });
    }
</script>



    <script src="__STATIC__/highcharts.js"></script>
    <script src="__STATIC__/exporting.js"></script>
    <script>
        $(function(){
            render_chart();
        });

        var type = 1;
        var day = 10;
        function refresh_chart(obj) {
            var text = $("#type").text();
            $("#type").text($(obj).text());
            $(obj).addClass("hover");
            $(obj).text(text);
            if(type == 1) {
                type = 2;
            }else {
                type = 1;
            }
            day = 10;
            render_chart(1);
        }

        function tab_charts_w(obj) {
            $(".range").removeClass("range");
            $(obj).addClass("range");
            day = 7;
            render_chart(1);
        }

        function tab_charts_m(obj) {
            $(".range").removeClass("range");
            $(obj).addClass("range");
            day = 30;
            render_chart(3);
        }

        function render_chart(step) {
            $("#loading").css("display", "inline-block");
            $.get("<?php echo U('Admin/Public/public_get_chart');?>", {"type":type, "day":day},
                    function(data){
                        $("#loading").css("display", "none");
                        get_chart(data.type1,data.type2,data.categories,$("#type").text(),step);
                    },"json");
        }

        function get_chart(data1,data2,categories,text,step){
            var text = text ? text : "手机端统计图表";
            var stepval = step ? step: 1;

            Highcharts.setOptions({
                colors:['#27A9E3','#FF6666']
            });
            $('#chart').highcharts({
                chart: {
                    renderTo: 'container',
                    defaultSeriesType: 'line',//图表类别，可取值有：line、spline、area、areaspline、bar、column等
                },
                credits:{
                    enabled:false
                },
                exporting :{
                    enabled :false
                },
                title: {
                    text: text,
                    x: -20
                },
                xAxis: {
                    type : 'datetime',
                    categories: categories,
                    labels:{
                        step:stepval,
                        staggerLines: 1
                    }
                },
                yAxis: {
                    title: {
                        text: 'PV/IP'
                    },
                    plotLines: [{
                        value: 0,
                        width: 1,
                        color: '#808080'
                    }],
                },
                tooltip: {
                    valueSuffix: '',
                    //shared: true
                },
                legend: {
                    layout: 'vertical',
                    align: 'right',
                    verticalAlign: 'middle',
                    borderWidth: 0
                },
                plotOptions: {
                    line: {
                        dataLabels: {
                            enabled: true
                        },
                    }
                },
                series: [{
                    name: 'IP',
                    data: data1
                }, {
                    name: 'PV',
                    data: data2
                }
                ]
            });
        }
    </script>

</body>
</html>