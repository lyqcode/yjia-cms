<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<!--[if IE 8 ]><html class="ie8"><![endif]-->
<!--[if IE 9 ]><html class="ie9"><![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--><html class="w3c"><!--<![endif]-->
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge,Chrome=1" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" type="text/css" href="__CSS__/elpis.min.css">
<link rel="stylesheet" href="__STATIC__/font-awesome/css/font-awesome.min.css">

<!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
<script src="__JS__/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="__JS__/bootstrap.js"></script>


<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="__STATIC__/bootstrap/js/vendor/html5shiv.js"></script>
<script src="__STATIC__/bootstrap/js/vendor/respond.min.js"></script>
<![endif]-->
<title>网站管理系统</title>

</head>

<body>

<nav>
    <!-- 面包屑导航 -->
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><i class="fa fa-map-marker"></i></li>
        <?php if(is_array($parent_menu)): $i = 0; $__LIST__ = $parent_menu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$menu_li): $mod = ($i % 2 );++$i;?><li class="breadcrumb-item"><?php echo ($menu_li["name"]); ?></li><?php endforeach; endif; else: echo "" ;endif; ?>
    </ol>
</nav>
<div class="page-container">
    
<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">邮箱发送配置（用于网站发送邮件）</div>
            <div class="card-block">
                <form class="myform form-horizontal" method='post' action="<?php echo U('Sysconfig/save');?>">

                    <div class="form-group row">
                        <label class="form-control-label col-md-3">邮件服务器</label>
                        <div class="col-md-7">
                            <input type="text" class="form-control" name="SMTP_HOST" value="<?php echo ($sysconf['SMTP_HOST']); ?>"/>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="form-control-label col-md-3">邮件发送端口</label>
                        <div class="col-md-3">
                            <input type="text" class="form-control" name="SMTP_PORT" value="<?php echo ($sysconf["SMTP_PORT"]); ?>"/>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="form-control-label col-md-3">发件人地址</label>
                        <div class="col-md-7">
                            <input type="text" class="form-control" name="mail_from" value="<?php echo ($sysconf["mail_from"]); ?>"/>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="form-control-label col-md-3">验证用户名</label>
                        <div class="col-md-7">
                            <input type="text" class="form-control" name="SMTP_USER" value="<?php echo ($sysconf["SMTP_USER"]); ?>"/>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="form-control-label col-md-3">验证密码</label>
                        <div class="col-md-7" id="mail_password">
                            <?php if(!empty($sysconf['SMTP_PASS'])){ ?>
                            <p class="form-control-static" style="width: 100px;float:left;">*********</p>
                            <button type="button" onclick="changepwd()" class="btn btn-sm btn-primary" style="float:left;">修改</button>
                            <?php }else{ ?>
                            <input type="password" class="form-control" name="SMTP_PASS" value=""/>
                            <?php } ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="form-control-label col-md-3">邮件设置测试</label>
                        <div class="col-md-5">
                            <input type="text" class="form-control" name="mail_to" id="mail_to" value=""/>
                            <input type="button" class="btn btn-sm btn-primary" onClick="javascript:test_mail();" value="测试发送">
                        </div>
                    </div>
                    <div class="form-actions">
                        <input type="submit" value="保存" class="btn btn-primary">
                        <input type="reset" value="重置" class="btn btn-primary">
                    </div>
                </form>

            </div>
        </div>

    </div>
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">邮箱接收配置（用于接收邮件）</div>
            <div class="card-block">
                <form class="myform" method='post' action="<?php echo U('Sysconfig/save');?>">
                    <div class="form-group row">
                        <label class="form-control-label col-md-3">邮箱地址</label>
                        <div class="col-md-7">
                            <input type="text" class="form-control" name="mail_accept" id="mail_server" value="<?php echo ($sysconf['mail_accept']); ?>"/>
                        </div>
                    </div>

                    <div class="form-actions">
                        <input type="submit" value="保存" class="btn btn-primary">
                        <input type="reset" value="重置" class="btn btn-primary">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<script>
function changepwd(){
    var html = '<input type="password" class="form-control" name="SMTP_PASS" value=""/>';
    $('#mail_password').html(html);
}
function test_mail(){
    $.ajax({
        url:'<?php echo U("Sysconfig/testmail");?>&mail_to='+$('#mail_to').val(),
        beforeSend:function(){
            layer.msg('正在发送邮件');
        },
        success:function(data){
            layer.msg(data.info);
        }
    });
}
</script>

<script type="text/javascript">
$(document).ready(function() {
    $('.myform').ajaxForm({
        success:  complete,  // post-submit callback
        dataType: 'json'
    });
});

function complete(data){
    if(data.status==1){
        layer.msg('修改成功');
    }else{
        layer.msg(data.info);
    }
}
</script>

</div>

<!-- 引入js -->
<script type="text/javascript" src="__STATIC__/layer/layer.js"></script>
<script src="__STATIC__/laydate/laydate.js"></script>
<script type="text/javascript" src="__JS__/admin.js"></script>
<script type="text/javascript" src="__JS__/jquery.form.js"></script>
<script type="text/javascript" src="__JS__/jquery.colorpicker.js"></script>
<script type="text/javascript" src="__STATIC__/MyDate/WdatePicker.js"></script>

<script type="text/javascript">

    var APP = '';
    var ROOT = '';
    var PUBLIC = '/public';

    $('.dropdown-toggle').dropdown()

    laydate.skin('molv');

    //登出
    window.onload = function (){

        $('#logout').click(function(){
            var url = $('#logout').attr('href');
            $.ajax({
                url: url,
                success:function(data){
                    layer.msg(data.info);
                    window.location.href = "<?php echo U('Login/index');?>";
                }
            });
            return false;
        })
    }

    //更新缓存
    function update_cache(){
        $.ajax({
            url:"<?php echo U('Public/cache');?>",
            beforeSend:function(){
                layer.msg('正在更新缓存');
            },
            success:function(data){
                window.location.reload();
            }
        });
    }
</script>


</body>
</html>