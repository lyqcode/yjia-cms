<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<!--[if IE 8 ]><html class="ie8"><![endif]-->
<!--[if IE 9 ]><html class="ie9"><![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--><html class="w3c"><!--<![endif]-->
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge,Chrome=1" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" type="text/css" href="__CSS__/elpis.min.css">
<link rel="stylesheet" href="__STATIC__/font-awesome/css/font-awesome.min.css">

<!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
<script src="__JS__/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="__JS__/bootstrap.js"></script>


<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="__STATIC__/bootstrap/js/vendor/html5shiv.js"></script>
<script src="__STATIC__/bootstrap/js/vendor/respond.min.js"></script>
<![endif]-->
<title>网站管理系统</title>

</head>

<body>

<nav>
    <!-- 面包屑导航 -->
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><i class="fa fa-map-marker"></i></li>
        <?php if(is_array($parent_menu)): $i = 0; $__LIST__ = $parent_menu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$menu_li): $mod = ($i % 2 );++$i;?><li class="breadcrumb-item"><?php echo ($menu_li["name"]); ?></li><?php endforeach; endif; else: echo "" ;endif; ?>
    </ol>
</nav>
<div class="page-container">
    

<div class="table-toolbar">
    <a href="<?php echo U('Database/index');?>" class="btn btn-primary">备份数据</a>
    <button class="btn btn-danger" onclick="myform.action='<?php echo U('Database/recover?do=delete');?>'; $('#myform').submit();">删除</button>
</div>

<form id="myform" name="myform" method="post" action="">
    <table class="table table-bordered">
        <thead>
        <tr>
          <th class="w-50"><input type="checkbox" id="check_box" onclick="selectall('files[]');"></th>
          <th align="left">名称</th>
          <th align="left">大小</th>
          <th align="left">备份时间</th>
          <th align="left">下载</th>
          <!-- <th align="left" style="width:8%">还原数据</th> -->
        </tr>
      </thead>

    <tbody>
    <?php if(is_array($files)): $i = 0; $__LIST__ = $files;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr>
      <td><input type="checkbox" name="files[]" value="<?php echo ($vo["path"]); ?>"> </td>
      <td><?php echo ($vo["name"]); ?></td>
      <td><?php echo (byte_format($vo["size"])); ?></td>
      <td><?php echo (todate($vo["time"])); ?></td>
      <td><a class="btn btn-sm btn-primary" href="javascript:window.location='<?php echo U('Database/download?filename='.$vo[name]);?>'">下载</a></td>
      <!-- <td><a href="javascript:if(confirm('确认要还原数据吗？')) window.location='<?php echo U('Database/recover?do=import&filename='.$vo[name]);?>'">还原数据</a></td> -->
    </tr><?php endforeach; endif; else: echo "" ;endif; ?>

    </tbody>
    </table>
</form>


</div>

<!-- 引入js -->
<script type="text/javascript" src="__STATIC__/layer/layer.js"></script>
<script src="__STATIC__/laydate/laydate.js"></script>
<script type="text/javascript" src="__JS__/admin.js"></script>
<script type="text/javascript" src="__JS__/jquery.form.js"></script>
<script type="text/javascript" src="__JS__/jquery.colorpicker.js"></script>
<script type="text/javascript" src="__STATIC__/MyDate/WdatePicker.js"></script>

<script type="text/javascript">

    var APP = '';
    var ROOT = '';
    var PUBLIC = '/public';

    $('.dropdown-toggle').dropdown()

    laydate.skin('molv');

    //登出
    window.onload = function (){

        $('#logout').click(function(){
            var url = $('#logout').attr('href');
            $.ajax({
                url: url,
                success:function(data){
                    layer.msg(data.info);
                    window.location.href = "<?php echo U('Login/index');?>";
                }
            });
            return false;
        })
    }

    //更新缓存
    function update_cache(){
        $.ajax({
            url:"<?php echo U('Public/cache');?>",
            beforeSend:function(){
                layer.msg('正在更新缓存');
            },
            success:function(data){
                window.location.reload();
            }
        });
    }
</script>


</body>
</html>