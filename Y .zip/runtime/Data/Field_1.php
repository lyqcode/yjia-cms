<?php	return array ( 'title' => array ( 'id' => '1', 'modelid' => '1', 'field' => 'title', 'name' => '标题', 'tips' => '', 'required' => '1', 'minlength' => '3', 'maxlength' => '80', 'pattern' => '0', 'errormsg' => '标题必填3-80个字', 'class' => '', 'type' => 'title', 'setup' => '{"thumb":"0","style":"0","size":"55"}', 'isbase' => '1', 'unpostgroup' => '', 'listorder' => '0', 'status' => '1', 'issystem' => '1', ), 'keywords' => array ( 'id' => '2', 'modelid' => '1', 'field' => 'keywords', 'name' => '关键词', 'tips' => '', 'required' => '0', 'minlength' => '0', 'maxlength' => '0', 'pattern' => '', 'errormsg' => '', 'class' => '', 'type' => 'text', 'setup' => 'array (
  \'size\' => \'55\',
  \'default\' => \'\',
  \'ispassword\' => \'0\',
)', 'isbase' => '1', 'unpostgroup' => '', 'listorder' => '0', 'status' => '0', 'issystem' => '1', ), 'description' => array ( 'id' => '3', 'modelid' => '1', 'field' => 'description', 'name' => 'SEO简介', 'tips' => '', 'required' => '0', 'minlength' => '0', 'maxlength' => '0', 'pattern' => '', 'errormsg' => '', 'class' => '', 'type' => 'textarea', 'setup' => 'array (
  \'rows\' => \'4\',
  \'cols\' => \'55\',
  \'default\' => \'\',
)', 'isbase' => '1', 'unpostgroup' => '', 'listorder' => '0', 'status' => '0', 'issystem' => '1', ), 'content' => array ( 'id' => '4', 'modelid' => '1', 'field' => 'content', 'name' => '内容', 'tips' => '', 'required' => '0', 'minlength' => '0', 'maxlength' => '0', 'pattern' => '', 'errormsg' => '', 'class' => '', 'type' => 'editor', 'setup' => 'array (
  \'toolbar\' => \'full\',
  \'default\' => \'\',
  \'height\' => \'\',
  \'showpage\' => \'1\',
  \'enablekeylink\' => \'0\',
  \'replacenum\' => \'\',
  \'enablesaveimage\' => \'0\',
  \'flashupload\' => \'1\',
  \'alowuploadexts\' => \'jpg,jpeg,gif,doc,rar,zip,xls\',
)', 'isbase' => '1', 'unpostgroup' => '', 'listorder' => '0', 'status' => '1', 'issystem' => '1', ), 'wap_content' => array ( 'id' => '76', 'modelid' => '1', 'field' => 'wap_content', 'name' => '手机内容', 'tips' => '', 'required' => '0', 'minlength' => '0', 'maxlength' => '0', 'pattern' => '0', 'errormsg' => '', 'class' => '', 'type' => 'editor', 'setup' => '{"toolbar":"full","default":"","height":"280","show_add_description":"0","show_auto_thumb":"0","showpage":"0","enablekeylink":"0","replacenum":"","enablesaveimage":"0","flashupload":"0","alowuploadexts":"","alowuploadlimit":""}', 'isbase' => '1', 'unpostgroup' => '', 'listorder' => '0', 'status' => '1', 'issystem' => '0', ), );?>