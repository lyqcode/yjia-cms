##README
Y+是一款基于PHP+MYSQL开发的中文内容管理框架。

##INSTALL

安装请执行http://yourdomain/install/index.php
安装完成后请删除或改名install/index.php