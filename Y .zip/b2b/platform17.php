<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>网站大全</title>
<link rel="stylesheet" href="css/style.css" />
</head>



<body>
<div class=" IncludeBox grWidth">
	<?php include "platform.php";?>
	<ul  class="IncludeContainer clearfix">
		<li><a href="javascript:search('中国商务服务网')">中国商务服务网</a></li>
		<li><a href="javascript:search('中国猪产品交易网')">中国猪产品交易网</a></li>
		<li><a href="javascript:search('中国纸制品网')">中国纸制品网</a></li>
		<li><a href="javascript:search('中国口红用品网')">中国口红用品网</a></li>
		<li><a href="javascript:search('中国运动护具网')">中国运动护具网</a></li>
		<li><a href="javascript:search('中国防身用具网')">中国防身用具网</a></li>
		<li><a href="javascript:search('中国防爆网')">中国防爆网</a></li>
		<li><a href="javascript:search('中国胶带网')">中国胶带网</a></li>
		<li><a href="javascript:search('中国包装材料总汇')">中国包装材料总汇</a></li>
		<li><a href="javascript:search('中国纸网')">中国纸网</a></li>
		<li><a href="javascript:search('中国台历网')">中国台历网</a></li>
		<li><a href="javascript:search('中国报刊网')">中国报刊网</a></li>
		<li><a href="javascript:search('中国音像网')">中国音像网</a></li>
		<li><a href="javascript:search('中国电子读物网')">中国电子读物网</a></li>
		<li><a href="javascript:search('中华文具网')">中华文具网</a></li>
		<li><a href="javascript:search('中华百笔网')">中华百笔网</a></li>
		<li><a href="javascript:search('中国计算器具网')">中国计算器具网</a></li>
		<li><a href="javascript:search('中国教学器材网')">中国教学器材网</a></li>
		<li><a href="javascript:search('中国办公设备网')">中国办公设备网</a></li>
		<li><a href="javascript:search('中国耗材网')">中国耗材网</a></li>
		<li><a href="javascript:search('中国光学仪器网')">中国光学仪器网</a></li>
		<li><a href="javascript:search('中国眼镜网')">中国眼镜网</a></li>
		<li><a href="javascript:search('中国翻译服务网')">中国翻译服务网</a></li>
		<li><a href="javascript:search('中国手机配件网')">中国手机配件网</a></li>
		<li><a href="javascript:search('中国笔记本专业网')">中国笔记本专业网</a></li>
		<li><a href="javascript:search('IDC供求在线')">IDC供求在线</a></li>
		<li><a href="javascript:search('中国网络设备网')">中国网络设备网</a></li>
		<li><a href="javascript:search('中软网')">中软网</a></li>
		<li><a href="javascript:search('中国电力电器网')">中国电力电器网</a></li>
		<li><a href="javascript:search('中国电力设备网')">中国电力设备网</a></li>
		<li><a href="javascript:search('中国充电器网')">中国充电器网</a></li>
		<li><a href="javascript:search('中国风机网')">中国风机网</a></li>
		<li><a href="javascript:search('中国压缩机网')">中国压缩机网</a></li>
		<li><a href="javascript:search('中国弹簧网')">中国弹簧网</a></li>
		<li><a href="javascript:search('中国减速机网')">中国减速机网</a></li>
		<li><a href="javascript:search('中国焊机网')">中国焊机网</a></li>
		<li><a href="javascript:search('中国电阻炉专业网')">中国电阻炉专业网</a></li>
		<li><a href="javascript:search('中国电容网')">中国电容网</a></li>
		<li><a href="javascript:search('中国设备网')">中国设备网</a></li>
		<li><a href="javascript:search('中华汽配网')">中华汽配网</a></li>
		<li><a href="javascript:search('中国医院总网')">中国医院总网</a></li>
		<li><a href="javascript:search('中国印刷网')">中国印刷网</a></li>
		<li><a href="javascript:search('中国物流网')">中国物流网</a></li>
		<li><a href="javascript:search('中国涂料网')">中国涂料网</a></li>
		<li><a href="javascript:search('中国树脂网')">中国树脂网</a></li>
		<li><a href="javascript:search('中国钢管网')">中国钢管网</a></li>
		<li><a href="javascript:search('中国玻璃网')">中国玻璃网</a></li>
		<li><a href="javascript:search('中国照明网')">中国照明网</a></li>
		<li><a href="javascript:search('中国电子元件网')">中国电子元件网</a></li>
		<li><a href="javascript:search('第一电机网')">第一电机网</a></li>
		<li><a href="javascript:search('中国传媒网')">中国传媒网</a></li>
		<li><a href="javascript:search('中国广电器材网')">中国广电器材网</a></li>
		<li><a href="javascript:search('中国安防仪器网')">中国安防仪器网</a></li>
		<li><a href="javascript:search('中国包装业总站')">中国包装业总站</a></li>
		<li><a href="javascript:search('中国发发纸业网')">中国发发纸业网</a></li>
		<li><a href="javascript:search('中国床上用品网')">中国床上用品网</a></li>
		<li><a href="javascript:search('中国摄像网')">中国摄像网</a></li>
		<li><a href="javascript:search('中国舞台设备网')">中国舞台设备网</a></li>
		<li><a href="javascript:search('中国音响网')">中国音响网</a></li>
		<li><a href="javascript:search('中国摄影机网')">中国摄影机网</a></li>
		<li><a href="javascript:search('中国办公文教用品网')">中国办公文教用品网</a></li>
		<li><a href="javascript:search('中国数码电脑网')">中国数码电脑网</a></li>
		<li><a href="javascript:search('中华电工电气网')">中华电工电气网</a></li>
		<li><a href="javascript:search('中国纺织皮革网')">中国纺织皮革网</a></li>
		<li><a href="javascript:search('中华服装服饰网')">中华服装服饰网</a></li>
		<li><a href="javascript:search('中国五金工具网')">中国五金工具网</a></li>
		<li><a href="javascript:search('中国化工行业总汇')">中国化工行业总汇</a></li>
		<li><a href="javascript:search('中国精细化学网')">中国精细化学网</a></li>
		<li><a href="javascript:search('中国橡塑网')">中国橡塑网</a></li>
		<li><a href="javascript:search('中华环保网')">中华环保网</a></li>
		<li><a href="javascript:search('中国仪器仪表网')">中国仪器仪表网</a></li>
		<li><a href="javascript:search('中国家居用品展览网')">中国家居用品展览网</a></li>
		<li><a href="javascript:search('中国家用电器网')">中国家用电器网</a></li>
		<li><a href="javascript:search('中华建筑建材总汇')">中华建筑建材总汇</a></li>
		<li><a href="javascript:search('中国交通运输设备网')">中国交通运输设备网</a></li>
		<li><a href="javascript:search('中国电热设备网')">中国电热设备网</a></li>
		<li><a href="javascript:search('中华工控网')">中华工控网</a></li>
		<li><a href="javascript:search('中国仪器仪表网')">中国仪器仪表网</a></li>
		<li><a href="javascript:search('中国电动工具网')">中国电动工具网</a></li>
		<li><a href="javascript:search('中国天线网')">中国天线网</a></li>
		<li><a href="javascript:search('中国电器维修网')">中国电器维修网</a></li>
		<li><a href="javascript:search('中国纺织在线')">中国纺织在线</a></li>
		<li><a href="javascript:search('中华皮革商情网')">中华皮革商情网</a></li>
		<li><a href="javascript:search('中国面料供求网')">中国面料供求网</a></li>
		<li><a href="javascript:search('中国反光材料网')">中国反光材料网</a></li>
		<li><a href="javascript:search('中国辅料交易网')">中国辅料交易网</a></li>
		<li><a href="javascript:search('中国纺织设备交易网')">中国纺织设备交易网</a></li>
		<li><a href="javascript:search('中国电子器件网')">中国电子器件网</a></li>
		<li><a href="javascript:search('中国广告情报网')">中国广告情报网</a></li>
		<li><a href="javascript:search('中国广告器材交易网')">中国广告器材交易网</a></li>
		<li><a href="javascript:search('中华促销礼品总汇')">中华促销礼品总汇</a></li>
		<li><a href="javascript:search('中国厨房用品网')">中国厨房用品网</a></li>
		<li><a href="javascript:search('中国布艺网')">中国布艺网</a></li>
		<li><a href="javascript:search('中国制革网')">中国制革网</a></li>
		<li><a href="javascript:search('杭州女装网')">杭州女装网</a></li>
		<li><a href="javascript:search('性感内衣网')">性感内衣网</a></li>
		<li><a href="javascript:search('爱心童装商务网')">爱心童装商务网</a></li>
		<li><a href="javascript:search('中国男装网')">中国男装网</a></li>
		<li><a href="javascript:search('中国运动服网')">中国运动服网</a></li>
		<li><a href="javascript:search('中国服装辅料网')">中国服装辅料网</a></li>
		<li><a href="javascript:search('中国工艺品网')">中国工艺品网</a></li>
		<li><a href="javascript:search('中国能源网')">中国能源网</a></li>
		<li><a href="javascript:search('中国汽摩配件网')">中国汽摩配件网</a></li>
		<li><a href="javascript:search('中国食品饮料网')">中国食品饮料网</a></li>
		<li><a href="javascript:search('中国通信产品商情网')">中国通信产品商情网</a></li>
		<li><a href="javascript:search('中国冶金矿产总站')">中国冶金矿产总站</a></li>
		<li><a href="javascript:search('中国医疗保养总汇')">中国医疗保养总汇</a></li>
		<li><a href="javascript:search('中国运动休闲用品网')">中国运动休闲用品网</a></li>
		<li><a href="javascript:search('华夏服装机械网')">华夏服装机械网</a></li>
		<li><a href="javascript:search('中国设计服务网')">中国设计服务网</a></li>
		<li><a href="javascript:search('全球皮鞋网')">全球皮鞋网</a></li>
		<li><a href="javascript:search('中国运动鞋专业交易网')">中国运动鞋专业交易网</a></li>
		<li><a href="javascript:search('中华鞋模网')">中华鞋模网</a></li>
		<li><a href="javascript:search('中国制鞋机械网')">中国制鞋机械网</a></li>
		<li><a href="javascript:search('全球手套网')">全球手套网</a></li>
		<li><a href="javascript:search('华夏鞋帽网')">华夏鞋帽网</a></li>
		<li><a href="javascript:search('全球皮带总汇')">全球皮带总汇</a></li>
		<li><a href="javascript:search('中国皮腰带网')">中国皮腰带网</a></li>
		<li><a href="javascript:search('中华塑料机械网')">中华塑料机械网</a></li>
		<li><a href="javascript:search('华人石油设备总站')">华人石油设备总站</a></li>
	</ul>
	<div class="pages">
		<div class="pagination">
			<a href="platform16.php#putongweb">上一页</a>
			<a href="platform18.php#putongweb">下一页</a>
			<a href="platform1.php">第一页</a>
			<a href="platform11.php#putongweb">上5页</a>
			<a href="platform16.php#putongweb">16</a>
			<span class="current">17</span>
			<a href="platform18.php#putongweb">18</a>
			<a href="platform19.php#putongweb">19</a>
			<a href="platform20.php#putongweb">20</a>
			<a href="platform21.php#putongweb">下5页</a>
			<a href="platform23.php#putongweb"><span id="lastspan">最后一页</span></a>
		</div>
	</div>
</div>
<script>
	function search(val){
		window.open("https://www.baidu.com/s?wd="+val);
	}
</script>
</body>
</html>
