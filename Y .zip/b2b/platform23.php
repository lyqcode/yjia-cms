<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>网站大全</title>
<link rel="stylesheet" href="css/style.css" />
</head>

<body>
<div class=" IncludeBox grWidth">
	<?php include "platform.php";?>
	<ul  class="IncludeContainer clearfix">
		<li><a href="javascript:search('中国休闲服装网')">中国休闲服装网</a></li>
		<li><a href="javascript:search('西部鞋网')">西部鞋网</a></li>
		<li><a href="javascript:search('中国内衣贸易网')">中国内衣贸易网</a></li>
		<li><a href="javascript:search('全球缝制设备网')">全球缝制设备网</a></li>
		<li><a href="javascript:search('中国服装业务网')">中国服装业务网</a></li>
		<li><a href="javascript:search('康药网')">康药网</a></li>
		<li><a href="javascript:search('中国医药招商网')">中国医药招商网</a></li>
		<li><a href="javascript:search('中国金药网')">中国金药网</a></li>
		<li><a href="javascript:search('中国医药企业网')">中国医药企业网</a></li>
		<li><a href="javascript:search('环球医药信息网')">环球医药信息网</a></li>
		<li><a href="javascript:search('都市健康网')">都市健康网</a></li>
		<li><a href="javascript:search('39健康网')">39健康网</a></li>
		<li><a href="javascript:search('乳业中国')">乳业中国</a></li>
		<li><a href="javascript:search('食品在线')">食品在线</a></li>
		<li><a href="javascript:search('食品中国')">食品中国</a></li>
		<li><a href="javascript:search('健康食品网')">健康食品网</a></li>
		<li><a href="javascript:search('中国粮油招商网')">中国粮油招商网</a></li>
		<li><a href="javascript:search('中国金属商贸网')">中国金属商贸网</a></li>
		<li><a href="javascript:search('中国煤矿网')">中国煤矿网</a></li>
		<li><a href="javascript:search('中国能源信息网')">中国能源信息网</a></li>
		<li><a href="javascript:search('中国铜加工网')">中国铜加工网</a></li>
		<li><a href="javascript:search('中国保温耐火材料网')">中国保温耐火材料网</a></li>
		<li><a href="javascript:search('中国铝氧化信息网')">中国铝氧化信息网</a></li>
		<li><a href="javascript:search('上海有色金属网')">上海有色金属网</a></li>
		<li><a href="javascript:search('中华不锈钢网')">中华不锈钢网</a></li>
		<li><a href="javascript:search('钢管企业推广网')">钢管企业推广网</a></li>
		<li><a href="javascript:search('博燃网')">博燃网</a></li>
		<li><a href="javascript:search('中国新能源网')">中国新能源网</a></li>
		<li><a href="javascript:search('中国煤炭工业网')">中国煤炭工业网</a></li>
		<li><a href="javascript:search('钢之家')">钢之家</a></li>
		<li><a href="javascript:search('中国煤炭市场网')">中国煤炭市场网</a></li>
		<li><a href="javascript:search('新能量电力信息网')">新能量电力信息网</a></li>
		<li><a href="javascript:search('中国金属加工网')">中国金属加工网</a></li>
		<li><a href="javascript:search('中华铝业网')">中华铝业网</a></li>
		<li><a href="javascript:search('无锡钢铁网')">无锡钢铁网</a></li>
		<li><a href="javascript:search('中国废品网')">中国废品网</a></li>
		<li><a href="javascript:search('中国电炉网')">中国电炉网</a></li>
		<li><a href="javascript:search('中国太阳能配件网')">中国太阳能配件网</a></li>
		<li><a href="javascript:search('钢铁人网')">钢铁人网</a></li>
		<li><a href="javascript:search('中国矿山信息网')">中国矿山信息网</a></li>
		<li><a href="javascript:search('中国特油网')">中国特油网</a></li>
		<li><a href="javascript:search('石油在线')">石油在线</a></li>
		<li><a href="javascript:search('油库网')">油库网</a></li>
		<li><a href="javascript:search('中国石化网')">中国石化网</a></li>
		<li><a href="javascript:search('中华纸业网')">中华纸业网</a></li>
		<li><a href="javascript:search('中国纸网')">中国纸网</a></li>
		<li><a href="javascript:search('中国环保商务网')">中国环保商务网</a></li>
		<li><a href="javascript:search('中国环保网')">中国环保网</a></li>
		<li><a href="javascript:search('中国生活用纸信息网')">中国生活用纸信息网</a></li>
		<li><a href="javascript:search('中国水网')">中国水网</a></li>
		<li><a href="javascript:search('中华环保设备网')">中华环保设备网</a></li>
		<li><a href="javascript:search('中国卫生用品网')">中国卫生用品网</a></li>
		<li><a href="javascript:search('纸业中国·生活用纸')">纸业中国·生活用纸</a></li>
		<li><a href="javascript:search('中国纸制品供应商')">中国纸制品供应商</a></li>
		<li><a href="javascript:search('第一纸业网')">第一纸业网</a></li>
		<li><a href="javascript:search('中国保洁人网')">中国保洁人网</a></li>
		<li><a href="javascript:search('宜生环保资讯')">宜生环保资讯</a></li>
		<li><a href="javascript:search('易居网')">易居网</a></li>
		<li><a href="javascript:search('中国灯饰商贸网')">中国灯饰商贸网</a></li>
		<li><a href="javascript:search('中国家具网')">中国家具网</a></li>
		<li><a href="javascript:search('安居商城')">安居商城</a></li>
		<li><a href="javascript:search('喜悦家居网')">喜悦家居网</a></li>
		<li><a href="javascript:search('中国寝具网')">中国寝具网</a></li>
		<li><a href="javascript:search('新居网')">新居网</a></li>
		<li><a href="javascript:search('云南橱柜网')">云南橱柜网</a></li>
	</ul>
	<div class="pages">
		<div class="pagination">
			<a href="platform22.php#putongweb">上一页</a>
			<a href="platform24.php#putongweb">下一页</a>
			<a href="platform1.php">第一页</a>
			<a href="platform16.php#putongweb">上5页</a>
			<a href="platform21.php#putongweb">21</a>
			<a href="platform22.php#putongweb">22</a>
			<span class="current">23</span>
			<a href="platform23.php#putongweb"><span id="lastspan">最后一页</span></a>
		</div>
	</div>
</div>
<script>
	function search(val){
		window.open("https://www.baidu.com/s?wd="+val);
	}
</script>
</body>
</html>
