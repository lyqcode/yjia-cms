<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>网站大全</title>
<link rel="stylesheet" href="css/style.css" />
</head>



<body>
<div class=" IncludeBox grWidth">
	<?php include "platform.php";?>
	<ul  class="IncludeContainer clearfix">
		<li><a href="javascript:search('勤加缘网')">勤加缘网</a></li>
		<li><a href="javascript:search('中国供应商')">中国供应商</a></li>
		<li><a href="javascript:search('金泉网')">金泉网</a></li>
		<li><a href="javascript:search('淘金地')">淘金地</a></li>
		<li><a href="javascript:search('云盟在线商机网')">云盟在线商机网</a></li>
		<li><a href="javascript:search('名站在线网')">名站在线网</a></li>
		<li><a href="javascript:search('际通宝')">际通宝</a></li>
		<li><a href="javascript:search('百贸网')">百贸网</a></li>
		<li><a href="javascript:search('中国海商网')">中国海商网</a></li>
		<li><a href="javascript:search('商虎中国')">商虎中国</a></li>
		<li><a href="javascript:search('发一发信息网')">发一发信息网</a></li>
		<li><a href="javascript:search('环球经贸网')">环球经贸网</a></li>
		<li><a href="javascript:search('诺比网')">诺比网</a></li>
		<li><a href="javascript:search('黄页88')">黄页88</a></li>
		<li><a href="javascript:search('国际贸易网')">国际贸易网</a></li>
		<li><a href="javascript:search('中国工业信息网')">中国工业信息网</a></li>
		<li><a href="javascript:search('中国制造网')">中国制造网</a></li>
		<li><a href="javascript:search('八方资源网')">八方资源网</a></li>
		<li><a href="javascript:search('马可波罗')">马可波罗</a></li>
		<li><a href="javascript:search('商国互联网')">商国互联网</a></li>
		<li><a href="javascript:search('51搜了网')">51搜了网</a></li>
		<li><a href="javascript:search('中国114黄页')">中国114黄页</a></li>
		<li><a href="javascript:search('58同城分类网')">58同城分类网</a></li>
		<li><a href="javascript:search('化妆品招商网')">化妆品招商网</a></li>
		<li><a href="javascript:search('国际机械信息网')">国际机械信息网</a></li>
		<li><a href="javascript:search('万国企业网')">万国企业网</a></li>
		<li><a href="javascript:search('余姚生活网')">余姚生活网</a></li>
		<li><a href="javascript:search('智通商务网')">智通商务网</a></li>
		<li><a href="javascript:search('叫卖网')">叫卖网</a></li>
		<li><a href="javascript:search('三帝贸易网')">三帝贸易网</a></li>
		<li><a href="javascript:search('深圳珠宝网')">深圳珠宝网</a></li>
		<li><a href="javascript:search('中国LED网')">中国LED网</a></li>
		<li><a href="javascript:search('中华标准件网')">中华标准件网</a></li>
		<li><a href="javascript:search('中国农业网')">中国农业网</a></li>
		<li><a href="javascript:search('中国建材在线')">中国建材在线</a></li>
		<li><a href="javascript:search('E展网')">E展网</a></li>
		<li><a href="javascript:search('不锈钢天地')">不锈钢天地</a></li>
		<li><a href="javascript:search('切它网')">切它网</a></li>
		<li><a href="javascript:search('孕婴童招商网')">孕婴童招商网</a></li>
		<li><a href="javascript:search('中国茶叶网')">中国茶叶网</a></li>
		<li><a href="javascript:search('中国宗教用品网')">中国宗教用品网</a></li>
		<li><a href="javascript:search('食品产业网')">食品产业网</a></li>
		<li><a href="javascript:search('PVC塑料网')">PVC塑料网</a></li>
		<li><a href="javascript:search('客集齐网')">客集齐网</a></li>
		<li><a href="javascript:search('农搜')">农搜</a></li>
		<li><a href="javascript:search('中国女装网')">中国女装网</a></li>
		<li><a href="javascript:search('食品机械行业网')">食品机械行业网</a></li>
		<li><a href="javascript:search('盈科商务网')">盈科商务网</a></li>
		<li><a href="javascript:search('114城市分类信息网')">114城市分类信息网</a></li>
		<li><a href="javascript:search('全球商务网')">全球商务网</a></li>
		<li><a href="javascript:search('中国水泥网')">中国水泥网</a></li>
		<li><a href="javascript:search('中国好酒招商网')">中国好酒招商网</a></li>
		<li><a href="javascript:search('中国洗涤化妆品网')">中国洗涤化妆品网</a></li>
		<li><a href="javascript:search('中国纺织网')">中国纺织网</a></li>
		<li><a href="javascript:search('中国品牌童装网')">中国品牌童装网</a></li>
		<li><a href="javascript:search('中国项目招标网')">中国项目招标网</a></li>
		<li><a href="javascript:search('中国机械设备网')">中国机械设备网</a></li>
		<li><a href="javascript:search('中国电子市场')">中国电子市场</a></li>
		<li><a href="javascript:search('瑞联网')">瑞联网</a></li>
		<li><a href="javascript:search('百度虫医药商务网')">百度虫医药商务网</a></li>
		<li><a href="javascript:search('贸易谷网')">贸易谷网</a></li>
		<li><a href="javascript:search('会商宝')">会商宝</a></li>
		<li><a href="javascript:search('大禹网')">大禹网</a></li>
		<li><a href="javascript:search('全球金属网')">全球金属网</a></li>
		<li><a href="javascript:search('十环建材网')">十环建材网</a></li>
		<li><a href="javascript:search('宝谷网')">宝谷网</a></li>
		<li><a href="javascript:search('模具联盟')">模具联盟</a></li>
		<li><a href="javascript:search('中国化工企业联盟')">中国化工企业联盟</a></li>
		<li><a href="javascript:search('跨国采购网')">跨国采购网</a></li>
		<li><a href="javascript:search('全球机械网')">全球机械网</a></li>
		<li><a href="javascript:search('雷州壹网')">雷州壹网</a></li>
		<li><a href="javascript:search('装饰e站通')">装饰e站通</a></li>
		<li><a href="javascript:search('中国企业库')">中国企业库</a></li>
		<li><a href="javascript:search('慧聚中国')">慧聚中国</a></li>
		<li><a href="javascript:search('商牛网')">商牛网</a></li>
		<li><a href="javascript:search('大拇指商务网')">大拇指商务网</a></li>
		<li><a href="javascript:search('中国蔬菜网')">中国蔬菜网</a></li>
		<li><a href="javascript:search('易登网')">易登网</a></li>
		<li><a href="javascript:search('中国摩托车网')">中国摩托车网</a></li>
		<li><a href="javascript:search('E都市')">E都市</a></li>
		<li><a href="javascript:search('久久信息网')">久久信息网</a></li>
		<li><a href="javascript:search('中国采购与招标网')">中国采购与招标网</a></li>
		<li><a href="javascript:search('中国机械网')">中国机械网</a></li>
		<li><a href="javascript:search('中国设备网')">中国设备网</a></li>
		<li><a href="javascript:search('行业中国网')">行业中国网</a></li>
		<li><a href="javascript:search('电子展览网')">电子展览网</a></li>
		<li><a href="javascript:search('金蜘蛛轴承网')">金蜘蛛轴承网</a></li>
		<li><a href="javascript:search('河北制冷网')">河北制冷网</a></li>
		<li><a href="javascript:search('中华纺织网')">中华纺织网</a></li>
		<li><a href="javascript:search('维库仪器仪表网')">维库仪器仪表网</a></li>
		<li><a href="javascript:search('1688批发网')">1688批发网</a></li>
		<li><a href="javascript:search('二手摩托交易网')">二手摩托交易网</a></li>
		<li><a href="javascript:search('财宝地')">财宝地</a></li>
		<li><a href="javascript:search('生意宝')">生意宝</a></li>
		<li><a href="javascript:search('东商网')">东商网</a></li>
		<li><a href="javascript:search('播视网')">播视网</a></li>
		<li><a href="javascript:search('中华工具网')">中华工具网</a></li>
		<li><a href="javascript:search('中国路面机械网')">中国路面机械网</a></li>
		<li><a href="javascript:search('华源医药网')">华源医药网</a></li>
		<li><a href="javascript:search('中国药材市场')">中国药材市场</a></li>
		<li><a href="javascript:search('白山在线')">白山在线</a></li>
		<li><a href="javascript:search('中国压铸网')">中国压铸网</a></li>
		<li><a href="javascript:search('KVOV信息发布网')">KVOV信息发布网</a></li>
		<li><a href="javascript:search('华强电子世界网')">华强电子世界网</a></li>
		<li><a href="javascript:search('西夏网')">西夏网</a></li>
		<li><a href="javascript:search('网商在线')">网商在线</a></li>
		<li><a href="javascript:search('分类岛')">分类岛</a></li>
		<li><a href="javascript:search('中国丽人网')">中国丽人网</a></li>
		<li><a href="javascript:search('中国诚信网')">中国诚信网</a></li>
		<li><a href="javascript:search('东方包装网')">东方包装网</a></li>
		<li><a href="javascript:search('地纬商机网')">地纬商机网</a></li>
		<li><a href="javascript:search('中国化工制造网')">中国化工制造网</a></li>
		<li><a href="javascript:search('全球知名网')">全球知名网</a></li>
		<li><a href="javascript:search('一比多')">一比多</a></li>
		<li><a href="javascript:search('中国装修第一网')">中国装修第一网</a></li>
		<li><a href="javascript:search('中国材料网')">中国材料网</a></li>
		<li><a href="javascript:search('慧赢网')">慧赢网</a></li>
		<li><a href="javascript:search('中国服装网')">中国服装网</a></li>
		<li><a href="javascript:search('网商之窗')">网商之窗</a></li>
		<li><a href="javascript:search('中国二手设备网')">中国二手设备网</a></li>
	</ul>
	<div class="pages">
		<div class="pagination">
			<a href="platform2.php#putongweb">下一页</a><span class="current">1</span><a href="platform2.php#putongweb">2</a><a href="platform3.php#putongweb">3</a><a href="platform4.php#putongweb">4</a><a href="platform5.php#putongweb">5</a><a href="platform6.php#putongweb">下5页</a><a href="platform23.php#putongweb"><span id="lastspan">最后一页</span></a>
		</div>
	</div>
</div>

<script>
	function search(val){
		window.open("https://www.baidu.com/s?wd="+val);
	}
</script>
</body>
</html>
