<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>网站大全</title>
<link rel="stylesheet" href="css/style.css" />
</head>



<body>
<div class=" IncludeBox grWidth">
	<?php include "platform.php";?>
	<ul class="IncludeContainer clearfix">
		<li><a href="javascript:search('中国灯网')">中国灯网</a></li>
		<li><a href="javascript:search('大陶瓷·中国')">大陶瓷·中国</a></li>
		<li><a href="javascript:search('中国食品商务网')">中国食品商务网</a></li>
		<li><a href="javascript:search('中国玻璃信息网')">中国玻璃信息网</a></li>
		<li><a href="javascript:search('数字水泥网')">数字水泥网</a></li>
		<li><a href="javascript:search('我的钢铁网')">我的钢铁网</a></li>
		<li><a href="javascript:search('中国装饰材料网')">中国装饰材料网</a></li>
		<li><a href="javascript:search('中国爱车在线')">中国爱车在线</a></li>
		<li><a href="javascript:search('全球铁艺网')">全球铁艺网</a></li>
		<li><a href="javascript:search('中国搜丝网')">中国搜丝网</a></li>
		<li><a href="javascript:search('中国滤材网')">中国滤材网</a></li>
		<li><a href="javascript:search('华夏建材网')">华夏建材网</a></li>
		<li><a href="javascript:search('中国公路运输网')">中国公路运输网</a></li>
		<li><a href="javascript:search('浙江电动车网')">浙江电动车网</a></li>
		<li><a href="javascript:search('建筑新时代')">建筑新时代</a></li>
		<li><a href="javascript:search('中国浮石网')">中国浮石网</a></li>
		<li><a href="javascript:search('华夏汽车网')">华夏汽车网</a></li>
		<li><a href="javascript:search('加固改造网')">加固改造网</a></li>
		<li><a href="javascript:search('中国汽车用品网')">中国汽车用品网</a></li>
		<li><a href="javascript:search('进口食品网')">进口食品网</a></li>
		<li><a href="javascript:search('中国建材供求网')">中国建材供求网</a></li>
		<li><a href="javascript:search('糖酒快讯')">糖酒快讯</a></li>
		<li><a href="javascript:search('青岛汽车网')">青岛汽车网</a></li>
		<li><a href="javascript:search('中国钢管网')">中国钢管网</a></li>
		<li><a href="javascript:search('网上车市')">网上车市</a></li>
		<li><a href="javascript:search('都市汽车网')">都市汽车网</a></li>
		<li><a href="javascript:search('PVC管信息网')">PVC管信息网</a></li>
		<li><a href="javascript:search('中国汽车电子网')">中国汽车电子网</a></li>
		<li><a href="javascript:search('中国苗木花卉网')">中国苗木花卉网</a></li>
		<li><a href="javascript:search('中国食品交易网')">中国食品交易网</a></li>
		<li><a href="javascript:search('中国汽车内饰网')">中国汽车内饰网</a></li>
		<li><a href="javascript:search('中国酒品牌网')">中国酒品牌网</a></li>
		<li><a href="javascript:search('食用油招商网')">食用油招商网</a></li>
		<li><a href="javascript:search('农博网')">农博网</a></li>
		<li><a href="javascript:search('中国二手摩托车网')">中国二手摩托车网</a></li>
		<li><a href="javascript:search('中国蜂业网')">中国蜂业网</a></li>
		<li><a href="javascript:search('中国二手电动车网')">中国二手电动车网</a></li>
		<li><a href="javascript:search('中国电瓶车网')">中国电瓶车网</a></li>
		<li><a href="javascript:search('商用车网')">商用车网</a></li>
		<li><a href="javascript:search('中国园林网')">中国园林网</a></li>
		<li><a href="javascript:search('壹食品中国网')">壹食品中国网</a></li>
		<li><a href="javascript:search('木本植物产业网')">木本植物产业网</a></li>
		<li><a href="javascript:search('中国蔬菜网')">中国蔬菜网</a></li>
		<li><a href="javascript:search('齐鲁车市')">齐鲁车市</a></li>
		<li><a href="javascript:search('中国牧业网')">中国牧业网</a></li>
		<li><a href="javascript:search('中华装饰画网')">中华装饰画网</a></li>
		<li><a href="javascript:search('金农网')">金农网</a></li>
		<li><a href="javascript:search('中国水果网')">中国水果网</a></li>
		<li><a href="javascript:search('中国饰品展览网')">中国饰品展览网</a></li>
		<li><a href="javascript:search('中华粮网')">中华粮网</a></li>
		<li><a href="javascript:search('中国珍珠展览网')">中国珍珠展览网</a></li>
		<li><a href="javascript:search('中国农药信息网')">中国农药信息网</a></li>
		<li><a href="javascript:search('中国礼品展览网')">中国礼品展览网</a></li>
		<li><a href="javascript:search('金光农业网')">金光农业网</a></li>
		<li><a href="javascript:search('温州眼镜网')">温州眼镜网</a></li>
		<li><a href="javascript:search('中国木业信息网')">中国木业信息网</a></li>
		<li><a href="javascript:search('种子中国')">种子中国</a></li>
		<li><a href="javascript:search('中国工艺品商贸网')">中国工艺品商贸网</a></li>
		<li><a href="javascript:search('中国食品展会网')">中国食品展会网</a></li>
		<li><a href="javascript:search('中国钟表网')">中国钟表网</a></li>
		<li><a href="javascript:search('中国蔬菜信息网')">中国蔬菜信息网</a></li>
		<li><a href="javascript:search('21世纪珠宝网')">21世纪珠宝网</a></li>
		<li><a href="javascript:search('中国黄金珠宝网')">中国黄金珠宝网</a></li>
		<li><a href="javascript:search('中渔网')">中渔网</a></li>
		<li><a href="javascript:search('深圳珠宝网')">深圳珠宝网</a></li>
		<li><a href="javascript:search('中国工艺网')">中国工艺网</a></li>
		<li><a href="javascript:search('中华干果信息网')">中华干果信息网</a></li>
		<li><a href="javascript:search('中国工艺品企业网')">中国工艺品企业网</a></li>
		<li><a href="javascript:search('中国水稻网')">中国水稻网</a></li>
		<li><a href="javascript:search('华夏收藏网')">华夏收藏网</a></li>
		<li><a href="javascript:search('中国马铃薯种薯网')">中国马铃薯种薯网</a></li>
		<li><a href="javascript:search('我要工艺品网')">我要工艺品网</a></li>
		<li><a href="javascript:search('中国养殖信息网')">中国养殖信息网</a></li>
		<li><a href="javascript:search('中国艺术珍品网')">中国艺术珍品网</a></li>
		<li><a href="javascript:search('花木交易网')">花木交易网</a></li>
		<li><a href="javascript:search('亚商在线')">亚商在线</a></li>
		<li><a href="javascript:search('中国家禽网')">中国家禽网</a></li>
		<li><a href="javascript:search('中国菜籽信息网')">中国菜籽信息网</a></li>
		<li><a href="javascript:search('批发区')">批发区</a></li>
		<li><a href="javascript:search('中华笔网')">中华笔网</a></li>
		<li><a href="javascript:search('无忧耗材网')">无忧耗材网</a></li>
		<li><a href="javascript:search('中国休闲用品网')">中国休闲用品网</a></li>
		<li><a href="javascript:search('中国芝麻网')">中国芝麻网</a></li>
		<li><a href="javascript:search('中华文具网')">中华文具网</a></li>
		<li><a href="javascript:search('体育资源网')">体育资源网</a></li>
		<li><a href="javascript:search('中国羊网')">中国羊网</a></li>
		<li><a href="javascript:search('中国耗材网')">中国耗材网</a></li>
		<li><a href="javascript:search('中国牛羊信息网')">中国牛羊信息网</a></li>
		<li><a href="javascript:search('中华笔业网')">中华笔业网</a></li>
		<li><a href="javascript:search('牌品无忧服装网')">牌品无忧服装网</a></li>
		<li><a href="javascript:search('中华衣服网')">中华衣服网</a></li>
		<li><a href="javascript:search('青岛商务采购网')">青岛商务采购网</a></li>
		<li><a href="javascript:search('国际服装设计网')">国际服装设计网</a></li>
		<li><a href="javascript:search('丝路网')">丝路网</a></li>
		<li><a href="javascript:search('办公耗材商务网')">办公耗材商务网</a></li>
		<li><a href="javascript:search('中国花样分色网')">中国花样分色网</a></li>
		<li><a href="javascript:search('中华服装网')">中华服装网</a></li>
		<li><a href="javascript:search('中国帽业网')">中国帽业网</a></li>
		<li><a href="javascript:search('中国服装企业网')">中国服装企业网</a></li>
		<li><a href="javascript:search('服装网')">服装网</a></li>
		<li><a href="javascript:search('大连服装网')">大连服装网</a></li>
		<li><a href="javascript:search('厦门玩具网')">厦门玩具网</a></li>
		<li><a href="javascript:search('中国童装网')">中国童装网</a></li>
		<li><a href="javascript:search('我爱礼品网')">我爱礼品网</a></li>
		<li><a href="javascript:search('中国国际礼品玩具网')">中国国际礼品玩具网</a></li>
		<li><a href="javascript:search('中国服装款式网')">中国服装款式网</a></li>
		<li><a href="javascript:search('华夏内衣网')">华夏内衣网</a></li>
		<li><a href="javascript:search('3C在线IT传播平台')">3C在线IT传播平台</a></li>
		<li><a href="javascript:search('衣服网')">衣服网</a></li>
		<li><a href="javascript:search('太平洋电脑网')">太平洋电脑网</a></li>
		<li><a href="javascript:search('中国服饰网')">中国服饰网</a></li>
		<li><a href="javascript:search('蓝狐狸电脑城')">蓝狐狸电脑城</a></li>
		<li><a href="javascript:search('环球鞋网')">环球鞋网</a></li>
		<li><a href="javascript:search('中国PC电脑在线网')">中国PC电脑在线网</a></li>
		<li><a href="javascript:search('国际童装网')">国际童装网</a></li>
		<li><a href="javascript:search('中国服装进货网')">中国服装进货网</a></li>
		<li><a href="javascript:search('中国鞋都网')">中国鞋都网</a></li>
		<li><a href="javascript:search('中国制衣网')">中国制衣网</a></li>
		<li><a href="javascript:search('中国服装时尚网')">中国服装时尚网</a></li>
		<li><a href="javascript:search('全球服装网')">全球服装网</a></li>
	</ul>
	<div class="pages">
		<div class="pagination">
			<a href="platform21.php#putongweb">上一页</a>
			<a href="platform23.php#putongweb">下一页</a>
			<a href="platform1.php">第一页</a>
			<a href="platform16.php#putongweb">上5页</a>
			<a href="platform21.php#putongweb">21</a>
			<span class="current">22</span>
			<a href="platform23.php#putongweb">23</a>
			<a href="platform23.php#putongweb"><span id="lastspan">最后一页</span></a>
		</div>
	</div>
</div>
<script>
	function search(val){
		window.open("https://www.baidu.com/s?wd="+val);
	}
</script>
</body>
</html>
