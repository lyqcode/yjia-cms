<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>网站大全</title>
<link rel="stylesheet" href="css/style.css" />
</head>

<body>
<div class=" IncludeBox grWidth">
	<?php include "platform.php";?>
	<ul class="IncludeContainer clearfix">
		<li><a href="javascript:search('阿德采购网')">阿德采购网</a></li>
		<li><a href="javascript:search('邯郸信息网')">邯郸信息网</a></li>
		<li><a href="javascript:search('诸暨在线')">诸暨在线</a></li>
		<li><a href="javascript:search('U88加盟网')">U88加盟网</a></li>
		<li><a href="javascript:search('融资租赁网')">融资租赁网</a></li>
		<li><a href="javascript:search('贸商网')">贸商网</a></li>
		<li><a href="javascript:search('商路通')">商路通</a></li>
		<li><a href="javascript:search('商家汇')">商家汇</a></li>
		<li><a href="javascript:search('一路发发')">一路发发</a></li>
		<li><a href="javascript:search('顺联网')">顺联网</a></li>
		<li><a href="javascript:search('展商网')">展商网</a></li>
		<li><a href="javascript:search('全球二手网')">全球二手网</a></li>
		<li><a href="javascript:search('中国家具网')">中国家具网</a></li>
		<li><a href="javascript:search('展企网')">展企网</a></li>
		<li><a href="javascript:search('大章丘')">大章丘</a></li>
		<li><a href="javascript:search('亚欧网')">亚欧网</a></li>
		<li><a href="javascript:search('E木业网')">E木业网</a></li>
		<li><a href="javascript:search('萍乡城事网')">萍乡城事网</a></li>
		<li><a href="javascript:search('中华粮网')">中华粮网</a></li>
		<li><a href="javascript:search('中国吃网')">中国吃网</a></li>
		<li><a href="javascript:search('商务圈')">商务圈</a></li>
		<li><a href="javascript:search('聚商5158')">聚商5158</a></li>
		<li><a href="javascript:search('天罗地网')">天罗地网</a></li>
		<li><a href="javascript:search('通辽信息网')">通辽信息网</a></li>
		<li><a href="javascript:search('艾特贸易网')">艾特贸易网</a></li>
		<li><a href="javascript:search('云南商机网')">云南商机网</a></li>
		<li><a href="javascript:search('植物网')">植物网</a></li>
		<li><a href="javascript:search('百联网')">百联网</a></li>
		<li><a href="javascript:search('万有引力商贸网')">万有引力商贸网</a></li>
		<li><a href="javascript:search('企业搜')">企业搜</a></li>
		<li><a href="javascript:search('商机链')">商机链</a></li>
		<li><a href="javascript:search('07商务网')">07商务网</a></li>
		<li><a href="javascript:search('福州便民网')">福州便民网</a></li>
		<li><a href="javascript:search('唠叨网')">唠叨网</a></li>
		<li><a href="javascript:search('中国搜丝网')">中国搜丝网</a></li>
		<li><a href="javascript:search('中国万业网')">中国万业网</a></li>
		<li><a href="javascript:search('榕粮网')">榕粮网</a></li>
		<li><a href="javascript:search('易鑫商务')">易鑫商务</a></li>
		<li><a href="javascript:search('全球节能环保网')">全球节能环保网</a></li>
		<li><a href="javascript:search('花木商情网')">花木商情网</a></li>
		<li><a href="javascript:search('中国特种设备采购网')">中国特种设备采购网</a></li>
		<li><a href="javascript:search('深圳热线')">深圳热线</a></li>
		<li><a href="javascript:search('中国万维化工城')">中国万维化工城</a></li>
		<li><a href="javascript:search('浙江机械信息网')">浙江机械信息网</a></li>
		<li><a href="javascript:search('中国安防采购网')">中国安防采购网</a></li>
		<li><a href="javascript:search('企业供求网')">企业供求网</a></li>
		<li><a href="javascript:search('富民服装网')">富民服装网</a></li>
		<li><a href="javascript:search('中国轴承行业网')">中国轴承行业网</a></li>
		<li><a href="javascript:search('100招商网')">100招商网</a></li>
		<li><a href="javascript:search('通宝网')">通宝网</a></li>
		<li><a href="javascript:search('中国黄页大全')">中国黄页大全</a></li>
		<li><a href="javascript:search('乐备网')">乐备网</a></li>
		<li><a href="javascript:search('中国汽配网')">中国汽配网</a></li>
		<li><a href="javascript:search('OFweek商贸网')">OFweek商贸网</a></li>
		<li><a href="javascript:search('华夏商务网')">华夏商务网</a></li>
		<li><a href="javascript:search('意思商务网')">意思商务网</a></li>
		<li><a href="javascript:search('百方网')">百方网</a></li>
		<li><a href="javascript:search('企贸网')">企贸网</a></li>
		<li><a href="javascript:search('中国库存服装信息网')">中国库存服装信息网</a></li>
		<li><a href="javascript:search('更富网')">更富网</a></li>
		<li><a href="javascript:search('自助贸易')">自助贸易</a></li>
		<li><a href="javascript:search('ecvv商务服务网')">ecvv商务服务网</a></li>
		<li><a href="javascript:search('易维企业服务')">易维企业服务</a></li>
		<li><a href="javascript:search('倚天商务信息网')">倚天商务信息网</a></li>
		<li><a href="javascript:search('制药机械网')">制药机械网</a></li>
		<li><a href="javascript:search('中国招标信息网')">中国招标信息网</a></li>
		<li><a href="javascript:search('阿里巴巴')">阿里巴巴</a></li>
		<li><a href="javascript:search('百业网')">百业网</a></li>
		<li><a href="javascript:search('国际铸业咨询网')">国际铸业咨询网</a></li>
		<li><a href="javascript:search('中国管道商务网')">中国管道商务网</a></li>
		<li><a href="javascript:search('蒜皮网')">蒜皮网</a></li>
		<li><a href="javascript:search('翔云商务网')">翔云商务网</a></li>
		<li><a href="javascript:search('中华企业录')">中华企业录</a></li>
		<li><a href="javascript:search('企业一站通')">企业一站通</a></li>
		<li><a href="javascript:search('e炉360网')">e炉360网</a></li>
		<li><a href="javascript:search('山东兴农网')">山东兴农网</a></li>
		<li><a href="javascript:search('中国塑料包装网')">中国塑料包装网</a></li>
		<li><a href="javascript:search('阿福中国')">阿福中国</a></li>
		<li><a href="javascript:search('恩施装饰网')">恩施装饰网</a></li>
		<li><a href="javascript:search('中国粮油网')">中国粮油网</a></li>
		<li><a href="javascript:search('中国暖通制冷网')">中国暖通制冷网</a></li>
		<li><a href="javascript:search('四川密封件网')">四川密封件网</a></li>
		<li><a href="javascript:search('万商汇网')">万商汇网</a></li>
		<li><a href="javascript:search('中国融资网')">中国融资网</a></li>
		<li><a href="javascript:search('山盟网')">山盟网</a></li>
		<li><a href="javascript:search('长春163')">长春163</a></li>
		<li><a href="javascript:search('百信网')">百信网</a></li>
		<li><a href="javascript:search('中华生意网')">中华生意网</a></li>
		<li><a href="javascript:search('中国油缸网')">中国油缸网</a></li>
		<li><a href="javascript:search('东北饲料信息')">东北饲料信息(求)</a></li>
		<li><a href="javascript:search('慧商网')">慧商网</a></li>
		<li><a href="javascript:search('中国闽东企业信息网')">中国闽东企业信息网</a></li>
		<li><a href="javascript:search('领衔商业网')">领衔商业网</a></li>
		<li><a href="javascript:search('中国工程机械商贸网')">中国工程机械商贸网</a></li>
		<li><a href="javascript:search('中国印刷网')">中国印刷网</a></li>
		<li><a href="javascript:search('汽车零配件网')">汽车零配件网</a></li>
		<li><a href="javascript:search('中国小商品城')">中国小商品城</a></li>
		<li><a href="javascript:search('天地宝商务网')">天地宝商务网</a></li>
		<li><a href="javascript:search('中国化妆品网')">中国化妆品网</a></li>
		<li><a href="javascript:search('铸造行业信息网')">铸造行业信息网</a></li>
		<li><a href="javascript:search('中国酚醛树脂网')">中国酚醛树脂网</a></li>
		<li><a href="javascript:search('奇搜网')">奇搜网</a></li>
		<li><a href="javascript:search('机床买卖网')">机床买卖网</a></li>
		<li><a href="javascript:search('中国之光网')">中国之光网</a></li>
		<li><a href="javascript:search('金名商务网')">金名商务网</a></li>
		<li><a href="javascript:search('河北五金网')">河北五金网</a></li>
		<li><a href="javascript:search('中国青蛙网')">中国青蛙网</a></li>
		<li><a href="javascript:search('爱泵阀网')">爱泵阀网</a></li>
		<li><a href="javascript:search('十堰装饰网')">十堰装饰网</a></li>
		<li><a href="javascript:search('企业发布网')">企业发布网</a></li>
		<li><a href="javascript:search('万嘴酒企业网')">万嘴酒企业网</a></li>
		<li><a href="javascript:search('116114商机网')">116114商机网</a></li>
		<li><a href="javascript:search('云南农业信息网')">云南农业信息网</a></li>
		<li><a href="javascript:search('化工中国网')">化工中国网</a></li>
		<li><a href="javascript:search('中国压缩机网')">中国压缩机网</a></li>
		<li><a href="javascript:search('中华商贸网')">中华商贸网</a></li>
		<li><a href="javascript:search('中国大米企业网')">中国大米企业网</a></li>
		<li><a href="javascript:search('中国软件网')">中国软件网</a></li>
		<li><a href="javascript:search('全球黄页网')">全球黄页网</a></li>
		<li><a href="javascript:search('山西煤焦网')">山西煤焦网</a></li>
	</ul>
	<div class="pages">
		<div class="pagination">
			<a href="platform1.php">上一页</a>
			<a href="platform3.php#putongweb">下一页</a>
			<a href="platform1.php">1</a>
			<span class="current">2</span>
			<a href="platform3.php#putongweb">3</a>
			<a href="platform4.php#putongweb">4</a>
			<a href="platform5.php#putongweb">5</a>
			<a href="platform6.php#putongweb">下5页</a>
			<a href="platform23.php#putongweb"><span id="lastspan">最后一页</span></a>
		</div>
	</div>
</div>
<script>
	function search(val){
		window.open("https://www.baidu.com/s?wd="+val);
	}
</script>
</body>
</html>
