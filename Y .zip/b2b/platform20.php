<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>网站大全</title>
<link rel="stylesheet" href="css/style.css" />
</head>

<body>
<div class=" IncludeBox grWidth">
	<?php include "platform.php";?>
	<ul  class="IncludeContainer clearfix">
		<li><a href="javascript:search('指甲刀');">指甲刀</a></li>
		<li><a href="javascript:search('中国夹克衫');">中国夹克衫</a></li>
		<li><a href="javascript:search('冰淇淋冷饮');">冰淇淋冷饮</a></li>
		<li><a href="javascript:search('搏饼月饼网');">搏饼月饼网</a></li>
		<li><a href="javascript:search('中国药业网');">中国药业网</a></li>
		<li><a href="javascript:search('中国棉纺网');">中国棉纺网</a></li>
		<li><a href="javascript:search('中国衬衣网');">中国衬衣网</a></li>
		<li><a href="javascript:search('中国婚展网');">中国婚展网</a></li>
		<li><a href="javascript:search('中国美展');">中国美展</a></li>
		<li><a href="javascript:search('华夏美厨网');">华夏美厨网</a></li>
		<li><a href="javascript:search('中国补品网');">中国补品网</a></li>
		<li><a href="javascript:search('中国废铁网');">中国废铁网</a></li>
		<li><a href="javascript:search('馋嘴餐饮网');">馋嘴餐饮网</a></li>
		<li><a href="javascript:search('沐浴露');">沐浴露</a></li>
		<li><a href="javascript:search('中国电琴网');">中国电琴网</a></li>
		<li><a href="javascript:search('包装机械');">包装机械</a></li>
		<li><a href="javascript:search('中国药具网');">中国药具网</a></li>
		<li><a href="javascript:search('丝竹乐器网');">丝竹乐器网</a></li>
		<li><a href="javascript:search('中国染业网');">中国染业网</a></li>
		<li><a href="javascript:search('中国工模网');">中国工模网</a></li>
		<li><a href="javascript:search('中国烘培网');">中国烘培网</a></li>
		<li><a href="javascript:search('中国家博会网');">中国家博会网</a></li>
		<li><a href="javascript:search('喜来登酒店用品网');">喜来登酒店用品网</a></li>
		<li><a href="javascript:search('中国篮球用品网');">中国篮球用品网</a></li>
		<li><a href="javascript:search('中国农艺网');">中国农艺网</a></li>
		<li><a href="javascript:search('买卖麦网');">买卖麦网</a></li>
		<li><a href="javascript:search('无忧交易');">无忧交易</a></li>
		<li><a href="javascript:search('中欧在线');">中欧在线</a></li>
		<li><a href="javascript:search('环球商务网');">环球商务网</a></li>
		<li><a href="javascript:search('品牌伙伴网');">品牌伙伴网</a></li>
		<li><a href="javascript:search('首商网');">首商网</a></li>
		<li><a href="javascript:search('考要供求信息网');">考要供求信息网</a></li>
		<li><a href="javascript:search('企业平台网');">企业平台网</a></li>
		<li><a href="javascript:search('世界电子商务网');">世界电子商务网</a></li>
		<li><a href="javascript:search('商情平台网');">商情平台网</a></li>
		<li><a href="javascript:search('啊里吧吧');">啊里吧吧</a></li>
		<li><a href="javascript:search('商机平台网');">商机平台网</a></li>
		<li><a href="javascript:search('惠聪网');">惠聪网</a></li>
		<li><a href="javascript:search('中国产品平台');">中国产品平台</a></li>
		<li><a href="javascript:search('中国新经济信息网');">中国新经济信息网</a></li>
		<li><a href="javascript:search('中国交易平台网');">中国交易平台网</a></li>
		<li><a href="javascript:search('黄页大全');">黄页大全</a></li>
		<li><a href="javascript:search('买卖平台中心');">买卖平台中心</a></li>
		<li><a href="javascript:search('中国贸易平台');">中国贸易平台</a></li>
		<li><a href="javascript:search('美容加盟网');">美容加盟网</a></li>
		<li><a href="javascript:search('箱包加盟连锁网');">箱包加盟连锁网</a></li>
		<li><a href="javascript:search('中国商贸网');">中国商贸网</a></li>
		<li><a href="javascript:search('商机360');">商机360</a></li>
		<li><a href="javascript:search('中国原料平台');">中国原料平台</a></li>
		<li><a href="javascript:search('现代橡胶网');">现代橡胶网</a></li>
		<li><a href="javascript:search('加工平台');">加工平台</a></li>
		<li><a href="javascript:search('中国吸塑网');">中国吸塑网</a></li>
		<li><a href="javascript:search('长城化工网');">长城化工网</a></li>
		<li><a href="javascript:search('代理平台网');">代理平台网</a></li>
		<li><a href="javascript:search('华北化工网');">华北化工网</a></li>
		<li><a href="javascript:search('中国泡沫材料网');">中国泡沫材料网</a></li>
		<li><a href="javascript:search('中国生意网');">中国生意网</a></li>
		<li><a href="javascript:search('中国美妆招商网');">中国美妆招商网</a></li>
		<li><a href="javascript:search('中国纺织化工网');">中国纺织化工网</a></li>
		<li><a href="javascript:search('箱包袋市场');">箱包袋市场</a></li>
		<li><a href="javascript:search('中国服装皮革机械网');">中国服装皮革机械网</a></li>
		<li><a href="javascript:search('中国材料网');">中国材料网</a></li>
		<li><a href="javascript:search('中国纺织网');">中国纺织网</a></li>
		<li><a href="javascript:search('全球纺织网');">全球纺织网</a></li>
		<li><a href="javascript:search('中华纺织网');">中华纺织网</a></li>
		<li><a href="javascript:search('供求总目录网');">供求总目录网</a></li>
		<li><a href="javascript:search('中国棉花信息网');">中国棉花信息网</a></li>
		<li><a href="javascript:search('中国化纤信息网');">中国化纤信息网</a></li>
		<li><a href="javascript:search('供应商在线');">供应商在线</a></li>
		<li><a href="javascript:search('中国纺织经济信息网');">中国纺织经济信息网</a></li>
		<li><a href="javascript:search('中国无忧商务网');">中国无忧商务网</a></li>
		<li><a href="javascript:search('中国纺织采购网');">中国纺织采购网</a></li>
		<li><a href="javascript:search('中国印染网');">中国印染网</a></li>
		<li><a href="javascript:search('中国绸都网');">中国绸都网</a></li>
		<li><a href="javascript:search('中国毛针织网');">中国毛针织网</a></li>
		<li><a href="javascript:search('中国经贸网');">中国经贸网</a></li>
		<li><a href="javascript:search('中国纺织助剂网');">中国纺织助剂网</a></li>
		<li><a href="javascript:search('中国物资采购网');">中国物资采购网</a></li>
		<li><a href="javascript:search('企业商盟网');">企业商盟网</a></li>
		<li><a href="javascript:search('中国包装交易网');">中国包装交易网</a></li>
		<li><a href="javascript:search('中国印刷包装市场');">中国印刷包装市场</a></li>
		<li><a href="javascript:search('Foreign');">Foreign Trade</a></li>
		<li><a href="javascript:search('中国包装网');">中国包装网</a></li>
		<li><a href="javascript:search('中华时装网');">中华时装网</a></li>
		<li><a href="javascript:search('大中华印艺网');">大中华印艺网</a></li>
		<li><a href="javascript:search('中国印刷市场');">中国印刷市场</a></li>
		<li><a href="javascript:search('中国开门网');">中国开门网</a></li>
		<li><a href="javascript:search('中国优秀企业网');">中国优秀企业网</a></li>
		<li><a href="javascript:search('国际企业网');">国际企业网</a></li>
		<li><a href="javascript:search('世贸贸易网');">世贸贸易网</a></li>
		<li><a href="javascript:search('中国防伪标签网');">中国防伪标签网</a></li>
		<li><a href="javascript:search('中国商标交易网');">中国商标交易网</a></li>
		<li><a href="javascript:search('批发中国');">批发中国</a></li>
		<li><a href="javascript:search('中国印包市场');">中国印包市场</a></li>
		<li><a href="javascript:search('ECVV·中国站');">ECVV·中国站</a></li>
		<li><a href="javascript:search('中国丝印器材网');">中国丝印器材网</a></li>
		<li><a href="javascript:search('万国商业网');">万国商业网</a></li>
		<li><a href="javascript:search('中华机械网');">中华机械网</a></li>
		<li><a href="javascript:search('全球五金网');">全球五金网</a></li>
		<li><a href="javascript:search('河南纺织机械器材网');">河南纺织机械器材网</a></li>
		<li><a href="javascript:search('中国五金网');">中国五金网</a></li>
		<li><a href="javascript:search('八方资源网');">八方资源网</a></li>
		<li><a href="javascript:search('中国塑料机械商务');">中国塑料机械商务</a></li>
		<li><a href="javascript:search('中国机械网');">中国机械网</a></li>
		<li><a href="javascript:search('中国过滤网');">中国过滤网</a></li>
		<li><a href="javascript:search('中国海商网');">中国海商网</a></li>
		<li><a href="javascript:search('中国电机网');">中国电机网</a></li>
		<li><a href="javascript:search('中国农业机械化信息网');">中国农业机械化信息网</a></li>
		<li><a href="javascript:search('中国食品制药设备网');">中国食品制药设备网</a></li>
		<li><a href="javascript:search('金贸铸造网');">金贸铸造网</a></li>
		<li><a href="javascript:search('中国制砖机网');">中国制砖机网</a></li>
		<li><a href="javascript:search('环球轴承网');">环球轴承网</a></li>
		<li><a href="javascript:search('中国塑料模具网');">中国塑料模具网</a></li>
		<li><a href="javascript:search('商品资源网');">商品资源网</a></li>
		<li><a href="javascript:search('今日五金网');">今日五金网</a></li>
		<li><a href="javascript:search('我要仪器网');">我要仪器网</a></li>
		<li><a href="javascript:search('华人螺丝网');">华人螺丝网</a></li>
		<li><a href="javascript:search('易网贸易');">易网贸易</a></li>
		<li><a href="javascript:search('中国泵阀网');">中国泵阀网</a></li>
		<li><a href="javascript:search('中华纺机网');">中华纺机网</a></li>
	</ul>
	<div class="pages">
		<div class="pagination">
			<a href="platform19.php#putongweb">上一页</a>
			<a href="platform21.php#putongweb">下一页</a>
			<a href="platform1.php">第一页</a>
			<a href="platform11.php#putongweb">上5页</a>
			<a href="platform16.php#putongweb">16</a>
			<a href="platform17.php#putongweb">17</a>
			<a href="platform18.php#putongweb">18</a>
			<a href="platform19.php#putongweb">19</a>
			<span class="current">20</span>
			<a href="platform21.php#putongweb">下5页</a>
			<a href="platform23.php#putongweb"><span id="lastspan">最后一页</span></a>
		</div>
	</div>
</div>

<script>
	function search(val){
		window.open("https://www.baidu.com/s?wd="+val);
	}
</script>
</body>
</html>
