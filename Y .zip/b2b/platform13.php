<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>网站大全</title>
<link rel="stylesheet" href="css/style.css" />
</head>



<body>
<div class=" IncludeBox grWidth">
	<?php include "platform.php";?>
	<ul  class="IncludeContainer clearfix">
		<li><a href="javascript:search('中国管件网')">中国管件网</a></li>
		<li><a href="javascript:search('广东包装信息网')">广东包装信息网</a></li>
		<li><a href="javascript:search('中国铝材网')">中国铝材网</a></li>
		<li><a href="javascript:search('中国皮革护理网')">中国皮革护理网</a></li>
		<li><a href="javascript:search('中国交易网')">中国交易网</a></li>
		<li><a href="javascript:search('宁波二手车网')">宁波二手车网</a></li>
		<li><a href="javascript:search('中塑网')">中塑网</a></li>
		<li><a href="javascript:search('无忧企业通')">无忧企业通</a></li>
		<li><a href="javascript:search('中国铸造')">中国铸造</a></li>
		<li><a href="javascript:search('医护服饰网')">医护服饰网</a></li>
		<li><a href="javascript:search('中国磁都网')">中国磁都网</a></li>
		<li><a href="javascript:search('中华铜业网')">中华铜业网</a></li>
		<li><a href="javascript:search('选软件网')">选软件网</a></li>
		<li><a href="javascript:search('b2b免费商务平台')">b2b免费商务平台</a></li>
		<li><a href="javascript:search('改锥网')">改锥网</a></li>
		<li><a href="javascript:search('8688信息网')">8688信息网</a></li>
		<li><a href="javascript:search('中原园林网')">中原园林网</a></li>
		<li><a href="javascript:search('中国进口燃气设备网')">中国进口燃气设备网</a></li>
		<li><a href="javascript:search('涌硕科技网')">涌硕科技网</a></li>
		<li><a href="javascript:search('中国眼镜网')">中国眼镜网</a></li>
		<li><a href="javascript:search('钢管商务网')">钢管商务网</a></li>
		<li><a href="javascript:search('优企录')">优企录</a></li>
		<li><a href="javascript:search('文登信息港')">文登信息港</a></li>
		<li><a href="javascript:search('中国迅商网')">中国迅商网</a></li>
		<li><a href="javascript:search('中国仪器搜索网')">中国仪器搜索网</a></li>
		<li><a href="javascript:search('95爱站网')">95爱站网</a></li>
		<li><a href="javascript:search('中华摩配网')">中华摩配网</a></li>
		<li><a href="javascript:search('看中网')">看中网</a></li>
		<li><a href="javascript:search('谷卖网')">谷卖网</a></li>
		<li><a href="javascript:search('中国B2B')">中国B2B</a></li>
		<li><a href="javascript:search('中华显示网')">中华显示网</a></li>
		<li><a href="javascript:search('青开网')">青开网</a></li>
		<li><a href="javascript:search('中国医疗器械招标网')">中国医疗器械招标网</a></li>
		<li><a href="javascript:search('中国免费信息网')">中国免费信息网</a></li>
		<li><a href="javascript:search('广西农业产品贸易网')">广西农业产品贸易网</a></li>
		<li><a href="javascript:search('中药贸易网')">中药贸易网</a></li>
		<li><a href="javascript:search('E8商务网')">E8商务网</a></li>
		<li><a href="javascript:search('易商网')">易商网</a></li>
		<li><a href="javascript:search('新丝路叮当市场网')">新丝路叮当市场网</a></li>
		<li><a href="javascript:search('中州花木网')">中州花木网</a></li>
		<li><a href="javascript:search('云南商贸网')">云南商贸网</a></li>
		<li><a href="javascript:search('商卖网')">商卖网</a></li>
		<li><a href="javascript:search('中国铜业网')">中国铜业网</a></li>
		<li><a href="javascript:search('创业社网')">创业社网</a></li>
		<li><a href="javascript:search('聚能网')">聚能网</a></li>
		<li><a href="javascript:search('国联商务网')">国联商务网</a></li>
		<li><a href="javascript:search('富达商务网')">富达商务网</a></li>
		<li><a href="javascript:search('91农资网')">91农资网</a></li>
		<li><a href="javascript:search('钣金行业网')">钣金行业网</a></li>
		<li><a href="javascript:search('中国国际家具网')">中国国际家具网</a></li>
		<li><a href="javascript:search('中国弯头网')">中国弯头网</a></li>
		<li><a href="javascript:search('今商网')">今商网</a></li>
		<li><a href="javascript:search('万通商联')">万通商联</a></li>
		<li><a href="javascript:search('日日发商机网')">日日发商机网</a></li>
		<li><a href="javascript:search('文化创意网')">文化创意网</a></li>
		<li><a href="javascript:search('中国固废网')">中国固废网</a></li>
		<li><a href="javascript:search('中国天然水晶网')">中国天然水晶网</a></li>
		<li><a href="javascript:search('齐发网')">齐发网</a></li>
		<li><a href="javascript:search('减速机信息网')">减速机信息网</a></li>
		<li><a href="javascript:search('三七智能网')">三七智能网</a></li>
		<li><a href="javascript:search('易信商务网')">易信商务网</a></li>
		<li><a href="javascript:search('114国际贸易网')">114国际贸易网</a></li>
		<li><a href="javascript:search('买购网')">买购网</a></li>
		<li><a href="javascript:search('伊春信息港')">伊春信息港</a></li>
		<li><a href="javascript:search('医流比价网')">医流比价网</a></li>
		<li><a href="javascript:search('小微企业网')">小微企业网</a></li>
		<li><a href="javascript:search('中国特种陶瓷网')">中国特种陶瓷网</a></li>
		<li><a href="javascript:search('江西太阳能网')">江西太阳能网</a></li>
		<li><a href="javascript:search('万发供求网')">万发供求网</a></li>
		<li><a href="javascript:search('宁波二手车')">宁波二手车</a></li>
		<li><a href="javascript:search('001工业网')">001工业网</a></li>
		<li><a href="javascript:search('中国油墨网')">中国油墨网</a></li>
		<li><a href="javascript:search('中国建筑卫生陶瓷网')">中国建筑卫生陶瓷网</a></li>
		<li><a href="javascript:search('糖酒食品招商网')">糖酒食品招商网</a></li>
		<li><a href="javascript:search('多甲虫B2B')">多甲虫B2B</a></li>
		<li><a href="javascript:search('55商务网')">55商务网</a></li>
		<li><a href="javascript:search('亿配网')">亿配网</a></li>
		<li><a href="javascript:search('珠穆朗玛峰')">珠穆朗玛峰</a></li>
		<li><a href="javascript:search('有机批发网')">有机批发网</a></li>
		<li><a href="javascript:search('铸造采购网')">铸造采购网</a></li>
		<li><a href="javascript:search('中国机器人应用网')">中国机器人应用网</a></li>
		<li><a href="javascript:search('中国安徽紧固件协会网')">中国安徽紧固件协会网</a></li>
		<li><a href="javascript:search('北京ZIYE114')">北京ZIYE114</a></li>
		<li><a href="javascript:search('商务领域')">商务领域</a></li>
		<li><a href="javascript:search('企库商务网')">企库商务网</a></li>
		<li><a href="javascript:search('秦越变频器网')">秦越变频器网</a></li>
		<li><a href="javascript:search('中国采购招标导航网')">中国采购招标导航网</a></li>
		<li><a href="javascript:search('中国万商网')">中国万商网</a></li>
		<li><a href="javascript:search('天狼网')">天狼网</a></li>
		<li><a href="javascript:search('企商网')">企商网</a></li>
		<li><a href="javascript:search('成都花木网')">成都花木网</a></li>
		<li><a href="javascript:search('中国箱包城')">中国箱包城</a></li>
		<li><a href="javascript:search('中国洁具网')">中国洁具网</a></li>
		<li><a href="javascript:search('中国冶金矿业网')">中国冶金矿业网</a></li>
		<li><a href="javascript:search('中国护栏网')">中国护栏网</a></li>
		<li><a href="javascript:search('怎当网')">怎当网</a></li>
		<li><a href="javascript:search('模具产业网')">模具产业网</a></li>
		<li><a href="javascript:search('蚂蚁发发网')">蚂蚁发发网</a></li>
		<li><a href="javascript:search('柘城百姓网')">柘城百姓网</a></li>
		<li><a href="javascript:search('行业信息网')">行业信息网</a></li>
		<li><a href="javascript:search('中国餐饮连锁')">中国餐饮连锁</a></li>
		<li><a href="javascript:search('中国麦网')">中国麦网</a></li>
		<li><a href="javascript:search('中国碳晶采暖网')">中国碳晶采暖网</a></li>
		<li><a href="javascript:search('中国行业信息网')">中国行业信息网</a></li>
		<li><a href="javascript:search('中联B2B商务网')">中联B2B商务网</a></li>
		<li><a href="javascript:search('多企网')">多企网</a></li>
		<li><a href="javascript:search('中国玩具城')">中国玩具城</a></li>
		<li><a href="javascript:search('名城分类信息网')">名城分类信息网</a></li>
		<li><a href="javascript:search('微创网')">微创网</a></li>
		<li><a href="javascript:search('第一枪')">第一枪</a></li>
		<li><a href="javascript:search('商机黄页网')">商机黄页网</a></li>
		<li><a href="javascript:search('玻璃产业网')">玻璃产业网</a></li>
		<li><a href="javascript:search('金盟商务站网')">金盟商务站网</a></li>
		<li><a href="javascript:search('趣逗商务网')">趣逗商务网</a></li>
		<li><a href="javascript:search('中国石材网')">中国石材网</a></li>
		<li><a href="javascript:search('联科绣花网')">联科绣花网</a></li>
		<li><a href="javascript:search('电动车配件网')">电动车配件网</a></li>
		<li><a href="javascript:search('麻辣批发网')">麻辣批发网</a></li>
		<li><a href="javascript:search('销得快')">销得快</a></li>
		<li><a href="javascript:search('消毒杀菌灭菌网')">消毒杀菌灭菌网</a></li>
	</ul>
	<div class="pages">
		<div class="pagination">
			<a href="platform12.php#putongweb">上一页</a>
			<a href="platform14.php#putongweb">下一页</a>
			<a href="platform1.php">第一页</a>
			<a href="platform6.php#putongweb">上5页</a>
			<a href="platform11.php#putongweb">11</a>
			<a href="platform12.php#putongweb">12</a>
			<span class="current">13</span>
			<a href="platform14.php#putongweb">14</a>
			<a href="platform15.php#putongweb">15</a>
			<a href="platform16.php#putongweb">下5页</a>
			<a href="platform23.php#putongweb"><span id="lastspan">最后一页</span></a>
		</div>
	</div>
</div>
<script>
	function search(val){
		window.open("https://www.baidu.com/s?wd="+val);
	}
</script>
</body>
</html>
