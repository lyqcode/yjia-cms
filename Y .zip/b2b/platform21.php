<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>网站大全</title>
<link rel="stylesheet" href="css/style.css" />
</head>



<body>
<div class=" IncludeBox grWidth">
	<?php include "platform.php";?>
	<ul  class="IncludeContainer clearfix">
		<li><a href="javascript:search('中国纺织机电网');">中国纺织机电网</a></li>
		<li><a href="javascript:search('中国数控机床网');">中国数控机床网</a></li>
		<li><a href="javascript:search('中国船舶设备网');">中国船舶设备网</a></li>
		<li><a href="javascript:search('中国矿产设备网');">中国矿产设备网</a></li>
		<li><a href="javascript:search('中国机械库');">中国机械库</a></li>
		<li><a href="javascript:search('中国工程机械网');">中国工程机械网</a></li>
		<li><a href="javascript:search('中国油缸网');">中国油缸网</a></li>
		<li><a href="javascript:search('中国热能设备网');">中国热能设备网</a></li>
		<li><a href="javascript:search('中国工业市场网');">中国工业市场网</a></li>
		<li><a href="javascript:search('中国洗涤网');">中国洗涤网</a></li>
		<li><a href="javascript:search('中国水处理设备信息网');">中国水处理设备信息网</a></li>
		<li><a href="javascript:search('全球锅炉网');">全球锅炉网</a></li>
		<li><a href="javascript:search('东博机床网');">东博机床网</a></li>
		<li><a href="javascript:search('香港贸易网');">香港贸易网</a></li>
		<li><a href="javascript:search('中国制冷配件网');">中国制冷配件网</a></li>
		<li><a href="javascript:search('中国减速机传动网');">中国减速机传动网</a></li>
		<li><a href="javascript:search('气体分离设备网');">气体分离设备网</a></li>
		<li><a href="javascript:search('中国焊切器材网');">中国焊切器材网</a></li>
		<li><a href="javascript:search('二分钟弹簧网');">二分钟弹簧网</a></li>
		<li><a href="javascript:search('第一商贸网');">第一商贸网</a></li>
		<li><a href="javascript:search('起重机械信息网');">起重机械信息网</a></li>
		<li><a href="javascript:search('对台经贸网');">对台经贸网</a></li>
		<li><a href="javascript:search('西南模具网');">西南模具网</a></li>
		<li><a href="javascript:search('侨乡贸易网');">侨乡贸易网</a></li>
		<li><a href="javascript:search('中国建筑机械门户网');">中国建筑机械门户网</a></li>
		<li><a href="javascript:search('中国维修信息网');">中国维修信息网</a></li>
		<li><a href="javascript:search('华强电子网');">华强电子网</a></li>
		<li><a href="javascript:search('中国工控网');">中国工控网</a></li>
		<li><a href="javascript:search('大功率LED网');">大功率LED网</a></li>
		<li><a href="javascript:search('中国软启动网');">中国软启动网</a></li>
		<li><a href="javascript:search('中国电工仪表网');">中国电工仪表网</a></li>
		<li><a href="javascript:search('中国电气自动化网');">中国电气自动化网</a></li>
		<li><a href="javascript:search('中国化工网');">中国化工网</a></li>
		<li><a href="javascript:search('中国日用五金网');">中国日用五金网</a></li>
		<li><a href="javascript:search('工业电脑网');">工业电脑网</a></li>
		<li><a href="javascript:search('华南塑胶五金网');">华南塑胶五金网</a></li>
		<li><a href="javascript:search('中国化工技术交易网');">中国化工技术交易网</a></li>
		<li><a href="javascript:search('中国胶水网');">中国胶水网</a></li>
		<li><a href="javascript:search('美国化工网');">美国化工网</a></li>
		<li><a href="javascript:search('中塑在线');">中塑在线</a></li>
		<li><a href="javascript:search('中国缓蚀剂网');">中国缓蚀剂网</a></li>
		<li><a href="javascript:search('浙江化工网');">浙江化工网</a></li>
		<li><a href="javascript:search('华东化工网');">华东化工网</a></li>
		<li><a href="javascript:search('中国PVC产品网');">中国PVC产品网</a></li>
		<li><a href="javascript:search('中国表面活性剂网');">中国表面活性剂网</a></li>
		<li><a href="javascript:search('中国医药化工网');">中国医药化工网</a></li>
		<li><a href="javascript:search('中化网');">中化网</a></li>
		<li><a href="javascript:search('国际化工展');">国际化工展</a></li>
		<li><a href="javascript:search('中华涂料网');">中华涂料网</a></li>
		<li><a href="javascript:search('中国涂装');">中国涂装</a></li>
		<li><a href="javascript:search('环球表面处理网');">环球表面处理网</a></li>
		<li><a href="javascript:search('中国油墨网');">中国油墨网</a></li>
		<li><a href="javascript:search('有机化学网');">有机化学网</a></li>
		<li><a href="javascript:search('中国化工商务网');">中国化工商务网</a></li>
		<li><a href="javascript:search('中国橡胶网');">中国橡胶网</a></li>
		<li><a href="javascript:search('中国化工电子商务网');">中国化工电子商务网</a></li>
		<li><a href="javascript:search('中国塑料制品网');">中国塑料制品网</a></li>
		<li><a href="javascript:search('中国注塑网');">中国注塑网</a></li>
		<li><a href="javascript:search('国际电气网');">国际电气网</a></li>
		<li><a href="javascript:search('中电网');">中电网</a></li>
		<li><a href="javascript:search('蓄电池在线');">蓄电池在线</a></li>
		<li><a href="javascript:search('中国IC网');">中国IC网</a></li>
		<li><a href="javascript:search('中国家居网');">中国家居网</a></li>
		<li><a href="javascript:search('中国工业电气网');">中国工业电气网</a></li>
		<li><a href="javascript:search('华强IC网');">华强IC网</a></li>
		<li><a href="javascript:search('天天家具网');">天天家具网</a></li>
		<li><a href="javascript:search('中国自动化网');">中国自动化网</a></li>
		<li><a href="javascript:search('爱佳家家居网');">爱佳家家居网</a></li>
		<li><a href="javascript:search('国际电子网');">国际电子网</a></li>
		<li><a href="javascript:search('华夏医药健康网');">华夏医药健康网</a></li>
		<li><a href="javascript:search('环球厨卫网');">环球厨卫网</a></li>
		<li><a href="javascript:search('中外家居网');">中外家居网</a></li>
		<li><a href="javascript:search('中国日用品网');">中国日用品网</a></li>
		<li><a href="javascript:search('医药招商在线');">医药招商在线</a></li>
		<li><a href="javascript:search('重庆装饰网');">重庆装饰网</a></li>
		<li><a href="javascript:search('中国电力仪器网');">中国电力仪器网</a></li>
		<li><a href="javascript:search('中华五金信息网');">中华五金信息网</a></li>
		<li><a href="javascript:search('中国室内装饰网');">中国室内装饰网</a></li>
		<li><a href="javascript:search('中国电气设备网');">中国电气设备网</a></li>
		<li><a href="javascript:search('中国伞交易网');">中国伞交易网</a></li>
		<li><a href="javascript:search('西部名家具网');">西部名家具网</a></li>
		<li><a href="javascript:search('中国节电设备网');">中国节电设备网</a></li>
		<li><a href="javascript:search('中国洁具网');">中国洁具网</a></li>
		<li><a href="javascript:search('药品商情网');">药品商情网</a></li>
		<li><a href="javascript:search('中国厨具网');">中国厨具网</a></li>
		<li><a href="javascript:search('中国节能灯网');">中国节能灯网</a></li>
		<li><a href="javascript:search('中国继电器交易网');">中国继电器交易网</a></li>
		<li><a href="javascript:search('中国座椅网');">中国座椅网</a></li>
		<li><a href="javascript:search('中国发酵工业网');">中国发酵工业网</a></li>
		<li><a href="javascript:search('中国传感器总网');">中国传感器总网</a></li>
		<li><a href="javascript:search('广西装修网');">广西装修网</a></li>
		<li><a href="javascript:search('电机电气工程网');">电机电气工程网</a></li>
		<li><a href="javascript:search('中国五金机电网');">中国五金机电网</a></li>
		<li><a href="javascript:search('中国医疗器械设备网');">中国医疗器械设备网</a></li>
		<li><a href="javascript:search('中国窗饰网');">中国窗饰网</a></li>
		<li><a href="javascript:search('仪表商务网');">仪表商务网</a></li>
		<li><a href="javascript:search('搜搜医药网');">搜搜医药网</a></li>
		<li><a href="javascript:search('万维家电网');">万维家电网</a></li>
		<li><a href="javascript:search('中国环保建材网');">中国环保建材网</a></li>
		<li><a href="javascript:search('中国家电网');">中国家电网</a></li>
		<li><a href="javascript:search('健康四通网');">健康四通网</a></li>
		<li><a href="javascript:search('西部建材网');">西部建材网</a></li>
		<li><a href="javascript:search('福建家电网');">福建家电网</a></li>
		<li><a href="javascript:search('大绿播药网');">大绿播药网</a></li>
		<li><a href="javascript:search('景药师医药网');">景药师医药网</a></li>
		<li><a href="javascript:search('世界建筑建材总网');">世界建筑建材总网</a></li>
		<li><a href="javascript:search('迪希玛医药招商网');">迪希玛医药招商网</a></li>
		<li><a href="javascript:search('党山卫浴城');">党山卫浴城</a></li>
		<li><a href="javascript:search('中国石材网');">中国石材网</a></li>
		<li><a href="javascript:search('广东家电网');">广东家电网</a></li>
		<li><a href="javascript:search('医药商机在线');">医药商机在线</a></li>
		<li><a href="javascript:search('南方建材网');">南方建材网</a></li>
		<li><a href="javascript:search('中国水泥网');">中国水泥网</a></li>
		<li><a href="javascript:search('中华电器网');">中华电器网</a></li>
		<li><a href="javascript:search('中国动物医药网');">中国动物医药网</a></li>
		<li><a href="javascript:search('绿色建材网');">绿色建材网</a></li>
		<li><a href="javascript:search('中国建筑网');">中国建筑网</a></li>
		<li><a href="javascript:search('中国建材信息总网');">中国建材信息总网</a></li>
		<li><a href="javascript:search('全球家用电器网');">全球家用电器网</a></li>
		<li><a href="javascript:search('中国建材网');">中国建材网</a></li>
	</ul>
	<div class="pages">
		<div class="pagination">
			<a href="platform20.php#putongweb">上一页</a>
			<a href="platform22.php#putongweb">下一页</a>
			<a href="platform1.php">第一页</a>
			<a href="platform16.php#putongweb">上5页</a>
			<span class="current">21</span>
			<a href="platform22.php#putongweb">22</a>
			<a href="platform23.php#putongweb">23</a>
			<a href="platform23.php#putongweb"><span id="lastspan">最后一页</span></a>
		</div>
	</div>
</div>
<script>
	function search(val){
		window.open("https://www.baidu.com/s?wd="+val);
	}
</script>
</body>
</html>
