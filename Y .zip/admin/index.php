<?php

header('Location: ../index.php?g=admin&m=login');
