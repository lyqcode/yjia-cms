<?php
return array (
    'field' => 'status',
    'name' => '状态',
    'tips' => '',
    'required' => '0',
    'minlength' => '0',
    'maxlength' => '0',
    'pattern' => '0',
    'errormsg' => '',
    'class' => '',
    'type' => 'radio',
    'setup' => '{"options":"\\u5df2\\u5ba1\\u6838|1\\n\\u672a\\u5ba1\\u6838|0","fieldtype":"tinyint","numbertype":"1","labelwidth":"75","default":"1"}',
    'isbase' => '0',
    'unpostgroup' => '3,4',
    'listorder' => '0',
    'status' => '1',
    'issystem' => '1',
)
?>