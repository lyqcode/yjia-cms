<?php

return array (
    'field' => 'readgroup',
    'name' => '访问权限',
    'tips' => '',
    'required' => '0',
    'minlength' => '0',
    'maxlength' => '0',
    'pattern' => '0',
    'errormsg' => '',
    'class' => '',
    'type' => 'groupid',
    'setup' => '{"inputtype":"checkbox","fieldtype":"varchar","numbertype":"1","labelwidth":"85","default":""}',
    'isbase' => '1',
    'unpostgroup' => '3,4',
    'listorder' => '0',
    'status' => '1',
    'issystem' => '1',
)
?>