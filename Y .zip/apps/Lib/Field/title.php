<?php

return array (
    'field' => 'title',
    'name' => '标题/问题',
    'tips' => '',
    'required' => '1',
    'minlength' => '0',
    'maxlength' => '0',
    'pattern' => '0',
    'errormsg' => '标题必须为1-80个字符',
    'class' => 'w-400',
    'type' => 'title',
    'setup' => '{"thumb":"1","style":"1","size":"55"}',
    'isbase' => '1',
    'unpostgroup' => '',
    'listorder' => '0',
    'status' => '1',
    'issystem' => '1',
)
?>