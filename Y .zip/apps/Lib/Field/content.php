<?php

return array (
    'field' => 'content',
    'name' => '内容/回答',
    'tips' => '',
    'required' => '0',
    'minlength' => '0',
    'maxlength' => '0',
    'pattern' => '0',
    'errormsg' => '',
    'class' => '',
    'type' => 'editor',
    'setup' => '{"toolbar":"full","default":"","height":"","show_add_description":"1","show_auto_thumb":"1","showpage":"1","enablekeylink":"0","replacenum":"","enablesaveimage":"0","flashupload":"1","alowuploadexts":"","alowuploadlimit":""}',
    'isbase' => '1',
    'unpostgroup' => '',
    'listorder' => '0',
    'status' => '1',
    'issystem' => '1',
)
?>