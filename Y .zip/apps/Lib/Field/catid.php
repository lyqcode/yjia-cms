<?php	
return array (
    'field' => 'catid',
    'name' => '栏目',
    'tips' => '',
    'required' => '1',
    'minlength' => '1',
    'maxlength' => '6',
    'pattern' => 'digits',
    'errormsg' => '必须选择一个栏目',
    'class' => 'w-400',
    'type' => 'catid',
    'setup' => '',
    'isbase' => '1',
    'unpostgroup' => '',
    'listorder' => '0',
    'status' => '1',
    'issystem' => '1',
)

?>