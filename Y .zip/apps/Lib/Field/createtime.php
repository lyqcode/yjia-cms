<?php

return array (
    'field' => 'createtime',
    'name' => '发布时间',
    'tips' => '',
    'required' => '1',
    'minlength' => '0',
    'maxlength' => '0',
    'pattern' => '0',
    'errormsg' => '',
    'class' => 'w-200',
    'type' => 'datetime',
    'setup' => '',
    'isbase' => '0',
    'unpostgroup' => '',
    'listorder' => '0',
    'status' => '1',
    'issystem' => '1',
)
?>