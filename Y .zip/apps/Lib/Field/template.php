<?php
return array (
    'field' => 'template',
    'name' => '模板',
    'tips' => '',
    'required' => '0',
    'minlength' => '0',
    'maxlength' => '0',
    'pattern' => '0',
    'errormsg' => '',
    'class' => '',
    'type' => 'template',
    'setup' => '',
    'isbase' => '0',
    'unpostgroup' => '3,4',
    'listorder' => '0',
    'status' => '0',
    'issystem' => '1',
)
?>
