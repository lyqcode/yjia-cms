<?php

return  array (
    'field' => 'description',
    'name' => 'SEO简介',
    'tips' => '',
    'required' => '0',
    'minlength' => '0',
    'maxlength' => '0',
    'pattern' => '0',
    'errormsg' => '',
    'class' => 'w-500',
    'type' => 'textarea',
    'setup' => '{"fieldtype":"mediumtext","rows":"4","cols":"55","default":""}',
    'isbase' => '1',
    'unpostgroup' => '',
    'listorder' => '0',
    'status' => '1',
    'issystem' => '1',
)
?>