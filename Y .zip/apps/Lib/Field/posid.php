<?php

return array (
    'field' => 'posid',
    'name' => '推荐位',
    'tips' => '',
    'required' => '0',
    'minlength' => '0',
    'maxlength' => '0',
    'pattern' => '0',
    'errormsg' => '',
    'class' => '',
    'type' => 'posid',
    'setup' => '',
    'isbase' => '1',
    'unpostgroup' => '3,4',
    'listorder' => '0',
    'status' => '1',
    'issystem' => '1',
)
?>