<?php

return array (
    'field' => 'keywords',
    'name' => '关键词',
    'tips' => '',
    'required' => '0',
    'minlength' => '0',
    'maxlength' => '0',
    'pattern' => '0',
    'errormsg' => '',
    'class' => 'w-400',
    'type' => 'text',
    'setup' => '{"size":"55","default":"","ispassword":"0","fieldtype":"varchar"}',
    'isbase' => '1',
    'unpostgroup' => '',
    'listorder' => '0',
    'status' => '1',
    'issystem' => '1',
)
?>