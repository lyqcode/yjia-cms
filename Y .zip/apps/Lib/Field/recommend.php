<?php

return array (
    'field' => 'recommend',
    'name' => '允许评论',
    'tips' => '',
    'required' => '0',
    'minlength' => '0',
    'maxlength' => '1',
    'pattern' => '0',
    'errormsg' => '',
    'class' => '',
    'type' => 'radio',
    'setup' => '{"options":"\\u5141\\u8bb8\\u8bc4\\u8bba|1\\n\\u4e0d\\u5141\\u8bb8\\u8bc4\\u8bba|0","fieldtype":"tinyint","numbertype":"1","labelwidth":"","default":"1"}',
    'isbase' => '1',
    'unpostgroup' => '3,4',
    'listorder' => '0',
    'status' => '0',
    'issystem' => '0',
)
?>