<?php
return array (
    'field' => 'hits',
    'name' => '点击次数',
    'tips' => '',
    'required' => '0',
    'minlength' => '0',
    'maxlength' => '8',
    'pattern' => '0',
    'errormsg' => '',
    'class' => '',
    'type' => 'number',
    'setup' => '{"size":"5","numbertype":"1","decimaldigits":"0","default":""}',
    'isbase' => '1',
    'unpostgroup' => '',
    'listorder' => '0',
    'status' => '0',
    'issystem' => '0',
)
?>