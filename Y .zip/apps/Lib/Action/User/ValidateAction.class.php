<?php

class ValidateAction extends PublicAction
{

    function updatePassword()
    {

        $this->display();
    }

    function updateMail()
    {
        $this->display();
    }
}