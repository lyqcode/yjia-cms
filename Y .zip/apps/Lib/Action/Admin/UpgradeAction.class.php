<?php

class UpgradeAction extends PublicAction
{

    //升级首页
    public function index() {

        $this->display();
    }

}