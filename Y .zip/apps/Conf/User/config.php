<?php

$config	= array(
    // 是否开启子域名部署
    'APP_SUB_DOMAIN_DEPLOY' => false,

);
return $config;
?>
