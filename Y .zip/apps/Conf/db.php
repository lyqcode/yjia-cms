<?php

return array(
	'DB_TYPE'=>'mysqli',
	'DB_HOST'=>'127.0.0.1',
	'DB_NAME'=>'e35yuzihao',
	'DB_USER'=>'e35yuzihao',
	'DB_PWD'=>'3P5icqJ0KQmlnes',
	'DB_PORT'=>'3306',
	'DB_PREFIX'=>'yzh_',
);

?>