<?php

/**
 * version配置
 */
return array(
    "CMS_APPNAME" => "E+", //产品名称
    "CMS_BUILD" => 20171109,  //产品流水号
    "CMS_VERSION" => "2.0.17.11", //产品版本号
);